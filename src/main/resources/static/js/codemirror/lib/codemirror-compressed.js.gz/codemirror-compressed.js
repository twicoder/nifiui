!function(b){if("object"==typeof exports&&"object"==typeof module){module.exports=b()
}else{if("function"==typeof define&&define.amd){return define([],b)
}this.CodeMirror=b()
}}(function(){function fL(e,d){if(!(this instanceof fL)){return new fL(e,d)
}this.options=d=d?d7(d):{},d7(em,d,!1),gL(d);
var l=d.value;
"string"==typeof l&&(l=new fp(l,d.mode)),this.doc=l;
var k=this.display=new fK(e,l);
k.wrapper.CodeMirror=this,gS(this),gW(this),d.lineWrapping&&(this.display.wrapper.className+=" CodeMirror-wrap"),d.autofocus&&!fT&&av(this),this.state={keyMaps:[],overlays:[],modeGen:0,overwrite:!1,focused:!1,suppressEdits:!1,pasteIncoming:!1,cutIncoming:!1,draggingText:!1,highlight:new hJ,keySeq:null},f9&&11>f7&&setTimeout(dU(c0,this,!0),20),f8(this),ek(),bX(this),this.curOp.forceUpdate=!0,er(this,l),d.autofocus&&!fT||gK()==k.input?setTimeout(dU(hy,this),20):g5(this);
for(var j in d3){d3.hasOwnProperty(j)&&d3[j](this,d[j],dD)
}gE(this);
for(var i=0;
i<cz.length;
++i){cz[i](this)
}bp(this)
}function fK(e,d){var h=this,f=h.input=b6("textarea",null,null,"position: absolute; padding: 0; width: 1px; height: 1em; outline: none");
f5?f.style.width="1000px":f.setAttribute("wrap","off"),fU&&(f.style.border="1px solid black"),f.setAttribute("autocorrect","off"),f.setAttribute("autocapitalize","off"),f.setAttribute("spellcheck","false"),h.inputDiv=b6("div",[f],null,"overflow: hidden; position: relative; width: 3px; height: 0px;"),h.scrollbarH=b6("div",[b6("div",null,null,"height: 100%; min-height: 1px")],"CodeMirror-hscrollbar"),h.scrollbarV=b6("div",[b6("div",null,null,"min-width: 1px")],"CodeMirror-vscrollbar"),h.scrollbarFiller=b6("div",null,"CodeMirror-scrollbar-filler"),h.gutterFiller=b6("div",null,"CodeMirror-gutter-filler"),h.lineDiv=b6("div",null,"CodeMirror-code"),h.selectionDiv=b6("div",null,null,"position: relative; z-index: 1"),h.cursorDiv=b6("div",null,"CodeMirror-cursors"),h.measure=b6("div",null,"CodeMirror-measure"),h.lineMeasure=b6("div",null,"CodeMirror-measure"),h.lineSpace=b6("div",[h.measure,h.lineMeasure,h.selectionDiv,h.cursorDiv,h.lineDiv],null,"position: relative; outline: none"),h.mover=b6("div",[b6("div",[h.lineSpace],"CodeMirror-lines")],null,"position: relative"),h.sizer=b6("div",[h.mover],"CodeMirror-sizer"),h.heightForcer=b6("div",null,null,"position: absolute; height: "+bz+"px; width: 1px;"),h.gutters=b6("div",null,"CodeMirror-gutters"),h.lineGutter=null,h.scroller=b6("div",[h.sizer,h.heightForcer,h.gutters],"CodeMirror-scroll"),h.scroller.setAttribute("tabIndex","-1"),h.wrapper=b6("div",[h.inputDiv,h.scrollbarH,h.scrollbarV,h.scrollbarFiller,h.gutterFiller,h.scroller],"CodeMirror"),f9&&8>f7&&(h.gutters.style.zIndex=-1,h.scroller.style.paddingRight=0),fU&&(f.style.width="0px"),f5||(h.scroller.draggable=!0),fX&&(h.inputDiv.style.height="1px",h.inputDiv.style.position="absolute"),f9&&8>f7&&(h.scrollbarH.style.minHeight=h.scrollbarV.style.minWidth="18px"),e&&(e.appendChild?e.appendChild(h.wrapper):e(h.wrapper)),h.viewFrom=h.viewTo=d.first,h.view=[],h.externalMeasured=null,h.viewOffset=0,h.lastWrapHeight=h.lastWrapWidth=0,h.updateLineNumbers=null,h.lineNumWidth=h.lineNumInnerWidth=h.lineNumChars=null,h.prevInput="",h.alignWidgets=!1,h.pollingFast=!1,h.poll=new hJ,h.cachedCharWidth=h.cachedTextHeight=h.cachedPaddingH=null,h.inaccurateSelection=!1,h.maxLine=null,h.maxLineLength=0,h.maxLineChanged=!1,h.wheelDX=h.wheelDY=h.wheelStartX=h.wheelStartY=null,h.shift=!1,h.selForContextMenu=null
}function fJ(b){b.doc.mode=fL.getMode(b.options,b.doc.modeOption),fH(b)
}function fH(b){b.doc.iter(function(c){c.stateAfter&&(c.stateAfter=null),c.styles&&(c.styles=null)
}),b.doc.frontier=b.doc.first,dz(b,100),b.state.modeGen++,b.curOp&&eu(b)
}function g1(b){b.options.lineWrapping?(e9(b.display.wrapper,"CodeMirror-wrap"),b.display.sizer.style.minWidth=""):(fu(b.display.wrapper,"CodeMirror-wrap"),gM(b)),gY(b),eu(b),dS(b),setTimeout(function(){gH(b)
},100)
}function g0(f){var e=aJ(f.display),h=f.options.lineWrapping,g=h&&Math.max(5,f.display.scroller.clientWidth/ao(f.display)-3);
return function(c){if(fi(f.doc,c)){return 0
}var b=0;
if(c.widgets){for(var a=0;
a<c.widgets.length;
a++){c.widgets[a].height&&(b+=c.widgets[a].height)
}}return h?b+(Math.ceil(c.text.length/g)||1)*e:b+e
}
}function gY(e){var d=e.doc,f=g0(e);
d.iter(function(g){var c=f(g);
c!=g.height&&dv(g,c)
})
}function gW(b){b.display.wrapper.className=b.display.wrapper.className.replace(/\s*cm-s-\S+/g,"")+b.options.theme.replace(/(^|\s)\s*/g," cm-s-"),dS(b)
}function gU(b){gS(b),eu(b),setTimeout(function(){gF(b)
},20)
}function gS(h){var g=h.display.gutters,l=h.options.gutters;
cW(g);
for(var k=0;
k<l.length;
++k){var j=l[k],i=g.appendChild(b6("div",null,"CodeMirror-gutter "+j));
"CodeMirror-linenumbers"==j&&(h.display.lineGutter=i,i.style.width=(h.display.lineNumWidth||1)+"px")
}g.style.display=k?"":"none",gQ(h)
}function gQ(d){var c=d.display.gutters.offsetWidth;
d.display.sizer.style.marginLeft=c+"px",d.display.scrollbarH.style.left=d.options.fixedGutter?c+"px":0
}function gO(g){if(0==g.height){return 0
}for(var j,f=g.text.length,i=g;
j=bO(i);
){var h=j.find(0,!0);
i=h.from.line,f+=h.from.ch-h.to.ch
}for(i=g;
j=cY(i);
){var h=j.find(0,!0);
f-=i.text.length-h.from.ch,i=h.to.line,f+=i.text.length-h.to.ch
}return f
}function gM(e){var d=e.display,f=e.doc;
d.maxLine=d8(f,f.first),d.maxLineLength=gO(d.maxLine),d.maxLineChanged=!0,f.iter(function(b){var g=gO(b);
g>d.maxLineLength&&(d.maxLineLength=g,d.maxLine=b)
})
}function gL(d){var c=eQ(d.gutters,"CodeMirror-linenumbers");
-1==c&&d.lineNumbers?d.gutters=d.gutters.concat(["CodeMirror-linenumbers"]):c>-1&&!d.lineNumbers&&(d.gutters=d.gutters.slice(0),d.gutters.splice(c,1))
}function gJ(b){return b.display.scroller.clientHeight-b.display.wrapper.clientHeight<bz-3
}function gI(d){var c=d.display.scroller;
return{clientHeight:c.clientHeight,barHeight:d.display.scrollbarV.clientHeight,scrollWidth:c.scrollWidth,clientWidth:c.clientWidth,hScrollbarTakesSpace:gJ(d),barWidth:d.display.scrollbarH.clientWidth,docHeight:Math.round(d.doc.height+ci(d.display))}
}function gH(r,q){q||(q=gI(r));
var p=r.display,o=dm(p.measure),n=q.docHeight+bz,m=q.scrollWidth>q.clientWidth;
m&&q.scrollWidth<=q.clientWidth+1&&o>0&&!q.hScrollbarTakesSpace&&(m=!1);
var l=n>q.clientHeight;
if(l?(p.scrollbarV.style.display="block",p.scrollbarV.style.bottom=m?o+"px":"0",p.scrollbarV.firstChild.style.height=Math.max(0,n-q.clientHeight+(q.barHeight||p.scrollbarV.clientHeight))+"px"):(p.scrollbarV.style.display="",p.scrollbarV.firstChild.style.height="0"),m?(p.scrollbarH.style.display="block",p.scrollbarH.style.right=l?o+"px":"0",p.scrollbarH.firstChild.style.width=q.scrollWidth-q.clientWidth+(q.barWidth||p.scrollbarH.clientWidth)+"px"):(p.scrollbarH.style.display="",p.scrollbarH.firstChild.style.width="0"),m&&l?(p.scrollbarFiller.style.display="block",p.scrollbarFiller.style.height=p.scrollbarFiller.style.width=o+"px"):p.scrollbarFiller.style.display="",m&&r.options.coverGutterNextToScrollbar&&r.options.fixedGutter?(p.gutterFiller.style.display="block",p.gutterFiller.style.height=o+"px",p.gutterFiller.style.width=p.gutters.offsetWidth+"px"):p.gutterFiller.style.display="",!r.state.checkedOverlayScrollbar&&q.clientHeight>0){if(0===o){var k=fS&&!fW?"12px":"18px";
p.scrollbarV.style.minWidth=p.scrollbarH.style.minHeight=k;
var j=function(a){cx(a)!=p.scrollbarV&&cx(a)!=p.scrollbarH&&fG(r,eN)(a)
};
b0(p.scrollbarV,"mousedown",j),b0(p.scrollbarH,"mousedown",j)
}r.state.checkedOverlayScrollbar=!0
}}function gG(r,q,p){var o=p&&null!=p.top?Math.max(0,p.top):r.scroller.scrollTop;
o=Math.floor(o-cv(r));
var n=p&&null!=p.bottom?p.bottom:o+r.wrapper.clientHeight,m=cR(q,o),l=cR(q,n);
if(p&&p.ensure){var k=p.ensure.from.line,j=p.ensure.to.line;
if(m>k){return{from:k,to:cR(q,cE(d8(q,k))+r.wrapper.clientHeight)}
}if(Math.min(j,q.lastLine())>=l){return{from:cR(q,cE(d8(q,j))-r.wrapper.clientHeight),to:j}
}}return{from:m,to:Math.max(l,m+1)}
}function gF(r){var q=r.display,p=q.view;
if(q.alignWidgets||q.gutters.firstChild&&r.options.fixedGutter){for(var o=gC(q)-q.scroller.scrollLeft+r.doc.scrollLeft,n=q.gutters.offsetWidth,m=o+"px",l=0;
l<p.length;
l++){if(!p[l].hidden){r.options.fixedGutter&&p[l].gutter&&(p[l].gutter.style.left=m);
var k=p[l].alignable;
if(k){for(var j=0;
j<k.length;
j++){k[j].style.left=m
}}}}r.options.fixedGutter&&(q.gutters.style.left=o+n+"px")
}}function gE(i){if(!i.options.lineNumbers){return !1
}var h=i.doc,n=gD(i.options,h.first+h.size-1),m=i.display;
if(n.length!=m.lineNumChars){var l=m.measure.appendChild(b6("div",[b6("div",n)],"CodeMirror-linenumber CodeMirror-gutter-elt")),k=l.firstChild.offsetWidth,j=l.offsetWidth-k;
return m.lineGutter.style.width="",m.lineNumInnerWidth=Math.max(k,m.lineGutter.offsetWidth-j),m.lineNumWidth=m.lineNumInnerWidth+j,m.lineNumChars=m.lineNumInnerWidth?n.length:-1,m.lineGutter.style.width=m.lineNumWidth+"px",gQ(i),!0
}return !1
}function gD(d,c){return String(d.lineNumberFormatter(c+d.firstLineNumber))
}function gC(b){return b.scroller.getBoundingClientRect().left-b.sizer.getBoundingClientRect().left
}function gB(f,e,h){var g=f.display;
this.viewport=e,this.visible=gG(g,f.doc,e),this.editorIsHidden=!g.wrapper.offsetWidth,this.wrapperHeight=g.wrapper.clientHeight,this.wrapperWidth=g.wrapper.clientWidth,this.oldViewFrom=g.viewFrom,this.oldViewTo=g.viewTo,this.oldScrollerWidth=g.scroller.clientWidth,this.force=h,this.dims=ht(f)
}function gA(t,s){var r=t.display,q=t.doc;
if(s.editorIsHidden){return dY(t),!1
}if(!s.force&&s.visible.from>=r.viewFrom&&s.visible.to<=r.viewTo&&(null==r.updateLineNumbers||r.updateLineNumbers>=r.viewTo)&&0==cU(t)){return !1
}gE(t)&&(dY(t),s.dims=ht(t));
var p=q.first+q.size,o=Math.max(s.visible.from-t.options.viewportMargin,q.first),n=Math.min(p,s.visible.to+t.options.viewportMargin);
r.viewFrom<o&&o-r.viewFrom<20&&(o=Math.max(q.first,r.viewFrom)),r.viewTo>n&&r.viewTo-n<20&&(n=Math.min(p,r.viewTo)),fM&&(o=f4(t.doc,o),n=fw(t.doc,n));
var m=o!=r.viewFrom||n!=r.viewTo||r.lastWrapHeight!=s.wrapperHeight||r.lastWrapWidth!=s.wrapperWidth;
dk(t,o,n),r.viewOffset=cE(d8(t.doc,r.viewFrom)),t.display.mover.style.top=r.viewOffset+"px";
var l=cU(t);
if(!m&&0==l&&!s.force&&(null==r.updateLineNumbers||r.updateLineNumbers>=r.viewTo)){return !1
}var k=gK();
return l>4&&(r.lineDiv.style.display="none"),go(t,r.updateLineNumbers,s.dims),l>4&&(r.lineDiv.style.display=""),k&&gK()!=k&&k.offsetHeight&&k.focus(),cW(r.cursorDiv),cW(r.selectionDiv),m&&(r.lastWrapHeight=s.wrapperHeight,r.lastWrapWidth=s.wrapperWidth,dz(t,400)),r.updateLineNumbers=null,!0
}function gz(h,g){for(var l=g.force,k=g.viewport,j=!0;
;
j=!1){if(j&&h.options.lineWrapping&&g.oldScrollerWidth!=h.display.scroller.clientWidth){l=!0
}else{if(l=!1,k&&null!=k.top&&(k={top:Math.min(h.doc.height+ci(h.display)-bz-h.display.scroller.clientHeight,k.top)}),g.visible=gG(h.display,h.doc,k),g.visible.from>=h.display.viewFrom&&g.visible.to<=h.display.viewTo){break
}}if(!gA(h,g)){break
}gv(h);
var i=gI(h);
ev(h),gx(h,i),gH(h,i)
}aT(h,"update",h),(h.display.viewFrom!=g.oldViewFrom||h.display.viewTo!=g.oldViewTo)&&aT(h,"viewportChange",h,h.display.viewFrom,h.display.viewTo)
}function gy(f,e){var h=new gB(f,e);
if(gA(f,h)){gv(f),gz(f,h);
var g=gI(f);
ev(f),gx(f,g),gH(f,g)
}}function gx(d,c){d.display.sizer.style.minHeight=d.display.heightForcer.style.top=c.docHeight+"px",d.display.gutters.style.height=Math.max(c.docHeight,c.clientHeight-bz)+"px"
}function gw(d,c){d.display.sizer.offsetWidth+d.display.gutters.offsetWidth<d.display.scroller.clientWidth-1&&(d.display.sizer.style.minHeight=d.display.heightForcer.style.top="0px",d.display.gutters.style.height=c.docHeight+"px")
}function gv(t){for(var s=t.display,r=s.lineDiv.offsetTop,q=0;
q<s.view.length;
q++){var o,p=s.view[q];
if(!p.hidden){if(f9&&8>f7){var n=p.node.offsetTop+p.node.offsetHeight;
o=n-r,r=n
}else{var m=p.node.getBoundingClientRect();
o=m.bottom-m.top
}var e=p.line.height-o;
if(2>o&&(o=aJ(s)),(e>0.001||-0.001>e)&&(dv(p.line,o),gu(p.line),p.rest)){for(var d=0;
d<p.rest.length;
d++){gu(p.rest[d])
}}}}}function gu(d){if(d.widgets){for(var c=0;
c<d.widgets.length;
++c){d.widgets[c].height=d.widgets[c].node.offsetHeight
}}}function ht(i){for(var h=i.display,n={},m={},l=h.gutters.clientLeft,k=h.gutters.firstChild,j=0;
k;
k=k.nextSibling,++j){n[i.options.gutters[j]]=k.offsetLeft+k.clientLeft+l,m[i.options.gutters[j]]=k.clientWidth
}return{fixedPos:gC(h),gutterTotalWidth:h.gutters.offsetWidth,gutterLeft:n,gutterWidth:m,wrapperWidth:h.wrapper.clientWidth}
}function go(B,A,z){function u(a){var d=a.nextSibling;
return f5&&fS&&B.display.currentWheelTarget==a?a.style.display="none":a.parentNode.removeChild(a),d
}for(var y=B.display,x=B.options.lineNumbers,w=y.lineDiv,v=w.firstChild,t=y.view,s=y.viewFrom,r=0;
r<t.length;
r++){var q=t[r];
if(q.hidden){}else{if(q.node){for(;
v!=q.node;
){v=u(v)
}var f=x&&null!=A&&s>=A&&q.lineNumber;
q.changes&&(eQ(q.changes,"gutter")>-1&&(f=!1),hs(B,q,s,z)),f&&(cW(q.lineNumber),q.lineNumber.appendChild(document.createTextNode(gD(B.options,s)))),v=q.node.nextSibling
}else{var p=ep(B,q,s,z);
w.insertBefore(p,v)
}}s+=q.size
}for(;
v;
){v=u(v)
}}function hs(h,g,l,k){for(var j=0;
j<g.changes.length;
j++){var i=g.changes[j];
"text"==i?fm(h,g):"gutter"==i?eP(h,g,l,k):"class"==i?e2(g):"widget"==i&&eC(g,k)
}g.changes=null
}function gX(b){return b.node==b.text&&(b.node=b6("div",null,null,"position: relative"),b.text.parentNode&&b.text.parentNode.replaceChild(b.node,b.text),b.node.appendChild(b.text),f9&&8>f7&&(b.node.style.zIndex=2)),b.node
}function gj(e){var d=e.bgClass?e.bgClass+" "+(e.line.bgClass||""):e.line.bgClass;
if(d&&(d+=" CodeMirror-linebackground"),e.background){d?e.background.className=d:(e.background.parentNode.removeChild(e.background),e.background=null)
}else{if(d){var f=gX(e);
e.background=f.insertBefore(b6("div",null,d),f.firstChild)
}}}function fA(e,d){var f=e.display.externalMeasured;
return f&&f.line==d.line?(e.display.externalMeasured=null,d.measure=f.measure,f.built):ha(e,d)
}function fm(f,e){var h=e.text.className,g=fA(f,e);
e.text==e.node&&(e.node=g.pre),e.text.parentNode.replaceChild(g.pre,e.text),e.text=g.pre,g.bgClass!=e.bgClass||g.textClass!=e.textClass?(e.bgClass=g.bgClass,e.textClass=g.textClass,e2(e)):h&&(e.text.className=h)
}function e2(d){gj(d),d.line.wrapClass?gX(d).className=d.line.wrapClass:d.node!=d.text&&(d.node.className="");
var c=d.textClass?d.textClass+" "+(d.line.textClass||""):d.line.textClass;
d.text.className=c||""
}function eP(t,s,r,q){s.gutter&&(s.node.removeChild(s.gutter),s.gutter=null);
var p=s.line.gutterMarkers;
if(t.options.lineNumbers||p){var o=gX(s),n=s.gutter=o.insertBefore(b6("div",null,"CodeMirror-gutter-wrapper","left: "+(t.options.fixedGutter?q.fixedPos:-q.gutterTotalWidth)+"px; width: "+q.gutterTotalWidth+"px"),s.text);
if(s.line.gutterClass&&(n.className+=" "+s.line.gutterClass),!t.options.lineNumbers||p&&p["CodeMirror-linenumbers"]||(s.lineNumber=n.appendChild(b6("div",gD(t.options,r),"CodeMirror-linenumber CodeMirror-gutter-elt","left: "+q.gutterLeft["CodeMirror-linenumbers"]+"px; width: "+t.display.lineNumInnerWidth+"px"))),p){for(var m=0;
m<t.options.gutters.length;
++m){var l=t.options.gutters[m],k=p.hasOwnProperty(l)&&p[l];
k&&n.appendChild(b6("div",[k],"CodeMirror-gutter-elt","left: "+q.gutterLeft[l]+"px; width: "+q.gutterWidth[l]+"px"))
}}}}function eC(f,e){f.alignable&&(f.alignable=null);
for(var g,h=f.node.firstChild;
h;
h=g){var g=h.nextSibling;
"CodeMirror-linewidget"==h.className&&f.node.removeChild(h)
}d6(f,e)
}function ep(g,f,j,i){var h=fA(g,f);
return f.text=f.node=h.pre,h.bgClass&&(f.bgClass=h.bgClass),h.textClass&&(f.textClass=h.textClass),e2(f),eP(g,f,j,i),d6(f,i),f.node
}function d6(e,d){if(dT(e.line,e,d,!0),e.rest){for(var f=0;
f<e.rest.length;
f++){dT(e.rest[f],e,d,!1)
}}}function dT(r,q,p,o){if(r.widgets){for(var n=gX(q),m=0,l=r.widgets;
m<l.length;
++m){var k=l[m],j=b6("div",[k.node],"CodeMirror-linewidget");
k.handleMouseEvents||(j.ignoreEvents=!0),dG(k,j,q,p),o&&k.above?n.insertBefore(j,q.gutter||q.text):n.appendChild(j),aT(k,"redraw")
}}}function dG(g,f,j,i){if(g.noHScroll){(j.alignable||(j.alignable=[])).push(f);
var h=i.wrapperWidth;
f.style.left=i.fixedPos+"px",g.coverGutter||(h-=i.gutterTotalWidth,f.style.paddingLeft=i.gutterTotalWidth+"px"),f.style.width=h+"px"
}g.coverGutter&&(f.style.zIndex=5,f.style.position="relative",g.noHScroll||(f.style.marginLeft=-i.gutterTotalWidth+"px"))
}function cP(b){return dt(b.line,b.ch)
}function cC(d,c){return c8(d,c)<0?c:d
}function cp(d,c){return c8(d,c)<0?d:c
}function b5(d,c){this.ranges=d,this.primIndex=c
}function bL(d,c){this.anchor=d,this.head=c
}function bx(r,q){var p=r[q];
r.sort(function(d,c){return c8(d.from(),c.from())
}),q=eQ(r,p);
for(var o=1;
o<r.length;
o++){var n=r[o],m=r[o-1];
if(c8(m.to(),n.from())>=0){var l=cp(m.from(),n.from()),k=cC(m.to(),n.to()),j=m.empty()?n.from()==n.head:m.from()==m.head;
q>=o&&--q,r.splice(--o,2,new bL(j?k:l,j?l:k))
}}return new b5(r,q)
}function bj(d,c){return new b5([new bL(d,c||d)],0)
}function aY(d,c){return Math.max(d.first,Math.min(c,d.first+d.size-1))
}function aK(e,d){if(d.line<e.first){return dt(e.first,0)
}var f=e.first+e.size-1;
return d.line>f?dt(f,d8(e,f).text.length):ap(d,d8(e,d.line).text.length)
}function ap(e,d){var f=e.ch;
return null==f||f>d?dt(e.line,d):0>f?dt(e.line,0):e
}function hH(d,c){return c>=d.first&&c<d.first+d.size
}function hl(f,e){for(var h=[],g=0;
g<e.length;
g++){h[g]=aK(f,e[g])
}return h
}function bY(h,g,l,k){if(h.cm&&h.cm.display.shift||h.extend){var j=g.anchor;
if(k){var i=c8(l,j)<0;
i!=c8(k,j)<0?(j=l,l=k):i!=c8(l,k)<0&&(l=k)
}return new bL(j,l)
}return new bL(k||l,l)
}function bE(f,e,h,g){hA(f,new b5([bY(f,f.sel.primary(),e,h)],0),g)
}function bq(h,g,l){for(var k=[],j=0;
j<h.sel.ranges.length;
j++){k[j]=bY(h,h.sel.ranges[j],g[j],null)
}var i=bx(k,h.sel.primIndex);
hA(h,i,l)
}function a5(g,f,j,i){var h=g.sel.ranges.slice(0);
h[f]=j,hA(g,bx(h,g.sel.primIndex),i)
}function aR(f,e,h,g){hA(f,bj(e,h),g)
}function aD(e,d){var f={ranges:d.ranges,update:function(a){this.ranges=[];
for(var g=0;
g<a.length;
g++){this.ranges[g]=new bL(aK(e,a[g].anchor),aK(e,a[g].head))
}}};
return bs(e,"beforeSelectionChange",e,f),e.cm&&bs(e.cm,"beforeSelectionChange",e.cm,f),f.ranges!=d.ranges?bx(f.ranges,f.ranges.length-1):d
}function ai(g,f,j){var i=g.history.done,h=fo(i);
h&&h.ranges?(i[i.length-1]=f,g7(g,f,j)):hA(g,f,j)
}function hA(e,d,f){g7(e,d,f),f2(e,e.sel,e.cm?e.cm.curOp.id:0/0,f)
}function g7(f,e,h){(g9(f,"beforeSelectionChange")||f.cm&&g9(f.cm,"beforeSelectionChange"))&&(e=aD(f,e));
var g=h&&h.bias||(c8(e.primary().head,f.sel.primary().head)<0?-1:1);
gt(f,ft(f,e,g,!0)),h&&h.scroll===!1||!f.cm||gR(f.cm)
}function gt(d,c){c.equals(d.sel)||(d.sel=c,d.cm&&(d.cm.curOp.updateInput=d.cm.curOp.selectionChanged=!0,hC(d.cm)),aT(d,"cursorActivity",d))
}function fI(b){gt(b,ft(b,b.sel,null,!1),a0)
}function ft(r,q,p,o){for(var n,m=0;
m<q.ranges.length;
m++){var l=q.ranges[m],k=e8(r,l.anchor,p,o),j=e8(r,l.head,p,o);
(n||k!=l.anchor||j!=l.head)&&(n||(n=q.ranges.slice(0,m)),n[m]=new bL(k,j))
}return n?bx(n,q.primIndex):q
}function e8(x,w,v,u){var t=!1,s=w,r=v||1;
x.cantEdit=!1;
x:for(;
;
){var q=d8(x,s.line);
if(q.markedSpans){for(var p=0;
p<q.markedSpans.length;
++p){var o=q.markedSpans[p],n=o.marker;
if((null==o.from||(n.inclusiveLeft?o.from<=s.ch:o.from<s.ch))&&(null==o.to||(n.inclusiveRight?o.to>=s.ch:o.to>s.ch))){if(u&&(bs(n,"beforeCursorEnter"),n.explicitlyCleared)){if(q.markedSpans){--p;
continue
}break
}if(!n.atomic){continue
}var m=n.find(0>r?-1:1);
if(0==c8(m,s)&&(m.ch+=r,m.ch<0?m=m.line>x.first?aK(x,dt(m.line-1)):null:m.ch>q.text.length&&(m=m.line<x.first+x.size-1?dt(m.line+1,0):null),!m)){if(t){return u?(x.cantEdit=!0,dt(x.first,0)):e8(x,w,v,!0)
}t=!0,m=w,r=-r
}s=m;
continue x
}}}return s
}}function eV(x){for(var w=x.display,v=x.doc,u={},t=u.cursors=document.createDocumentFragment(),s=u.selection=document.createDocumentFragment(),r=0;
r<v.sel.ranges.length;
r++){var q=v.sel.ranges[r],p=q.empty();
(p||x.options.showCursorWhenSelecting)&&ej(x,q,t),p||dZ(x,q,s)
}if(x.options.moveInputWithCursor){var o=co(x,v.sel.primary().head,"div"),n=w.wrapper.getBoundingClientRect(),m=w.lineDiv.getBoundingClientRect();
u.teTop=Math.max(0,Math.min(w.wrapper.clientHeight-10,o.top+m.top-n.top)),u.teLeft=Math.max(0,Math.min(w.wrapper.clientWidth-10,o.left+m.left-n.left))
}return u
}function eI(d,c){aq(d.display.cursorDiv,c.cursors),aq(d.display.selectionDiv,c.selection),null!=c.teTop&&(d.display.inputDiv.style.top=c.teTop+"px",d.display.inputDiv.style.left=c.teLeft+"px")
}function ev(b){eI(b,eV(b))
}function ej(h,g,l){var k=co(h,g.head,"div",null,null,!h.options.singleCursorHeightPerLine),j=l.appendChild(b6("div","\xa0","CodeMirror-cursor"));
if(j.style.left=k.left+"px",j.style.top=k.top+"px",j.style.height=Math.max(0,k.bottom-k.top)*h.options.cursorHeight+"px",k.other){var i=l.appendChild(b6("div","\xa0","CodeMirror-cursor CodeMirror-secondarycursor"));
i.style.display="",i.style.left=k.other.left+"px",i.style.top=k.other.top+"px",i.style.height=0.85*(k.other.bottom-k.other.top)+"px"
}}function dZ(J,I,H){function A(f,e,h,g){0>e&&(e=0),e=Math.round(e),g=Math.round(g),E.appendChild(b6("div",null,"CodeMirror-selected","position: absolute; left: "+f+"px; top: "+e+"px; width: "+(null==h?B-f:h)+"px; height: "+(g-e)+"px"))
}function z(e,p,o){function a(f,b){return cB(J,dt(e,f),"div",n,b)
}var i,h,n=d8(F,e),j=n.text.length;
return aj(cr(n),p||0,null==o?j:o,function(d,c,m){var K,r,l,k=a(d,"left");
if(d==c){K=k,r=l=k.left
}else{if(K=a(c-1,"right"),"rtl"==m){var g=k;
k=K,K=g
}r=k.left,l=K.right
}null==p&&0==d&&(r=C),K.top-k.top>3&&(A(r,k.top,null,k.bottom),r=C,k.bottom<K.top&&A(r,k.bottom,null,K.top)),null==o&&c==j&&(l=B),(!i||k.top<i.top||k.top==i.top&&k.left<i.left)&&(i=k),(!h||K.bottom>h.bottom||K.bottom==h.bottom&&K.right>h.right)&&(h=K),C+1>r&&(r=C),A(r,K.top,l-r,K.bottom)
}),{start:i,end:h}
}var G=J.display,F=J.doc,E=document.createDocumentFragment(),D=bR(J.display),C=D.left,B=G.lineSpace.offsetWidth-D.right,y=I.from(),x=I.to();
if(y.line==x.line){z(y.line,y.ch,x.ch)
}else{var w=d8(F,y.line),v=d8(F,x.line),u=ho(w)==ho(v),t=z(y.line,y.ch,u?w.text.length+1:null).end,s=z(x.line,u?0:null,x.ch).start;
u&&(t.top<s.top-2?(A(t.right,t.top,null,t.bottom),A(C,s.top,s.left,s.bottom)):A(t.right,t.top,s.left-t.right,t.bottom)),t.bottom<s.top&&A(C,t.bottom,null,s.top)
}H.appendChild(E)
}function dM(e){if(e.state.focused){var d=e.display;
clearInterval(d.blinker);
var f=!0;
d.cursorDiv.style.visibility="",e.options.cursorBlinkRate>0?d.blinker=setInterval(function(){d.cursorDiv.style.visibility=(f=!f)?"":"hidden"
},e.options.cursorBlinkRate):e.options.cursorBlinkRate<0&&(d.cursorDiv.style.visibility="hidden")
}}function dz(d,c){d.doc.mode.startState&&d.doc.frontier<d.display.viewTo&&d.state.highlight.set(c,dU(dl,d))
}function dl(g){var f=g.doc;
if(f.frontier<f.first&&(f.frontier=f.first),!(f.frontier>=g.display.viewTo)){var j=+new Date+g.options.workTime,i=b2(f.mode,cI(g,f.frontier)),h=[];
f.iter(f.frontier,Math.min(f.first+f.size,g.display.viewTo+500),function(n){if(f.frontier>=g.display.viewFrom){var m=n.styles,e=bt(g,n,i,!0);
n.styles=e.styles;
var d=n.styleClasses,c=e.classes;
c?n.styleClasses=c:d&&(n.styleClasses=null);
for(var b=!m||m.length!=n.styles.length||d!=c&&(!d||!c||d.bgClass!=c.bgClass||d.textClass!=c.textClass),a=0;
!b&&a<m.length;
++a){b=m[a]!=n.styles[a]
}b&&h.push(f.frontier),n.stateAfter=b2(f.mode,i)
}else{aU(g,n.text,i),n.stateAfter=0==f.frontier%5?b2(f.mode,i):null
}return ++f.frontier,+new Date>j?(dz(g,g.options.workDelay),!0):void 0
}),h.length&&gs(g,function(){for(var a=0;
a<h.length;
a++){ei(g,h[a],"text")
}})
}}function cV(t,s,r){for(var q,p,o=t.doc,n=r?-1:s-(t.doc.mode.innerMode?1000:100),m=s;
m>n;
--m){if(m<=o.first){return o.first
}var l=d8(o,m-1);
if(l.stateAfter&&(!r||m<=o.frontier)){return m
}var k=hv(l.text,null,t.options.tabSize);
(null==p||q>k)&&(p=m-1,q=k)
}return p
}function cI(i,h,n){var m=i.doc,l=i.display;
if(!m.mode.startState){return !0
}var k=cV(i,h,n),j=k>m.first&&d8(m,k-1).stateAfter;
return j=j?b2(m.mode,j):bI(m.mode),m.iter(k,h,function(b){aU(i,b.text,j);
var a=k==h-1||0==k%5||k>=l.viewFrom&&k<l.viewTo;
b.stateAfter=a?b2(m.mode,j):null,++k
}),n&&(m.frontier=k),j
}function cv(b){return b.lineSpace.offsetTop
}function ci(b){return b.mover.offsetHeight-b.lineSpace.offsetHeight
}function bR(f){if(f.cachedPaddingH){return f.cachedPaddingH
}var e=aq(f.measure,b6("pre","x")),h=window.getComputedStyle?window.getComputedStyle(e):e.currentStyle,g={left:parseInt(h.paddingLeft),right:parseInt(h.paddingRight)};
return isNaN(g.left)||isNaN(g.right)||(f.cachedPaddingH=g),g
}function c1(t,s,r){var q=t.options.lineWrapping,p=q&&t.display.scroller.clientWidth;
if(!s.measure.heights||q&&s.measure.width!=p){var o=s.measure.heights=[];
if(q){s.measure.width=p;
for(var n=s.text.firstChild.getClientRects(),m=0;
m<n.length-1;
m++){var l=n[m],k=n[m+1];
Math.abs(l.bottom-k.bottom)>2&&o.push((l.bottom+k.top)/2-r.top)
}}o.push(r.bottom-r.top)
}}function aw(f,e,h){if(f.line==e){return{map:f.measure.map,cache:f.measure.cache}
}for(var g=0;
g<f.rest.length;
g++){if(f.rest[g]==e){return{map:f.measure.maps[g],cache:f.measure.caches[g]}
}}for(var g=0;
g<f.rest.length;
g++){if(da(f.rest[g])>h){return{map:f.measure.maps[g],cache:f.measure.caches[g],before:!0}
}}}function hr(g,f){f=ho(f);
var j=da(f),i=g.display.externalMeasured=new eU(g.doc,f,j);
i.lineN=j;
var h=i.built=ha(g,i);
return i.text=h.pre,aq(g.display.lineMeasure,h.pre),i
}function gV(f,e,h,g){return fl(f,fz(f,e),h,g)
}function ga(e,d){if(d>=e.display.viewFrom&&d<e.display.viewTo){return e.display.view[dL(e,d)]
}var f=e.display.externalMeasured;
return f&&d>=f.lineN&&d<f.lineN+f.size?f:void 0
}function fz(g,f){var j=da(f),i=ga(g,j);
i&&!i.text?i=null:i&&i.changes&&hs(g,i,j,ht(g)),i||(i=hr(g,f));
var h=aw(i,f,j);
return{line:f,view:i,rect:null,map:h.map,cache:h.cache,before:h.before,hasHeights:!1}
}function fl(i,h,n,m,l){h.before&&(n=-1);
var j,k=n+(m||"");
return h.cache.hasOwnProperty(k)?j=h.cache[k]:(h.rect||(h.rect=h.view.text.getBoundingClientRect()),h.hasHeights||(c1(i,h.view,h.rect),h.hasHeights=!0),j=eO(i,h,n,m),j.bogus||(h.cache[k]=j)),{left:j.left,right:j.right,top:l?j.rtop:j.top,bottom:l?j.rbottom:j.bottom}
}function eO(R,Q,P,O){for(var M,L,K,J,N=Q.map,I=0;
I<N.length;
I+=3){var H=N[I],G=N[I+1];
if(H>P?(L=0,K=1,J="left"):G>P?(L=P-H,K=L+1):(I==N.length-3||P==G&&N[I+3]>P)&&(K=G-H,L=K-1,P>=G&&(J="right")),null!=L){if(M=N[I+2],H==G&&O==(M.insertLeft?"left":"right")&&(J=O),"left"==O&&0==L){for(;
I&&N[I-2]==N[I-3]&&N[I-1].insertLeft;
){M=N[(I-=3)+2],J="left"
}}if("right"==O&&L==G-H){for(;
I<N.length-3&&N[I+3]==N[I+4]&&!N[I+5].insertLeft;
){M=N[(I+=3)+2],J="right"
}}break
}}var F;
if(3==M.nodeType){for(var I=0;
4>I;
I++){for(;
L&&cq(Q.line.text.charAt(H+L));
){--L
}for(;
G>H+K&&cq(Q.line.text.charAt(H+K));
){++K
}if(f9&&9>f7&&0==L&&K==G-H){F=M.parentNode.getBoundingClientRect()
}else{if(f9&&R.options.lineWrapping){var E=bM(M,L,K).getClientRects();
F=E.length?E["right"==O?E.length-1:0]:e1
}else{F=bM(M,L,K).getBoundingClientRect()||e1
}}if(F.left||F.right||0==L){break
}K=L,L-=1,J="right"
}f9&&11>f7&&(F=eB(R.display.measure,F))
}else{L>0&&(J=O="right");
var E;
F=R.options.lineWrapping&&(E=M.getClientRects()).length>1?E["right"==O?E.length-1:0]:M.getBoundingClientRect()
}if(f9&&9>f7&&!L&&(!F||!F.left&&!F.right)){var D=M.parentNode.getClientRects()[0];
F=D?{left:D.left,right:D.left+ao(R.display),top:D.top,bottom:D.bottom}:e1
}for(var C=F.top-Q.rect.top,B=F.bottom-Q.rect.top,A=(C+B)/2,z=Q.view.measure.heights,I=0;
I<z.length-1&&!(A<z[I]);
I++){}var y=I?z[I-1]:0,e=z[I],d={left:("right"==J?F.right:F.left)-Q.rect.left,right:("left"==J?F.left:F.right)-Q.rect.left,top:y,bottom:e};
return F.left||F.right||(d.bogus=!0),R.options.singleCursorHeightPerLine||(d.rtop=C,d.rbottom=B),d
}function eB(f,e){if(!window.screen||null==screen.logicalXDPI||screen.logicalXDPI==screen.deviceXDPI||!aS(f)){return e
}var h=screen.logicalXDPI/screen.deviceXDPI,g=screen.logicalYDPI/screen.deviceYDPI;
return{left:e.left*h,right:e.right*h,top:e.top*g,bottom:e.bottom*g}
}function eo(d){if(d.measure&&(d.measure.cache={},d.measure.heights=null,d.rest)){for(var c=0;
c<d.rest.length;
c++){d.measure.caches[c]={}
}}}function d5(d){d.display.externalMeasure=null,cW(d.display.lineMeasure);
for(var c=0;
c<d.display.view.length;
c++){eo(d.display.view[c])
}}function dS(b){d5(b),b.display.cachedCharWidth=b.display.cachedTextHeight=b.display.cachedPaddingH=null,b.options.lineWrapping||(b.display.maxLineChanged=!0),b.display.lineNumChars=null
}function dF(){return window.pageXOffset||(document.documentElement||document.body).scrollLeft
}function ds(){return window.pageYOffset||(document.documentElement||document.body).scrollTop
}function c7(r,q,p,o){if(q.widgets){for(var n=0;
n<q.widgets.length;
++n){if(q.widgets[n].above){var m=d2(q.widgets[n]);
p.top+=m,p.bottom+=m
}}}if("line"==o){return p
}o||(o="local");
var l=cE(q);
if("local"==o?l+=cv(r.display):l-=r.display.viewOffset,"page"==o||"window"==o){var k=r.display.lineSpace.getBoundingClientRect();
l+=k.top+("window"==o?0:ds());
var j=k.left+("window"==o?0:dF());
p.left+=j,p.right+=j
}return p.top+=l,p.bottom+=l,p
}function cO(i,h,n){if("div"==n){return h
}var m=h.left,l=h.top;
if("page"==n){m-=dF(),l-=ds()
}else{if("local"==n||!n){var k=i.display.sizer.getBoundingClientRect();
m+=k.left,l+=k.top
}}var j=i.display.lineSpace.getBoundingClientRect();
return{left:m-j.left,top:l-j.top}
}function cB(g,f,j,i,h){return i||(i=d8(g.doc,f.line)),c7(g,i,gV(g,i,f.ch,h),j)
}function co(x,w,v,u,t,s){function r(a,d){var c=fl(x,t,a,d?"right":"left",s);
return d?c.left=c.right:c.right=c.left,c7(x,u,c,v)
}function q(f,e){var h=p[e],g=h.level%2;
return f==hB(h)&&e&&h.level<p[e-1].level?(h=p[--e],f=g8(h)-(h.level%2?0:1),g=!0):f==g8(h)&&e<p.length-1&&h.level<p[e+1].level&&(h=p[++e],f=hB(h)-h.level%2,g=!1),g&&f==h.to&&f>h.from?r(f-1):r(f,g)
}u=u||d8(x.doc,w.line),t||(t=fz(x,u));
var p=cr(u),o=w.ch;
if(!p){return r(o)
}var n=hu(p,o),m=q(o,n);
return null!=hI&&(m.other=q(o,hI)),m
}function b4(g,f){var j=0,f=aK(g.doc,f);
g.options.lineWrapping||(j=ao(g.display)*f.ch);
var i=d8(g.doc,f.line),h=cE(i)+cv(g.display);
return{left:j,right:j,top:h,bottom:h+i.height}
}function bK(g,f,j,i){var h=dt(g,f);
return h.xRel=i,j&&(h.outside=!0),h
}function bw(t,s,r){var q=t.doc;
if(r+=t.display.viewOffset,0>r){return bK(q.first,0,!0,-1)
}var p=cR(q,r),o=q.first+q.size-1;
if(p>o){return bK(q.first+q.size-1,d8(q,o).text.length,!0,1)
}0>s&&(s=0);
for(var n=d8(q,p);
;
){var m=bi(t,n,p,s,r),l=cY(n),k=l&&l.find(0,!0);
if(!l||!(m.ch>k.from.ch||m.ch==k.from.ch&&m.xRel>0)){return m
}p=da(n=k.to.line)
}}function bi(X,W,V,U,T){function O(b){var a=co(X,dt(V,b),"line",W,P);
return R=!0,S>a.bottom?a.left-Q:S<a.top?a.left+Q:(R=!1,a.left)
}var S=T-cE(W),R=!1,Q=2*X.display.wrapper.clientWidth,P=fz(X,W),N=cr(W),M=W.text.length,L=bS(W),K=by(W),J=O(L),I=R,H=O(K),G=R;
if(U>H){return bK(V,K,G,1)
}for(;
;
){if(N?K==L||K==gm(W,L,1):1>=K-L){for(var F=J>U||H-U>=U-J?L:K,E=U-(F==L?J:H);
cq(W.text.charAt(F));
){++F
}var D=bK(V,F,F==L?I:G,-1>E?-1:E>1?1:0);
return D
}var C=Math.ceil(M/2),B=L+C;
if(N){B=L;
for(var A=0;
C>A;
++A){B=gm(W,B,1)
}}var z=O(B);
z>U?(K=B,H=z,(G=R)&&(H+=1000),M=C):(L=B,J=z,I=R,M-=C)
}}function aJ(e){if(null!=e.cachedTextHeight){return e.cachedTextHeight
}if(null==aX){aX=b6("pre");
for(var d=0;
49>d;
++d){aX.appendChild(document.createTextNode("x")),aX.appendChild(b6("br"))
}aX.appendChild(document.createTextNode("x"))
}aq(e.measure,aX);
var f=aX.offsetHeight/50;
return f>3&&(e.cachedTextHeight=f),cW(e.measure),f||1
}function ao(g){if(null!=g.cachedCharWidth){return g.cachedCharWidth
}var f=b6("span","xxxxxxxxxx"),j=b6("pre",[f]);
aq(g.measure,j);
var i=f.getBoundingClientRect(),h=(i.right-i.left)/10;
return h>2&&(g.cachedCharWidth=h),h||10
}function bX(b){b.curOp={cm:b,viewChanged:!1,startHeight:b.doc.height,forceUpdate:!1,updateInput:null,typing:!1,changeObjs:null,cursorActivityHandlers:null,cursorActivityCalled:0,selectionChanged:!1,updateMaxLine:!1,scrollLeft:null,scrollTop:null,scrollToPos:null,id:++hk},hG?hG.ops.push(b.curOp):b.curOp.ownsGroup=hG={ops:[b.curOp],delayedCallbacks:[]}
}function bD(g){var f=g.delayedCallbacks,j=0;
do{for(;
j<f.length;
j++){f[j]()
}for(var i=0;
i<g.ops.length;
i++){var h=g.ops[i];
if(h.cursorActivityHandlers){for(;
h.cursorActivityCalled<h.cursorActivityHandlers.length;
){h.cursorActivityHandlers[h.cursorActivityCalled++](h.cm)
}}}}while(j<f.length)
}function bp(f){var e=f.curOp,h=e.ownsGroup;
if(h){try{bD(h)
}finally{hG=null;
for(var g=0;
g<h.ops.length;
g++){h.ops[g].cm.curOp=null
}a4(h)
}}}function a4(e){for(var d=e.ops,f=0;
f<d.length;
f++){aQ(d[f])
}for(var f=0;
f<d.length;
f++){aC(d[f])
}for(var f=0;
f<d.length;
f++){aa(d[f])
}for(var f=0;
f<d.length;
f++){hz(d[f])
}for(var f=0;
f<d.length;
f++){g6(d[f])
}}function aQ(e){var d=e.cm,f=d.display;
e.updateMaxLine&&gM(d),e.mustUpdate=e.viewChanged||e.forceUpdate||null!=e.scrollTop||e.scrollToPos&&(e.scrollToPos.from.line<f.viewFrom||e.scrollToPos.to.line>=f.viewTo)||f.maxLineChanged&&d.options.lineWrapping,e.update=e.mustUpdate&&new gB(d,e.mustUpdate&&{top:e.scrollTop,ensure:e.scrollToPos},e.forceUpdate)
}function aC(b){b.updatedDisplay=b.mustUpdate&&gA(b.cm,b.update)
}function aa(e){var d=e.cm,f=d.display;
e.updatedDisplay&&gv(d),e.barMeasure=gI(d),f.maxLineChanged&&!d.options.lineWrapping&&(e.adjustWidthTo=gV(d,f.maxLine,f.maxLine.text.length).left+3,e.maxScrollLeft=Math.max(0,f.sizer.offsetLeft+e.adjustWidthTo+bz-f.scroller.clientWidth)),(e.updatedDisplay||e.selectionChanged)&&(e.newSelectionNodes=eV(d))
}function hz(d){var c=d.cm;
null!=d.adjustWidthTo&&(c.display.sizer.style.minWidth=d.adjustWidthTo+"px",d.maxScrollLeft<c.doc.scrollLeft&&bJ(c,Math.min(c.display.scroller.scrollLeft,d.maxScrollLeft),!0),c.display.maxLineChanged=!1),d.newSelectionNodes&&eI(c,d.newSelectionNodes),d.updatedDisplay&&gx(c,d.barMeasure),(d.updatedDisplay||d.startHeight!=c.doc.height)&&gH(c,d.barMeasure),d.selectionChanged&&dM(c),c.state.focused&&d.updateInput&&c0(c,d.typing)
}function g6(t){var s=t.cm,r=s.display,q=s.doc;
if(null!=t.adjustWidthTo&&Math.abs(t.barMeasure.scrollWidth-s.display.scroller.scrollWidth)>1&&gH(s),t.updatedDisplay&&gz(s,t.update),null==r.wheelStartX||null==t.scrollTop&&null==t.scrollLeft&&!t.scrollToPos||(r.wheelStartX=r.wheelStartY=null),null!=t.scrollTop&&(r.scroller.scrollTop!=t.scrollTop||t.forceScroll)){var p=Math.max(0,Math.min(r.scroller.scrollHeight-r.scroller.clientHeight,t.scrollTop));
r.scroller.scrollTop=r.scrollbarV.scrollTop=q.scrollTop=p
}if(null!=t.scrollLeft&&(r.scroller.scrollLeft!=t.scrollLeft||t.forceScroll)){var o=Math.max(0,Math.min(r.scroller.scrollWidth-r.scroller.clientWidth,t.scrollLeft));
r.scroller.scrollLeft=r.scrollbarH.scrollLeft=q.scrollLeft=o,gF(s)
}if(t.scrollToPos){var n=bP(s,aK(q,t.scrollToPos.from),aK(q,t.scrollToPos.to),t.scrollToPos.margin);
t.scrollToPos.isCursor&&s.state.focused&&b9(s,n)
}var m=t.maybeHiddenMarkers,l=t.maybeUnhiddenMarkers;
if(m){for(var f=0;
f<m.length;
++f){m[f].lines.length||bs(m[f],"hide")
}}if(l){for(var f=0;
f<l.length;
++f){l[f].lines.length&&bs(l[f],"unhide")
}}r.wrapper.offsetHeight&&(q.scrollTop=s.display.scroller.scrollTop),t.updatedDisplay&&f5&&(s.options.lineWrapping&&gw(s,t.barMeasure),t.barMeasure.scrollWidth>t.barMeasure.clientWidth&&t.barMeasure.scrollWidth<t.barMeasure.clientWidth+1&&!gJ(s)&&gH(s)),t.changeObjs&&bs(s,"changes",s,t.changeObjs)
}function gs(d,c){if(d.curOp){return c()
}bX(d);
try{return c()
}finally{bp(d)
}}function fG(d,c){return function(){if(d.curOp){return c.apply(d,arguments)
}bX(d);
try{return c.apply(d,arguments)
}finally{bp(d)
}}
}function fs(b){return function(){if(this.curOp){return b.apply(this,arguments)
}bX(this);
try{return b.apply(this,arguments)
}finally{bp(this)
}}
}function e7(b){return function(){var a=this.cm;
if(!a||a.curOp){return b.apply(this,arguments)
}bX(a);
try{return b.apply(this,arguments)
}finally{bp(a)
}}
}function eU(e,d,f){this.line=d,this.rest=gP(d),this.size=this.rest?da(fo(this.rest))-f+1:1,this.node=this.text=null,this.hidden=fi(e,d)
}function eH(i,h,n){for(var l,m=[],k=h;
n>k;
k=l){var j=new eU(i.doc,d8(i.doc,k),k);
l=k+j.size,m.push(j)
}return m
}function eu(r,q,p,o){null==q&&(q=r.doc.first),null==p&&(p=r.doc.first+r.doc.size),o||(o=0);
var n=r.display;
if(o&&p<n.viewTo&&(null==n.updateLineNumbers||n.updateLineNumbers>q)&&(n.updateLineNumbers=q),r.curOp.viewChanged=!0,q>=n.viewTo){fM&&f4(r.doc,q)<n.viewTo&&dY(r)
}else{if(p<=n.viewFrom){fM&&fw(r.doc,p+o)>n.viewFrom?dY(r):(n.viewFrom+=o,n.viewTo+=o)
}else{if(q<=n.viewFrom&&p>=n.viewTo){dY(r)
}else{if(q<=n.viewFrom){var m=dy(r,p,p+o,1);
m?(n.view=n.view.slice(m.index),n.viewFrom=m.lineN,n.viewTo+=o):dY(r)
}else{if(p>=n.viewTo){var m=dy(r,q,q,-1);
m?(n.view=n.view.slice(0,m.index),n.viewTo=m.lineN):dY(r)
}else{var l=dy(r,q,q,-1),k=dy(r,p,p+o,1);
l&&k?(n.view=n.view.slice(0,l.index).concat(eH(r,l.lineN,k.lineN)).concat(n.view.slice(k.index)),n.viewTo+=o):dY(r)
}}}}}var j=n.externalMeasured;
j&&(p<j.lineN?j.lineN+=o:q<j.lineN+j.size&&(n.externalMeasured=null))
}function ei(i,h,n){i.curOp.viewChanged=!0;
var m=i.display,l=i.display.externalMeasured;
if(l&&h>=l.lineN&&h<l.lineN+l.size&&(m.externalMeasured=null),!(h<m.viewFrom||h>=m.viewTo)){var k=m.view[dL(i,h)];
if(null!=k.node){var j=k.changes||(k.changes=[]);
-1==eQ(j,n)&&j.push(n)
}}}function dY(b){b.display.viewFrom=b.display.viewTo=b.doc.first,b.display.view=[],b.display.viewOffset=0
}function dL(f,e){if(e>=f.display.viewTo){return null
}if(e-=f.display.viewFrom,0>e){return null
}for(var h=f.display.view,g=0;
g<h.length;
g++){if(e-=h[g].size,0>e){return g
}}}function dy(r,q,p,o){var m,n=dL(r,q),l=r.display.view;
if(!fM||p==r.doc.first+r.doc.size){return{index:n,lineN:p}
}for(var k=0,j=r.display.viewFrom;
n>k;
k++){j+=l[k].size
}if(j!=q){if(o>0){if(n==l.length-1){return null
}m=j+l[n].size-q,n++
}else{m=j-q
}q+=m,p+=m
}for(;
f4(r.doc,p)!=p;
){if(n==(0>o?0:l.length-1)){return null
}p+=o*l[n-(0>o?1:0)].size,n+=o
}return{index:n,lineN:p}
}function dk(g,f,j){var i=g.display,h=i.view;
0==h.length||f>=i.viewTo||j<=i.viewFrom?(i.view=eH(g,f,j),i.viewFrom=f):(i.viewFrom>f?i.view=eH(g,f,i.viewFrom).concat(i.view):i.viewFrom<f&&(i.view=i.view.slice(dL(g,f))),i.viewFrom=f,i.viewTo<j?i.view=i.view.concat(eH(g,i.viewTo,j)):i.viewTo>j&&(i.view=i.view.slice(0,dL(g,j)))),i.viewTo=j
}function cU(g){for(var f=g.display.view,j=0,i=0;
i<f.length;
i++){var h=f[i];
h.hidden||h.node&&!h.changes||++j
}return j
}function cH(b){b.display.pollingFast||b.display.poll.set(b.options.pollInterval,function(){bQ(b),b.state.focused&&cH(b)
})
}function cu(e){function f(){var a=bQ(e);
a||d?(e.display.pollingFast=!1,cH(e)):(d=!0,e.display.poll.set(60,f))
}var d=!1;
e.display.pollingFast=!0,e.display.poll.set(20,f)
}function bQ(N){var M=N.display.input,L=N.display.prevInput,K=N.doc;
if(!N.state.focused||bF(M)&&!L||gT(N)||N.options.disableInput||N.state.keySeq){return !1
}N.state.pasteIncoming&&N.state.fakedLastChar&&(M.value=M.value.substring(0,M.value.length-1),N.state.fakedLastChar=!1);
var J=M.value;
if(J==L&&!N.somethingSelected()){return !1
}if(f9&&f7>=9&&N.display.inputHasSelection===J||fS&&/[\uf700-\uf7ff]/.test(J)){return c0(N),!1
}var I=!N.curOp;
I&&bX(N),N.display.shift=!1,8203!=J.charCodeAt(0)||K.sel!=N.display.selForContextMenu||L||(L="\u200b");
for(var H=0,G=Math.min(L.length,J.length);
G>H&&L.charCodeAt(H)==J.charCodeAt(H);
){++H
}var F=J.slice(H),E=bZ(F),D=null;
N.state.pasteIncoming&&K.sel.ranges.length>1&&(ca&&ca.join("\n")==F?D=0==K.sel.ranges.length%ca.length&&eD(ca,bZ):E.length==K.sel.ranges.length&&(D=eD(E,function(b){return[b]
})));
for(var C=K.sel.ranges.length-1;
C>=0;
C--){var B=K.sel.ranges[C],A=B.from(),z=B.to();
H<L.length?A=dt(A.line,A.ch-(L.length-H)):N.state.overwrite&&B.empty()&&!N.state.pasteIncoming&&(z=dt(z.line,Math.min(d8(K,z.line).text.length,z.ch+fo(E).length)));
var y=N.curOp.updateInput,x={from:A,to:z,text:D?D[C%D.length]:E,origin:N.state.pasteIncoming?"paste":N.state.cutIncoming?"cut":"+input"};
if(dX(N.doc,x),aT(N,"inputRead",N,x),F&&!N.state.pasteIncoming&&N.options.electricChars&&N.options.smartIndent&&B.head.ch<100&&(!C||K.sel.ranges[C-1].head.line!=B.head.line)){var p=N.getModeAt(B.head),e=fr(x);
if(p.electricChars){for(var d=0;
d<p.electricChars.length;
d++){if(F.indexOf(p.electricChars.charAt(d))>-1){fx(N,e.line,"smart");
break
}}}else{p.electricInput&&p.electricInput.test(d8(K,e.line).text.slice(0,e.ch))&&fx(N,e.line,"smart")
}}}return gR(N),N.curOp.updateInput=y,N.curOp.typing=!0,J.length>1000||J.indexOf("\n")>-1?M.value=N.display.prevInput="":N.display.prevInput=J,I&&bp(N),N.state.pasteIncoming=N.state.cutIncoming=!1,!0
}function c0(e,d){var n,m,l=e.doc;
if(e.somethingSelected()){e.display.prevInput="";
var k=l.sel.primary();
n=br&&(k.to().line-k.from().line>100||(m=e.getSelection()).length>1000);
var j=n?"-":m||e.getSelection();
e.display.input.value=j,e.state.focused&&e3(e.display.input),f9&&f7>=9&&(e.display.inputHasSelection=j)
}else{d||(e.display.prevInput=e.display.input.value="",f9&&f7>=9&&(e.display.inputHasSelection=null))
}e.display.inaccurateSelection=n
}function av(b){"nocursor"==b.options.readOnly||fT&&gK()==b.display.input||b.display.input.focus()
}function hq(b){b.state.focused||(av(b),hy(b))
}function gT(b){return b.options.readOnly||b.doc.cantEdit
}function f8(e){function j(){e.state.focused&&setTimeout(dU(av,e),0)
}function i(a){ak(e,a)||cK(a)
}function f(n){if(e.somethingSelected()){ca=e.getSelections(),d.inaccurateSelection&&(d.prevInput="",d.inaccurateSelection=!1,d.input.value=ca.join("\n"),e3(d.input))
}else{for(var m=[],l=[],k=0;
k<e.doc.sel.ranges.length;
k++){var b=e.doc.sel.ranges[k].head.line,a={anchor:dt(b,0),head:dt(b+1,0)};
l.push(a),m.push(e.getRange(a.anchor,a.head))
}"cut"==n.type?e.setSelections(l,null,a0):(d.prevInput="",d.input.value=m.join("\n"),e3(d.input)),ca=m
}"cut"==n.type&&(e.state.cutIncoming=!0)
}var d=e.display;
b0(d.scroller,"mousedown",fG(e,eN)),f9&&11>f7?b0(d.scroller,"dblclick",fG(e,function(a){if(!ak(e,a)){var h=e0(e,a);
if(h&&!c6(e,a)&&!fk(e.display,a)){dB(a);
var g=e.findWordAt(h);
bE(e.doc,g.anchor,g.head)
}}})):b0(d.scroller,"dblclick",function(a){ak(e,a)||dB(a)
}),b0(d.lineSpace,"selectstart",function(b){fk(d,b)||dB(b)
}),fO||b0(d.scroller,"contextmenu",function(a){gr(e,a)
}),b0(d.scroller,"scroll",function(){d.scroller.clientHeight&&(b3(e,d.scroller.scrollTop),bJ(e,d.scroller.scrollLeft,!0),bs(e,"scroll",e))
}),b0(d.scrollbarV,"scroll",function(){d.scroller.clientHeight&&b3(e,d.scrollbarV.scrollTop)
}),b0(d.scrollbarH,"scroll",function(){d.scroller.clientHeight&&bJ(e,d.scrollbarH.scrollLeft)
}),b0(d.scroller,"mousewheel",function(a){aW(e,a)
}),b0(d.scroller,"DOMMouseScroll",function(a){aW(e,a)
}),b0(d.scrollbarH,"mousedown",j),b0(d.scrollbarV,"mousedown",j),b0(d.wrapper,"scroll",function(){d.wrapper.scrollTop=d.wrapper.scrollLeft=0
}),b0(d.input,"keyup",function(a){aB.call(e,a)
}),b0(d.input,"input",function(){f9&&f7>=9&&e.display.inputHasSelection&&(e.display.inputHasSelection=null),cu(e)
}),b0(d.input,"keydown",fG(e,a3)),b0(d.input,"keypress",fG(e,hM)),b0(d.input,"focus",dU(hy,e)),b0(d.input,"blur",dU(g5,e)),e.options.dragDrop&&(b0(d.scroller,"dragstart",function(a){cn(e,a)
}),b0(d.scroller,"dragenter",i),b0(d.scroller,"dragover",i),b0(d.scroller,"drop",fG(e,cA))),b0(d.scroller,"paste",function(a){fk(d,a)||(e.state.pasteIncoming=!0,av(e),cu(e))
}),b0(d.input,"paste",function(){if(f5&&!e.state.fakedLastChar&&!(new Date-e.state.lastMiddleDown<200)){var b=d.input.selectionStart,a=d.input.selectionEnd;
d.input.value+="$",d.input.selectionEnd=a,d.input.selectionStart=b,e.state.fakedLastChar=!0
}e.state.pasteIncoming=!0,cu(e)
}),b0(d.input,"cut",f),b0(d.input,"copy",f),fX&&b0(d.sizer,"mouseup",function(){gK()==d.input&&d.input.blur(),av(e)
})
}function fy(d){var c=d.display;
(c.lastWrapHeight!=c.wrapper.clientHeight||c.lastWrapWidth!=c.wrapper.clientWidth)&&(c.cachedCharWidth=c.cachedTextHeight=c.cachedPaddingH=null,d.setSize())
}function fk(e,d){for(var f=cx(d);
f!=e.wrapper;
f=f.parentNode){if(!f||f.ignoreEvents||f.parentNode==e.sizer&&f!=e.mover){return !0
}}}function e0(x,w,v,u){var t=x.display;
if(!v){var s=cx(w);
if(s==t.scrollbarH||s==t.scrollbarV||s==t.scrollbarFiller||s==t.gutterFiller){return null
}}var r,q,p=t.lineSpace.getBoundingClientRect();
try{r=w.clientX-p.left,q=w.clientY-p.top
}catch(w){return null
}var n,o=bw(x,r,q);
if(u&&1==o.xRel&&(n=d8(x.doc,o.line).text).length==o.ch){var m=hv(n,n.length,x.options.tabSize)-n.length;
o=dt(o.line,Math.max(0,Math.round((r-bR(x.display).left)/ao(x.display))-m))
}return o
}function eN(f){if(!ak(this,f)){var e=this,h=e.display;
if(h.shift=f.shiftKey,fk(h,f)){return f5||(h.scroller.draggable=!1,setTimeout(function(){h.scroller.draggable=!0
},100)),void 0
}if(!c6(e,f)){var g=e0(e,f);
switch(window.focus(),ck(f)){case 1:g?d4(e,f,g):cx(f)==h.scroller&&dB(f);
break;
case 2:f5&&(e.state.lastMiddleDown=+new Date),g&&bE(e.doc,g),setTimeout(dU(av,e),20),dB(f);
break;
case 3:fO&&gr(e,f)
}}}}function d4(i,h,n){setTimeout(dU(hq,i),0);
var l,m=+new Date;
en&&en.time>m-400&&0==c8(en.pos,n)?l="triple":eA&&eA.time>m-400&&0==c8(eA.pos,n)?(l="double",en={time:m,pos:n}):(l="single",eA={time:m,pos:n});
var k=i.doc.sel,j=fS?h.metaKey:h.ctrlKey;
i.options.dragDrop&&dN&&!gT(i)&&"single"==l&&k.contains(n)>-1&&k.somethingSelected()?dR(i,h,n,j):dE(i,h,n,l,j)
}function dR(e,d,l,k){var j=e.display,f=fG(e,function(a){f5&&(j.scroller.draggable=!1),e.state.draggingText=!1,bG(document,"mouseup",f),bG(j.scroller,"drop",f),Math.abs(d.clientX-a.clientX)+Math.abs(d.clientY-a.clientY)<10&&(dB(a),k||bE(e.doc,l),av(e),f9&&9==f7&&setTimeout(function(){document.body.focus(),av(e)
},20))
});
f5&&(j.scroller.draggable=!0),e.state.draggingText=f,j.scroller.dragDrop&&j.scroller.dragDrop(),b0(document,"mouseup",f),b0(j.scroller,"drop",f)
}function dE(N,M,L,K,J){function A(P){if(0!=c8(B,P)){if(B=P,"rect"==K){for(var O=[],m=N.options.tabSize,j=hv(d8(H,L.line).text,L.ch,m),i=hv(d8(H,P.line).text,P.ch,m),h=Math.min(j,i),g=Math.max(j,i),d=Math.min(L.line,P.line),c=Math.min(N.lastLine(),Math.max(L.line,P.line));
c>=d;
d++){var a=d8(H,d).text,U=g2(a,h,m);
h==g?O.push(new bL(dt(d,U),dt(d,U))):a.length>U&&O.push(new bL(dt(d,U),dt(d,g2(a,g,m))))
}O.length||O.push(new bL(L,L)),hA(H,bx(E.ranges.slice(0,F).concat(O),F),{origin:"*mouse",scroll:!1}),N.scrollIntoView(P)
}else{var T=G,S=T.anchor,R=P;
if("single"!=K){if("double"==K){var Q=N.findWordAt(P)
}else{var Q=new bL(dt(P.line,0),aK(H,dt(P.line+1,0)))
}c8(Q.anchor,S)>0?(R=Q.head,S=cp(T.from(),Q.anchor)):(R=Q.anchor,S=cC(T.to(),Q.head))
}var O=E.ranges.slice(0);
O[F]=new bL(aK(H,S),R),hA(H,bx(O,F),aM)
}}}function x(a){var j=++y,g=e0(N,a,!0,"rect"==K);
if(g){if(0!=c8(g,B)){hq(N),A(g);
var f=gG(I,H);
(g.line>=f.to||g.line<f.from)&&setTimeout(fG(N,function(){y==j&&x(a)
}),150)
}else{var d=a.clientY<z.top?-20:a.clientY>z.bottom?20:0;
d&&setTimeout(fG(N,function(){y==j&&(I.scroller.scrollTop+=d,x(a))
}),50)
}}}function w(a){y=1/0,dB(a),av(N),bG(document,"mousemove",v),bG(document,"mouseup",u),H.history.lastSelOrigin=null
}var I=N.display,H=N.doc;
dB(M);
var G,F,E=H.sel;
if(J&&!M.shiftKey?(F=H.sel.contains(L),G=F>-1?H.sel.ranges[F]:new bL(L,L)):G=H.sel.primary(),M.altKey){K="rect",J||(G=new bL(L,L)),L=e0(N,M,!0,!0),F=-1
}else{if("double"==K){var D=N.findWordAt(L);
G=N.display.shift||H.extend?bY(H,G,D.anchor,D.head):D
}else{if("triple"==K){var C=new bL(dt(L.line,0),aK(H,dt(L.line+1,0)));
G=N.display.shift||H.extend?bY(H,G,C.anchor,C.head):C
}else{G=bY(H,G,L)
}}}J?F>-1?a5(H,F,G,aM):(F=H.sel.ranges.length,hA(H,bx(H.sel.ranges.concat([G]),F),{scroll:!1,origin:"*mouse"})):(F=0,hA(H,new b5([G],0),aM),E=H.sel);
var B=L,z=I.wrapper.getBoundingClientRect(),y=0,v=fG(N,function(b){ck(b)?x(b):w(b)
}),u=fG(N,w);
b0(document,"mousemove",v),b0(document,"mouseup",u)
}function dr(z,y,x,w,v){try{var u=y.clientX,t=y.clientY
}catch(y){return !1
}if(u>=Math.floor(z.display.gutters.getBoundingClientRect().right)){return !1
}w&&dB(y);
var s=z.display,r=s.lineDiv.getBoundingClientRect();
if(t>r.bottom||!g9(z,x)){return c3(y)
}t-=r.top-s.viewOffset;
for(var q=0;
q<z.options.gutters.length;
++q){var p=s.gutters.childNodes[q];
if(p&&p.getBoundingClientRect().right>=u){var o=cR(z.doc,t),n=z.options.gutters[q];
return v(z,x,z,o,n,y),c3(y)
}}}function c6(d,c){return dr(d,c,"gutterClick",!0,aT)
}function cA(t){var s=this;
if(!ak(s,t)&&!fk(s.display,t)){dB(t),f9&&(cN=+new Date);
var r=e0(s,t,!0),q=t.dataTransfer.files;
if(r&&!gT(s)){if(q&&q.length&&window.FileReader&&window.File){for(var p=q.length,o=Array(p),n=0,m=function(b,f){var c=new FileReader;
c.onload=fG(s,function(){if(o[f]=c.result,++n==p){r=aK(s.doc,r);
var e={from:r,to:r,text:bZ(o.join("\n")),origin:"paste"};
dX(s.doc,e),ai(s.doc,bj(r,fr(e)))
}}),c.readAsText(b)
},l=0;
p>l;
++l){m(q[l],l)
}}else{if(s.state.draggingText&&s.doc.sel.contains(r)>-1){return s.state.draggingText(t),setTimeout(dU(av,s),20),void 0
}try{var o=t.dataTransfer.getData("Text");
if(o){if(s.state.draggingText&&!(fS?t.metaKey:t.ctrlKey)){var d=s.listSelections()
}if(g7(s.doc,bj(r,r)),d){for(var l=0;
l<d.length;
++l){ct(s.doc,"",d[l].anchor,d[l].head,"drag")
}}s.replaceSelection(o,"around","paste"),av(s)
}}catch(t){}}}}}function cn(e,d){if(f9&&(!e.state.draggingText||+new Date-cN<100)){return cK(d),void 0
}if(!ak(e,d)&&!fk(e.display,d)&&(d.dataTransfer.setData("Text",e.getSelection()),d.dataTransfer.setDragImage&&!fY)){var f=b6("img",null,null,"position: fixed; left: 0; top: 0;");
f.src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",fZ&&(f.width=f.height=1,e.display.wrapper.appendChild(f),f._top=f.offsetTop),d.dataTransfer.setDragImage(f,0,0),fZ&&f.parentNode.removeChild(f)
}}function b3(a,d){Math.abs(a.doc.scrollTop-d)<2||(a.doc.scrollTop=d,gl||gy(a,{top:d}),a.display.scroller.scrollTop!=d&&(a.display.scroller.scrollTop=d),a.display.scrollbarV.scrollTop!=d&&(a.display.scrollbarV.scrollTop=d),gl&&gy(a),dz(a,100))
}function bJ(e,d,f){(f?d==e.doc.scrollLeft:Math.abs(e.doc.scrollLeft-d)<2)||(d=Math.min(d,e.display.scroller.scrollWidth-e.display.scroller.clientWidth),e.doc.scrollLeft=d,gF(e),e.display.scroller.scrollLeft!=d&&(e.display.scroller.scrollLeft=d),e.display.scrollbarH.scrollLeft!=d&&(e.display.scrollbarH.scrollLeft=d))
}function aW(x,w){var v=w.wheelDeltaX,u=w.wheelDeltaY;
null==v&&w.detail&&w.axis==w.HORIZONTAL_AXIS&&(v=w.detail),null==u&&w.detail&&w.axis==w.VERTICAL_AXIS?u=w.detail:null==u&&(u=w.wheelDelta);
var t=x.display,s=t.scroller;
if(v&&s.scrollWidth>s.clientWidth||u&&s.scrollHeight>s.clientHeight){if(u&&fS&&f5){gl:for(var r=w.target,q=t.view;
r!=s;
r=r.parentNode){for(var p=0;
p<q.length;
p++){if(q[p].node==r){x.display.currentWheelTarget=r;
break gl
}}}}if(v&&!gl&&!fZ&&null!=ba){return u&&b3(x,Math.max(0,Math.min(s.scrollTop+u*ba,s.scrollHeight-s.clientHeight))),bJ(x,Math.max(0,Math.min(s.scrollLeft+v*ba,s.scrollWidth-s.clientWidth))),dB(w),t.wheelStartX=null,void 0
}if(u&&null!=ba){var i=u*ba,f=x.doc.scrollTop,a=f+t.wrapper.clientHeight;
0>i?f=Math.max(0,f+i-50):a=Math.min(x.doc.height,a+i+50),gy(x,{top:f,bottom:a})
}20>bv&&(null==t.wheelStartX?(t.wheelStartX=s.scrollLeft,t.wheelStartY=s.scrollTop,t.wheelDX=v,t.wheelDY=u,setTimeout(function(){if(null!=t.wheelStartX){var e=s.scrollLeft-t.wheelStartX,d=s.scrollTop-t.wheelStartY,g=d&&t.wheelDY&&d/t.wheelDY||e&&t.wheelDX&&e/t.wheelDX;
t.wheelStartX=t.wheelStartY=null,g&&(ba=(ba*bv+g)/(bv+1),++bv)
}},200)):(t.wheelDX+=v,t.wheelDY+=u))
}}function aI(g,f,j){if("string"==typeof f&&(f=bu[f],!f)){return !1
}g.display.pollingFast&&bQ(g)&&(g.display.pollingFast=!1);
var i=g.display.shift,h=!1;
try{gT(g)&&(g.state.suppressEdits=!0),j&&(g.display.shift=!1),h=f(g)!=bl
}finally{g.display.shift=i,g.state.suppressEdits=!1
}return h
}function an(g,f,j){for(var i=0;
i<g.state.keyMaps.length;
i++){var h=aH(f,g.state.keyMaps[i],j);
if(h){return h
}}return g.options.extraKeys&&aH(f,g.options.extraKeys,j)||aH(f,g.options.keyMap,j)
}function hj(h,g,l,k){var j=h.state.keySeq;
if(j){if(am(g)){return"handled"
}hF.set(50,function(){h.state.keySeq==j&&(h.state.keySeq=null,c0(h))
}),g=j+" "+g
}var i=an(h,g,k);
return"multi"==i&&(h.state.keySeq=g),"handled"==i&&aT(h,"keyHandled",h,g,l),("handled"==i||"multi"==i)&&(dB(l),dM(h)),j&&!i&&/\'$/.test(g)?(dB(l),!0):!!i
}function bW(e,d){var f=hE(d,!0);
return f?d.shiftKey&&!e.state.keySeq?hj(e,"Shift-"+f,d,function(a){return aI(e,a,!0)
})||hj(e,f,d,function(a){return("string"==typeof a?/^go[A-Z]/.test(a):a.motion)?aI(e,a):void 0
}):hj(e,f,d,function(a){return aI(e,a)
}):!1
}function bC(e,d,f){return hj(e,"'"+f+"'",d,function(a){return aI(e,a,!0)
})
}function a3(e){var d=this;
if(hq(d),!ak(d,e)){f9&&11>f7&&27==e.keyCode&&(e.returnValue=!1);
var h=e.keyCode;
d.display.shift=16==h||e.shiftKey;
var g=bW(d,e);
fZ&&(bo=g?h:null,!g&&88==h&&!br&&(fS?e.metaKey:e.ctrlKey)&&d.replaceSelection("",null,"cut")),18!=h||/\bCodeMirror-crosshair\b/.test(d.display.lineDiv.className)||aP(d)
}}function aP(e){function f(b){18!=b.keyCode&&b.altKey||(fu(d,"CodeMirror-crosshair"),bG(document,"keyup",f),bG(document,"mouseover",f))
}var d=e.display.lineDiv;
e9(d,"CodeMirror-crosshair"),b0(document,"keyup",f),b0(document,"mouseover",f)
}function aB(b){16==b.keyCode&&(this.doc.sel.shift=!1),ak(this,b)
}function hM(e){var d=this;
if(!(ak(d,e)||e.ctrlKey&&!e.altKey||fS&&e.metaKey)){var j=e.keyCode,i=e.charCode;
if(fZ&&j==bo){return bo=null,dB(e),void 0
}if(!(fZ&&(!e.which||e.which<10)||fX)||!bW(d,e)){var h=String.fromCharCode(null==i?j:i);
bC(d,e,h)||(f9&&f7>=9&&(d.display.inputHasSelection=null),cu(d))
}}}function hy(b){"nocursor"!=b.options.readOnly&&(b.state.focused||(bs(b,"focus",b),b.state.focused=!0,e9(b.display.wrapper,"CodeMirror-focused"),b.curOp||b.display.selForContextMenu==b.doc.sel||(c0(b),f5&&setTimeout(dU(c0,b,!0),0))),cH(b),dM(b))
}function g5(b){b.state.focused&&(bs(b,"blur",b),b.state.focused=!1,fu(b.display.wrapper,"CodeMirror-focused")),clearInterval(b.display.blinker),setTimeout(function(){b.state.focused||(b.display.shift=!1)
},150)
}function gr(v,u){function f(){if(null!=t.input.selectionStart){var a=v.somethingSelected(),c=t.input.value="\u200b"+(a?t.input.value:"");
t.prevInput=a?"":"\u200b",t.input.selectionStart=1,t.input.selectionEnd=c.length,t.selForContextMenu=v.doc.sel
}}function e(){if(t.inputDiv.style.position="relative",t.input.style.cssText=p,f9&&9>f7&&(t.scrollbarV.scrollTop=t.scroller.scrollTop=r),cH(v),null!=t.input.selectionStart){(!f9||f9&&9>f7)&&f();
var a=0,c=function(){t.selForContextMenu==v.doc.sel&&0==t.input.selectionStart?fG(v,bu.selectAll)(v):a++<10?t.detectingSelectAll=setTimeout(c,500):c0(v)
};
t.detectingSelectAll=setTimeout(c,200)
}}if(!ak(v,u,"contextmenu")){var t=v.display;
if(!fk(t,u)&&!fF(v,u)){var s=e0(v,u),r=t.scroller.scrollTop;
if(s&&!fZ){var q=v.options.resetSelectionOnContextMenu;
q&&-1==v.doc.sel.contains(s)&&fG(v,hA)(v.doc,bj(s),a0);
var p=t.input.style.cssText;
if(t.inputDiv.style.position="absolute",t.input.style.cssText="position: fixed; width: 30px; height: 30px; top: "+(u.clientY-5)+"px; left: "+(u.clientX-5)+"px; z-index: 1000; background: "+(f9?"rgba(255, 255, 255, .05)":"transparent")+"; outline: none; border-width: 0; outline: none; overflow: hidden; opacity: .05; filter: alpha(opacity=5);",f5){var i=window.scrollY
}if(av(v),f5&&window.scrollTo(null,i),c0(v),v.somethingSelected()||(t.input.value=t.prevInput=" "),t.selForContextMenu=v.doc.sel,clearTimeout(t.detectingSelectAll),f9&&f7>=9&&f(),fO){cK(u);
var d=function(){bG(window,"mouseup",d),setTimeout(e,20)
};
b0(window,"mouseup",d)
}else{setTimeout(e,50)
}}}}}function fF(d,c){return g9(d,"gutterContextMenu")?dr(d,c,"gutterContextMenu",!1,bs):!1
}function e6(f,e){if(c8(f,e.from)<0){return f
}if(c8(f,e.to)<=0){return fr(e)
}var h=f.line+e.text.length-(e.to.line-e.from.line)-1,g=f.ch;
return f.line==e.to.line&&(g+=fr(e).ch-e.to.ch),dt(h,g)
}function eT(g,f){for(var j=[],i=0;
i<g.sel.ranges.length;
i++){var h=g.sel.ranges[i];
j.push(new bL(e6(h.anchor,f),e6(h.head,f)))
}return bx(j,g.sel.primIndex)
}function eG(e,d,f){return e.line==d.line?dt(f.line,e.ch-d.ch+f.ch):dt(f.line+(e.line-d.line),e.ch)
}function et(x,w,v){for(var u=[],t=dt(x.first,0),s=t,r=0;
r<w.length;
r++){var q=w[r],p=eG(q.from,t,s),o=eG(fr(q),t,s);
if(t=q.to,s=o,"around"==v){var n=x.sel.ranges[r],m=c8(n.head,n.anchor)<0;
u[r]=new bL(m?o:p,m?p:o)
}else{u[r]=new bL(p,p)
}}return new b5(u,x.sel.primIndex)
}function ea(f,e,h){var g={canceled:!1,from:e.from,to:e.to,text:e.text,origin:e.origin,cancel:function(){this.canceled=!0
}};
return h&&(g.update=function(a,k,j,i){a&&(this.from=aK(f,a)),k&&(this.to=aK(f,k)),j&&(this.text=j),void 0!==i&&(this.origin=i)
}),bs(f,"beforeChange",f,g),f.cm&&bs(f.cm,"beforeChange",f.cm,g),g.canceled?null:{from:g.from,to:g.to,text:g.text,origin:g.origin}
}function dX(g,f,j){if(g.cm){if(!g.cm.curOp){return fG(g.cm,dX)(g,f,j)
}if(g.cm.state.suppressEdits){return
}}if(!(g9(g,"beforeChange")||g.cm&&g9(g.cm,"beforeChange"))||(f=ea(g,f,!0))){var i=fN&&!j&&dJ(g,f.from,f.to);
if(i){for(var h=i.length-1;
h>=0;
--h){dK(g,{from:i[h].from,to:i[h].to,text:h?[""]:f.text})
}}else{dK(g,f)
}}}function dK(f,e){if(1!=e.text.length||""!=e.text[0]||0!=c8(e.from,e.to)){var h=eT(f,e);
hn(f,e,h,f.cm?f.cm.curOp.id:0/0),cT(f,e,h,es(f,e));
var g=[];
eE(f,function(b,d){d||-1!=eQ(g,b.history)||(dO(b.history,e),g.push(b.history)),cT(b,e,null,es(b,e))
})
}}function dx(B,A,z){if(!B.cm||!B.cm.state.suppressEdits){for(var x,y=B.history,w=B.sel,v="undo"==A?y.done:y.undone,u="undo"==A?y.undone:y.done,t=0;
t<v.length&&(x=v[t],z?!x.ranges||x.equals(B.sel):x.ranges);
t++){}if(t!=v.length){for(y.lastOrigin=y.lastSelOrigin=null;
x=v.pop(),x.ranges;
){if(fv(x,u),z&&!x.equals(B.sel)){return hA(B,x,{clearRedo:!1}),void 0
}w=x
}var s=[];
fv(w,u),u.push({changes:s,generation:y.generation}),y.generation=x.generation||++y.maxGeneration;
for(var r=g9(B,"beforeChange")||B.cm&&g9(B.cm,"beforeChange"),t=x.changes.length-1;
t>=0;
--t){var q=x.changes[t];
if(q.origin=A,r&&!ea(B,q,!1)){return v.length=0,void 0
}s.push(bN(B,q));
var p=t?eT(B,q):fo(v);
cT(B,q,p,dW(B,q)),!t&&B.cm&&B.cm.scrollIntoView({from:q.from,to:fr(q)});
var o=[];
eE(B,function(d,c){c||-1!=eQ(o,d.history)||(dO(d.history,q),o.push(d.history)),cT(d,q,null,dW(d,q))
})
}}}}function dj(f,e){if(0!=e&&(f.first+=e,f.sel=new b5(eD(f.sel.ranges,function(b){return new bL(dt(b.anchor.line+e,b.anchor.ch),dt(b.head.line+e,b.head.ch))
}),f.sel.primIndex),f.cm)){eu(f.cm,f.first,f.first-e,e);
for(var h=f.cm.display,g=h.viewFrom;
g<h.viewTo;
g++){ei(f.cm,g,"gutter")
}}}function cT(h,g,l,k){if(h.cm&&!h.cm.curOp){return fG(h.cm,cT)(h,g,l,k)
}if(g.to.line<h.first){return dj(h,g.text.length-1-(g.to.line-g.from.line)),void 0
}if(!(g.from.line>h.lastLine())){if(g.from.line<h.first){var j=g.text.length-1-(h.first-g.from.line);
dj(h,j),g={from:dt(h.first,0),to:dt(g.to.line+j,g.to.ch),text:[fo(g.text)],origin:g.origin}
}var i=h.lastLine();
g.to.line>i&&(g={from:g.from,to:dt(i,d8(h,i).text.length),text:[g.text[0]],origin:g.origin}),g.removed=dV(h,g.from,g.to),l||(l=eT(h,g)),h.cm?cG(h.cm,g,k):hw(h,g,k),g7(h,l,a0)
}}function cG(z,y,x){var w=z.doc,v=z.display,u=y.from,t=y.to,s=!1,r=u.line;
z.options.lineWrapping||(r=da(ho(d8(w,u.line))),w.iter(r,t.line+1,function(b){return b==v.maxLine?(s=!0,!0):void 0
})),w.sel.contains(y.from,y.to)>-1&&hC(z),hw(w,y,x,g0(z)),z.options.lineWrapping||(w.iter(r,u.line+y.text.length,function(d){var c=gO(d);
c>v.maxLineLength&&(v.maxLine=d,v.maxLineLength=c,v.maxLineChanged=!0,s=!1)
}),s&&(z.curOp.updateMaxLine=!0)),w.frontier=Math.min(w.frontier,u.line),dz(z,400);
var q=y.text.length-(t.line-u.line)-1;
u.line!=t.line||1!=y.text.length||hK(z.doc,y)?eu(z,u.line,t.line+1,q):ei(z,u.line,"text");
var p=g9(z,"changes"),o=g9(z,"change");
if(o||p){var n={from:u,to:t,text:y.text,removed:y.removed,origin:y.origin};
o&&aT(z,"change",z,n),p&&(z.curOp.changeObjs||(z.curOp.changeObjs=[])).push(n)
}z.display.selForContextMenu=null
}function ct(h,g,l,k,j){if(k||(k=l),c8(k,l)<0){var i=k;
k=l,l=i
}"string"==typeof g&&(g=bZ(g)),dX(h,{from:l,to:k,text:g,origin:j})
}function b9(h,g){if(!ak(h,"scrollCursorIntoView")){var l=h.display,k=l.sizer.getBoundingClientRect(),j=null;
if(g.top+k.top<0?j=!0:g.bottom+k.top>(window.innerHeight||document.documentElement.clientHeight)&&(j=!1),null!=j&&!fV){var i=b6("div","\u200b",null,"position: absolute; top: "+(g.top-l.viewOffset-cv(h.display))+"px; height: "+(g.bottom-g.top+bz)+"px; left: "+g.left+"px; width: 2px;");
h.display.lineSpace.appendChild(i),i.scrollIntoView(j),h.display.lineSpace.removeChild(i)
}}}function bP(v,u,t,s){null==s&&(s=0);
for(var r=0;
5>r;
r++){var q=!1,p=co(v,u),o=t&&t!=u?co(v,t):p,n=au(v,Math.min(p.left,o.left),Math.min(p.top,o.top)-s,Math.max(p.left,o.left),Math.max(p.bottom,o.bottom)+s),m=v.doc.scrollTop,l=v.doc.scrollLeft;
if(null!=n.scrollTop&&(b3(v,n.scrollTop),Math.abs(v.doc.scrollTop-m)>1&&(q=!0)),null!=n.scrollLeft&&(bJ(v,n.scrollLeft),Math.abs(v.doc.scrollLeft-l)>1&&(q=!0)),!q){return p
}}}function cZ(h,g,l,k,j){var i=au(h,g,l,k,j);
null!=i.scrollTop&&b3(h,i.scrollTop),null!=i.scrollLeft&&bJ(h,i.scrollLeft)
}function au(H,G,F,E,D){var C=H.display,B=aJ(H.display);
0>F&&(F=0);
var A=H.curOp&&null!=H.curOp.scrollTop?H.curOp.scrollTop:C.scroller.scrollTop,z=C.scroller.clientHeight-bz,y={};
D-F>z&&(D=F+z);
var x=H.doc.height+ci(C),w=B>F,v=D>x-B;
if(A>F){y.scrollTop=w?0:F
}else{if(D>A+z){var u=Math.min(F,(v?x:D)-z);
u!=A&&(y.scrollTop=u)
}}var t=H.curOp&&null!=H.curOp.scrollLeft?H.curOp.scrollLeft:C.scroller.scrollLeft,s=C.scroller.clientWidth-bz-C.gutters.offsetWidth,r=E-G>s;
return r&&(E=G+s),10>G?y.scrollLeft=0:t>G?y.scrollLeft=Math.max(0,G-(r?0:10)):E>s+t-3&&(y.scrollLeft=E+(r?0:10)-s),y
}function hp(e,d,f){(null!=d||null!=f)&&f6(e),null!=d&&(e.curOp.scrollLeft=(null==e.curOp.scrollLeft?e.doc.scrollLeft:e.curOp.scrollLeft)+d),null!=f&&(e.curOp.scrollTop=(null==e.curOp.scrollTop?e.doc.scrollTop:e.curOp.scrollTop)+f)
}function gR(f){f6(f);
var e=f.getCursor(),h=e,g=e;
f.options.lineWrapping||(h=e.ch?dt(e.line,e.ch-1):e,g=dt(e.line,e.ch+1)),f.curOp.scrollToPos={from:h,to:g,margin:f.options.cursorScrollMargin,isCursor:!0}
}function f6(g){var f=g.curOp.scrollToPos;
if(f){g.curOp.scrollToPos=null;
var j=b4(g,f.from),i=b4(g,f.to),h=au(g,Math.min(j.left,i.left),Math.min(j.top,i.top)-f.margin,Math.max(j.right,i.right),Math.max(j.bottom,i.bottom)+f.margin);
g.scrollTo(h.scrollLeft,h.scrollTop)
}}function fx(D,C,B,A){var y,z=D.doc;
null==B&&(B="add"),"smart"==B&&(z.mode.indent?y=cI(D,C):B="prev");
var x=D.options.tabSize,w=d8(z,C),v=hv(w.text,null,x);
w.stateAfter&&(w.stateAfter=null);
var t,u=w.text.match(/^\s*/)[0];
if(A||/\S/.test(w.text)){if("smart"==B&&(t=z.mode.indent(y,w.text.slice(u.length),w.text),t==bl||t>150)){if(!A){return
}B="prev"
}}else{t=0,B="not"
}"prev"==B?t=C>z.first?hv(d8(z,C-1).text,null,x):0:"add"==B?t=v+D.options.indentUnit:"subtract"==B?t=v-D.options.indentUnit:"number"==typeof B&&(t=v+B),t=Math.max(0,t);
var s="",r=0;
if(D.options.indentWithTabs){for(var q=Math.floor(t/x);
q;
--q){r+=x,s+="	"
}}if(t>r&&(s+=fC(t-r)),s!=u){ct(z,s,dt(C,0),dt(C,u.length),"+input")
}else{for(var q=0;
q<z.sel.ranges.length;
q++){var p=z.sel.ranges[q];
if(p.head.line==C&&p.head.ch<u.length){var r=dt(C,u.length);
a5(z,q,new bL(r,r));
break
}}}w.stateAfter=null
}function fj(h,g,l,k){var j=g,i=g;
return"number"==typeof g?i=d8(h,aY(h,g)):j=da(g),null==j?null:(k(i,j)&&h.cm&&ei(h.cm,j,l),i)
}function eZ(i,h){for(var n=i.doc.sel.ranges,m=[],l=0;
l<n.length;
l++){for(var k=h(n[l]);
m.length&&c8(k.from,fo(m).to)<=0;
){var j=m.pop();
if(c8(j.from,k.from)<0){k.from=j.from;
break
}}m.push(k)
}gs(i,function(){for(var a=m.length-1;
a>=0;
a--){ct(i.doc,"",m[a].from,m[a].to,"+delete")
}gR(i)
})
}function eM(L,K,J,I,H){function B(){var a=G+J;
return a<L.first||a>=L.first+L.size?C=!1:(G=a,D=d8(L,a))
}function A(d){var c=(H?gm:fB)(D,F,J,!0);
if(null==c){if(d||!B()){return C=!1
}F=H?(0>J?by:bS)(D):0>J?D.text.length:0
}else{F=c
}return !0
}var G=K.line,F=K.ch,E=J,D=d8(L,G),C=!0;
if("char"==I){A()
}else{if("column"==I){A(!0)
}else{if("word"==I||"group"==I){for(var z=null,y="group"==I,x=L.cm&&L.cm.getHelper(K,"wordChars"),w=!0;
!(0>J)||A(!w);
w=!1){var v=D.text.charAt(F)||"\n",u=c9(v,x)?"w":y&&"\n"==v?"n":!y||/\s/.test(v)?null:"p";
if(!y||w||u||(u="s"),z&&z!=u){0>J&&(J=1,A());
break
}if(u&&(z=u),J>0&&!A(!w)){break
}}}}}var t=e8(L,dt(G,F),E,!0);
return C||(t.hitSide=!0),t
}function ez(r,q,p,o){var l,n=r.doc,m=q.left;
if("page"==o){var k=Math.min(r.display.wrapper.clientHeight,window.innerHeight||document.documentElement.clientHeight);
l=q.top+p*(k-(0>p?1.5:0.5)*aJ(r.display))
}else{"line"==o&&(l=p>0?q.bottom+3:q.top-3)
}for(;
;
){var j=bw(r,m,l);
if(!j.outside){break
}if(0>p?0>=l:l>=n.height){j.hitSide=!0;
break
}l+=5*p
}return j
}function dQ(f,e,h,g){fL.defaults[f]=e,h&&(d3[f]=g?function(i,c,j){j!=dD&&h(i,c,j)
}:h)
}function aV(j){for(var p,o,n,m,i=j.split(/-(?!$)/),j=i[i.length-1],l=0;
l<i.length-1;
l++){var k=i[l];
if(/^(cmd|meta|m)$/i.test(k)){m=!0
}else{if(/^a(lt)?$/i.test(k)){p=!0
}else{if(/^(c|ctrl|control)$/i.test(k)){o=!0
}else{if(!/^s(hift)$/i.test(k)){throw new Error("Unrecognized modifier name: "+k)
}n=!0
}}}}return p&&(j="Alt-"+j),o&&(j="Ctrl-"+j),m&&(j="Cmd-"+j),n&&(j="Shift-"+j),j
}function hi(b){return"string"==typeof b?a9[b]:b
}function a2(v,u,t,s,r){if(s&&s.shared){return aA(v,u,t,s,r)
}if(v.cm&&!v.cm.curOp){return fG(v.cm,a2)(v,u,t,s,r)
}var q=new bB(v,r),p=c8(u,t);
if(s&&d7(s,q,!1),p>0||0==p&&q.clearWhenEmpty!==!1){return q
}if(q.replacedWith&&(q.collapsed=!0,q.widgetNode=b6("span",[q.replacedWith],"CodeMirror-widget"),s.handleMouseEvents||(q.widgetNode.ignoreEvents=!0),s.insertLeft&&(q.widgetNode.insertLeft=!0)),q.collapsed){if(at(v,u.line,u,t,q)||u.line!=t.line&&at(v,t.line,u,t,q)){throw new Error("Inserting collapsed marker partially overlapping an existing one")
}fM=!0
}q.addToHistory&&hn(v,{from:u,to:t,origin:"markText"},v.sel,0/0);
var m,o=u.line,n=v.cm;
if(v.iter(o,t.line+1,function(b){n&&q.collapsed&&!n.options.lineWrapping&&ho(b)==n.display.maxLine&&(m=!0),q.collapsed&&o!=u.line&&dv(b,0),e5(b,new gq(q,o==u.line?u.ch:null,o==t.line?t.ch:null)),++o
}),q.collapsed&&v.iter(u.line,t.line+1,function(a){fi(v,a)&&dv(a,0)
}),q.clearOnEnter&&b0(q,"beforeCursorEnter",function(){q.clear()
}),q.readOnly&&(fN=!0,(v.history.done.length||v.history.undone.length)&&v.clearHistory()),q.collapsed&&(q.id=++bn,q.atomic=!0),n){if(m&&(n.curOp.updateMaxLine=!0),q.collapsed){eu(n,u.line,t.line+1)
}else{if(q.className||q.title||q.startStyle||q.endStyle){for(var l=u.line;
l<=t.line;
l++){ei(n,l,"text")
}}}q.atomic&&fI(n.doc),aT(n,"markerAdded",n,q)
}return q
}function aA(j,i,p,o,n){o=d7(o),o.shared=!1;
var m=[a2(j,i,p,o,n)],l=m[0],k=o.widgetNode;
return eE(j,function(b){k&&(o.widgetNode=k.cloneNode(!0)),m.push(a2(b,aK(b,i),aK(b,p),o,n));
for(var c=0;
c<b.linked.length;
++c){if(b.linked[c].isParent){return
}}l=fo(m)
}),new aO(m,l)
}function hL(b){return b.findMarks(dt(b.first,0),b.clipPos(dt(b.lastLine())),function(c){return c.parent
})
}function hx(j,i){for(var p=0;
p<i.length;
p++){var o=i[p],n=o.find(),m=j.clipPos(n.from),l=j.clipPos(n.to);
if(c8(m,l)){var k=a2(j,m,l,o.primary,o.primary.type);
o.markers.push(k),k.parent=o
}}}function g4(h){for(var g=0;
g<h.length;
g++){var l=h[g],k=[l.primary.doc];
eE(l.primary.doc,function(b){k.push(b)
});
for(var j=0;
j<l.markers.length;
j++){var i=l.markers[j];
-1==eQ(k,i.doc)&&(i.parent=null,l.markers.splice(j--,1))
}}}function gq(e,d,f){this.marker=e,this.from=d,this.to=f
}function fE(f,e){if(f){for(var h=0;
h<f.length;
++h){var g=f[h];
if(g.marker==e){return g
}}}}function fq(f,e){for(var h,g=0;
g<f.length;
++g){f[g]!=e&&(h||(h=[])).push(f[g])
}return h
}function e5(d,c){d.markedSpans=d.markedSpans?d.markedSpans.concat([c]):[c],c.marker.attachLine(d)
}function eS(r,q,p){if(r){for(var n,o=0;
o<r.length;
++o){var m=r[o],l=m.marker,k=null==m.from||(l.inclusiveLeft?m.from<=q:m.from<q);
if(k||m.from==q&&"bookmark"==l.type&&(!p||!m.marker.insertLeft)){var j=null==m.to||(l.inclusiveRight?m.to>=q:m.to>q);
(n||(n=[])).push(new gq(l,m.from,j?null:m.to))
}}}return n
}function eF(r,q,p){if(r){for(var n,o=0;
o<r.length;
++o){var m=r[o],l=m.marker,k=null==m.to||(l.inclusiveRight?m.to>=q:m.to>q);
if(k||m.from==q&&"bookmark"==l.type&&(!p||m.marker.insertLeft)){var j=null==m.from||(l.inclusiveLeft?m.from<=q:m.from<q);
(n||(n=[])).push(new gq(l,j?null:m.from-q,null==m.to?null:m.to-q))
}}}return n
}function es(H,G){var F=hH(H,G.from.line)&&d8(H,G.from.line).markedSpans,E=hH(H,G.to.line)&&d8(H,G.to.line).markedSpans;
if(!F&&!E){return null
}var D=G.from.ch,C=G.to.ch,B=0==c8(G.from,G.to),A=eS(F,D,B),z=eF(E,C,B),y=1==G.text.length,x=fo(G.text).length+(y?D:0);
if(A){for(var w=0;
w<A.length;
++w){var v=A[w];
if(null==v.to){var u=fE(z,v.marker);
u?y&&(v.to=null==u.to?null:u.to+x):v.to=D
}}}if(z){for(var w=0;
w<z.length;
++w){var v=z[w];
if(null!=v.to&&(v.to+=x),null==v.from){var u=fE(A,v.marker);
u||(v.from=x,y&&(A||(A=[])).push(v))
}else{v.from+=x,y&&(A||(A=[])).push(v)
}}}A&&(A=d9(A)),z&&z!=A&&(z=d9(z));
var t=[A];
if(!y){var r,s=G.text.length-2;
if(s>0&&A){for(var w=0;
w<A.length;
++w){null==A[w].to&&(r||(r=[])).push(new gq(A[w].marker,null,null))
}}for(var w=0;
s>w;
++w){t.push(r)
}t.push(z)
}return t
}function d9(e){for(var d=0;
d<e.length;
++d){var f=e[d];
null!=f.from&&f.from==f.to&&f.marker.clearWhenEmpty!==!1&&e.splice(d--,1)
}return e.length?e:null
}function dW(t,s){var r=eK(t,s),q=es(t,s);
if(!r){return q
}if(!q){return r
}for(var p=0;
p<r.length;
++p){var o=r[p],n=q[p];
if(o&&n){t:for(var m=0;
m<n.length;
++m){for(var l=n[m],k=0;
k<o.length;
++k){if(o[k].marker==l.marker){continue t
}}o.push(l)
}}else{n&&(r[p]=n)
}}return r
}function dJ(z,y,x){var w=null;
if(z.iter(y.line,x.line+1,function(e){if(e.markedSpans){for(var d=0;
d<e.markedSpans.length;
++d){var f=e.markedSpans[d].marker;
!f.readOnly||w&&-1!=eQ(w,f)||(w||(w=[])).push(f)
}}}),!w){return null
}for(var v=[{from:y,to:x}],u=0;
u<w.length;
++u){for(var t=w[u],s=t.find(0),r=0;
r<v.length;
++r){var q=v[r];
if(!(c8(q.to,s.from)<0||c8(q.from,s.to)>0)){var p=[r,1],o=c8(q.from,s.from),n=c8(q.to,s.to);
(0>o||!t.inclusiveLeft&&!o)&&p.push({from:q.from,to:s.from}),(n>0||!t.inclusiveRight&&!n)&&p.push({from:s.to,to:q.to}),v.splice.apply(v,p),r+=p.length-1
}}}return v
}function dw(e){var d=e.markedSpans;
if(d){for(var f=0;
f<d.length;
++f){d[f].marker.detachLine(e)
}e.markedSpans=null
}}function di(e,d){if(d){for(var f=0;
f<d.length;
++f){d[f].marker.attachLine(e)
}e.markedSpans=d
}}function cS(b){return b.inclusiveLeft?-1:0
}function cF(b){return b.inclusiveRight?1:0
}function cs(i,h){var n=i.lines.length-h.lines.length;
if(0!=n){return n
}var m=i.find(),l=h.find(),k=c8(m.from,l.from)||cS(i)-cS(h);
if(k){return -k
}var j=c8(m.to,l.to)||cF(i)-cF(h);
return j?j:h.id-i.id
}function b8(h,g){var k,l=fM&&h.markedSpans;
if(l){for(var j,i=0;
i<l.length;
++i){j=l[i],j.marker.collapsed&&null==(g?j.from:j.to)&&(!k||cs(k,j.marker)<0)&&(k=j.marker)
}}return k
}function bO(b){return b8(b,!0)
}function cY(b){return b8(b,!1)
}function at(x,w,v,u,t){var s=d8(x,w),r=fM&&s.markedSpans;
if(r){for(var q=0;
q<r.length;
++q){var p=r[q];
if(p.marker.collapsed){var o=p.marker.find(0),n=c8(o.from,v)||cS(p.marker)-cS(t),m=c8(o.to,u)||cF(p.marker)-cF(t);
if(!(n>=0&&0>=m||0>=n&&m>=0)&&(0>=n&&(c8(o.to,v)>0||p.marker.inclusiveRight&&t.inclusiveLeft)||n>=0&&(c8(o.from,u)<0||p.marker.inclusiveLeft&&t.inclusiveRight))){return !0
}}}}}function ho(d){for(var c;
c=bO(d);
){d=c.find(-1,!0).line
}return d
}function gP(e){for(var d,f;
d=cY(e);
){e=d.find(1,!0).line,(f||(f=[])).push(e)
}return f
}function f4(f,e){var h=d8(f,e),g=ho(h);
return h==g?e:da(g)
}function fw(f,e){if(e>f.lastLine()){return e
}var g,h=d8(f,e);
if(!fi(f,h)){return e
}for(;
g=cY(h);
){h=g.find(1,!0).line
}return da(h)+1
}function fi(g,f){var j=fM&&f.markedSpans;
if(j){for(var i,h=0;
h<j.length;
++h){if(i=j[h],i.marker.collapsed){if(null==i.from){return !0
}if(!i.marker.widgetNode&&0==i.from&&i.marker.inclusiveLeft&&eY(g,f,i)){return !0
}}}}}function eY(h,g,l){if(null==l.to){var k=l.marker.find(1,!0);
return eY(h,k.line,fE(k.line.markedSpans,l.marker))
}if(l.marker.inclusiveRight&&l.to==g.text.length){return !0
}for(var j,i=0;
i<g.markedSpans.length;
++i){if(j=g.markedSpans[i],j.marker.collapsed&&!j.marker.widgetNode&&j.from==l.to&&(null==j.to||j.to!=l.from)&&(j.marker.inclusiveLeft||l.marker.inclusiveRight)&&eY(h,g,j)){return !0
}}}function ey(e,d,f){cE(d)<(e.curOp&&e.curOp.scrollTop||e.doc.scrollTop)&&hp(e,null,f)
}function d2(d){if(null!=d.height){return d.height
}if(!hm(document.body,d.node)){var c="position: relative;";
d.coverGutter&&(c+="margin-left: -"+d.cm.getGutterElement().offsetWidth+"px;"),aq(d.cm.display.measure,b6("div",[d.node],null,c))
}return d.height=d.node.offsetHeight
}function dP(g,f,j,i){var h=new eL(g,j,i);
return h.noHScroll&&(g.display.alignWidgets=!0),fj(g.doc,f,"widget",function(a){var k=a.widgets||(a.widgets=[]);
if(null==h.insertAt?k.push(h):k.splice(Math.min(k.length-1,Math.max(0,h.insertAt)),0,h),h.line=a,!fi(g.doc,a)){var e=cE(a)<g.doc.scrollTop;
dv(a,a.height+d2(h)),e&&hp(g,null,h.height),g.curOp.forceUpdate=!0
}return !0
}),h
}function dp(g,f,j,i){g.text=f,g.stateAfter&&(g.stateAfter=null),g.styles&&(g.styles=null),null!=g.order&&(g.order=null),dw(g),di(g,j);
var h=i?i(g):1;
h!=g.height&&dv(g,h)
}function c4(b){b.parent=null,dw(b)
}function cL(f,e){if(f){for(;
;
){var h=f.match(/(?:^|\s+)line-(background-)?(\S+)/);
if(!h){break
}f=f.slice(0,h.index)+f.slice(h.index+h[0].length);
var g=h[1]?"bgClass":"textClass";
null==e[g]?e[g]=h[2]:new RegExp("(?:^|s)"+h[2]+"(?:$|s)").test(e[g])||(e[g]+=" "+h[2])
}}return f
}function cy(e,d){if(e.blankLine){return e.blankLine(d)
}if(e.innerMode){var f=fL.innerMode(e,d);
return f.mode.blankLine?f.mode.blankLine(f.state):void 0
}}function cl(h,g,l,k){for(var j=0;
10>j;
j++){k&&(k[0]=fL.innerMode(h,l).mode);
var i=h.token(g,l);
if(g.pos>g.start){return i
}}throw new Error("Mode "+h.name+" failed to advance stream.")
}function b1(x,w,v,u){function t(b){return{start:n.start,end:n.pos,string:n.current(),type:q||null,state:b?b2(s.mode,o):o}
}var q,s=x.doc,r=s.mode;
w=aK(s,w);
var m,p=d8(s,w.line),o=cI(x,w.line,v),n=new bV(p.text,x.options.tabSize);
for(u&&(m=[]);
(u||n.pos<w.ch)&&!n.eol();
){n.start=n.pos,q=cl(r,n,o),u&&m.push(t(!0))
}return u?m:t()
}function bH(D,C,B,A,z,y,x){var w=B.flattenSpans;
null==w&&(w=D.options.flattenSpans);
var s,v=0,u=null,t=new bV(C,D.options.tabSize),r=D.options.addModeClass&&[null];
for(""==C&&cL(cy(B,A),y);
!t.eol();
){if(t.pos>D.options.maxHighlightLength?(w=!1,x&&aU(D,C,A,t.pos),t.pos=C.length,s=null):s=cL(cl(B,t,A,r),y),r){var q=r[0].name;
q&&(s="m-"+(s?q+" "+s:q))
}w&&u==s||(v<t.start&&z(t.start,u),v=t.start,u=s),t.start=t.pos
}for(;
v<t.pos;
){var p=Math.min(t.pos,v+50000);
z(p,u),v=p
}}function bt(t,s,r,q){var p=[t.state.modeGen],o={};
bH(t,s.text,t.doc.mode,r,function(d,c){p.push(d,c)
},o,q);
for(var n=0;
n<t.state.overlays.length;
++n){var m=t.state.overlays[n],l=1,k=0;
bH(t,s.text,m.mode,!0,function(g,e){for(var j=l;
g>k;
){var i=p[l];
i>g&&p.splice(l,1,g,p[l+1],i),l+=2,k=Math.min(g,i)
}if(e){if(m.opaque){p.splice(j,l-j,g,"cm-overlay "+e),l=j+2
}else{for(;
l>j;
j+=2){var h=p[j+1];
p[j+1]=(h?h+" ":"")+"cm-overlay "+e
}}}},o)
}return{styles:p,classes:o.bgClass||o.textClass?o:null}
}function a8(f,e,h){if(!e.styles||e.styles[0]!=f.state.modeGen){var g=bt(f,e,e.stateAfter=cI(f,da(e)));
e.styles=g.styles,g.classes?e.styleClasses=g.classes:e.styleClasses&&(e.styleClasses=null),h===f.doc.frontier&&f.doc.frontier++
}return e.styles
}function aU(h,g,l,k){var j=h.doc.mode,i=new bV(g,h.options.tabSize);
for(i.start=i.pos=k||0,""==g&&cy(j,l);
!i.eol()&&i.pos<=h.options.maxHighlightLength;
){cl(j,i,l),i.start=i.pos
}}function hD(e,d){if(!e||/^\s*$/.test(e)){return null
}var f=d.addModeClass?al:aG;
return f[e]||(f[e]=e.replace(/\S+/g,"cm-$&"))
}function ha(f,d){var p=b6("span",null,null,f5?"padding-right: .1px":null),o={pre:b6("pre",[p]),content:p,col:0,pos:0,cm:f};
d.measure={};
for(var n=0;
n<=(d.rest?d.rest.length:0);
n++){var l,m=n?d.rest[n-1]:d.line;
o.pos=0,o.addToken=bA,(f9||f5)&&f.getOption("lineWrapping")&&(o.addToken=bm(o.addToken)),cj(f.display.measure)&&(l=cr(m))&&(o.addToken=a1(o.addToken,l)),o.map=[];
var k=d!=f.display.externalMeasured&&da(m);
az(m,o,a8(f,m,k)),m.styleClasses&&(m.styleClasses.bgClass&&(o.bgClass=eW(m.styleClasses.bgClass,o.bgClass||"")),m.styleClasses.textClass&&(o.textClass=eW(m.styleClasses.textClass,o.textClass||""))),0==o.map.length&&o.map.push(0,0,o.content.appendChild(cJ(f.display.measure))),0==n?(d.measure.map=o.map,d.measure.cache={}):((d.measure.maps||(d.measure.maps=[])).push(o.map),(d.measure.caches||(d.measure.caches=[])).push({}))
}return f5&&/\bcm-tab\b/.test(o.content.lastChild.className)&&(o.content.className="cm-tab-wrap-hack"),bs(f,"renderLine",f,d.line,o.pre),o.pre.className&&(o.textClass=eW(o.pre.className,o.textClass||"")),o
}function bU(d){var c=b6("span","\u2022","cm-invalidchar");
return c.title="\\u"+d.charCodeAt(0).toString(16),c
}function bA(G,F,E,D,C,B){if(F){var A=G.cm.options.specialChars,z=!1;
if(A.test(F)){for(var y=document.createDocumentFragment(),x=0;
;
){A.lastIndex=x;
var w=A.exec(F),v=w?w.index-x:F.length-x;
if(v){var u=document.createTextNode(F.slice(x,x+v));
f9&&9>f7?y.appendChild(b6("span",[u])):y.appendChild(u),G.map.push(G.pos,G.pos+v,u),G.col+=v,G.pos+=v
}if(!w){break
}if(x+=v+1,"	"==w[0]){var t=G.cm.options.tabSize,e=t-G.col%t,u=y.appendChild(b6("span",fC(e),"cm-tab"));
G.col+=e
}else{var u=G.cm.options.specialCharPlaceholder(w[0]);
f9&&9>f7?y.appendChild(b6("span",[u])):y.appendChild(u),G.col+=1
}G.map.push(G.pos,G.pos+1,u),G.pos++
}}else{G.col+=F.length;
var y=document.createTextNode(F);
G.map.push(G.pos,G.pos+F.length,y),f9&&9>f7&&(z=!0),G.pos+=F.length
}if(E||D||C||z){var d=E||"";
D&&(d+=D),C&&(d+=C);
var H=b6("span",[y],d);
return B&&(H.title=B),G.content.appendChild(H)
}G.content.appendChild(y)
}}function bm(d){function c(f){for(var e=" ",g=0;
g<f.length-2;
++g){e+=g%2?" ":"\xa0"
}return e+=" "
}return function(l,k,j,i,b,a){d(l,k.replace(/ {3,}/g,c),j,i,b,a)
}
}function a1(d,c){return function(t,s,r,q,p,o){r=r?r+" cm-force-border":"cm-force-border";
for(var n=t.pos,m=n+s.length;
;
){for(var b=0;
b<c.length;
b++){var a=c[b];
if(a.to>n&&a.from<=n){break
}}if(a.to>=m){return d(t,s,r,q,p,o)
}d(t,s.slice(0,a.to-n),r,q,null,o),q=null,s=s.slice(a.to-n),n=a.to
}}
}function aN(g,f,j,i){var h=!i&&j.widgetNode;
h&&(g.map.push(g.pos,g.pos+f,h),g.content.appendChild(h)),g.pos+=f
}function az(V,U,T){var S=V.markedSpans,R=V.text,Q=0;
if(S){for(var L,J,I,H,G,F,O=R.length,N=0,P=1,M="",K=0;
;
){if(K==N){J=I=H=G="",F=null,K=1/0;
for(var E=[],D=0;
D<S.length;
++D){var C=S[D],B=C.marker;
C.from<=N&&(null==C.to||C.to>N)?(null!=C.to&&K>C.to&&(K=C.to,I=""),B.className&&(J+=" "+B.className),B.startStyle&&C.from==N&&(H+=" "+B.startStyle),B.endStyle&&C.to==K&&(I+=" "+B.endStyle),B.title&&!G&&(G=B.title),B.collapsed&&(!F||cs(F.marker,B)<0)&&(F=C)):C.from>N&&K>C.from&&(K=C.from),"bookmark"==B.type&&C.from==N&&B.widgetNode&&E.push(B)
}if(F&&(F.from||0)==N&&(aN(U,(null==F.to?O+1:F.to)-N,F.marker,null==F.from),null==F.to)){return
}if(!F&&E.length){for(var D=0;
D<E.length;
++D){aN(U,0,E[D])
}}}if(N>=O){break
}for(var A=Math.min(O,K);
;
){if(M){var z=N+M.length;
if(!F){var y=z>A?M.slice(0,A-N):M;
U.addToken(U,y,L?L+J:J,H,N+y.length==K?I:"",G)
}if(z>=A){M=M.slice(A-N),N=A;
break
}N=z,H=""
}M=R.slice(Q,Q=T[P++]),L=hD(T[P++],U.cm.options)
}}}else{for(var P=1;
P<T.length;
P+=2){U.addToken(U,R.slice(Q,Q=T[P]),hD(T[P+1],U.cm.options))
}}}function hK(d,c){return 0==c.from.ch&&0==c.to.ch&&""==fo(c.text)&&(!d.cm||d.cm.options.wholeLineUpdateBefore)
}function hw(F,E,D,C){function B(b){return D?D[b]:null
}function A(b,f,d){dp(b,f,d,C),aT(b,"change",b,E)
}var z=E.from,y=E.to,x=E.text,w=d8(F,z.line),v=d8(F,y.line),u=fo(x),t=B(x.length-1),s=y.line-z.line;
if(hK(F,E)){for(var r=0,q=[];
r<x.length-1;
++r){q.push(new dC(x[r],B(r),C))
}A(v,v.text,t),s&&F.remove(z.line,s),q.length&&F.insert(z.line,q)
}else{if(w==v){if(1==x.length){A(w,w.text.slice(0,z.ch)+u+w.text.slice(y.ch),t)
}else{for(var q=[],r=1;
r<x.length-1;
++r){q.push(new dC(x[r],B(r),C))
}q.push(new dC(u+w.text.slice(y.ch),t,C)),A(w,w.text.slice(0,z.ch)+x[0],B(0)),F.insert(z.line+1,q)
}}else{if(1==x.length){A(w,w.text.slice(0,z.ch)+x[0]+v.text.slice(y.ch),B(0)),F.remove(z.line+1,s)
}else{A(w,w.text.slice(0,z.ch)+x[0],B(0)),A(v,u+v.text.slice(y.ch),t);
for(var r=1,q=[];
r<x.length-1;
++r){q.push(new dC(x[r],B(r),C))
}s>1&&F.remove(z.line+1,s-1),F.insert(z.line+1,q)
}}}aT(F,"change",F,E)
}function g3(e){this.lines=e,this.parent=null;
for(var d=0,f=0;
d<e.length;
++d){e[d].parent=this,f+=e[d].height
}this.height=f
}function gp(g){this.children=g;
for(var f=0,j=0,i=0;
i<g.length;
++i){var h=g[i];
f+=h.chunkSize(),j+=h.height,h.parent=this
}this.size=f,this.height=j,this.parent=null
}function eE(f,e,h){function g(b,l,k){if(b.linked){for(var j=0;
j<b.linked.length;
++j){var d=b.linked[j];
if(d.doc!=l){var c=k&&d.sharedHist;
(!h||c)&&(e(d.doc,c),g(d.doc,b,c))
}}}}g(f,null,!0)
}function er(d,c){if(c.cm){throw new Error("This document is already in use.")
}d.doc=c,c.cm=d,gY(d),fJ(d),d.options.lineWrapping||gM(d),d.options.mode=c.modeOption,eu(d)
}function d8(h,g){if(g-=h.first,0>g||g>=h.size){throw new Error("There is no line "+(g+h.first)+" in the document.")
}for(var l=h;
!l.lines;
){for(var k=0;
;
++k){var j=l.children[k],i=j.chunkSize();
if(i>g){l=j;
break
}g-=i
}}return l.lines[g]
}function dV(g,f,j){var i=[],h=f.line;
return g.iter(f.line,j.line+1,function(b){var c=b.text;
h==j.line&&(c=c.slice(0,j.ch)),h==f.line&&(c=c.slice(f.ch)),i.push(c),++h
}),i
}function dI(f,e,h){var g=[];
return f.iter(e,h,function(b){g.push(b.text)
}),g
}function dv(f,e){var h=e-f.height;
if(h){for(var g=f;
g;
g=g.parent){g.height+=h
}}}function da(g){if(null==g.parent){return null
}for(var f=g.parent,j=eQ(f.lines,g),i=f.parent;
i;
f=i,i=i.parent){for(var h=0;
i.children[h]!=f;
++h){j+=i.children[h].chunkSize()
}}return j+f.first
}function cR(j,i){var p=j.first;
j:do{for(var o=0;
o<j.children.length;
++o){var n=j.children[o],m=n.height;
if(m>i){j=n;
continue j
}i-=m,p+=n.chunkSize()
}return p
}while(!j.lines);
for(var o=0;
o<j.lines.length;
++o){var l=j.lines[o],k=l.height;
if(k>i){break
}i-=k
}return p+o
}function cE(i){i=ho(i);
for(var h=0,n=i.parent,m=0;
m<n.lines.length;
++m){var l=n.lines[m];
if(l==i){break
}h+=l.height
}for(var k=n.parent;
k;
n=k,k=n.parent){for(var m=0;
m<k.children.length;
++m){var j=k.children[m];
if(j==n){break
}h+=j.height
}}return h
}function cr(d){var c=d.order;
return null==c&&(c=d.order=fn(d.text)),c
}function b7(b){this.done=[],this.undone=[],this.undoDepth=1/0,this.lastModTime=this.lastSelTime=0,this.lastOp=this.lastSelOp=null,this.lastOrigin=this.lastSelOrigin=null,this.generation=this.maxGeneration=b||1
}function bN(e,d){var f={from:cP(d.from),to:fr(d),text:dV(e,d.from,d.to)};
return fa(e,f,d.from.line,d.to.line+1),eE(e,function(b){fa(b,f,d.from.line,d.to.line+1)
},!0),f
}function cX(d){for(;
d.length;
){var c=fo(d);
if(!c.ranges){break
}d.pop()
}}function ar(d,c){return c?(cX(d.done),fo(d.done)):d.done.length&&!fo(d.done).ranges?fo(d.done):d.done.length>1&&!d.done[d.done.length-2].ranges?(d.done.pop(),fo(d.done)):void 0
}function hn(r,q,p,o){var n=r.history;
n.undone.length=0;
var l,m=+new Date;
if((n.lastOp==o||n.lastOrigin==q.origin&&q.origin&&("+"==q.origin.charAt(0)&&r.cm&&n.lastModTime>m-r.cm.options.historyEventDelay||"*"==q.origin.charAt(0)))&&(l=ar(n,n.lastOp==o))){var k=fo(l.changes);
0==c8(q.from,q.to)&&0==c8(q.from,k.to)?k.to=fr(q):l.changes.push(bN(r,q))
}else{var j=fo(n.done);
for(j&&j.ranges||fv(r.sel,n.done),l={changes:[bN(r,q)],generation:n.generation},n.done.push(l);
n.done.length>n.undoDepth;
){n.done.shift(),n.done[0].ranges||n.done.shift()
}}n.done.push(p),n.generation=++n.maxGeneration,n.lastModTime=n.lastSelTime=m,n.lastOp=n.lastSelOp=o,n.lastOrigin=n.lastSelOrigin=q.origin,k||bs(r,"historyAdded")
}function gN(g,f,j,i){var h=f.charAt(0);
return"*"==h||"+"==h&&j.ranges.length==i.ranges.length&&j.somethingSelected()==i.somethingSelected()&&new Date-g.history.lastSelTime<=(g.cm?g.cm.options.historyEventDelay:500)
}function f2(h,g,l,k){var j=h.history,i=k&&k.origin;
l==j.lastSelOp||i&&j.lastSelOrigin==i&&(j.lastModTime==j.lastSelTime&&j.lastOrigin==i||gN(h,i,fo(j.done),g))?j.done[j.done.length-1]=g:fv(g,j.done),j.lastSelTime=+new Date,j.lastSelOrigin=i,j.lastSelOp=l,k&&k.clearRedo!==!1&&cX(j.undone)
}function fv(e,d){var f=fo(d);
f&&f.ranges&&f.equals(e)||d.push(e)
}function fa(h,g,l,k){var j=g["spans_"+h.id],i=0;
h.iter(Math.max(h.first,l),Math.min(h.first+h.size,k),function(a){a.markedSpans&&((j||(j=g["spans_"+h.id]={}))[i]=a.markedSpans),++i
})
}function eX(e){if(!e){return null
}for(var f,d=0;
d<e.length;
++d){e[d].marker.explicitlyCleared?f||(f=e.slice(0,d)):f&&f.push(e[d])
}return f?f.length?f:null:e
}function eK(g,f){var j=f["spans_"+g.id];
if(!j){return null
}for(var i=0,h=[];
i<f.text.length;
++i){h.push(eX(j[i]))
}return h
}function ex(x,w,v){for(var u=0,t=[];
u<x.length;
++u){var s=x[u];
if(s.ranges){t.push(v?b5.prototype.deepCopy.call(s):s)
}else{var r=s.changes,q=[];
t.push({changes:q});
for(var p=0;
p<r.length;
++p){var n,o=r[p];
if(q.push({from:o.from,to:o.to,text:o.text}),w){for(var m in o){(n=m.match(/^spans_(\d+)$/))&&eQ(w,Number(n[1]))>-1&&(fo(q)[m]=o[m],delete o[m])
}}}}}return t
}function el(f,e,h,g){h<f.line?f.line+=g:e<f.line&&(f.line=e,f.ch=0)
}function d1(r,q,p,o){for(var n=0;
n<r.length;
++n){var m=r[n],l=!0;
if(m.ranges){m.copied||(m=r[n]=m.deepCopy(),m.copied=!0);
for(var k=0;
k<m.ranges.length;
k++){el(m.ranges[k].anchor,q,p,o),el(m.ranges[k].head,q,p,o)
}}else{for(var k=0;
k<m.changes.length;
++k){var j=m.changes[k];
if(p<j.from.line){j.from=dt(j.from.line+o,j.from.ch),j.to=dt(j.to.line+o,j.to.ch)
}else{if(q<=j.to.line){l=!1;
break
}}}l||(r.splice(0,n+1),n=0)
}}}function dO(g,f){var j=f.from.line,i=f.to.line,h=f.text.length-(i-j)-1;
d1(g.done,j,i,h),d1(g.undone,j,i,h)
}function c3(b){return null!=b.defaultPrevented?b.defaultPrevented:0==b.returnValue
}function cx(b){return b.target||b.srcElement
}function ck(d){var c=d.which;
return null==c&&(1&d.button?c=1:2&d.button?c=3:4&d.button&&(c=2)),fS&&d.ctrlKey&&1==c&&(c=3),c
}function aT(i,h){function k(b){return function(){b.apply(null,m)
}
}var n=i._handlers&&i._handlers[h];
if(n){var l,m=Array.prototype.slice.call(arguments,2);
hG?l=hG.delayedCallbacks:a7?l=a7:(l=a7=[],setTimeout(aF,0));
for(var j=0;
j<n.length;
++j){l.push(k(n[j]))
}}}function aF(){var d=a7;
a7=null;
for(var c=0;
c<d.length;
++c){d[c]()
}}function ak(e,d,f){return"string"==typeof d&&(d={type:d,preventDefault:function(){this.defaultPrevented=!0
}}),bs(e,f||d.type,e,d),c3(d)||d.codemirrorIgnore
}function hC(f){var e=f._handlers&&f._handlers.cursorActivity;
if(e){for(var h=f.curOp.cursorActivityHandlers||(f.curOp.cursorActivityHandlers=[]),g=0;
g<e.length;
++g){-1==eQ(h,e[g])&&h.push(e[g])
}}}function g9(e,d){var f=e._handlers&&e._handlers[d];
return f&&f.length>0
}function bT(b){b.prototype.on=function(d,c){b0(this,d,c)
},b.prototype.off=function(d,c){bG(this,d,c)
}
}function hJ(){this.id=null
}function g2(i,h,n){for(var m=0,l=0;
;
){var k=i.indexOf("	",m);
-1==k&&(k=i.length);
var j=k-m;
if(k==i.length||l+j>=h){return m+Math.min(j,h-l)
}if(l+=k-m,l+=n-l%n,m=k+1,l>=h){return m
}}}function fC(b){for(;
gn.length<=b;
){gn.push(fo(gn)+" ")
}return gn[b]
}function fo(b){return b[b.length-1]
}function eQ(e,d){for(var f=0;
f<e.length;
++f){if(e[f]==d){return f
}}return -1
}function eD(f,e){for(var h=[],g=0;
g<f.length;
g++){h[g]=e(f[g],g)
}return h
}function eq(f,e){var h;
if(Object.create){h=Object.create(f)
}else{var g=function(){};
g.prototype=f,h=new g
}return e&&d7(e,h),h
}function d7(f,e,h){e||(e={});
for(var g in f){!f.hasOwnProperty(g)||h===!1&&e.hasOwnProperty(g)||(e[g]=f[g])
}return e
}function dU(d){var c=Array.prototype.slice.call(arguments,1);
return function(){return d.apply(null,c)
}
}function c9(d,c){return c?c.source.indexOf("\\w")>-1&&du(d)?!0:c.test(d):du(d)
}function cQ(d){for(var c in d){if(d.hasOwnProperty(c)&&d[c]){return !1
}}return !0
}function cq(b){return b.charCodeAt(0)>=768&&cD.test(b)
}function b6(h,g,l,k){var j=document.createElement(h);
if(l&&(j.className=l),k&&(j.style.cssText=k),"string"==typeof g){j.appendChild(document.createTextNode(g))
}else{if(g){for(var i=0;
i<g.length;
++i){j.appendChild(g[i])
}}}return j
}function cW(d){for(var c=d.childNodes.length;
c>0;
--c){d.removeChild(d.firstChild)
}return d
}function aq(d,c){return cW(d).appendChild(c)
}function hm(d,c){if(d.contains){return d.contains(c)
}for(;
c=c.parentNode;
){if(c==d){return !0
}}}function gK(){return document.activeElement
}function f0(b){return new RegExp("(^|\\s)"+b+"(?:$|\\s)\\s*")
}function eW(f,e){for(var h=f.split(" "),g=0;
g<h.length;
g++){h[g]&&!f0(h[g]).test(e)&&(e+=" "+h[g])
}return e
}function eJ(f){if(document.body.getElementsByClassName){for(var e=document.body.getElementsByClassName("CodeMirror"),h=0;
h<e.length;
h++){var g=e[h].CodeMirror;
g&&f(g)
}}}function ek(){ew||(d0(),ew=!0)
}function d0(){var b;
b0(window,"resize",function(){null==b&&(b=setTimeout(function(){b=null,dA=null,eJ(fy)
},100))
}),b0(window,"blur",function(){eJ(g5)
})
}function dm(d){if(null!=dA){return dA
}var c=b6("div",null,null,"width: 50px; height: 50px; overflow-x: scroll");
return aq(d,c),c.offsetWidth&&(dA=c.offsetHeight-c.clientHeight),dA||0
}function cJ(d){if(null==c2){var c=b6("span","\u200b");
aq(d,b6("span",[c,document.createTextNode("x")])),0!=d.firstChild.offsetHeight&&(c2=c.offsetWidth<=1&&c.offsetHeight>2&&!(f9&&8>f7))
}return c2?b6("span","\u200b"):b6("span","\xa0",null,"display: inline-block; width: 1px; margin-right: -1px")
}function cj(f){if(null!=cw){return cw
}var e=aq(f,document.createTextNode("A\u062eA")),h=bM(e,0,1).getBoundingClientRect();
if(!h||h.left==h.right){return !1
}var g=bM(e,1,2).getBoundingClientRect();
return cw=g.right-h.right<3
}function aS(f){if(null!=a6){return a6
}var e=aq(f,b6("span","x")),h=e.getBoundingClientRect(),g=bM(e,0,1).getBoundingClientRect();
return a6=Math.abs(h.left-g.left)>1
}function aj(i,h,n,m){if(!i){return m(h,n,"ltr")
}for(var l=!1,k=0;
k<i.length;
++k){var j=i[k];
(j.from<n&&j.to>h||h==n&&j.to==h)&&(m(Math.max(j.from,h),Math.min(j.to,n),1==j.level?"rtl":"ltr"),l=!0)
}l||m(h,n,"ltr")
}function hB(b){return b.level%2?b.to:b.from
}function g8(b){return b.level%2?b.from:b.to
}function bS(d){var c=cr(d);
return c?hB(c[0]):0
}function by(d){var c=cr(d);
return c?g8(fo(c)):d.text.length
}function bk(h,g){var l=d8(h.doc,g),k=ho(l);
k!=l&&(g=da(k));
var j=cr(k),i=j?j[0].level%2?by(k):bS(k):0;
return dt(g,i)
}function aZ(h,g){for(var l,k=d8(h.doc,g);
l=cY(k);
){k=l.find(1,!0).line,g=null
}var j=cr(k),i=j?j[0].level%2?bS(k):by(k):k.text.length;
return dt(null==g?da(k):g,i)
}function aL(i,h){var n=bk(i,h.line),m=d8(i.doc,n.line),l=cr(m);
if(!l||0==l[0].level){var k=Math.max(0,m.text.search(/\S/)),j=h.line==n.line&&h.ch<=k&&h.ch;
return dt(n.line,j?0:k)
}return n
}function ax(f,e,h){var g=f[0].level;
return e==g?!0:h==g?!1:h>e
}function hu(g,f){hI=null;
for(var i,j=0;
j<g.length;
++j){var h=g[j];
if(h.from<f&&h.to>f){return j
}if(h.from==f||h.to==f){if(null!=i){return ax(g,h.level,g[i].level)?(h.from!=h.to&&(hI=i),j):(h.from!=h.to&&(hI=j),i)
}i=j
}}return i
}function gZ(f,e,h,g){if(!g){return e+h
}do{e+=h
}while(e>0&&cq(f.text.charAt(e)));
return e
}function gm(j,i,p,o){var n=cr(j);
if(!n){return fB(j,i,p,o)
}for(var m=hu(n,i),l=n[m],k=gZ(j,i,l.level%2?-p:p,o);
;
){if(k>l.from&&k<l.to){return k
}if(k==l.from||k==l.to){return hu(n,k)==m?k:(l=n[m+=p],p>0==l.level%2?l.to:l.from)
}if(l=n[m+=p],!l){return null
}k=p>0==l.level%2?gZ(j,l.to,-1,o):gZ(j,l.from,1,o)
}}function fB(g,f,j,i){var h=f+j;
if(i){for(;
h>0&&cq(g.text.charAt(h));
){h+=j
}}return 0>h||h>g.text.length?null:h
}var gl=/gecko\/\d/i.test(navigator.userAgent),gk=/MSIE \d/.test(navigator.userAgent),gi=/Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent),f9=gk||gi,f7=f9&&(gk?document.documentMode||6:gi[1]),f5=/WebKit\//.test(navigator.userAgent),f3=f5&&/Qt\/\d+\.\d+/.test(navigator.userAgent),f1=/Chrome\//.test(navigator.userAgent),fZ=/Opera\//.test(navigator.userAgent),fY=/Apple Computer/.test(navigator.vendor),fX=/KHTML\//.test(navigator.userAgent),fW=/Mac OS X 1\d\D([8-9]|\d\d)\D/.test(navigator.userAgent),fV=/PhantomJS/.test(navigator.userAgent),fU=/AppleWebKit/.test(navigator.userAgent)&&/Mobile\/\w+/.test(navigator.userAgent),fT=fU||/Android|webOS|BlackBerry|Opera Mini|Opera Mobi|IEMobile/i.test(navigator.userAgent),fS=fU||/Mac/.test(navigator.platform),fR=/win/i.test(navigator.platform),fQ=fZ&&navigator.userAgent.match(/Version\/(\d*\.\d*)/);
fQ&&(fQ=Number(fQ[1])),fQ&&fQ>=15&&(fZ=!1,f5=!0);
var fP=fS&&(f3||fZ&&(null==fQ||12.11>fQ)),fO=gl||f9&&f7>=9,fN=!1,fM=!1,dt=fL.Pos=function(d,c){return this instanceof dt?(this.line=d,this.ch=c,void 0):new dt(d,c)
},c8=fL.cmpPos=function(d,c){return d.line-c.line||d.ch-c.ch
};
b5.prototype={primary:function(){return this.ranges[this.primIndex]
},equals:function(f){if(f==this){return !0
}if(f.primIndex!=this.primIndex||f.ranges.length!=this.ranges.length){return !1
}for(var e=0;
e<this.ranges.length;
e++){var h=this.ranges[e],g=f.ranges[e];
if(0!=c8(h.anchor,g.anchor)||0!=c8(h.head,g.head)){return !1
}}return !0
},deepCopy:function(){for(var d=[],c=0;
c<this.ranges.length;
c++){d[c]=new bL(cP(this.ranges[c].anchor),cP(this.ranges[c].head))
}return new b5(d,this.primIndex)
},somethingSelected:function(){for(var b=0;
b<this.ranges.length;
b++){if(!this.ranges[b].empty()){return !0
}}return !1
},contains:function(f,e){e||(e=f);
for(var h=0;
h<this.ranges.length;
h++){var g=this.ranges[h];
if(c8(e,g.from())>=0&&c8(f,g.to())<=0){return h
}}return -1
}},bL.prototype={from:function(){return cp(this.anchor,this.head)
},to:function(){return cC(this.anchor,this.head)
},empty:function(){return this.head.line==this.anchor.line&&this.head.ch==this.anchor.ch
}};
var aX,eA,en,e1={left:0,right:0,top:0,bottom:0},hG=null,hk=0,ca=null,cN=0,bv=0,ba=null;
f9?ba=-0.53:gl?ba=15:f1?ba=-0.7:fY&&(ba=-1/3);
var hF=new hJ,bo=null,fr=fL.changeEnd=function(b){return b.text?dt(b.from.line+b.text.length-1,fo(b.text).length+(1==b.text.length?b.from.ch:0)):b.to
};
fL.prototype={constructor:fL,focus:function(){window.focus(),av(this),cu(this)
},setOption:function(f,e){var h=this.options,g=h[f];
(h[f]!=e||"mode"==f)&&(h[f]=e,d3.hasOwnProperty(f)&&fG(this,d3[f])(this,e,g))
},getOption:function(b){return this.options[b]
},getDoc:function(){return this.doc
},addKeyMap:function(d,c){this.state.keyMaps[c?"push":"unshift"](hi(d))
},removeKeyMap:function(e){for(var d=this.state.keyMaps,f=0;
f<d.length;
++f){if(d[f]==e||d[f].name==e){return d.splice(f,1),!0
}}},addOverlay:fs(function(e,d){var f=e.token?e:fL.getMode(this.options,e);
if(f.startState){throw new Error("Overlays may not be stateful.")
}this.state.overlays.push({mode:f,modeSpec:e,opaque:d&&d.opaque}),this.state.modeGen++,eu(this)
}),removeOverlay:fs(function(f){for(var e=this.state.overlays,h=0;
h<e.length;
++h){var g=e[h].modeSpec;
if(g==f||"string"==typeof f&&g.name==f){return e.splice(h,1),this.state.modeGen++,eu(this),void 0
}}}),indentLine:fs(function(e,d,f){"string"!=typeof d&&"number"!=typeof d&&(d=null==d?this.options.smartIndent?"smart":"prev":d?"add":"subtract"),hH(this.doc,e)&&fx(this,e,d,f)
}),indentSelection:fs(function(t){for(var s=this.doc.sel.ranges,r=-1,q=0;
q<s.length;
q++){var p=s[q];
if(p.empty()){p.head.line>r&&(fx(this,p.head.line,t,!0),r=p.head.line,q==this.doc.sel.primIndex&&gR(this))
}else{var o=p.from(),n=p.to(),m=Math.max(r,o.line);
r=Math.min(this.lastLine(),n.line-(n.ch?0:1))+1;
for(var l=m;
r>l;
++l){fx(this,l,t)
}var k=this.doc.sel.ranges;
0==o.ch&&s.length==k.length&&k[q].from().ch>0&&a5(this.doc,q,new bL(o,k[q].to()),a0)
}}}),getTokenAt:function(d,c){return b1(this,d,c)
},getLineTokens:function(d,c){return b1(this,dt(d),c,!0)
},getTokenTypeAt:function(j){j=aK(this.doc,j);
var m,i=a8(this,d8(this.doc,j.line)),p=0,o=(i.length-1)/2,n=j.ch;
if(0==n){m=i[2]
}else{for(;
;
){var l=p+o>>1;
if((l?i[2*l-1]:0)>=n){o=l
}else{if(!(i[2*l+1]<n)){m=i[2*l+2];
break
}p=l+1
}}}var k=m?m.indexOf("cm-overlay "):-1;
return 0>k?m:0==k?null:m.slice(0,k-1)
},getModeAt:function(d){var c=this.doc.mode;
return c.innerMode?fL.innerMode(c,this.getTokenAt(d).state).mode:c
},getHelper:function(d,c){return this.getHelpers(d,c)[0]
},getHelpers:function(j,i){var p=[];
if(!cm.hasOwnProperty(i)){return cm
}var o=cm[i],n=this.getModeAt(j);
if("string"==typeof n[i]){o[n[i]]&&p.push(o[n[i]])
}else{if(n[i]){for(var m=0;
m<n[i].length;
m++){var l=o[n[i][m]];
l&&p.push(l)
}}else{n.helperType&&o[n.helperType]?p.push(o[n.helperType]):o[n.name]&&p.push(o[n.name])
}}for(var m=0;
m<o._global.length;
m++){var k=o._global[m];
k.pred(n,this)&&-1==eQ(p,k.val)&&p.push(k.val)
}return p
},getStateAfter:function(e,d){var f=this.doc;
return e=aY(f,null==e?f.first+f.size-1:e),cI(this,e+1,d)
},cursorCoords:function(f,e){var h,g=this.doc.sel.primary();
return h=null==f?g.head:"object"==typeof f?aK(this.doc,f):f?g.from():g.to(),co(this,h,e||"page")
},charCoords:function(d,c){return cB(this,aK(this.doc,d),c||"page")
},coordsChar:function(d,c){return d=cO(this,d,c||"page"),bw(this,d.left,d.top)
},lineAtHeight:function(d,c){return d=cO(this,{top:d,left:0},c||"page").top,cR(this.doc,d+this.display.viewOffset)
},heightAtLine:function(g,f){var j=!1,i=this.doc.first+this.doc.size-1;
g<this.doc.first?g=this.doc.first:g>i&&(g=i,j=!0);
var h=d8(this.doc,g);
return c7(this,h,{top:0,left:0},f||"page").top+(j?this.doc.height-cE(h):0)
},defaultTextHeight:function(){return aJ(this.display)
},defaultCharWidth:function(){return ao(this.display)
},setGutterMarker:fs(function(e,d,f){return fj(this.doc,e,"gutter",function(b){var c=b.gutterMarkers||(b.gutterMarkers={});
return c[d]=f,!f&&cQ(c)&&(b.gutterMarkers=null),!0
})
}),clearGutter:fs(function(f){var e=this,h=e.doc,g=h.first;
h.iter(function(a){a.gutterMarkers&&a.gutterMarkers[f]&&(a.gutterMarkers[f]=null,ei(e,g,"gutter"),cQ(a.gutterMarkers)&&(a.gutterMarkers=null)),++g
})
}),addLineWidget:fs(function(e,d,f){return dP(this,e,d,f)
}),removeLineWidget:function(b){b.clear()
},lineInfo:function(d){if("number"==typeof d){if(!hH(this.doc,d)){return null
}var c=d;
if(d=d8(this.doc,d),!d){return null
}}else{var c=da(d);
if(null==c){return null
}}return{line:c,handle:d,text:d.text,gutterMarkers:d.gutterMarkers,textClass:d.textClass,bgClass:d.bgClass,wrapClass:d.wrapClass,widgets:d.widgets}
},getViewport:function(){return{from:this.display.viewFrom,to:this.display.viewTo}
},addWidget:function(t,s,r,q,p){var o=this.display;
t=co(this,aK(this.doc,t));
var n=t.bottom,m=t.left;
if(s.style.position="absolute",o.sizer.appendChild(s),"over"==q){n=t.top
}else{if("above"==q||"near"==q){var l=Math.max(o.wrapper.clientHeight,this.doc.height),k=Math.max(o.sizer.clientWidth,o.lineSpace.clientWidth);
("above"==q||t.bottom+s.offsetHeight>l)&&t.top>s.offsetHeight?n=t.top-s.offsetHeight:t.bottom+s.offsetHeight<=l&&(n=t.bottom),m+s.offsetWidth>k&&(m=k-s.offsetWidth)
}}s.style.top=n+"px",s.style.left=s.style.right="","right"==p?(m=o.sizer.clientWidth-s.offsetWidth,s.style.right="0px"):("left"==p?m=0:"middle"==p&&(m=(o.sizer.clientWidth-s.offsetWidth)/2),s.style.left=m+"px"),r&&cZ(this,m,n,m+s.offsetWidth,n+s.offsetHeight)
},triggerOnKeyDown:fs(a3),triggerOnKeyPress:fs(hM),triggerOnKeyUp:aB,execCommand:function(b){return bu.hasOwnProperty(b)?bu[b](this):void 0
},findPosH:function(i,h,n,m){var l=1;
0>h&&(l=-1,h=-h);
for(var k=0,j=aK(this.doc,i);
h>k&&(j=eM(this.doc,j,l,n,m),!j.hitSide);
++k){}return j
},moveH:fs(function(e,d){var f=this;
f.extendSelectionsBy(function(a){return f.display.shift||f.doc.extend||a.empty()?eM(f.doc,a.head,e,d,f.options.rtlMoveVisually):0>e?a.from():a.to()
},ay)
}),deleteH:fs(function(f,e){var h=this.doc.sel,g=this.doc;
h.somethingSelected()?g.replaceSelection("",null,"+delete"):eZ(this,function(b){var a=eM(g,b.head,f,e,!1);
return 0>f?{from:a,to:b.head}:{from:b.head,to:a}
})
}),findPosV:function(r,q,p,o){var n=1,m=o;
0>q&&(n=-1,q=-q);
for(var l=0,k=aK(this.doc,r);
q>l;
++l){var j=co(this,k,"div");
if(null==m?m=j.left:j.left=m,k=ez(this,j,n,p),k.hitSide){break
}}return k
},moveV:fs(function(i,h){var n=this,m=this.doc,l=[],k=!n.display.shift&&!m.extend&&m.sel.somethingSelected();
if(m.extendSelectionsBy(function(c){if(k){return 0>i?c.from():c.to()
}var b=co(n,c.head,"div");
null!=c.goalColumn&&(b.left=c.goalColumn),l.push(b.left);
var a=ez(n,b,i,h);
return"page"==h&&c==m.sel.primary()&&hp(n,null,cB(n,a,"div").top-b.top),a
},ay),l.length){for(var j=0;
j<m.sel.ranges.length;
j++){m.sel.ranges[j].goalColumn=l[j]
}}}),findWordAt:function(j){var i=this.doc,p=d8(i,j.line).text,o=j.ch,n=j.ch;
if(p){var m=this.getHelper(j,"wordChars");
(j.xRel<0||n==p.length)&&o?--o:++n;
for(var l=p.charAt(o),k=c9(l,m)?function(b){return c9(b,m)
}:/\s/.test(l)?function(b){return/\s/.test(b)
}:function(b){return !/\s/.test(b)&&!c9(b)
};
o>0&&k(p.charAt(o-1));
){--o
}for(;
n<p.length&&k(p.charAt(n));
){++n
}}return new bL(dt(j.line,o),dt(j.line,n))
},toggleOverwrite:function(b){(null==b||b!=this.state.overwrite)&&((this.state.overwrite=!this.state.overwrite)?e9(this.display.cursorDiv,"CodeMirror-overwrite"):fu(this.display.cursorDiv,"CodeMirror-overwrite"),bs(this,"overwriteToggle",this,this.state.overwrite))
},hasFocus:function(){return gK()==this.display.input
},scrollTo:fs(function(d,c){(null!=d||null!=c)&&f6(this),null!=d&&(this.curOp.scrollLeft=d),null!=c&&(this.curOp.scrollTop=c)
}),getScrollInfo:function(){var d=this.display.scroller,c=bz;
return{left:d.scrollLeft,top:d.scrollTop,height:d.scrollHeight-c,width:d.scrollWidth-c,clientHeight:d.clientHeight-c,clientWidth:d.clientWidth-c}
},scrollIntoView:fs(function(e,d){if(null==e?(e={from:this.doc.sel.primary().head,to:null},null==d&&(d=this.options.cursorScrollMargin)):"number"==typeof e?e={from:dt(e,0),to:null}:null==e.from&&(e={from:e,to:null}),e.to||(e.to=e.from),e.margin=d||0,null!=e.from.line){f6(this),this.curOp.scrollToPos=e
}else{var f=au(this,Math.min(e.from.left,e.to.left),Math.min(e.from.top,e.to.top)-e.margin,Math.max(e.from.right,e.to.right),Math.max(e.from.bottom,e.to.bottom)+e.margin);
this.scrollTo(f.scrollLeft,f.scrollTop)
}}),setSize:fs(function(g,f){function i(b){return"number"==typeof b||/^\d+$/.test(String(b))?b+"px":b
}var j=this;
null!=g&&(j.display.wrapper.style.width=i(g)),null!=f&&(j.display.wrapper.style.height=i(f)),j.options.lineWrapping&&d5(this);
var h=j.display.viewFrom;
j.doc.iter(h,j.display.viewTo,function(d){if(d.widgets){for(var c=0;
c<d.widgets.length;
c++){if(d.widgets[c].noHScroll){ei(j,h,"widget");
break
}}}++h
}),j.curOp.forceUpdate=!0,bs(j,"refresh",this)
}),operation:function(b){return gs(this,b)
},refresh:fs(function(){var b=this.display.cachedTextHeight;
eu(this),this.curOp.forceUpdate=!0,dS(this),this.scrollTo(this.doc.scrollLeft,this.doc.scrollTop),gQ(this),(null==b||Math.abs(b-aJ(this.display))>0.5)&&gY(this),bs(this,"refresh",this)
}),swapDoc:fs(function(d){var c=this.doc;
return c.cm=null,er(this,d),dS(this),c0(this),this.scrollTo(d.scrollLeft,d.scrollTop),this.curOp.forceScroll=!0,aT(this,"swapDoc",this,c),c
}),getInputField:function(){return this.display.input
},getWrapperElement:function(){return this.display.wrapper
},getScrollerElement:function(){return this.display.scroller
},getGutterElement:function(){return this.display.gutters
}},bT(fL);
var em=fL.defaults={},d3=fL.optionHandlers={},dD=fL.Init={toString:function(){return"CodeMirror.Init"
}};
dQ("value","",function(d,c){d.setValue(c)
},!0),dQ("mode",null,function(d,c){d.doc.modeOption=c,fJ(d)
},!0),dQ("indentUnit",2,fJ,!0),dQ("indentWithTabs",!1),dQ("smartIndent",!0),dQ("tabSize",4,function(b){fH(b),dS(b),eu(b)
},!0),dQ("specialChars",/[\t\u0000-\u0019\u00ad\u200b-\u200f\u2028\u2029\ufeff]/g,function(d,c){d.options.specialChars=new RegExp(c.source+(c.test("	")?"":"|	"),"g"),d.refresh()
},!0),dQ("specialCharPlaceholder",bU,function(b){b.refresh()
},!0),dQ("electricChars",!0),dQ("rtlMoveVisually",!fR),dQ("wholeLineUpdateBefore",!0),dQ("theme","default",function(b){gW(b),gU(b)
},!0),dQ("keyMap","default",function(g,f,j){var i=hi(f),h=j!=fL.Init&&hi(j);
h&&h.detach&&h.detach(g,i),i.attach&&i.attach(g,h||null)
}),dQ("extraKeys",null),dQ("lineWrapping",!1,g1,!0),dQ("gutters",[],function(b){gL(b.options),gU(b)
},!0),dQ("fixedGutter",!0,function(d,c){d.display.gutters.style.left=c?gC(d.display)+"px":"0",d.refresh()
},!0),dQ("coverGutterNextToScrollbar",!1,gH,!0),dQ("lineNumbers",!1,function(b){gL(b.options),gU(b)
},!0),dQ("firstLineNumber",1,gU,!0),dQ("lineNumberFormatter",function(b){return b
},gU,!0),dQ("showCursorWhenSelecting",!1,ev,!0),dQ("resetSelectionOnContextMenu",!0),dQ("readOnly",!1,function(d,c){"nocursor"==c?(g5(d),d.display.input.blur(),d.display.disabled=!0):(d.display.disabled=!1,c||c0(d))
}),dQ("disableInput",!1,function(d,c){c||c0(d)
},!0),dQ("dragDrop",!0),dQ("cursorBlinkRate",530),dQ("cursorScrollMargin",0),dQ("cursorHeight",1,ev,!0),dQ("singleCursorHeightPerLine",!0,ev,!0),dQ("workTime",100),dQ("workDelay",100),dQ("flattenSpans",!0,fH,!0),dQ("addModeClass",!1,fH,!0),dQ("pollInterval",100),dQ("undoDepth",200,function(d,c){d.doc.history.undoDepth=c
}),dQ("historyEventDelay",1250),dQ("viewportMargin",10,function(b){b.refresh()
},!0),dQ("maxHighlightLength",10000,fH,!0),dQ("moveInputWithCursor",!0,function(d,c){c||(d.display.inputDiv.style.top=d.display.inputDiv.style.left=0)
}),dQ("tabindex",null,function(d,c){d.display.input.tabIndex=c||""
}),dQ("autofocus",null);
var dq=fL.modes={},c5=fL.mimeModes={};
fL.defineMode=function(d,c){fL.defaults.mode||"null"==d||(fL.defaults.mode=d),arguments.length>2&&(c.dependencies=Array.prototype.slice.call(arguments,2)),dq[d]=c
},fL.defineMIME=function(d,c){c5[d]=c
},fL.resolveMode=function(d){if("string"==typeof d&&c5.hasOwnProperty(d)){d=c5[d]
}else{if(d&&"string"==typeof d.name&&c5.hasOwnProperty(d.name)){var c=c5[d.name];
"string"==typeof c&&(c={name:c}),d=eq(c,d),d.name=c.name
}else{if("string"==typeof d&&/^[\w\-]+\/[\w\-]+\+xml$/.test(d)){return fL.resolveMode("application/xml")
}}}return"string"==typeof d?{name:d}:d||{name:"null"}
},fL.getMode=function(h,g){var g=fL.resolveMode(g),l=dq[g.name];
if(!l){return fL.getMode(h,"text/plain")
}var k=l(h,g);
if(cM.hasOwnProperty(g.name)){var j=cM[g.name];
for(var i in j){j.hasOwnProperty(i)&&(k.hasOwnProperty(i)&&(k["_"+i]=k[i]),k[i]=j[i])
}}if(k.name=g.name,g.helperType&&(k.helperType=g.helperType),g.modeProps){for(var i in g.modeProps){k[i]=g.modeProps[i]
}}return k
},fL.defineMode("null",function(){return{token:function(b){b.skipToEnd()
}}
}),fL.defineMIME("text/plain","null");
var cM=fL.modeExtensions={};
fL.extendMode=function(e,d){var f=cM.hasOwnProperty(e)?cM[e]:cM[e]={};
d7(d,f)
},fL.defineExtension=function(d,c){fL.prototype[d]=c
},fL.defineDocExtension=function(d,c){fp.prototype[d]=c
},fL.defineOption=dQ;
var cz=[];
fL.defineInitHook=function(b){cz.push(b)
};
var cm=fL.helpers={};
fL.registerHelper=function(e,d,f){cm.hasOwnProperty(e)||(cm[e]=fL[e]={_global:[]}),cm[e][d]=f
},fL.registerGlobalHelper=function(f,e,h,g){fL.registerHelper(f,e,g),cm[f]._global.push({pred:h,val:g})
};
var b2=fL.copyState=function(g,f){if(f===!0){return f
}if(g.copyState){return g.copyState(f)
}var j={};
for(var i in f){var h=f[i];
h instanceof Array&&(h=h.concat([])),j[i]=h
}return j
},bI=fL.startState=function(e,d,f){return e.startState?e.startState(d,f):!0
};
fL.innerMode=function(e,d){for(;
e.innerMode;
){var f=e.innerMode(d);
if(!f||f.mode==e){break
}d=f.state,e=f.mode
}return f||{mode:e,state:d}
};
var bu=fL.commands={selectAll:function(b){b.setSelection(dt(b.firstLine(),0),dt(b.lastLine()),a0)
},singleSelection:function(b){b.setSelection(b.getCursor("anchor"),b.getCursor("head"),a0)
},killLine:function(b){eZ(b,function(a){if(a.empty()){var d=d8(b.doc,a.head.line).text.length;
return a.head.ch==d&&a.head.line<b.lastLine()?{from:a.head,to:dt(a.head.line+1,0)}:{from:a.head,to:dt(a.head.line,d)}
}return{from:a.from(),to:a.to()}
})
},deleteLine:function(b){eZ(b,function(a){return{from:dt(a.from().line,0),to:aK(b.doc,dt(a.to().line+1,0))}
})
},delLineLeft:function(b){eZ(b,function(c){return{from:dt(c.from().line,0),to:c.from()}
})
},delWrappedLineLeft:function(b){eZ(b,function(a){var f=b.charCoords(a.head,"div").top+5,e=b.coordsChar({left:0,top:f},"div");
return{from:e,to:a.from()}
})
},delWrappedLineRight:function(b){eZ(b,function(a){var f=b.charCoords(a.head,"div").top+5,e=b.coordsChar({left:b.display.lineDiv.offsetWidth+100,top:f},"div");
return{from:a.from(),to:e}
})
},undo:function(b){b.undo()
},redo:function(b){b.redo()
},undoSelection:function(b){b.undoSelection()
},redoSelection:function(b){b.redoSelection()
},goDocStart:function(b){b.extendSelection(dt(b.firstLine(),0))
},goDocEnd:function(b){b.extendSelection(dt(b.lastLine()))
},goLineStart:function(b){b.extendSelectionsBy(function(a){return bk(b,a.head.line)
},{origin:"+move",bias:1})
},goLineStartSmart:function(b){b.extendSelectionsBy(function(a){return aL(b,a.head)
},{origin:"+move",bias:1})
},goLineEnd:function(b){b.extendSelectionsBy(function(a){return aZ(b,a.head.line)
},{origin:"+move",bias:-1})
},goLineRight:function(b){b.extendSelectionsBy(function(a){var d=b.charCoords(a.head,"div").top+5;
return b.coordsChar({left:b.display.lineDiv.offsetWidth+100,top:d},"div")
},ay)
},goLineLeft:function(b){b.extendSelectionsBy(function(a){var d=b.charCoords(a.head,"div").top+5;
return b.coordsChar({left:0,top:d},"div")
},ay)
},goLineLeftSmart:function(b){b.extendSelectionsBy(function(a){var f=b.charCoords(a.head,"div").top+5,e=b.coordsChar({left:0,top:f},"div");
return e.ch<b.getLine(e.line).search(/\S/)?aL(b,a.head):e
},ay)
},goLineUp:function(b){b.moveV(-1,"line")
},goLineDown:function(b){b.moveV(1,"line")
},goPageUp:function(b){b.moveV(-1,"page")
},goPageDown:function(b){b.moveV(1,"page")
},goCharLeft:function(b){b.moveH(-1,"char")
},goCharRight:function(b){b.moveH(1,"char")
},goColumnLeft:function(b){b.moveH(-1,"column")
},goColumnRight:function(b){b.moveH(1,"column")
},goWordLeft:function(b){b.moveH(-1,"word")
},goGroupRight:function(b){b.moveH(1,"group")
},goGroupLeft:function(b){b.moveH(-1,"group")
},goWordRight:function(b){b.moveH(1,"word")
},delCharBefore:function(b){b.deleteH(-1,"char")
},delCharAfter:function(b){b.deleteH(1,"char")
},delWordBefore:function(b){b.deleteH(-1,"word")
},delWordAfter:function(b){b.deleteH(1,"word")
},delGroupBefore:function(b){b.deleteH(-1,"group")
},delGroupAfter:function(b){b.deleteH(1,"group")
},indentAuto:function(b){b.indentSelection("smart")
},indentMore:function(b){b.indentSelection("add")
},indentLess:function(b){b.indentSelection("subtract")
},insertTab:function(b){b.replaceSelection("	")
},insertSoftTab:function(i){for(var h=[],n=i.listSelections(),m=i.options.tabSize,l=0;
l<n.length;
l++){var k=n[l].from(),j=hv(i.getLine(k.line),k.ch,m);
h.push(new Array(m-j%m+1).join(" "))
}i.replaceSelections(h)
},defaultTab:function(b){b.somethingSelected()?b.indentSelection("add"):b.execCommand("insertTab")
},transposeChars:function(b){gs(b,function(){for(var a=b.listSelections(),l=[],k=0;
k<a.length;
k++){var j=a[k].head,i=d8(b.doc,j.line).text;
if(i){if(j.ch==i.length&&(j=new dt(j.line,j.ch-1)),j.ch>0){j=new dt(j.line,j.ch+1),b.replaceRange(i.charAt(j.ch-1)+i.charAt(j.ch-2),dt(j.line,j.ch-2),j,"+transpose")
}else{if(j.line>b.doc.first){var h=d8(b.doc,j.line-1).text;
h&&b.replaceRange(i.charAt(0)+"\n"+h.charAt(h.length-1),dt(j.line-1,h.length-1),dt(j.line,1),"+transpose")
}}}l.push(new bL(j,j))
}b.setSelections(l)
})
},newlineAndIndent:function(b){gs(b,function(){for(var a=b.listSelections().length,f=0;
a>f;
f++){var e=b.listSelections()[f];
b.replaceRange("\n",e.anchor,e.head,"+input"),b.indentLine(e.from().line+1,null,!0),gR(b)
}})
},toggleOverwrite:function(b){b.toggleOverwrite()
}},a9=fL.keyMap={};
a9.basic={Left:"goCharLeft",Right:"goCharRight",Up:"goLineUp",Down:"goLineDown",End:"goLineEnd",Home:"goLineStartSmart",PageUp:"goPageUp",PageDown:"goPageDown",Delete:"delCharAfter",Backspace:"delCharBefore","Shift-Backspace":"delCharBefore",Tab:"defaultTab","Shift-Tab":"indentAuto",Enter:"newlineAndIndent",Insert:"toggleOverwrite",Esc:"singleSelection"},a9.pcDefault={"Ctrl-A":"selectAll","Ctrl-D":"deleteLine","Ctrl-Z":"undo","Shift-Ctrl-Z":"redo","Ctrl-Y":"redo","Ctrl-Home":"goDocStart","Ctrl-End":"goDocEnd","Ctrl-Up":"goLineUp","Ctrl-Down":"goLineDown","Ctrl-Left":"goGroupLeft","Ctrl-Right":"goGroupRight","Alt-Left":"goLineStart","Alt-Right":"goLineEnd","Ctrl-Backspace":"delGroupBefore","Ctrl-Delete":"delGroupAfter","Ctrl-S":"save","Ctrl-F":"find","Ctrl-G":"findNext","Shift-Ctrl-G":"findPrev","Shift-Ctrl-F":"replace","Shift-Ctrl-R":"replaceAll","Ctrl-[":"indentLess","Ctrl-]":"indentMore","Ctrl-U":"undoSelection","Shift-Ctrl-U":"redoSelection","Alt-U":"redoSelection",fallthrough:"basic"},a9.emacsy={"Ctrl-F":"goCharRight","Ctrl-B":"goCharLeft","Ctrl-P":"goLineUp","Ctrl-N":"goLineDown","Alt-F":"goWordRight","Alt-B":"goWordLeft","Ctrl-A":"goLineStart","Ctrl-E":"goLineEnd","Ctrl-V":"goPageDown","Shift-Ctrl-V":"goPageUp","Ctrl-D":"delCharAfter","Ctrl-H":"delCharBefore","Alt-D":"delWordAfter","Alt-Backspace":"delWordBefore","Ctrl-K":"killLine","Ctrl-T":"transposeChars"},a9.macDefault={"Cmd-A":"selectAll","Cmd-D":"deleteLine","Cmd-Z":"undo","Shift-Cmd-Z":"redo","Cmd-Y":"redo","Cmd-Home":"goDocStart","Cmd-Up":"goDocStart","Cmd-End":"goDocEnd","Cmd-Down":"goDocEnd","Alt-Left":"goGroupLeft","Alt-Right":"goGroupRight","Cmd-Left":"goLineLeft","Cmd-Right":"goLineRight","Alt-Backspace":"delGroupBefore","Ctrl-Alt-Backspace":"delGroupAfter","Alt-Delete":"delGroupAfter","Cmd-S":"save","Cmd-F":"find","Cmd-G":"findNext","Shift-Cmd-G":"findPrev","Cmd-Alt-F":"replace","Shift-Cmd-Alt-F":"replaceAll","Cmd-[":"indentLess","Cmd-]":"indentMore","Cmd-Backspace":"delWrappedLineLeft","Cmd-Delete":"delWrappedLineRight","Cmd-U":"undoSelection","Shift-Cmd-U":"redoSelection","Ctrl-Up":"goDocStart","Ctrl-Down":"goDocEnd",fallthrough:["basic","emacsy"]},a9["default"]=fS?a9.macDefault:a9.pcDefault,fL.normalizeKeyMap=function(t){var s={};
for(var r in t){if(t.hasOwnProperty(r)){var q=t[r];
if(/^(name|fallthrough|(de|at)tach)$/.test(r)){continue
}if("..."==q){delete t[r];
continue
}for(var p=eD(r.split(" "),aV),o=0;
o<p.length;
o++){var n,m;
o==p.length-1?(m=r,n=q):(m=p.slice(0,o+1).join(" "),n="...");
var l=s[m];
if(l){if(l!=n){throw new Error("Inconsistent bindings for "+m)
}}else{s[m]=n
}}delete t[r]
}}for(var k in s){t[k]=s[k]
}return t
};
var aH=fL.lookupKey=function(h,g,l){g=hi(g);
var k=g.call?g.call(h):g[h];
if(k===!1){return"nothing"
}if("..."===k){return"multi"
}if(null!=k&&l(k)){return"handled"
}if(g.fallthrough){if("[object Array]"!=Object.prototype.toString.call(g.fallthrough)){return aH(h,g.fallthrough,l)
}for(var j=0;
j<g.fallthrough.length;
j++){var i=aH(h,g.fallthrough[j],l);
if(i){return i
}}}},am=fL.isModifierKey=function(d){var c="string"==typeof d?d:aE[d.keyCode];
return"Ctrl"==c||"Alt"==c||"Shift"==c||"Mod"==c
},hE=fL.keyName=function(f,e){if(fZ&&34==f.keyCode&&f["char"]){return !1
}var h=aE[f.keyCode],g=h;
return null==g||f.altGraphKey?!1:(f.altKey&&"Alt"!=h&&(g="Alt-"+g),(fP?f.metaKey:f.ctrlKey)&&"Ctrl"!=h&&(g="Ctrl-"+g),(fP?f.ctrlKey:f.metaKey)&&"Cmd"!=h&&(g="Cmd-"+g),!e&&f.shiftKey&&"Shift"!=h&&(g="Shift-"+g),g)
};
fL.fromTextArea=function(r,q){function o(){r.value=j.getValue()
}if(q||(q={}),q.value=r.value,!q.tabindex&&r.tabindex&&(q.tabindex=r.tabindex),!q.placeholder&&r.placeholder&&(q.placeholder=r.placeholder),null==q.autofocus){var p=gK();
q.autofocus=p==r||null!=r.getAttribute("autofocus")&&p==document.body
}if(r.form&&(b0(r.form,"submit",o),!q.leaveSubmitMethodAlone)){var n=r.form,m=n.submit;
try{var l=n.submit=function(){o(),n.submit=m,n.submit(),n.submit=l
}
}catch(k){}}r.style.display="none";
var j=fL(function(a){r.parentNode.insertBefore(a,r.nextSibling)
},q);
return j.save=o,j.getTextArea=function(){return r
},j.toTextArea=function(){j.toTextArea=isNaN,o(),r.parentNode.removeChild(j.getWrapperElement()),r.style.display="",r.form&&(bG(r.form,"submit",o),"function"==typeof r.form.submit&&(r.form.submit=m))
},j
};
var bV=fL.StringStream=function(d,c){this.pos=this.start=0,this.string=d,this.tabSize=c||8,this.lastColumnPos=this.lastColumnValue=0,this.lineStart=0
};
bV.prototype={eol:function(){return this.pos>=this.string.length
},sol:function(){return this.pos==this.lineStart
},peek:function(){return this.string.charAt(this.pos)||void 0
},next:function(){return this.pos<this.string.length?this.string.charAt(this.pos++):void 0
},eat:function(e){var d=this.string.charAt(this.pos);
if("string"==typeof e){var f=d==e
}else{var f=d&&(e.test?e.test(d):e(d))
}return f?(++this.pos,d):void 0
},eatWhile:function(d){for(var c=this.pos;
this.eat(d);
){}return this.pos>c
},eatSpace:function(){for(var b=this.pos;
/[\s\u00a0]/.test(this.string.charAt(this.pos));
){++this.pos
}return this.pos>b
},skipToEnd:function(){this.pos=this.string.length
},skipTo:function(d){var c=this.string.indexOf(d,this.pos);
return c>-1?(this.pos=c,!0):void 0
},backUp:function(b){this.pos-=b
},column:function(){return this.lastColumnPos<this.start&&(this.lastColumnValue=hv(this.string,this.start,this.tabSize,this.lastColumnPos,this.lastColumnValue),this.lastColumnPos=this.start),this.lastColumnValue-(this.lineStart?hv(this.string,this.lineStart,this.tabSize):0)
},indentation:function(){return hv(this.string,null,this.tabSize)-(this.lineStart?hv(this.string,this.lineStart,this.tabSize):0)
},match:function(h,g,l){if("string"!=typeof h){var i=this.string.slice(this.pos).match(h);
return i&&i.index>0?null:(i&&g!==!1&&(this.pos+=i[0].length),i)
}var k=function(b){return l?b.toLowerCase():b
},j=this.string.substr(this.pos,h.length);
return k(j)==k(h)?(g!==!1&&(this.pos+=h.length),!0):void 0
},current:function(){return this.string.slice(this.start,this.pos)
},hideFirstChars:function(d,c){this.lineStart+=d;
try{return c()
}finally{this.lineStart-=d
}}};
var bB=fL.TextMarker=function(d,c){this.lines=[],this.type=c,this.doc=d
};
bT(bB),bB.prototype.clear=function(){if(!this.explicitlyCleared){var t=this.doc.cm,s=t&&!t.curOp;
if(s&&bX(t),g9(this,"clear")){var r=this.find();
r&&aT(this,"clear",r.from,r.to)
}for(var q=null,p=null,o=0;
o<this.lines.length;
++o){var n=this.lines[o],m=fE(n.markedSpans,this);
t&&!this.collapsed?ei(t,da(n),"text"):t&&(null!=m.to&&(p=da(n)),null!=m.from&&(q=da(n))),n.markedSpans=fq(n.markedSpans,m),null==m.from&&this.collapsed&&!fi(this.doc,n)&&t&&dv(n,aJ(t.display))
}if(t&&this.collapsed&&!t.options.lineWrapping){for(var o=0;
o<this.lines.length;
++o){var l=ho(this.lines[o]),k=gO(l);
k>t.display.maxLineLength&&(t.display.maxLine=l,t.display.maxLineLength=k,t.display.maxLineChanged=!0)
}}null!=q&&t&&this.collapsed&&eu(t,q,p+1),this.lines.length=0,this.explicitlyCleared=!0,this.atomic&&this.doc.cantEdit&&(this.doc.cantEdit=!1,t&&fI(t.doc)),t&&aT(t,"markerCleared",t,this),s&&bp(t),this.parent&&this.parent.clear()
}},bB.prototype.find=function(i,h){null==i&&"bookmark"==this.type&&(i=1);
for(var n,m,l=0;
l<this.lines.length;
++l){var k=this.lines[l],j=fE(k.markedSpans,this);
if(null!=j.from&&(n=dt(h?k:da(k),j.from),-1==i)){return n
}if(null!=j.to&&(m=dt(h?k:da(k),j.to),1==i)){return m
}}return n&&{from:n,to:m}
},bB.prototype.changed=function(){var e=this.find(-1,!0),d=this,f=this.doc.cm;
e&&f&&gs(f,function(){var j=e.line,i=da(e.line),c=ga(f,i);
if(c&&(eo(c),f.curOp.selectionChanged=f.curOp.forceUpdate=!0),f.curOp.updateMaxLine=!0,!fi(d.doc,j)&&null!=d.height){var b=d.height;
d.height=null;
var a=d2(d)-b;
a&&dv(j,j.height+a)
}})
},bB.prototype.attachLine=function(d){if(!this.lines.length&&this.doc.cm){var c=this.doc.cm.curOp;
c.maybeHiddenMarkers&&-1!=eQ(c.maybeHiddenMarkers,this)||(c.maybeUnhiddenMarkers||(c.maybeUnhiddenMarkers=[])).push(this)
}this.lines.push(d)
},bB.prototype.detachLine=function(d){if(this.lines.splice(eQ(this.lines,d),1),!this.lines.length&&this.doc.cm){var c=this.doc.cm.curOp;
(c.maybeHiddenMarkers||(c.maybeHiddenMarkers=[])).push(this)
}};
var bn=0,aO=fL.SharedTextMarker=function(e,d){this.markers=e,this.primary=d;
for(var f=0;
f<e.length;
++f){e[f].parent=this
}};
bT(aO),aO.prototype.clear=function(){if(!this.explicitlyCleared){this.explicitlyCleared=!0;
for(var b=0;
b<this.markers.length;
++b){this.markers[b].clear()
}aT(this,"clear")
}},aO.prototype.find=function(d,c){return this.primary.find(d,c)
};
var eL=fL.LineWidget=function(f,e,h){if(h){for(var g in h){h.hasOwnProperty(g)&&(this[g]=h[g])
}}this.cm=f,this.node=e
};
bT(eL),eL.prototype.clear=function(){var h=this.cm,g=this.line.widgets,l=this.line,k=da(l);
if(null!=k&&g){for(var j=0;
j<g.length;
++j){g[j]==this&&g.splice(j--,1)
}g.length||(l.widgets=null);
var i=d2(this);
gs(h,function(){ey(h,l,-i),ei(h,k,"widget"),dv(l,Math.max(0,l.height-i))
})
}},eL.prototype.changed=function(){var f=this.height,e=this.cm,h=this.line;
this.height=null;
var g=d2(this)-f;
g&&gs(e,function(){e.curOp.forceUpdate=!0,ey(e,h,g),dv(h,h.height+g)
})
};
var dC=fL.Line=function(e,d,f){this.text=e,di(this,d),this.height=f?f(this):1
};
bT(dC),dC.prototype.lineNo=function(){return da(this)
};
var aG={},al={};
g3.prototype={chunkSize:function(){return this.lines.length
},removeInner:function(g,f){for(var j=g,i=g+f;
i>j;
++j){var h=this.lines[j];
this.height-=h.height,c4(h),aT(h,"delete")
}this.lines.splice(g,f)
},collapse:function(b){b.push.apply(b,this.lines)
},insertInner:function(f,e,h){this.height+=h,this.lines=this.lines.slice(0,f).concat(e).concat(this.lines.slice(f));
for(var g=0;
g<e.length;
++g){e[g].parent=this
}},iterN:function(f,e,h){for(var g=f+e;
g>f;
++f){if(h(this.lines[f])){return !0
}}}},gp.prototype={chunkSize:function(){return this.size
},removeInner:function(j,i){this.size-=i;
for(var p=0;
p<this.children.length;
++p){var o=this.children[p],n=o.chunkSize();
if(n>j){var m=Math.min(i,n-j),l=o.height;
if(o.removeInner(j,m),this.height-=l-o.height,n==m&&(this.children.splice(p--,1),o.parent=null),0==(i-=m)){break
}j=0
}else{j-=n
}}if(this.size-i<25&&(this.children.length>1||!(this.children[0] instanceof g3))){var k=[];
this.collapse(k),this.children=[new g3(k)],this.children[0].parent=this
}},collapse:function(d){for(var c=0;
c<this.children.length;
++c){this.children[c].collapse(d)
}},insertInner:function(j,i,p){this.size+=i.length,this.height+=p;
for(var o=0;
o<this.children.length;
++o){var n=this.children[o],m=n.chunkSize();
if(m>=j){if(n.insertInner(j,i,p),n.lines&&n.lines.length>50){for(;
n.lines.length>50;
){var l=n.lines.splice(n.lines.length-25,25),k=new g3(l);
n.height-=k.height,this.children.splice(o+1,0,k),k.parent=this
}this.maybeSpill()
}break
}j-=m
}},maybeSpill:function(){if(!(this.children.length<=10)){var g=this;
do{var f=g.children.splice(g.children.length-5,5),j=new gp(f);
if(g.parent){g.size-=j.size,g.height-=j.height;
var h=eQ(g.parent.children,g);
g.parent.children.splice(h+1,0,j)
}else{var i=new gp(g.children);
i.parent=g,g.children=[i,j],g=i
}j.parent=g.parent
}while(g.children.length>10);
g.parent.maybeSpill()
}},iterN:function(i,h,n){for(var m=0;
m<this.children.length;
++m){var l=this.children[m],k=l.chunkSize();
if(k>i){var j=Math.min(h,k-i);
if(l.iterN(i,j,n)){return !0
}if(0==(h-=j)){break
}i=0
}else{i-=k
}}}};
var fD=0,fp=fL.Doc=function(f,e,h){if(!(this instanceof fp)){return new fp(f,e,h)
}null==h&&(h=0),gp.call(this,[new g3([new dC("",null)])]),this.first=h,this.scrollTop=this.scrollLeft=0,this.cantEdit=!1,this.cleanGeneration=1,this.frontier=h;
var g=dt(h,0);
this.sel=bj(g),this.history=new b7(null),this.id=++fD,this.modeOption=e,"string"==typeof f&&(f=bZ(f)),hw(this,{from:g,to:g,text:f}),hA(this,bj(g),a0)
};
fp.prototype=eq(gp.prototype,{constructor:fp,iter:function(e,d,f){f?this.iterN(e-this.first,d-e,f):this.iterN(this.first,this.first+this.size,e)
},insert:function(f,e){for(var h=0,g=0;
g<e.length;
++g){h+=e[g].height
}this.insertInner(f-this.first,e,h)
},remove:function(d,c){this.removeInner(d-this.first,c)
},getValue:function(d){var c=dI(this,this.first,this.first+this.size);
return d===!1?c:c.join(d||"\n")
},setValue:e7(function(e){var d=dt(this.first,0),f=this.first+this.size-1;
dX(this,{from:d,to:dt(f,d8(this,f).text.length),text:bZ(e),origin:"setValue"},!0),hA(this,bj(d))
}),replaceRange:function(f,e,h,g){e=aK(this,e),h=h?aK(this,h):e,ct(this,f,e,h,g)
},getRange:function(f,e,h){var g=dV(this,aK(this,f),aK(this,e));
return h===!1?g:g.join(h||"\n")
},getLine:function(d){var c=this.getLineHandle(d);
return c&&c.text
},getLineHandle:function(b){return hH(this,b)?d8(this,b):void 0
},getLineNumber:function(b){return da(b)
},getLineHandleVisualStart:function(b){return"number"==typeof b&&(b=d8(this,b)),ho(b)
},lineCount:function(){return this.size
},firstLine:function(){return this.first
},lastLine:function(){return this.first+this.size-1
},clipPos:function(b){return aK(this,b)
},getCursor:function(e){var f,d=this.sel.primary();
return f=null==e||"head"==e?d.head:"anchor"==e?d.anchor:"end"==e||"to"==e||e===!1?d.to():d.from()
},listSelections:function(){return this.sel.ranges
},somethingSelected:function(){return this.sel.somethingSelected()
},setCursor:e7(function(e,d,f){aR(this,aK(this,"number"==typeof e?dt(e,d||0):e),null,f)
}),setSelection:e7(function(e,d,f){aR(this,aK(this,e),aK(this,d||e),f)
}),extendSelection:e7(function(e,d,f){bE(this,aK(this,e),d&&aK(this,d),f)
}),extendSelections:e7(function(d,c){bq(this,hl(this,d,c))
}),extendSelectionsBy:e7(function(d,c){bq(this,eD(this.sel.ranges,d),c)
}),setSelections:e7(function(g,f,j){if(g.length){for(var i=0,h=[];
i<g.length;
i++){h[i]=new bL(aK(this,g[i].anchor),aK(this,g[i].head))
}null==f&&(f=Math.min(g.length-1,this.sel.primIndex)),hA(this,bx(h,f),j)
}}),addSelection:e7(function(f,e,h){var g=this.sel.ranges.slice(0);
g.push(new bL(aK(this,f),aK(this,e||f))),hA(this,bx(g,g.length-1),h)
}),getSelection:function(g){for(var j,f=this.sel.ranges,i=0;
i<f.length;
i++){var h=dV(this,f[i].from(),f[i].to());
j=j?j.concat(h):h
}return g===!1?j:j.join(g||"\n")
},getSelections:function(g){for(var f=[],j=this.sel.ranges,i=0;
i<j.length;
i++){var h=dV(this,j[i].from(),j[i].to());
g!==!1&&(h=h.join(g||"\n")),f[i]=h
}return f
},replaceSelection:function(g,f,j){for(var i=[],h=0;
h<this.sel.ranges.length;
h++){i[h]=g
}this.replaceSelections(i,f,j||"+input")
},replaceSelections:e7(function(j,i,p){for(var o=[],n=this.sel,m=0;
m<n.ranges.length;
m++){var l=n.ranges[m];
o[m]={from:l.from(),to:l.to(),text:bZ(j[m]),origin:p}
}for(var k=i&&"end"!=i&&et(this,o,i),m=o.length-1;
m>=0;
m--){dX(this,o[m])
}k?ai(this,k):this.cm&&gR(this.cm)
}),undo:e7(function(){dx(this,"undo")
}),redo:e7(function(){dx(this,"redo")
}),undoSelection:e7(function(){dx(this,"undo",!0)
}),redoSelection:e7(function(){dx(this,"redo",!0)
}),setExtending:function(b){this.extend=b
},getExtending:function(){return this.extend
},historySize:function(){for(var f=this.history,e=0,h=0,g=0;
g<f.done.length;
g++){f.done[g].ranges||++e
}for(var g=0;
g<f.undone.length;
g++){f.undone[g].ranges||++h
}return{undo:e,redo:h}
},clearHistory:function(){this.history=new b7(this.history.maxGeneration)
},markClean:function(){this.cleanGeneration=this.changeGeneration(!0)
},changeGeneration:function(b){return b&&(this.history.lastOp=this.history.lastSelOp=this.history.lastOrigin=null),this.history.generation
},isClean:function(b){return this.history.generation==(b||this.cleanGeneration)
},getHistory:function(){return{done:ex(this.history.done),undone:ex(this.history.undone)}
},setHistory:function(d){var c=this.history=new b7(this.history.maxGeneration);
c.done=ex(d.done.slice(0),null,!0),c.undone=ex(d.undone.slice(0),null,!0)
},addLineClass:e7(function(e,d,f){return fj(this,e,"gutter"==d?"gutter":"class",function(b){var c="text"==d?"textClass":"background"==d?"bgClass":"gutter"==d?"gutterClass":"wrapClass";
if(b[c]){if(f0(f).test(b[c])){return !1
}b[c]+=" "+f
}else{b[c]=f
}return !0
})
}),removeLineClass:e7(function(e,d,f){return fj(this,e,"class",function(b){var j="text"==d?"textClass":"background"==d?"bgClass":"gutter"==d?"gutterClass":"wrapClass",i=b[j];
if(!i){return !1
}if(null==f){b[j]=null
}else{var h=i.match(f0(f));
if(!h){return !1
}var c=h.index+h[0].length;
b[j]=i.slice(0,h.index)+(h.index&&c!=i.length?" ":"")+i.slice(c)||null
}return !0
})
}),markText:function(e,d,f){return a2(this,aK(this,e),aK(this,d),f,"range")
},setBookmark:function(e,d){var f={replacedWith:d&&(null==d.nodeType?d.widget:d),insertLeft:d&&d.insertLeft,clearWhenEmpty:!1,shared:d&&d.shared};
return e=aK(this,e),a2(this,e,e,f,"bookmark")
},findMarksAt:function(g){g=aK(this,g);
var f=[],j=d8(this,g.line).markedSpans;
if(j){for(var i=0;
i<j.length;
++i){var h=j[i];
(null==h.from||h.from<=g.ch)&&(null==h.to||h.to>=g.ch)&&f.push(h.marker.parent||h.marker)
}}return f
},findMarks:function(g,f,j){g=aK(this,g),f=aK(this,f);
var i=[],h=g.line;
return this.iter(g.line,f.line+1,function(d){var c=d.markedSpans;
if(c){for(var b=0;
b<c.length;
b++){var a=c[b];
h==g.line&&g.ch>a.to||null==a.from&&h!=g.line||h==f.line&&a.from>f.ch||j&&!j(a.marker)||i.push(a.marker.parent||a.marker)
}}++h
}),i
},getAllMarks:function(){var b=[];
return this.iter(function(a){var f=a.markedSpans;
if(f){for(var e=0;
e<f.length;
++e){null!=f[e].from&&b.push(f[e].marker)
}}}),b
},posFromIndex:function(e){var d,f=this.first;
return this.iter(function(b){var a=b.text.length+1;
return a>e?(d=e,!0):(e-=a,++f,void 0)
}),aK(this,dt(f,d))
},indexFromPos:function(d){d=aK(this,d);
var c=d.ch;
return d.line<this.first||d.ch<0?0:(this.iter(this.first,d.line,function(b){c+=b.text.length+1
}),c)
},copy:function(d){var c=new fp(dI(this,this.first,this.first+this.size),this.modeOption,this.first);
return c.scrollTop=this.scrollTop,c.scrollLeft=this.scrollLeft,c.sel=this.sel,c.extend=!1,d&&(c.history.undoDepth=this.history.undoDepth,c.setHistory(this.getHistory())),c
},linkedDoc:function(f){f||(f={});
var e=this.first,h=this.first+this.size;
null!=f.from&&f.from>e&&(e=f.from),null!=f.to&&f.to<h&&(h=f.to);
var g=new fp(dI(this,e,h),f.mode||this.modeOption,e);
return f.sharedHist&&(g.history=this.history),(this.linked||(this.linked=[])).push({doc:g,sharedHist:f.sharedHist}),g.linked=[{doc:this,isParent:!0,sharedHist:f.sharedHist}],hx(g,hL(this)),g
},unlinkDoc:function(f){if(f instanceof fL&&(f=f.doc),this.linked){for(var e=0;
e<this.linked.length;
++e){var h=this.linked[e];
if(h.doc==f){this.linked.splice(e,1),f.unlinkDoc(this),g4(hL(this));
break
}}}if(f.history==this.history){var g=[f.id];
eE(f,function(b){g.push(b.id)
},!0),f.history=new b7(null),f.history.done=ex(this.history.done,g),f.history.undone=ex(this.history.undone,g)
}},iterLinkedDocs:function(b){eE(this,b)
},getMode:function(){return this.mode
},getEditor:function(){return this.cm
}}),fp.prototype.eachLine=fp.prototype.iter;
var e4="iter insert remove copy getEditor".split(" ");
for(var eR in fp.prototype){fp.prototype.hasOwnProperty(eR)&&eQ(e4,eR)<0&&(fL.prototype[eR]=function(b){return function(){return b.apply(this.doc,arguments)
}
}(fp.prototype[eR]))
}bT(fp);
var dB=fL.e_preventDefault=function(b){b.preventDefault?b.preventDefault():b.returnValue=!1
},dn=fL.e_stopPropagation=function(b){b.stopPropagation?b.stopPropagation():b.cancelBubble=!0
},cK=fL.e_stop=function(b){dB(b),dn(b)
},b0=fL.on=function(g,f,j){if(g.addEventListener){g.addEventListener(f,j,!1)
}else{if(g.attachEvent){g.attachEvent("on"+f,j)
}else{var i=g._handlers||(g._handlers={}),h=i[f]||(i[f]=[]);
h.push(j)
}}},bG=fL.off=function(g,f,j){if(g.removeEventListener){g.removeEventListener(f,j,!1)
}else{if(g.detachEvent){g.detachEvent("on"+f,j)
}else{var i=g._handlers&&g._handlers[f];
if(!i){return
}for(var h=0;
h<i.length;
++h){if(i[h]==j){i.splice(h,1);
break
}}}}},bs=fL.signal=function(g,f){var j=g._handlers&&g._handlers[f];
if(j){for(var i=Array.prototype.slice.call(arguments,2),h=0;
h<j.length;
++h){j[h].apply(null,i)
}}},a7=null,bz=30,bl=fL.Pass={toString:function(){return"CodeMirror.Pass"
}},a0={scroll:!1},aM={origin:"*mouse"},ay={origin:"+move"};
hJ.prototype.set=function(d,c){clearTimeout(this.id),this.id=setTimeout(c,d)
};
var hv=fL.countColumn=function(j,i,p,o,n){null==i&&(i=j.search(/[^\s\u00a0]/),-1==i&&(i=j.length));
for(var m=o||0,l=n||0;
;
){var k=j.indexOf("	",m);
if(0>k||k>=i){return l+(i-m)
}l+=k-m,l+=p-l%p,m=k+1
}},gn=[""],e3=function(b){b.select()
};
fU?e3=function(b){b.selectionStart=0,b.selectionEnd=b.value.length
}:f9&&(e3=function(d){try{d.select()
}catch(c){}}),[].indexOf&&(eQ=function(d,c){return d.indexOf(c)
}),[].map&&(eD=function(d,c){return d.map(c)
});
var bM,dH=/[\u00df\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/,du=fL.isWordChar=function(b){return/\w/.test(b)||b>"\x80"&&(b.toUpperCase()!=b.toLowerCase()||dH.test(b))
},cD=/[\u0300-\u036f\u0483-\u0489\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u065e\u0670\u06d6-\u06dc\u06de-\u06e4\u06e7\u06e8\u06ea-\u06ed\u0711\u0730-\u074a\u07a6-\u07b0\u07eb-\u07f3\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0900-\u0902\u093c\u0941-\u0948\u094d\u0951-\u0955\u0962\u0963\u0981\u09bc\u09be\u09c1-\u09c4\u09cd\u09d7\u09e2\u09e3\u0a01\u0a02\u0a3c\u0a41\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a70\u0a71\u0a75\u0a81\u0a82\u0abc\u0ac1-\u0ac5\u0ac7\u0ac8\u0acd\u0ae2\u0ae3\u0b01\u0b3c\u0b3e\u0b3f\u0b41-\u0b44\u0b4d\u0b56\u0b57\u0b62\u0b63\u0b82\u0bbe\u0bc0\u0bcd\u0bd7\u0c3e-\u0c40\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0cbc\u0cbf\u0cc2\u0cc6\u0ccc\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0d3e\u0d41-\u0d44\u0d4d\u0d57\u0d62\u0d63\u0dca\u0dcf\u0dd2-\u0dd4\u0dd6\u0ddf\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0eb1\u0eb4-\u0eb9\u0ebb\u0ebc\u0ec8-\u0ecd\u0f18\u0f19\u0f35\u0f37\u0f39\u0f71-\u0f7e\u0f80-\u0f84\u0f86\u0f87\u0f90-\u0f97\u0f99-\u0fbc\u0fc6\u102d-\u1030\u1032-\u1037\u1039\u103a\u103d\u103e\u1058\u1059\u105e-\u1060\u1071-\u1074\u1082\u1085\u1086\u108d\u109d\u135f\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17b7-\u17bd\u17c6\u17c9-\u17d3\u17dd\u180b-\u180d\u18a9\u1920-\u1922\u1927\u1928\u1932\u1939-\u193b\u1a17\u1a18\u1a56\u1a58-\u1a5e\u1a60\u1a62\u1a65-\u1a6c\u1a73-\u1a7c\u1a7f\u1b00-\u1b03\u1b34\u1b36-\u1b3a\u1b3c\u1b42\u1b6b-\u1b73\u1b80\u1b81\u1ba2-\u1ba5\u1ba8\u1ba9\u1c2c-\u1c33\u1c36\u1c37\u1cd0-\u1cd2\u1cd4-\u1ce0\u1ce2-\u1ce8\u1ced\u1dc0-\u1de6\u1dfd-\u1dff\u200c\u200d\u20d0-\u20f0\u2cef-\u2cf1\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua66f-\ua672\ua67c\ua67d\ua6f0\ua6f1\ua802\ua806\ua80b\ua825\ua826\ua8c4\ua8e0-\ua8f1\ua926-\ua92d\ua947-\ua951\ua980-\ua982\ua9b3\ua9b6-\ua9b9\ua9bc\uaa29-\uaa2e\uaa31\uaa32\uaa35\uaa36\uaa43\uaa4c\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uabe5\uabe8\uabed\udc00-\udfff\ufb1e\ufe00-\ufe0f\ufe20-\ufe26\uff9e\uff9f]/;
bM=document.createRange?function(f,e,h){var g=document.createRange();
return g.setEnd(f,h),g.setStart(f,e),g
}:function(g,f,j){var i=document.body.createTextRange();
try{i.moveToElementText(g.parentNode)
}catch(h){return i
}return i.collapse(!0),i.moveEnd("character",j),i.moveStart("character",f),i
},f9&&11>f7&&(gK=function(){try{return document.activeElement
}catch(b){return document.body
}});
var dA,c2,cw,fu=fL.rmClass=function(g,f){var j=g.className,i=f0(f).exec(j);
if(i){var h=j.slice(i.index+i[0].length);
g.className=j.slice(0,i.index)+(h?i[1]+h:"")
}},e9=fL.addClass=function(e,d){var f=e.className;
f0(d).test(f)||(e.className+=(f?" ":"")+d)
},ew=!1,dN=function(){if(f9&&9>f7){return !1
}var b=b6("div");
return"draggable" in b||"dragDrop" in b
}(),bZ=fL.splitLines=3!="\n\nb".split(/\n/).length?function(i){for(var h=0,n=[],m=i.length;
m>=h;
){var l=i.indexOf("\n",h);
-1==l&&(l=i.length);
var k=i.slice(h,"\r"==i.charAt(l-1)?l-1:l),j=k.indexOf("\r");
-1!=j?(n.push(k.slice(0,j)),h+=j+1):(n.push(k),h=l+1)
}return n
}:function(b){return b.split(/\r\n?|\n/)
},bF=window.getSelection?function(d){try{return d.selectionStart!=d.selectionEnd
}catch(c){return !1
}}:function(e){try{var d=e.ownerDocument.selection.createRange()
}catch(f){}return d&&d.parentElement()==e?0!=d.compareEndPoints("StartToEnd",d):!1
},br=function(){var b=b6("div");
return"oncopy" in b?!0:(b.setAttribute("oncopy","return;"),"function"==typeof b.oncopy)
}(),a6=null,aE={3:"Enter",8:"Backspace",9:"Tab",13:"Enter",16:"Shift",17:"Ctrl",18:"Alt",19:"Pause",20:"CapsLock",27:"Esc",32:"Space",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"Left",38:"Up",39:"Right",40:"Down",44:"PrintScrn",45:"Insert",46:"Delete",59:";",61:"=",91:"Mod",92:"Mod",93:"Mod",107:"=",109:"-",127:"Delete",173:"-",186:";",187:"=",188:",",189:"-",190:".",191:"/",192:"`",219:"[",220:"\\",221:"]",222:"'",63232:"Up",63233:"Down",63234:"Left",63235:"Right",63272:"Delete",63273:"Home",63275:"End",63276:"PageUp",63277:"PageDown",63302:"Insert"};
fL.keyNames=aE,function(){for(var b=0;
10>b;
b++){aE[b+48]=aE[b+96]=String(b)
}for(var b=65;
90>=b;
b++){aE[b]=String.fromCharCode(b)
}for(var b=1;
12>=b;
b++){aE[b+111]=aE[b+63235]="F"+b
}}();
var hI,fn=function(){function r(a){return 247>=a?t.charAt(a):a>=1424&&1524>=a?"R":a>=1536&&1773>=a?s.charAt(a-1536):a>=1774&&2220>=a?"r":a>=8192&&8203>=a?"w":8204==a?"b":"L"
}function k(e,d,f){this.level=e,this.from=d,this.to=f
}var t="bbbbbbbbbtstwsbbbbbbbbbbbbbbssstwNN%%%NNNNNN,N,N1111111111NNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNbbbbbbsbbbbbbbbbbbbbbbbbbbbbbbbbb,N%%%%NNNNLNNNNN%%11NLNNN1LNNNNNLLLLLLLLLLLLLLLLLLLLLLLNLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLN",s="rrrrrrrrrrrr,rNNmmmmmmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmmmmmmmmrrrrrrrnnnnnnnnnn%nnrrrmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmmmmmmmmmmmmmNmmmm",q=/[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/,p=/[stwN]/,o=/[LRr]/,n=/[Lb1n]/,m=/[1n]/,l="L";
return function(J){if(!q.test(J)){return !1
}for(var F,I=J.length,H=[],G=0;
I>G;
++G){H.push(F=r(J.charCodeAt(G)))
}for(var G=0,E=l;
I>G;
++G){var F=H[G];
"m"==F?H[G]=E:E=F
}for(var G=0,D=l;
I>G;
++G){var F=H[G];
"1"==F&&"r"==D?H[G]="n":o.test(F)&&(D=F,"r"==F&&(H[G]="R"))
}for(var G=1,E=H[0];
I-1>G;
++G){var F=H[G];
"+"==F&&"1"==E&&"1"==H[G+1]?H[G]="1":","!=F||E!=H[G+1]||"1"!=E&&"n"!=E||(H[G]=E),E=F
}for(var G=0;
I>G;
++G){var F=H[G];
if(","==F){H[G]="N"
}else{if("%"==F){for(var C=G+1;
I>C&&"%"==H[C];
++C){}for(var B=G&&"!"==H[G-1]||I>C&&"1"==H[C]?"1":"N",A=G;
C>A;
++A){H[A]=B
}G=C-1
}}}for(var G=0,D=l;
I>G;
++G){var F=H[G];
"L"==D&&"1"==F?H[G]="L":o.test(F)&&(D=F)
}for(var G=0;
I>G;
++G){if(p.test(H[G])){for(var C=G+1;
I>C&&p.test(H[C]);
++C){}for(var j="L"==(G?H[G-1]:l),i="L"==(I>C?H[C]:l),B=j||i?"L":"R",A=G;
C>A;
++A){H[A]=B
}G=C-1
}}for(var g,h=[],G=0;
I>G;
){if(n.test(H[G])){var f=G;
for(++G;
I>G&&n.test(H[G]);
++G){}h.push(new k(0,f,G))
}else{var e=G,d=h.length;
for(++G;
I>G&&"L"!=H[G];
++G){}for(var A=e;
G>A;
){if(m.test(H[A])){A>e&&h.splice(d,0,new k(1,e,A));
var c=A;
for(++A;
G>A&&m.test(H[A]);
++A){}h.splice(d,0,new k(2,c,A)),e=A
}else{++A
}}G>e&&h.splice(d,0,new k(1,e,G))
}}return 1==h[0].level&&(g=J.match(/^\s+/))&&(h[0].from=g[0].length,h.unshift(new k(0,0,g[0].length))),1==fo(h).level&&(g=J.match(/\s+$/))&&(fo(h).to-=g[0].length,h.push(new k(0,I-g[0].length,I))),h[0].level!=fo(h).level&&h.push(new k(h[0].level,I,I)),h
}
}();
return fL.version="4.8.0",fL
}),function(b){"object"==typeof exports&&"object"==typeof module?b(require("../../lib/codemirror")):"function"==typeof define&&define.amd?define(["../../lib/codemirror"],b):b(CodeMirror)
}(function(r){function n(y,x,w,v){var u=y.getLineHandle(x.line),t=x.ch-1,s=t>=0&&o[u.text.charAt(t)]||o[u.text.charAt(++t)];
if(!s){return null
}var f=">"==s.charAt(1)?1:-1;
if(w&&f>0!=(t==x.ch)){return null
}var d=y.getTokenTypeAt(p(x.line,t+1)),c=m(y,p(x.line,t+(f>0?1:0)),f,d||null,v);
return null==c?null:{from:p(x.line,t),to:c&&c.pos,match:c&&c.ch==s.charAt(0),forward:f>0}
}function m(F,E,D,C,B){for(var A=B&&B.maxScanLineLength||10000,z=B&&B.maxScanLines||1000,y=[],x=B&&B.bracketRegex?B.bracketRegex:/[(){}[\]]/,w=D>0?Math.min(E.line+z,F.lastLine()+1):Math.max(F.firstLine()-1,E.line-z),v=E.line;
v!=w;
v+=D){var u=F.getLine(v);
if(u){var t=D>0?0:u.length-1,s=D>0?u.length:-1;
if(!(u.length>A)){for(v==E.line&&(t=E.ch-(0>D?1:0));
t!=s;
t+=D){var d=u.charAt(t);
if(x.test(d)&&(void 0===C||F.getTokenTypeAt(p(v,t+1))==C)){var c=o[d];
if(">"==c.charAt(1)==D>0){y.push(d)
}else{if(!y.length){return{pos:p(v,t),ch:d}
}y.pop()
}}}}}}return v-D==(D>0?F.lastLine():F.firstLine())?!1:null
}function l(y,x,w){for(var v=y.state.matchBrackets.maxHighlightLineLength||1000,u=[],t=y.listSelections(),s=0;
s<t.length;
s++){var e=t[s].empty()&&n(y,t[s].head,!1,w);
if(e&&y.getLine(e.from.line).length<=v){var c=e.match?"CodeMirror-matchingbracket":"CodeMirror-nonmatchingbracket";
u.push(y.markText(e.from,p(e.from.line,e.from.ch+1),{className:c})),e.to&&y.getLine(e.to.line).length<=v&&u.push(y.markText(e.to,p(e.to.line,e.to.ch+1),{className:c}))
}}if(u.length){q&&y.state.focused&&y.display.input.focus();
var b=function(){y.operation(function(){for(var d=0;
d<u.length;
d++){u[d].clear()
}})
};
if(!x){return b
}setTimeout(b,800)
}}function j(b){b.operation(function(){k&&(k(),k=null),k=l(b,!1,b.state.matchBrackets)
})
}var q=/MSIE \d/.test(navigator.userAgent)&&(null==document.documentMode||document.documentMode<8),p=r.Pos,o={"(":")>",")":"(<","[":"]>","]":"[<","{":"}>","}":"{<"},k=null;
r.defineOption("matchBrackets",!1,function(a,f,e){e&&e!=r.Init&&a.off("cursorActivity",j),f&&(a.state.matchBrackets="object"==typeof f?f:{},a.on("cursorActivity",j))
}),r.defineExtension("matchBrackets",function(){l(this,!0)
}),r.defineExtension("findMatchingBracket",function(e,d,f){return n(this,e,d,f)
}),r.defineExtension("scanForBracket",function(f,e,h,g){return m(this,f,e,h,g)
})
}),function(b){"object"==typeof exports&&"object"==typeof module?b(require("../../lib/codemirror")):"function"==typeof define&&define.amd?define(["../../lib/codemirror"],b):b(CodeMirror)
}(function(r){function o(d,c){this.cm=d,this.options=this.buildOptions(c),this.widget=this.onClose=null
}function n(b){return"string"==typeof b?b:b.text
}function m(s,i){function v(b,e){var c;
c="string"!=typeof e?function(d){return e(d,i)
}:y.hasOwnProperty(e)?y[e]:e,w[b]=c
}var y={Up:function(){i.moveFocus(-1)
},Down:function(){i.moveFocus(1)
},PageUp:function(){i.moveFocus(-i.menuSize()+1,!0)
},PageDown:function(){i.moveFocus(i.menuSize()-1,!0)
},Home:function(){i.setFocus(0)
},End:function(){i.setFocus(i.length-1)
},Enter:i.pick,Tab:i.pick,Esc:i.close},x=s.options.customKeys,w=x?{}:y;
if(x){for(var u in x){x.hasOwnProperty(u)&&v(u,x[u])
}}var t=s.options.extraKeys;
if(t){for(var u in t){t.hasOwnProperty(u)&&v(u,t[u])
}}return w
}function l(d,c){for(;
c&&c!=d;
){if("LI"===c.nodeName.toUpperCase()&&c.parentNode==d){return c
}c=c.parentNode
}}function k(V,U){this.completion=V,this.data=U;
var T=this,S=V.cm,R=this.hints=document.createElement("ul");
R.className="CodeMirror-hints",this.selectedHint=U.selectedHint||0;
for(var Q=U.list,P=0;
P<Q.length;
++P){var O=R.appendChild(document.createElement("li")),N=Q[P],M=q+(P!=this.selectedHint?"":" "+p);
null!=N.className&&(M=N.className+" "+M),O.className=M,N.render?N.render(O,U,N):O.appendChild(document.createTextNode(N.displayText||n(N))),O.hintId=P
}var K=S.cursorCoords(V.options.alignWithWord?U.from:null),I=K.left,G=K.bottom,E=!0;
R.style.left=I+"px",R.style.top=G+"px";
var g=window.innerWidth||Math.max(document.body.offsetWidth,document.documentElement.offsetWidth),f=window.innerHeight||Math.max(document.body.offsetHeight,document.documentElement.offsetHeight);
(V.options.container||document.body).appendChild(R);
var e=R.getBoundingClientRect(),c=e.bottom-f;
if(c>0){var b=e.bottom-e.top,a=K.top-(K.bottom-e.top);
if(a-b>0){R.style.top=(G=K.top-b)+"px",E=!1
}else{if(b>f){R.style.height=f-5+"px",R.style.top=(G=K.bottom-e.top)+"px";
var L=S.getCursor();
U.from.ch!=L.ch&&(K=S.cursorCoords(L),R.style.left=(I=K.left)+"px",e=R.getBoundingClientRect())
}}}var J=e.left-g;
if(J>0&&(e.right-e.left>g&&(R.style.width=g-5+"px",J-=e.right-e.left-g),R.style.left=(I=K.left-J)+"px"),S.addKeyMap(this.keyMap=m(V,{moveFocus:function(h,d){T.changeActive(T.selectedHint+h,d)
},setFocus:function(d){T.changeActive(d)
},menuSize:function(){return T.screenAmount()
},length:Q.length,close:function(){V.close()
},pick:function(){T.pick()
},data:U})),V.options.closeOnUnfocus){var H;
S.on("blur",this.onBlur=function(){H=setTimeout(function(){V.close()
},100)
}),S.on("focus",this.onFocus=function(){clearTimeout(H)
})
}var F=S.getScrollInfo();
return S.on("scroll",this.onScroll=function(){var h=S.getScrollInfo(),d=S.getWrapperElement().getBoundingClientRect(),s=G+F.top-h.top,i=s-(window.pageYOffset||(document.documentElement||document.body).scrollTop);
return E||(i+=R.offsetHeight),i<=d.top||i>=d.bottom?V.close():(R.style.top=s+"px",R.style.left=I+F.left-h.left+"px",void 0)
}),r.on(R,"dblclick",function(h){var d=l(R,h.target||h.srcElement);
d&&null!=d.hintId&&(T.changeActive(d.hintId),T.pick())
}),r.on(R,"click",function(h){var d=l(R,h.target||h.srcElement);
d&&null!=d.hintId&&(T.changeActive(d.hintId),V.options.completeOnSingleClick&&T.pick())
}),r.on(R,"mousedown",function(){setTimeout(function(){S.focus()
},20)
}),r.signal(U,"select",Q[0],R.firstChild),!0
}var q="CodeMirror-hint",p="CodeMirror-hint-active";
r.showHint=function(g,f,s){if(!f){return g.showHint(s)
}s&&s.async&&(f.async=!0);
var i={hint:f};
if(s){for(var h in s){i[h]=s[h]
}}return g.showHint(i)
},r.defineExtension("showHint",function(a){if(!(this.listSelections().length>1||this.somethingSelected())){this.state.completionActive&&this.state.completionActive.close();
var f=this.state.completionActive=new o(this,a),d=f.options.hint;
if(d){return r.signal(this,"startCompletion",this),d.async?(d(this,function(b){f.showHints(b)
},f.options),void 0):f.showHints(d(this,f.options))
}}}),o.prototype={close:function(){this.active()&&(this.cm.state.completionActive=null,this.widget&&this.widget.close(),this.onClose&&this.onClose(),r.signal(this.cm,"endCompletion",this.cm))
},active:function(){return this.cm.state.completionActive==this
},pick:function(a,f){var e=a.list[f];
e.hint?e.hint(this.cm,a,e):this.cm.replaceRange(n(e),e.from||a.from,e.to||a.to,"complete"),r.signal(a,"pick",e),this.close()
},showHints:function(b){return b&&b.list.length&&this.active()?(this.options.completeSingle&&1==b.list.length?this.pick(b,0):this.showWidget(b),void 0):this.close()
},showWidget:function(D){function u(){A||(A=!0,B.close(),B.cm.off("cursorActivity",a),D&&r.signal(D,"close"))
}function t(){if(!A){r.signal(D,"update");
var b=B.options.hint;
b.async?b(B.cm,s,B.options):s(b(B.cm,B.options))
}}function s(b){if(D=b,!A){if(!D||!D.list.length){return u()
}B.widget&&B.widget.close(),B.widget=new k(B,D)
}}function h(){C&&(v(C),C=0)
}function a(){h();
var d=B.cm.getCursor(),c=B.cm.getLine(d.line);
d.line!=y.line||c.length-d.ch!=x-y.ch||d.ch<y.ch||B.cm.somethingSelected()||d.ch&&z.test(c.charAt(d.ch-1))?B.close():(C=w(t),B.widget&&B.widget.close())
}this.widget=new k(this,D),r.signal(D,"shown");
var A,C=0,B=this,z=this.options.closeCharacters,y=this.cm.getCursor(),x=this.cm.getLine(y.line).length,w=window.requestAnimationFrame||function(b){return setTimeout(b,1000/60)
},v=window.cancelAnimationFrame||clearTimeout;
this.cm.on("cursorActivity",a),this.onClose=u
},buildOptions:function(f){var e=this.cm.options.hintOptions,h={};
for(var g in j){h[g]=j[g]
}if(e){for(var g in e){void 0!==e[g]&&(h[g]=e[g])
}}if(f){for(var g in f){void 0!==f[g]&&(h[g]=f[g])
}}return h
}},k.prototype={close:function(){if(this.completion.widget==this){this.completion.widget=null,this.hints.parentNode.removeChild(this.hints),this.completion.cm.removeKeyMap(this.keyMap);
var b=this.completion.cm;
this.completion.options.closeOnUnfocus&&(b.off("blur",this.onBlur),b.off("focus",this.onFocus)),b.off("scroll",this.onScroll)
}},pick:function(){this.completion.pick(this.data,this.selectedHint)
},changeActive:function(a,f){if(a>=this.data.list.length?a=f?this.data.list.length-1:0:0>a&&(a=f?0:this.data.list.length-1),this.selectedHint!=a){var c=this.hints.childNodes[this.selectedHint];
c.className=c.className.replace(" "+p,""),c=this.hints.childNodes[this.selectedHint=a],c.className+=" "+p,c.offsetTop<this.hints.scrollTop?this.hints.scrollTop=c.offsetTop-3:c.offsetTop+c.offsetHeight>this.hints.scrollTop+this.hints.clientHeight&&(this.hints.scrollTop=c.offsetTop+c.offsetHeight-this.hints.clientHeight+3),r.signal(this.data,"select",this.data.list[this.selectedHint],c)
}},screenAmount:function(){return Math.floor(this.hints.clientHeight/this.hints.firstChild.offsetHeight)||1
}},r.registerHelper("hint","auto",function(a,u){var s,t=a.getHelpers(a.getCursor(),"hint");
if(t.length){for(var i=0;
i<t.length;
i++){var h=t[i](a,u);
if(h&&h.list.length){return h
}}}else{if(s=a.getHelper(a.getCursor(),"hintWords")){if(s){return r.hint.fromList(a,{words:s})
}}else{if(r.hint.anyword){return r.hint.anyword(a,u)
}}}}),r.registerHelper("hint","fromList",function(a,w){for(var v=a.getCursor(),u=a.getTokenAt(v),t=[],s=0;
s<w.words.length;
s++){var i=w.words[s];
i.slice(0,u.string.length)==u.string&&t.push(i)
}return t.length?{list:t,from:r.Pos(v.line,u.start),to:r.Pos(v.line,u.end)}:void 0
}),r.commands.autocomplete=r.showHint;
var j={hint:r.hint.auto,completeSingle:!0,alignWithWord:!0,closeCharacters:/[\s()\[\]{};:>,]/,closeOnUnfocus:!0,completeOnSingleClick:!1,container:null,customKeys:null,extraKeys:null};
r.defineOption("hintOptions",null)
});