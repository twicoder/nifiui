(function(g){var d=function(h){return typeof h==="undefined"
};
var f=function(h){return h===null
};
var e=function(h){return !d(h)&&!f(h)
};
var b=function(h){return d(h)||f(h)||h===""
};
var a=function(l,m,k){var h=l.data("options");
var j=l.children("div.combo-text");
var i;
if(e(k)){g.each(h.options,function(n,o){if(k===o.value){i=o
}})
}if(d(i)){g.each(h.options,function(n,o){if(d(i)){i=o
}if(m===o.text){i=o
}})
}if(e(i)){j.removeClass("selected-disabled-option").attr("title",i.text).text(i.text).data("text",i.text).width(l.outerWidth()-25);
if(i.disabled===true){j.addClass("selected-disabled-option")
}l.data("selected-option",i);
if(e(h.select)){h.select.call(l,i)
}}};
var c={init:function(h){return this.each(function(){if(e(h)&&e(h.options)){var i=g(this);
i.empty().unbind().data("options",h);
g('<div class="combo-text"></div>').appendTo(i);
i.addClass("button-normal pointer combo").hover(function(){i.removeClass("button-normal").addClass("button-over")
},function(){i.removeClass("button-over").addClass("button-normal")
}).click(function(m){var j=i.offset();
var o=g("<div></div>").addClass("combo-options").css({position:"absolute",left:j.left+"px",top:(j.top+i.outerHeight()+1)+"px",width:(i.outerWidth()-10)+"px","overflow-y":"auto"});
var p=0;
var l=-1;
if(e(h.maxHeight)){l=parseInt(h.maxHeight);
if(l>0){o.css("max-height",l+"px")
}}var n=g("<ul></ul>").appendTo(o);
g.each(h.options,function(r,s){var u=g('<span class="combo-option-text"></span>').attr("title",s.text).text(s.text);
var t=g('<span class="hidden"></span>').text(s.value);
var q=g("<li></li>").addClass(s.optionClass).append(u).append(t).appendTo(n);
if(s.disabled===true){q.addClass("unset")
}else{q.click(function(){a(i,s.text,s.value);
g(".combo-glass-pane").click()
}).hover(function(){g(this).addClass("pointer").find(".combo-option-text").css("text-decoration","underline")
},function(){g(this).removeClass("pointer").find(".combo-option-text").css("text-decoration","none")
})
}if(!b(s.description)){g('<img style="float: left; margin-left: 5px; margin-top: 3px;" src="images/iconInfo.png"></img>').appendTo(q).qtip({content:s.description,style:{classes:"combo-nifi-tooltip"},show:{solo:true,effect:false},hide:{effect:false},position:{at:"top right",my:"bottom left"}})
}p+=16
});
n.find("span.combo-option-text").each(function(){var q=g(this);
var r=10;
if(q.parent().children("img").length>0){r=25
}if(l>0&&p>l){r+=20
}q.width(i.outerWidth()-r)
});
var k=g('<div class="combo-glass-pane"></div>').one("click",function(){if(o.length!==0){o.find("img").each(function(){var r=g(this);
if(r.data("qtip")){var q=r.qtip("api");
q.destroy(true)
}});
o.remove()
}g(this).remove()
});
g("body").append(o).append(k);
m.stopPropagation()
});
g('<div class="combo-arrow"></div>').appendTo(i);
if(e(h.selectedOption)){a(i,h.selectedOption.text,h.selectedOption.value)
}else{a(i)
}}})
},getSelectedOption:function(){var h;
this.each(function(){h=g(this).data("selected-option");
return false
});
return h
},setSelectedOption:function(h){return this.each(function(){a(g(this),h.text,h.value)
})
}};
g.fn.combo=function(h){if(c[h]){return c[h].apply(this,Array.prototype.slice.call(arguments,1))
}else{return c.init.apply(this,arguments)
}}
})(jQuery);