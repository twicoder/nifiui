(function(e){var b=function(f){return typeof f==="undefined"
};
var d=function(f){return f===null
};
var c=function(f){return !b(f)&&!d(f)
};
var a={init:function(f){return this.each(function(){if(c(f)&&c(f.charCountField)){var h=e(this);
var g=e(h).attr("maxlength");
if(b(g)||d(g)){g=f.maxLength
}if(c(g)){e(h).bind("keyup blur",function(){var i=e(h).val();
if(i.length>g){e(h).val(i.slice(0,g));
e(f.charCountField).text(0)
}else{e(f.charCountField).text(g-i.length)
}}).keyup()
}}})
}};
e.fn.count=function(f){if(a[f]){return a[f].apply(this,Array.prototype.slice.call(arguments,1))
}else{return a.init.apply(this,arguments)
}}
})(jQuery);