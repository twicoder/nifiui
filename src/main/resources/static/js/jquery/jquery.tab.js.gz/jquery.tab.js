(function(c){function a(d){c(d).keydown(function(f){if(f.which==9){if(f.shiftKey==false&&f.ctrlKey==false){b(this,"\t")
}return false
}}).keypress(function(f){if(f.which==9){return false
}})
}function b(d,h){d.focus();
if(typeof d.selectionStart=="number"){var g=d.value;
var f=d.selectionStart;
d.value=g.slice(0,f)+h+g.slice(d.selectionEnd);
d.selectionEnd=d.selectionStart=f+h.length
}else{if(typeof document.selection!="undefined"){var e=document.selection.createRange();
e.text=h;
e.collapse(false);
e.select()
}}}c.fn.tab=function(){return this.each(function(){if(this.nodeType==1){var d=this.nodeName.toLowerCase();
if(d=="textarea"||(d=="input"&&this.type=="text")){a(this)
}}})
}
})(jQuery);