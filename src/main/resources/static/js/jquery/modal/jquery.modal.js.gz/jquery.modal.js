(function(e){var h="overlay-background";
var c=function(j){return typeof j==="undefined"
};
var a=function(j){return j===null
};
var i=function(j){return !c(j)&&!a(j)
};
var d=function(j){return c(j)||a(j)||j===""
};
var f=function(j,l){if(i(l)){var k=e('<div class="dialog-buttons"></div>');
e.each(l,function(n,m){e('<div class="button button-normal"></div>').text(m.buttonText).click(function(){var o=e(this).data("handler");
if(i(o)&&typeof o.click==="function"){o.click.call(j)
}}).data("handler",m.handler).appendTo(k)
});
k.append('<div class="clear"></div>').appendTo(j)
}};
var g=function(j){var k=j.parent();
j.detach();
e("<div/>").append('<div class="dialog-border"></div>').append(j).appendTo(k)
};
var b={init:function(j){return this.each(function(){if(i(j)){var m=e(this).addClass("dialog cancellable");
var k=e('<span class="dialog-header-text"></span>');
var l=e('<div class="dialog-header"></div>').append(k);
if(i(j.handler)){m.data("handler",j.handler)
}if(!d(j.headerText)){k.text(j.headerText)
}m.prepend(l);
if(j.overlayBackground===false){g(m)
}f(m,j.buttons)
}})
},setHandler:function(j){return this.each(function(){e(this).data("handler",j)
})
},setOverlayBackground:function(j){return this.each(function(){if(i(j)){var k=e(this);
var l=k.prev();
if(j===true){if(l.hasClass("dialog-border")){k.detach();
l.parent().replaceWith(k)
}}else{if(!l.hasClass("dialog-border")){g(k)
}}}})
},setButtonModel:function(j){return this.each(function(){if(i(j)){var k=e(this);
k.children(".dialog-buttons").remove();
f(k,j)
}})
},setHeaderText:function(j){return this.each(function(){e(this).find("span.dialog-header-text").text(j)
})
},show:function(){return this.each(function(){var l=e(this);
if(!l.is(":visible")){var k;
var n=l.prev();
if(!n.hasClass("dialog-border")){l.addClass(h);
k=e("#faded-background")
}else{k=n;
var m=parseInt(l.css("width"));
var j=parseInt(l.css("height"));
k.css({width:(m+20)+"px",height:(j+20)+"px"}).center();
e("#glass-pane").show()
}k.show();
l.show().center()
}})
},hide:function(){return this.each(function(){var j=e(this);
if(j.is(":visible")){if(j.hasClass(h)){j.removeClass(h);
e("#faded-background").hide()
}else{j.prev().hide();
e("#glass-pane").hide()
}var k=j.data("handler");
if(i(k)&&typeof k.close==="function"){k.close.call(j)
}j.hide()
}})
}};
e.fn.modal=function(j){if(b[j]){return b[j].apply(this,Array.prototype.slice.call(arguments,1))
}else{return b.init.apply(this,arguments)
}}
})(jQuery);