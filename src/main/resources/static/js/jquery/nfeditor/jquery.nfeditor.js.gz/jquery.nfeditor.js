(function(f){var c=function(h){return typeof h==="undefined"
};
var e=function(h){return h===null
};
var d=function(h){return !c(h)&&!e(h)
};
var a=function(h){return c(h)||e(h)||h===""
};
var g=function(h){return typeof h==="function"
};
var b={init:function(h){return this.each(function(){if(c(h)||e(h)){return false
}var l=h.languageId;
var n=nf[l];
if(c(n)||e(n)){return false
}var i=h.resizable===true;
var r=h.sensitive===true;
var q=d(h.content)?h.content:"";
var s=f("<textarea></textarea>").text(q).appendTo(f(this));
if(g(n.color)){CodeMirror.commands.autocomplete=function(v){if(g(n.suggest)){CodeMirror.showHint(v,nf[l].suggest)
}};
CodeMirror.defineMode(l,nf[l].color);
var t=h.readOnly===true;
var p=CodeMirror.fromTextArea(s.get(0),{mode:l,lineNumbers:true,matchBrackets:true,readOnly:t,extraKeys:{"Ctrl-Space":"autocomplete",Esc:function(v){if(g(h.escape)){h.escape();
return
}return CodeMirror.Pass
},Enter:function(v){if(g(h.enter)){h.enter();
return
}return CodeMirror.Pass
}}});
var k=null;
if(d(h.width)){k=h.width
}var u=null;
if(d(h.height)){u=h.height
}p.setSize(k,u);
f(this).data("editorInstance",p);
var o=f(this).find(".CodeMirror");
var j=o.find(".CodeMirror-code");
if(i){o.append('<div class="ui-resizable-handle ui-resizable-se"></div>').resizable({handles:{se:".ui-resizable-se"},resize:function(){p.setSize(f(this).width(),f(this).height());
p.refresh()
}})
}p.on("change",function(v,w){o.addClass("modified")
});
if(r){j.addClass("sensitive");
var m=function(v,w){if(j.hasClass("sensitive")){j.removeClass("sensitive");
p.setValue("")
}};
p.on("mousedown",m);
p.on("keydown",m)
}if(d(h.minWidth)){o.resizable("option","minWidth",h.minWidth)
}if(d(h.minHeight)){o.resizable("option","minHeight",h.minHeight)
}}})
},refresh:function(){return this.each(function(){var h=f(this).data("editorInstance");
if(d(h)){h.refresh()
}})
},setSize:function(i,h){return this.each(function(){var j=f(this).data("editorInstance");
if(d(j)){j.setSize(i,h)
}})
},getValue:function(){var h;
this.each(function(){var i=f(this).data("editorInstance");
if(d(i)){h=i.getValue()
}return false
});
return h
},setValue:function(h){return this.each(function(){var i=f(this).data("editorInstance");
if(d(i)){i.setValue(h);
f(this).find(".CodeMirror").removeClass("modified")
}})
},focus:function(){return this.each(function(){var h=f(this).data("editorInstance");
if(d(h)){h.focus()
}})
},selectAll:function(){return this.each(function(){var h=f(this).data("editorInstance");
if(d(h)){h.execCommand("selectAll")
}})
},isModified:function(){var h;
this.each(function(){h=f(this).find(".CodeMirror").hasClass("modified");
return false
});
return h
},destroy:function(){return this.removeData("editorInstance").find(".CodeMirror").removeClass("modified")
}};
f.fn.nfeditor=function(h){if(b[h]){return b[h].apply(this,Array.prototype.slice.call(arguments,1))
}else{return b.init.apply(this,arguments)
}}
})(jQuery);