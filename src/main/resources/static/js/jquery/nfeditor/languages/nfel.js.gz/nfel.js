nf.nfel=(function(){var v=function(w){if($.isEmptyObject(w)){return'<span class="unset">None</span>'
}else{var x='<div class="clear"></div><ul class="el-arguments">';
$.each(w,function(y,z){x+=('<li><span class="el-argument-name">'+y+"</span> - "+z+"</li>")
});
x+="</ul>";
return x
}};
var r=[];
var l=[];
var j=new RegExp("^$");
var e=new RegExp("^$");
var b={};
$.ajax({type:"GET",url:"../nifi-docs/html/expression-language-guide.html",dataType:"html"}).done(function(w){$(w).find("div.function").each(function(){var D=$(this);
var A=D.find("h3").text();
var C=D.find("span.description").text();
var z=D.find("span.returnType").text();
var B;
var y=D.find("span.subjectless");
if(y.length){r.push(A);
B='<span class="unset">None</span>'
}else{l.push(A);
B=D.find("span.subject").text()
}var x={};
D.find("span.argName").each(function(){var F=$(this);
var E=F.next("span.argDesc");
x[F.text()]=E.text()
});
b[A]='<div><div class="el-name el-section">'+A+'</div><div class="el-section">'+C+'</div><div class="el-section"><div class="el-header">Arguments</div>'+v(x)+'</div><div class="el-section"><div class="el-header">Subject</div><p>'+B+'</p><div class="clear"></div></div><div class="el-section"><div class="el-header">Returns</div><p>'+z+'</p><div class="clear"></div></div></div>'
})
}).always(function(){j=new RegExp("^(("+r.join(")|(")+"))$");
e=new RegExp("^(("+l.join(")|(")+"))$")
});
var u="subject";
var f="function";
var g="subject-or-function";
var o="expression";
var q="arguments";
var a="argument";
var t="invalid";
var c=function(x,w){var y=0;
x.eatWhile(function(z){if(z==="$"){y++;
return true
}return false
});
if(y%2===0){return null
}if(y>1){x.backUp(1);
return null
}if(x.peek()==="{"){x.next();
w.push({context:o});
x.eatSpace();
return"bracket"
}else{return null
}};
var h=function(B,z){var A=B.next();
var w=false;
var y=false;
var x=B.eatWhile(function(C){if(w===true){return false
}if(C===A){w=y===false
}y=false;
if(C==="\\"){y=true
}return true
});
if(x){return"string"
}z.context=t;
B.skipToEnd();
return null
};
var d=null;
var s=null;
var p=[];
var m=function(w,x){i();
d=$(x).qtip("api");
s=setTimeout(function(){d.show()
},500)
};
var i=function(){if(s!==null){clearInterval(s);
s=null
}if(d!==null){d.hide()
}};
var k=function(){if(s!==null){clearInterval(s);
s=null
}d=null;
$.each(p,function(w,x){x.destroy(true)
});
p=[]
};
var n=function(y,x,A){var z=$("<div></div>").text(A.text);
var w=$(y).qtip({content:b[A.text],style:{classes:"nifi-tooltip nfel-tooltip",tip:false,width:350},show:{event:false,effect:false},hide:{event:false,effect:false},position:{at:"bottom right",my:"bottom left",adjust:{x:20}}}).append(z);
p.push(w.qtip("api"))
};
return{color:function(){var w=function(y){var x=y;
return{copy:function(){var A=[];
for(var z=0;
z<x.length;
z++){A.push({context:x[z].context})
}return A
},get:function(){if(x.length===0){return{context:null}
}else{return x[x.length-1]
}},push:function(z){return x.push(z)
},pop:function(){return x.pop()
}}
};
return{startState:function(){return w([])
},copyState:function(x){return w(x.copy())
},token:function(G,H){if(G.eatSpace()){return null
}if(G.eol()){return null
}var D=G.peek();
if(D==="#"){G.skipToEnd();
return"comment"
}var z=H.get();
if(z.context===t){G.skipToEnd();
return null
}if(z.context===o){var B=/^[^'"#${}()[\],:;\/*\\\s\t\r\n0-9][^'"#${}()[\],:;\/*\\\s\t\r\n]*/;
var y=G.match(B,false);
if(y!==null&&y.length===1){G.match(B);
if(j.test(y)){z.context=q;
return"builtin"
}else{z.context=g;
return"variable-2"
}}else{if(D==="'"||D==='"'){var A=h(G,z);
if(A!==null){z.context=u
}return A
}else{if(D==="$"){var C=c(G,H);
if(C!==null){z.context=u
}return C
}else{if(D==="}"){G.next();
if(typeof H.pop()==="undefined"){return null
}else{return"bracket"
}}else{G.skipToEnd();
z.context=t;
return null
}}}}}if(z.context===u||z.context===g){if(D===":"){G.next();
z.context=f;
G.eatSpace();
return null
}else{if(D==="}"){G.next();
if(typeof H.pop()==="undefined"){return null
}else{return"bracket"
}}else{G.skipToEnd();
z.context=t;
return null
}}}if(z.context===f){var E=G.match(/^[a-zA-Z]+/,false);
if(E!==null&&E.length===1){G.match(/^[a-zA-Z]+/);
if(e.test(E)){z.context=q;
return"builtin"
}else{return null
}}else{G.skipToEnd();
z.context=t;
return null
}}if(z.context===q){if(D==="("){G.next();
z.context=a;
return null
}else{if(D===")"){G.next();
z.context=u;
return null
}else{if(D===","){G.next();
z.context=a;
return null
}else{G.skipToEnd();
z.context=t;
return null
}}}}if(z.context===a){if(D==="'"||D==='"'){var F=h(G,z);
if(F!==null){z.context=q
}return F
}else{if(G.match(/^[0-9]+/)){z.context=q;
return"number"
}else{if(G.match(/^((true)|(false))/)){z.context=q;
return"number"
}else{if(D===")"){G.next();
z.context=u;
return null
}else{if(D==="$"){var x=c(G,H);
if(x!==null){z.context=q
}return x
}else{G.skipToEnd();
z.context=t;
return null
}}}}}}if(D==="$"){return c(G,H)
}if(D==="}"){G.next();
if(typeof H.pop()==="undefined"){return null
}else{return"bracket"
}}G.next();
return
}}
},suggest:function(D){var H=D.getCursor();
var z=D.getTokenAt(H);
var A=false;
var w=z.state.get();
var y=function(J){return J===f||J===q
};
var I=function(J){return J===o||J===g
};
var x=w.context;
if(!I(x)&&!y(x)){return null
}var G=z.string.toLowerCase();
var C=$.trim(G);
if(C==="${"||C===":"){A=true;
z.start+=G.length
}var E=function(K){var J=[];
$.each(K,function(M,L){if($.inArray(L,J)===-1){if(A||L.toLowerCase().indexOf(G)===0){J.push({text:L,render:n})
}}});
return J
};
var B=E(I(x)?r:l);
B=B.sort(function(L,J){var M=L.text.toLowerCase();
var K=J.text.toLowerCase();
return M===K?0:M>K?1:-1
});
var F={list:B,from:{line:H.line,ch:z.start},to:{line:H.line,ch:z.end}};
CodeMirror.on(F,"select",m);
CodeMirror.on(F,"close",k);
return F
}}
}());