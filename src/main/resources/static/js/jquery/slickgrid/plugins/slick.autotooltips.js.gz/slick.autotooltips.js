(function(b){b.extend(true,window,{Slick:{AutoTooltips:a}});
function a(e){var d;
var c=this;
var j={enableForCells:true,enableForHeaderCells:false,maxToolTipLength:null};
function i(k){e=b.extend(true,{},j,e);
d=k;
if(e.enableForCells){d.onMouseEnter.subscribe(g)
}if(e.enableForHeaderCells){d.onHeaderMouseEnter.subscribe(h)
}}function f(){if(e.enableForCells){d.onMouseEnter.unsubscribe(g)
}if(e.enableForHeaderCells){d.onHeaderMouseEnter.unsubscribe(h)
}}function g(m){var k=d.getCellFromEvent(m);
if(k){var l=b(d.getCellNode(k.row,k.cell));
var n;
if(l.innerWidth()<l[0].scrollWidth){n=b.trim(l.text());
if(e.maxToolTipLength&&n.length>e.maxToolTipLength){n=n.substr(0,e.maxToolTipLength-3)+"..."
}}else{n=""
}l.attr("title",n)
}}function h(n,l){var m=l.column,k=b(n.target).closest(".slick-header-column");
if(!m.toolTip){k.attr("title",(k.innerWidth()<k[0].scrollWidth)?m.name:"")
}}b.extend(this,{init:i,destroy:f})
}})(jQuery);