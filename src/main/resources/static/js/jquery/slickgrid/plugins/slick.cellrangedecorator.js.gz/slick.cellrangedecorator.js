(function(b){b.extend(true,window,{Slick:{CellRangeDecorator:a}});
function a(g,d){var f;
var h={selectionCssClass:"slick-range-decorator",selectionCss:{zIndex:"9999",border:"2px dashed red"}};
d=b.extend(true,{},h,d);
function c(i){if(!f){f=b("<div></div>",{css:d.selectionCss}).addClass(d.selectionCssClass).css("position","absolute").appendTo(g.getCanvasNode())
}var k=g.getCellNodeBox(i.fromRow,i.fromCell);
var j=g.getCellNodeBox(i.toRow,i.toCell);
f.css({top:k.top-1,left:k.left-1,height:j.bottom-k.top-2,width:j.right-k.left-2});
return f
}function e(){if(f){f.remove();
f=null
}}b.extend(this,{show:c,hide:e})
}})(jQuery);