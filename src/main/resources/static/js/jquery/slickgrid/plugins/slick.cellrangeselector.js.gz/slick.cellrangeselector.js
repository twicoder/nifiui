(function(b){b.extend(true,window,{Slick:{CellRangeSelector:a}});
function a(p){var i;
var g;
var o;
var d;
var h=this;
var m=new Slick.EventHandler();
var e={selectionCss:{border:"2px dashed blue"}};
function n(q){p=b.extend(true,{},e,p);
d=new Slick.CellRangeDecorator(q,p);
i=q;
g=i.getCanvasNode();
m.subscribe(i.onDragInit,k).subscribe(i.onDragStart,f).subscribe(i.onDrag,c).subscribe(i.onDragEnd,j)
}function l(){m.unsubscribeAll()
}function k(r,q){r.stopImmediatePropagation()
}function f(s,r){var q=i.getCellFromEvent(s);
if(h.onBeforeCellRangeSelected.notify(q)!==false){if(i.canCellBeSelected(q.row,q.cell)){o=true;
s.stopImmediatePropagation()
}}if(!o){return
}i.focus();
var t=i.getCellFromPoint(r.startX-b(g).offset().left,r.startY-b(g).offset().top);
r.range={start:t,end:{}};
return d.show(new Slick.Range(t.row,t.cell))
}function c(s,q){if(!o){return
}s.stopImmediatePropagation();
var r=i.getCellFromPoint(s.pageX-b(g).offset().left,s.pageY-b(g).offset().top);
if(!i.canCellBeSelected(r.row,r.cell)){return
}q.range.end=r;
d.show(new Slick.Range(q.range.start.row,q.range.start.cell,r.row,r.cell))
}function j(r,q){if(!o){return
}o=false;
r.stopImmediatePropagation();
d.hide();
h.onCellRangeSelected.notify({range:new Slick.Range(q.range.start.row,q.range.start.cell,q.range.end.row,q.range.end.cell)})
}b.extend(this,{init:n,destroy:l,onBeforeCellRangeSelected:new Slick.Event(),onCellRangeSelected:new Slick.Event()})
}})(jQuery);