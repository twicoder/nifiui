(function(b){b.extend(true,window,{Slick:{RowSelectionModel:a}});
function a(f){var r;
var o=[];
var i=this;
var n=new Slick.EventHandler();
var m;
var q;
var s={selectActiveRow:true};
function t(x){q=b.extend(true,{},s,f);
r=x;
n.subscribe(r.onActiveCellChanged,e(v));
n.subscribe(r.onKeyDown,e(l));
n.subscribe(r.onClick,e(k))
}function w(){n.unsubscribeAll()
}function e(x){return function(){if(!m){m=true;
x.apply(this,arguments);
m=false
}}
}function g(x){var A=[];
for(var z=0;
z<x.length;
z++){for(var y=x[z].fromRow;
y<=x[z].toRow;
y++){A.push(y)
}}return A
}function h(A){var y=[];
var x=r.getColumns().length-1;
for(var z=0;
z<A.length;
z++){y.push(new Slick.Range(A[z],0,A[z],x))
}return y
}function u(A,z){var x,y=[];
for(x=A;
x<=z;
x++){y.push(x)
}for(x=z;
x<A;
x++){y.push(x)
}return y
}function d(){return g(o)
}function j(x){c(h(x))
}function c(x){o=x;
i.onSelectedRangesChanged.notify(o)
}function p(){return o
}function v(y,x){if(q.selectActiveRow&&x.row!=null){c([new Slick.Range(x.row,0,x.row,r.getColumns().length-1)])
}}function l(C){var y=r.getActiveCell();
if(y&&C.shiftKey&&!C.ctrlKey&&!C.altKey&&!C.metaKey&&(C.which==38||C.which==40)){var B=d();
B.sort(function(D,E){return D-E
});
if(!B.length){B=[y.row]
}var A=B[0];
var x=B[B.length-1];
var z;
if(C.which==40){z=y.row<x||A==x?++x:++A
}else{z=y.row<x?--x:--A
}if(z>=0&&z<r.getDataLength()){r.scrollRowIntoView(z);
o=h(u(A,x));
c(o)
}C.preventDefault();
C.stopPropagation()
}}function k(C){var y=r.getCellFromEvent(C);
if(!y||!r.canCellBeActive(y.row,y.cell)){return false
}if(!r.getOptions().multiSelect||(!C.ctrlKey&&!C.shiftKey&&!C.metaKey)){return false
}var A=g(o);
var x=b.inArray(y.row,A);
if(x===-1&&(C.ctrlKey||C.metaKey)){A.push(y.row);
r.setActiveCell(y.row,y.cell)
}else{if(x!==-1&&(C.ctrlKey||C.metaKey)){A=b.grep(A,function(G,F){return(G!==y.row)
});
r.setActiveCell(y.row,y.cell)
}else{if(A.length&&C.shiftKey){var B=A.pop();
var E=Math.min(y.row,B);
var D=Math.max(y.row,B);
A=[];
for(var z=E;
z<=D;
z++){if(z!==B){A.push(z)
}}A.push(B);
r.setActiveCell(y.row,y.cell)
}}}o=h(A);
c(o);
C.stopImmediatePropagation();
return true
}b.extend(this,{getSelectedRows:d,setSelectedRows:j,getSelectedRanges:p,setSelectedRanges:c,init:t,destroy:w,onSelectedRangesChanged:new Slick.Event()})
}})(jQuery);