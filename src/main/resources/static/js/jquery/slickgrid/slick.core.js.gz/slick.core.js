(function(c){c.extend(true,window,{Slick:{Event:h,EventData:g,EventHandler:i,Range:b,NonDataRow:e,Group:f,GroupTotals:d,EditorLock:a,GlobalEditorLock:new a()}});
function g(){var j=false;
var k=false;
this.stopPropagation=function(){j=true
};
this.isPropagationStopped=function(){return j
};
this.stopImmediatePropagation=function(){k=true
};
this.isImmediatePropagationStopped=function(){return k
}
}function h(){var j=[];
this.subscribe=function(k){j.push(k)
};
this.unsubscribe=function(l){for(var k=j.length-1;
k>=0;
k--){if(j[k]===l){j.splice(k,1)
}}};
this.notify=function(k,o,n){o=o||new g();
n=n||this;
var m;
for(var l=0;
l<j.length&&!(o.isPropagationStopped()||o.isImmediatePropagationStopped());
l++){m=j[l].call(n,o,k)
}return m
}
}function i(){var j=[];
this.subscribe=function(l,k){j.push({event:l,handler:k});
l.subscribe(k);
return this
};
this.unsubscribe=function(m,l){var k=j.length;
while(k--){if(j[k].event===m&&j[k].handler===l){j.splice(k,1);
m.unsubscribe(l);
return
}}return this
};
this.unsubscribeAll=function(){var k=j.length;
while(k--){j[k].event.unsubscribe(j[k].handler)
}j=[];
return this
}
}function b(k,j,l,m){if(l===undefined&&m===undefined){l=k;
m=j
}this.fromRow=Math.min(k,l);
this.fromCell=Math.min(j,m);
this.toRow=Math.max(k,l);
this.toCell=Math.max(j,m);
this.isSingleRow=function(){return this.fromRow==this.toRow
};
this.isSingleCell=function(){return this.fromRow==this.toRow&&this.fromCell==this.toCell
};
this.contains=function(o,n){return o>=this.fromRow&&o<=this.toRow&&n>=this.fromCell&&n<=this.toCell
};
this.toString=function(){if(this.isSingleCell()){return"("+this.fromRow+":"+this.fromCell+")"
}else{return"("+this.fromRow+":"+this.fromCell+" - "+this.toRow+":"+this.toCell+")"
}}
}function e(){this.__nonDataRow=true
}function f(){this.__group=true;
this.level=0;
this.count=0;
this.value=null;
this.title=null;
this.collapsed=false;
this.totals=null;
this.rows=[];
this.groups=null;
this.groupingKey=null
}f.prototype=new e();
f.prototype.equals=function(j){return this.value===j.value&&this.count===j.count&&this.collapsed===j.collapsed&&this.title===j.title
};
function d(){this.__groupTotals=true;
this.group=null;
this.initialized=false
}d.prototype=new e();
function a(){var j=null;
this.isActive=function(l){return(l?j===l:j!==null)
};
this.activate=function(l){if(l===j){return
}if(j!==null){throw"SlickGrid.EditorLock.activate: an editController is still active, can't activate another editController"
}if(!l.commitCurrentEdit){throw"SlickGrid.EditorLock.activate: editController must implement .commitCurrentEdit()"
}if(!l.cancelCurrentEdit){throw"SlickGrid.EditorLock.activate: editController must implement .cancelCurrentEdit()"
}j=l
};
this.deactivate=function(l){if(j!==l){throw"SlickGrid.EditorLock.deactivate: specified editController is not the currently active one"
}j=null
};
this.commitCurrentEdit=function(){return(j?j.commitCurrentEdit():true)
};
this.cancelCurrentEdit=function k(){return(j?j.cancelCurrentEdit():true)
}
}})(jQuery);