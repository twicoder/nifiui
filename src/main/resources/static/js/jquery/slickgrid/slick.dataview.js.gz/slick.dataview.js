(function(d){d.extend(true,window,{Slick:{Data:{DataView:f,Aggregators:{Avg:c,Min:b,Max:a,Sum:e}}}});
function f(aa){var at=this;
var M={groupItemMetadataProvider:null,inlineFilters:false};
var r="id";
var au=[];
var W=[];
var aA={};
var av=null;
var w=null;
var ar=null;
var F=false;
var k=true;
var aN;
var z;
var ag={};
var O={};
var aG;
var o=[];
var H;
var A;
var al=[];
var aC={getter:null,formatter:null,comparer:function(aS,aR){return aS.value-aR.value
},predefinedValues:[],aggregators:[],aggregateEmpty:false,aggregateCollapsed:false,aggregateChildGroups:false,collapsed:false,displayTotalsRow:true,lazyTotalsCalculation:false};
var aq=[];
var h=[];
var j=[];
var aJ=":|:";
var D=0;
var E=0;
var g=0;
var aE=new Slick.Event();
var N=new Slick.Event();
var aO=new Slick.Event();
aa=d.extend(true,{},M,aa);
function q(){F=true
}function s(){F=false;
aw()
}function ay(aR){ag=aR
}function P(aR){aG=aR
}function aH(aT){aT=aT||0;
var aU;
for(var aS=aT,aR=au.length;
aS<aR;
aS++){aU=au[aS][r];
if(aU===undefined){throw"Each data element must implement a unique 'id' property"
}aA[aU]=aS
}}function G(){var aT;
for(var aS=0,aR=au.length;
aS<aR;
aS++){aT=au[aS][r];
if(aT===undefined||aA[aT]!==aS){throw"Each data element must implement a unique 'id' property"
}}}function aP(){return au
}function U(aS,aR){if(aR!==undefined){r=aR
}au=o=aS;
aA={};
aH();
G();
aw()
}function B(aR){if(aR.pageSize!=undefined){D=aR.pageSize;
E=D?Math.min(E,Math.max(0,Math.ceil(g/D)-1)):0
}if(aR.pageNum!=undefined){E=Math.min(aR.pageNum,Math.max(0,Math.ceil(g/D)-1))
}aO.notify(am(),null,at);
aw()
}function am(){var aR=D?Math.max(1,Math.ceil(g/D)):1;
return{pageSize:D,pageNum:E,totalRows:g,totalPages:aR}
}function I(aS,aR){k=aR;
z=aS;
aN=null;
if(aR===false){au.reverse()
}au.sort(aS);
if(aR===false){au.reverse()
}aA={};
aH();
aw()
}function aI(aT,aS){k=aS;
aN=aT;
z=null;
var aR=Object.prototype.toString;
Object.prototype.toString=(typeof aT=="function")?aT:function(){return this[aT]
};
if(aS===false){au.reverse()
}au.sort();
Object.prototype.toString=aR;
if(aS===false){au.reverse()
}aA={};
aH();
aw()
}function y(){if(z){I(z,k)
}else{if(aN){aI(aN,k)
}}}function ac(aR){w=aR;
if(aa.inlineFilters){H=ak();
A=C()
}aw()
}function ah(){return aq
}function K(aU){if(!aa.groupItemMetadataProvider){aa.groupItemMetadataProvider=new Slick.Data.GroupItemMetadataProvider()
}h=[];
j=[];
aU=aU||[];
aq=(aU instanceof Array)?aU:[aU];
for(var aT=0;
aT<aq.length;
aT++){var aS=aq[aT]=d.extend(true,{},aC,aq[aT]);
aS.getterIsAFn=typeof aS.getter==="function";
aS.compiledAccumulators=[];
var aR=aS.aggregators.length;
while(aR--){aS.compiledAccumulators[aR]=ao(aS.aggregators[aR])
}j[aT]={}
}aw()
}function ad(aR,aS,aT){if(aR==null){K([]);
return
}K({getter:aR,formatter:aS,comparer:aT})
}function aL(aS,aR){if(!aq.length){throw new Error("At least one grouping must be specified before calling setAggregators().")
}aq[0].aggregators=aS;
aq[0].aggregateCollapsed=aR;
K(aq)
}function az(aR){return au[aR]
}function J(aR){return aA[aR]
}function v(){if(!av){av={};
for(var aS=0,aR=W.length;
aS<aR;
aS++){av[W[aS][r]]=aS
}}}function ai(aR){v();
return av[aR]
}function Y(aR){return au[aA[aR]]
}function aF(aT){var aU=[];
v();
for(var aS=0,aR=aT.length;
aS<aR;
aS++){var aV=av[aT[aS]];
if(aV!=null){aU[aU.length]=aV
}}return aU
}function T(aU){var aT=[];
for(var aS=0,aR=aU.length;
aS<aR;
aS++){if(aU[aS]<W.length){aT[aT.length]=W[aU[aS]][r]
}}return aT
}function m(aS,aR){if(aA[aS]===undefined||aS!==aR[r]){throw"Invalid or non-matching id"
}au[aA[aS]]=aR;
if(!ar){ar={}
}ar[aS]=true;
aw()
}function aK(aR,aS){au.splice(aR,0,aS);
aH(aR);
aw()
}function ap(aR){au.push(aR);
aH(au.length-1);
aw()
}function aQ(aS){var aR=aA[aS];
if(aR===undefined){throw"Invalid id"
}delete aA[aS];
au.splice(aR,1);
aH(aR);
aw()
}function ax(){return W.length
}function aD(aS){var aT=W[aS];
if(aT&&aT.__group&&aT.totals&&!aT.totals.initialized){var aR=aq[aT.level];
if(!aR.displayTotalsRow){af(aT.totals);
aT.title=aR.formatter?aR.formatter(aT):aT.value
}}else{if(aT&&aT.__groupTotals&&!aT.initialized){af(aT)
}}return aT
}function L(aR){var aS=W[aR];
if(aS===undefined){return null
}if(aS.__group){return aa.groupItemMetadataProvider.getGroupRowMetadata(aS)
}if(aS.__groupTotals){return aa.groupItemMetadataProvider.getTotalsRowMetadata(aS)
}return null
}function aM(aT,aS){if(aT==null){for(var aR=0;
aR<aq.length;
aR++){j[aR]={};
aq[aR].collapsed=aS
}}else{j[aT]={};
aq[aT].collapsed=aS
}aw()
}function Q(aR){aM(aR,true)
}function aB(aR){aM(aR,false)
}function X(aT,aR,aS){j[aT][aR]=aq[aT].collapsed^aS;
aw()
}function aj(aT){var aR=Array.prototype.slice.call(arguments);
var aS=aR[0];
if(aR.length==1&&aS.indexOf(aJ)!=-1){X(aS.split(aJ).length-1,aS,true)
}else{X(aR.length-1,aR.join(aJ),true)
}}function ae(aT){var aR=Array.prototype.slice.call(arguments);
var aS=aR[0];
if(aR.length==1&&aS.indexOf(aJ)!=-1){X(aS.split(aJ).length-1,aS,false)
}else{X(aR.length-1,aR.join(aJ),false)
}}function an(){return h
}function Z(a1,aY){var a0;
var aT;
var aU=[];
var aZ={};
var aR;
var aS=aY?aY.level+1:0;
var aX=aq[aS];
for(var aW=0,aV=aX.predefinedValues.length;
aW<aV;
aW++){aT=aX.predefinedValues[aW];
a0=aZ[aT];
if(!a0){a0=new Slick.Group();
a0.value=aT;
a0.level=aS;
a0.groupingKey=(aY?aY.groupingKey+aJ:"")+aT;
aU[aU.length]=a0;
aZ[aT]=a0
}}for(var aW=0,aV=a1.length;
aW<aV;
aW++){aR=a1[aW];
aT=aX.getterIsAFn?aX.getter(aR):aR[aX.getter];
a0=aZ[aT];
if(!a0){a0=new Slick.Group();
a0.value=aT;
a0.level=aS;
a0.groupingKey=(aY?aY.groupingKey+aJ:"")+aT;
aU[aU.length]=a0;
aZ[aT]=a0
}a0.rows[a0.count++]=aR
}if(aS<aq.length-1){for(var aW=0;
aW<aU.length;
aW++){a0=aU[aW];
a0.groups=Z(a0.rows,a0)
}}aU.sort(aq[aS].comparer);
return aU
}function af(aV){var aX=aV.group;
var aT=aq[aX.level];
var aW=(aX.level==aq.length);
var aS,aR=aT.aggregators.length;
if(!aW&&aT.aggregateChildGroups){var aU=aX.groups.length;
while(aU--){if(!aX.groups[aU].initialized){af(aX.groups[aU])
}}}while(aR--){aS=aT.aggregators[aR];
aS.init();
if(!aW&&aT.aggregateChildGroups){aT.compiledAccumulators[aR].call(aS,aX.groups)
}else{aT.compiledAccumulators[aR].call(aS,aX.rows)
}aS.storeResult(aV)
}aV.initialized=true
}function n(aT){var aR=aq[aT.level];
var aS=new Slick.GroupTotals();
aS.group=aT;
aT.totals=aS;
if(!aR.lazyTotalsCalculation){af(aS)
}}function u(aS,aX){aX=aX||0;
var aT=aq[aX];
var aU=aT.collapsed;
var aW=j[aX];
var aR=aS.length,aV;
while(aR--){aV=aS[aR];
if(aV.collapsed&&!aT.aggregateCollapsed){continue
}if(aV.groups){u(aV.groups,aX+1)
}if(aT.aggregators.length&&(aT.aggregateEmpty||aV.rows.length||(aV.groups&&aV.groups.length))){n(aV)
}aV.collapsed=aU^aW[aV.groupingKey];
aV.title=aT.formatter?aT.formatter(aV):aV.value
}}function i(aS,aR){aR=aR||0;
var a0=aq[aR];
var aT=[],a1,aX=0,aZ;
for(var aW=0,aU=aS.length;
aW<aU;
aW++){aZ=aS[aW];
aT[aX++]=aZ;
if(!aZ.collapsed){a1=aZ.groups?i(aZ.groups,aR+1):aZ.rows;
for(var aV=0,aY=a1.length;
aV<aY;
aV++){aT[aX++]=a1[aV]
}}if(aZ.totals&&a0.displayTotalsRow&&(!aZ.collapsed||a0.aggregateCollapsed)){aT[aX++]=aZ.totals
}}return aT
}function S(aS){var aR=/^function[^(]*\(([^)]*)\)\s*{([\s\S]*)}$/;
var aT=aS.toString().match(aR);
return{params:aT[1].split(","),body:aT[2]}
}function ao(aT){var aS=S(aT.accumulate);
var aR=new Function("_items","for (var "+aS.params[0]+", _i=0, _il=_items.length; _i<_il; _i++) {"+aS.params[0]+" = _items[_i]; "+aS.body+"}");
aR.displayName=aR.name="compiledAccumulatorLoop";
return aR
}function ak(){var aU=S(w);
var aR=aU.body.replace(/return false\s*([;}]|$)/gi,"{ continue _coreloop; }$1").replace(/return true\s*([;}]|$)/gi,"{ _retval[_idx++] = $item$; continue _coreloop; }$1").replace(/return ([^;}]+?)\s*([;}]|$)/gi,"{ if ($1) { _retval[_idx++] = $item$; }; continue _coreloop; }$2");
var aS=["var _retval = [], _idx = 0; ","var $item$, $args$ = _args; ","_coreloop: ","for (var _i = 0, _il = _items.length; _i < _il; _i++) { ","$item$ = _items[_i]; ","$filter$; ","} ","return _retval; "].join("");
aS=aS.replace(/\$filter\$/gi,aR);
aS=aS.replace(/\$item\$/gi,aU.params[0]);
aS=aS.replace(/\$args\$/gi,aU.params[1]);
var aT=new Function("_items,_args",aS);
aT.displayName=aT.name="compiledFilter";
return aT
}function C(){var aU=S(w);
var aR=aU.body.replace(/return false\s*([;}]|$)/gi,"{ continue _coreloop; }$1").replace(/return true\s*([;}]|$)/gi,"{ _cache[_i] = true;_retval[_idx++] = $item$; continue _coreloop; }$1").replace(/return ([^;}]+?)\s*([;}]|$)/gi,"{ if ((_cache[_i] = $1)) { _retval[_idx++] = $item$; }; continue _coreloop; }$2");
var aS=["var _retval = [], _idx = 0; ","var $item$, $args$ = _args; ","_coreloop: ","for (var _i = 0, _il = _items.length; _i < _il; _i++) { ","$item$ = _items[_i]; ","if (_cache[_i]) { ","_retval[_idx++] = $item$; ","continue _coreloop; ","} ","$filter$; ","} ","return _retval; "].join("");
aS=aS.replace(/\$filter\$/gi,aR);
aS=aS.replace(/\$item\$/gi,aU.params[0]);
aS=aS.replace(/\$args\$/gi,aU.params[1]);
var aT=new Function("_items,_args,_cache",aS);
aT.displayName=aT.name="compiledFilterWithCaching";
return aT
}function p(aT,aU){var aS=[],aR=0;
for(var aV=0,aW=aT.length;
aV<aW;
aV++){if(w(aT[aV],aU)){aS[aR++]=aT[aV]
}}return aS
}function R(aU,aV,aT){var aS=[],aR=0,aY;
for(var aW=0,aX=aU.length;
aW<aX;
aW++){aY=aU[aW];
if(aT[aW]){aS[aR++]=aY
}else{if(w(aY,aV)){aS[aR++]=aY;
aT[aW]=true
}}}return aS
}function x(aS){if(w){var aR=aa.inlineFilters?H:p;
var aU=aa.inlineFilters?A:R;
if(ag.isFilterNarrowing){o=aR(o,aG)
}else{if(ag.isFilterExpanding){o=aU(aS,aG,al)
}else{if(!ag.isFilterUnchanged){o=aR(aS,aG)
}}}}else{o=D?aS:aS.concat()
}var aT;
if(D){if(o.length<E*D){E=Math.floor(o.length/D)
}aT=o.slice(D*E,D*E+D)
}else{aT=o
}return{totalRows:o.length,rows:aT}
}function l(a0,aU){var aZ,aR,aS,aY=[];
var aW=0,aX=aU.length;
if(ag&&ag.ignoreDiffsBefore){aW=Math.max(0,Math.min(aU.length,ag.ignoreDiffsBefore))
}if(ag&&ag.ignoreDiffsAfter){aX=Math.min(aU.length,Math.max(0,ag.ignoreDiffsAfter))
}for(var aT=aW,aV=a0.length;
aT<aX;
aT++){if(aT>=aV){aY[aY.length]=aT
}else{aZ=aU[aT];
aR=a0[aT];
if((aq.length&&(aS=(aZ.__nonDataRow)||(aR.__nonDataRow))&&aZ.__group!==aR.__group||aZ.__group&&!aZ.equals(aR))||(aS&&(aZ.__groupTotals||aR.__groupTotals))||aZ[r]!=aR[r]||(ar&&ar[aZ[r]])){aY[aY.length]=aT
}}}return aY
}function t(aU){av=null;
if(ag.isFilterNarrowing!=O.isFilterNarrowing||ag.isFilterExpanding!=O.isFilterExpanding){al=[]
}var aS=x(aU);
g=aS.totalRows;
var aR=aS.rows;
h=[];
if(aq.length){h=Z(aR);
if(h.length){u(h);
aR=i(h)
}}var aT=l(W,aR);
W=aR;
return aT
}function aw(){if(F){return
}var aR=W.length;
var aS=g;
var aT=t(au,w);
if(D&&g<E*D){E=Math.max(0,Math.ceil(g/D)-1);
aT=t(au,w)
}ar=null;
O=ag;
ag={};
if(aS!=g){aO.notify(am(),null,at)
}if(aR!=W.length){aE.notify({previous:aR,current:W.length},null,at)
}if(aT.length>0){N.notify({rows:aT},null,at)
}}function V(aR,aX,aZ){var aY=this;
var aS;
var aT=aY.mapRowsToIds(aR.getSelectedRows());
var aV=new Slick.Event();
function aW(a0){if(aT.join(",")==a0.join(",")){return
}aT=a0;
aV.notify({grid:aR,ids:aT},new Slick.EventData(),aY)
}function aU(){if(aT.length>0){aS=true;
var a0=aY.mapIdsToRows(aT);
if(!aX){aW(aY.mapRowsToIds(a0))
}aR.setSelectedRows(a0);
aS=false
}}aR.onSelectedRowsChanged.subscribe(function(a3,a0){if(aS){return
}var a2=aY.mapRowsToIds(aR.getSelectedRows());
if(!aZ||!aR.getOptions().multiSelect){aW(a2)
}else{var a1=d.grep(aT,function(a4){return aY.getRowById(a4)===undefined
});
aW(a1.concat(a2))
}});
this.onRowsChanged.subscribe(aU);
this.onRowCountChanged.subscribe(aU);
return aV
}function ab(aT,aS){var aR;
var aV;
aU(aT.getCellCssStyles(aS));
function aU(aX){aR={};
for(var aY in aX){var aZ=W[aY][r];
aR[aZ]=aX[aY]
}}function aW(){if(aR){aV=true;
v();
var aX={};
for(var aZ in aR){var aY=av[aZ];
if(aY!=undefined){aX[aY]=aR[aZ]
}}aT.setCellCssStyles(aS,aX);
aV=false
}}aT.onCellCssStylesChanged.subscribe(function(aY,aX){if(aV){return
}if(aS!=aX.key){return
}if(aX.hash){aU(aX.hash)
}});
this.onRowsChanged.subscribe(aW);
this.onRowCountChanged.subscribe(aW)
}d.extend(this,{beginUpdate:q,endUpdate:s,setPagingOptions:B,getPagingInfo:am,getItems:aP,setItems:U,setFilter:ac,sort:I,fastSort:aI,reSort:y,setGrouping:K,getGrouping:ah,groupBy:ad,setAggregators:aL,collapseAllGroups:Q,expandAllGroups:aB,collapseGroup:aj,expandGroup:ae,getGroups:an,getIdxById:J,getRowById:ai,getItemById:Y,getItemByIdx:az,mapRowsToIds:T,mapIdsToRows:aF,setRefreshHints:ay,setFilterArgs:P,refresh:aw,updateItem:m,insertItem:aK,addItem:ap,deleteItem:aQ,syncGridSelection:V,syncGridCellCssStyles:ab,getLength:ax,getItem:aD,getItemMetadata:L,onRowCountChanged:aE,onRowsChanged:N,onPagingInfoChanged:aO})
}function c(g){this.field_=g;
this.init=function(){this.count_=0;
this.nonNullCount_=0;
this.sum_=0
};
this.accumulate=function(h){var i=h[this.field_];
this.count_++;
if(i!=null&&i!==""&&i!==NaN){this.nonNullCount_++;
this.sum_+=parseFloat(i)
}};
this.storeResult=function(h){if(!h.avg){h.avg={}
}if(this.nonNullCount_!=0){h.avg[this.field_]=this.sum_/this.nonNullCount_
}}
}function b(g){this.field_=g;
this.init=function(){this.min_=null
};
this.accumulate=function(h){var i=h[this.field_];
if(i!=null&&i!==""&&i!==NaN){if(this.min_==null||i<this.min_){this.min_=i
}}};
this.storeResult=function(h){if(!h.min){h.min={}
}h.min[this.field_]=this.min_
}
}function a(g){this.field_=g;
this.init=function(){this.max_=null
};
this.accumulate=function(h){var i=h[this.field_];
if(i!=null&&i!==""&&i!==NaN){if(this.max_==null||i>this.max_){this.max_=i
}}};
this.storeResult=function(h){if(!h.max){h.max={}
}h.max[this.field_]=this.max_
}
}function e(g){this.field_=g;
this.init=function(){this.sum_=null
};
this.accumulate=function(h){var i=h[this.field_];
if(i!=null&&i!==""&&i!==NaN){this.sum_+=parseFloat(i)
}};
this.storeResult=function(h){if(!h.sum){h.sum={}
}h.sum[this.field_]=this.sum_
}
}})(jQuery);