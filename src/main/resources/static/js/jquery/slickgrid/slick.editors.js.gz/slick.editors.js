(function(f){f.extend(true,window,{Slick:{Editors:{Text:h,Integer:b,Date:c,YesNoSelect:d,Checkbox:e,PercentComplete:a,LongText:g}}});
function h(j){var l;
var i;
var k=this;
this.init=function(){l=f("<INPUT type=text class='editor-text' />").appendTo(j.container).bind("keydown.nav",function(m){if(m.keyCode===f.ui.keyCode.LEFT||m.keyCode===f.ui.keyCode.RIGHT){m.stopImmediatePropagation()
}}).focus().select()
};
this.destroy=function(){l.remove()
};
this.focus=function(){l.focus()
};
this.getValue=function(){return l.val()
};
this.setValue=function(m){l.val(m)
};
this.loadValue=function(m){i=m[j.column.field]||"";
l.val(i);
l[0].defaultValue=i;
l.select()
};
this.serializeValue=function(){return l.val()
};
this.applyValue=function(m,n){m[j.column.field]=n
};
this.isValueChanged=function(){return(!(l.val()==""&&i==null))&&(l.val()!=i)
};
this.validate=function(){if(j.column.validator){var m=j.column.validator(l.val());
if(!m.valid){return m
}}return{valid:true,msg:null}
};
this.init()
}function b(j){var l;
var i;
var k=this;
this.init=function(){l=f("<INPUT type=text class='editor-text' />");
l.bind("keydown.nav",function(m){if(m.keyCode===f.ui.keyCode.LEFT||m.keyCode===f.ui.keyCode.RIGHT){m.stopImmediatePropagation()
}});
l.appendTo(j.container);
l.focus().select()
};
this.destroy=function(){l.remove()
};
this.focus=function(){l.focus()
};
this.loadValue=function(m){i=m[j.column.field];
l.val(i);
l[0].defaultValue=i;
l.select()
};
this.serializeValue=function(){return parseInt(l.val(),10)||0
};
this.applyValue=function(m,n){m[j.column.field]=n
};
this.isValueChanged=function(){return(!(l.val()==""&&i==null))&&(l.val()!=i)
};
this.validate=function(){if(isNaN(l.val())){return{valid:false,msg:"Please enter a valid integer"}
}return{valid:true,msg:null}
};
this.init()
}function c(j){var m;
var i;
var k=this;
var l=false;
this.init=function(){m=f("<INPUT type=text class='editor-text' />");
m.appendTo(j.container);
m.focus().select();
m.datepicker({showOn:"button",buttonImageOnly:true,buttonImage:"../images/calendar.gif",beforeShow:function(){l=true
},onClose:function(){l=false
}});
m.width(m.width()-18)
};
this.destroy=function(){f.datepicker.dpDiv.stop(true,true);
m.datepicker("hide");
m.datepicker("destroy");
m.remove()
};
this.show=function(){if(l){f.datepicker.dpDiv.stop(true,true).show()
}};
this.hide=function(){if(l){f.datepicker.dpDiv.stop(true,true).hide()
}};
this.position=function(n){if(!l){return
}f.datepicker.dpDiv.css("top",n.top+30).css("left",n.left)
};
this.focus=function(){m.focus()
};
this.loadValue=function(n){i=n[j.column.field];
m.val(i);
m[0].defaultValue=i;
m.select()
};
this.serializeValue=function(){return m.val()
};
this.applyValue=function(n,o){n[j.column.field]=o
};
this.isValueChanged=function(){return(!(m.val()==""&&i==null))&&(m.val()!=i)
};
this.validate=function(){return{valid:true,msg:null}
};
this.init()
}function d(k){var j;
var i;
var l=this;
this.init=function(){j=f("<SELECT tabIndex='0' class='editor-yesno'><OPTION value='yes'>Yes</OPTION><OPTION value='no'>No</OPTION></SELECT>");
j.appendTo(k.container);
j.focus()
};
this.destroy=function(){j.remove()
};
this.focus=function(){j.focus()
};
this.loadValue=function(m){j.val((i=m[k.column.field])?"yes":"no");
j.select()
};
this.serializeValue=function(){return(j.val()=="yes")
};
this.applyValue=function(m,n){m[k.column.field]=n
};
this.isValueChanged=function(){return(j.val()!=i)
};
this.validate=function(){return{valid:true,msg:null}
};
this.init()
}function e(k){var j;
var i;
var l=this;
this.init=function(){j=f("<INPUT type=checkbox value='true' class='editor-checkbox' hideFocus>");
j.appendTo(k.container);
j.focus()
};
this.destroy=function(){j.remove()
};
this.focus=function(){j.focus()
};
this.loadValue=function(m){i=!!m[k.column.field];
if(i){j.prop("checked",true)
}else{j.prop("checked",false)
}};
this.serializeValue=function(){return j.prop("checked")
};
this.applyValue=function(m,n){m[k.column.field]=n
};
this.isValueChanged=function(){return(this.serializeValue()!==i)
};
this.validate=function(){return{valid:true,msg:null}
};
this.init()
}function a(j){var m,l;
var i;
var k=this;
this.init=function(){m=f("<INPUT type=text class='editor-percentcomplete' />");
m.width(f(j.container).innerWidth()-25);
m.appendTo(j.container);
l=f("<div class='editor-percentcomplete-picker' />").appendTo(j.container);
l.append("<div class='editor-percentcomplete-helper'><div class='editor-percentcomplete-wrapper'><div class='editor-percentcomplete-slider' /><div class='editor-percentcomplete-buttons' /></div></div>");
l.find(".editor-percentcomplete-buttons").append("<button val=0>Not started</button><br/><button val=50>In Progress</button><br/><button val=100>Complete</button>");
m.focus().select();
l.find(".editor-percentcomplete-slider").slider({orientation:"vertical",range:"min",value:i,slide:function(n,o){m.val(o.value)
}});
l.find(".editor-percentcomplete-buttons button").bind("click",function(n){m.val(f(this).attr("val"));
l.find(".editor-percentcomplete-slider").slider("value",f(this).attr("val"))
})
};
this.destroy=function(){m.remove();
l.remove()
};
this.focus=function(){m.focus()
};
this.loadValue=function(n){m.val(i=n[j.column.field]);
m.select()
};
this.serializeValue=function(){return parseInt(m.val(),10)||0
};
this.applyValue=function(n,o){n[j.column.field]=o
};
this.isValueChanged=function(){return(!(m.val()==""&&i==null))&&((parseInt(m.val(),10)||0)!=i)
};
this.validate=function(){if(isNaN(parseInt(m.val(),10))){return{valid:false,msg:"Please enter a valid positive number"}
}return{valid:true,msg:null}
};
this.init()
}function g(j){var m,l;
var i;
var k=this;
this.init=function(){var n=f("body");
l=f("<DIV style='z-index:10000;position:absolute;background:white;padding:5px;border:3px solid gray; -moz-border-radius:10px; border-radius:10px;'/>").appendTo(n);
m=f("<TEXTAREA hidefocus rows=5 style='backround:white;width:250px;height:80px;border:0;outline:0'>").appendTo(l);
f("<DIV style='text-align:right'><BUTTON>Save</BUTTON><BUTTON>Cancel</BUTTON></DIV>").appendTo(l);
l.find("button:first").bind("click",this.save);
l.find("button:last").bind("click",this.cancel);
m.bind("keydown",this.handleKeyDown);
k.position(j.position);
m.focus().select()
};
this.handleKeyDown=function(n){if(n.which==f.ui.keyCode.ENTER&&n.ctrlKey){k.save()
}else{if(n.which==f.ui.keyCode.ESCAPE){n.preventDefault();
k.cancel()
}else{if(n.which==f.ui.keyCode.TAB&&n.shiftKey){n.preventDefault();
j.grid.navigatePrev()
}else{if(n.which==f.ui.keyCode.TAB){n.preventDefault();
j.grid.navigateNext()
}}}}};
this.save=function(){j.commitChanges()
};
this.cancel=function(){m.val(i);
j.cancelChanges()
};
this.hide=function(){l.hide()
};
this.show=function(){l.show()
};
this.position=function(n){l.css("top",n.top-5).css("left",n.left-5)
};
this.destroy=function(){l.remove()
};
this.focus=function(){m.focus()
};
this.loadValue=function(n){m.val(i=n[j.column.field]);
m.select()
};
this.serializeValue=function(){return m.val()
};
this.applyValue=function(n,o){n[j.column.field]=o
};
this.isValueChanged=function(){return(!(m.val()==""&&i==null))&&(m.val()!=i)
};
this.validate=function(){return{valid:true,msg:null}
};
this.init()
}})(jQuery);