(function(d){var a=function(e){return typeof e==="undefined"
};
var c=function(e){return e===null
};
var b=function(e){return !a(e)&&!c(e)
};
d.fn.tabbs=function(e){return this.each(function(){var g=d(this);
var f=d("<ul/>").addClass("tab-pane");
var h=false;
d.each(e.tabs,function(){var k=g.attr("id")+"-content";
var j=this;
d("#"+j.tabContentId).addClass(k);
var i=d("<li></li>").text(j.name).addClass(e.tabStyle).click(function(){d("."+k).hide();
d("#"+j.tabContentId).show();
f.children("."+e.tabStyle).removeClass(e.selectedTabStyle);
d(this).addClass(e.selectedTabStyle);
if(b(e.select)){e.select.call(this)
}}).appendTo(f);
if(!h){i.click();
h=true
}});
f.appendTo(g)
})
}
})(jQuery);