$(document).ready(function(){nf.BulletinBoard.init()
});
nf.BulletinBoard=(function(){var d={pollInterval:3,maxBulletins:1000,defaultFilterText:"Filter",urls:{banners:"../nifi-api/controller/banners",controllerAbout:"../nifi-api/controller/about",bulletinBoard:"../nifi-api/controller/bulletin-board"},styles:{filterList:"bulletin-board-filter-list",bulletinBoardPolling:"bulletin-board-polling",bulletinBoardPollingHover:"bulletin-board-polling-hover",bulletinBoardStopped:"bulletin-board-stopped",bulletinBoardStoppedHover:"bulletin-board-stopped-hover"}};
var f=null;
var i=null;
var e=null;
var a=null;
var c=function(){$("#refresh-button").addClass(d.styles.bulletinBoardPolling).click(function(){h();
if($(this).hasClass(d.styles.bulletinBoardPollingHover)){$(this).removeClass(d.styles.bulletinBoardPollingHover).addClass(d.styles.bulletinBoardStoppedHover)
}else{if($(this).hasClass(d.styles.bulletinBoardStoppedHover)){$(this).removeClass(d.styles.bulletinBoardStoppedHover).addClass(d.styles.bulletinBoardPollingHover)
}}}).hover(function(){if(f===true){$(this).removeClass(d.styles.bulletinBoardPolling).addClass(d.styles.bulletinBoardPollingHover)
}else{$(this).removeClass(d.styles.bulletinBoardStopped).addClass(d.styles.bulletinBoardStoppedHover)
}},function(){if(f===true){$(this).removeClass(d.styles.bulletinBoardPollingHover+" "+d.styles.bulletinBoardStoppedHover).addClass(d.styles.bulletinBoardPolling)
}else{$(this).removeClass(d.styles.bulletinBoardStoppedHover+" "+d.styles.bulletinBoardPollingHover).addClass(d.styles.bulletinBoardStopped)
}});
nf.Common.addHoverEffect("#clear-bulletins-button","button-normal","button-over").click(function(){$("#bulletin-board-container").empty()
});
$("#bulletin-board-filter").focus(function(){if($(this).hasClass(d.styles.filterList)){$(this).removeClass(d.styles.filterList).val("")
}}).blur(function(){if($(this).val()===""){$(this).addClass(d.styles.filterList).val(d.defaultFilterText)
}}).addClass(d.styles.filterList).val(d.defaultFilterText);
$("#bulletin-board-filter-type").combo({options:[{text:"by message",value:"message"},{text:"by source name",value:"sourceName"},{text:"by source id",value:"sourceId"},{text:"by group id",value:"groupId"}]});
var o=$.ajax({type:"GET",url:d.urls.controllerAbout,dataType:"json"}).done(function(q){var p=q.about;
var r=p.title+" Bulletin Board";
document.title=r;
$("#bulletin-board-header-text").text(r)
}).fail(nf.Common.handleAjaxError);
var n=$.Deferred(function(p){if(top===window){$.ajax({type:"GET",url:d.urls.banners,dataType:"json"}).done(function(u){if(nf.Common.isDefinedAndNotNull(u.banners)){if(nf.Common.isDefinedAndNotNull(u.banners.headerText)&&u.banners.headerText!==""){var r=$("#banner-header").text(u.banners.headerText).show();
var t=function(v){var w=$("#"+v);
w.css("top",(parseInt(r.css("height"),10)+parseInt(w.css("top"),10))+"px")
};
t("bulletin-board")
}if(nf.Common.isDefinedAndNotNull(u.banners.footerText)&&u.banners.footerText!==""){var q=$("#banner-footer").text(u.banners.footerText).show();
var s=function(v){var w=$("#"+v);
w.css("bottom",parseInt(q.css("height"),10)+"px")
};
s("bulletin-board")
}}p.resolve()
}).fail(function(s,q,r){nf.Common.handleAjaxError(s,q,r);
p.reject()
})
}else{p.resolve()
}});
return $.Deferred(function(p){$.when(o,n).done(function(){p.resolve()
}).fail(function(){p.reject()
})
}).promise()
};
var h=function(){if(f===true){m()
}else{b()
}};
var b=function(){var o=$("#refresh-button");
var n=$("#bulletin-board-container");
g(n,'<div class="bulletin-action">Auto refresh started</div>');
$("#bulletin-error-message").text("").hide();
f=true;
k();
o.removeClass(d.styles.bulletinBoardStopped).addClass(d.styles.bulletinBoardPolling)
};
var m=function(){var o=$("#refresh-button");
var n=$("#bulletin-board-container");
g(n,'<div class="bulletin-action">Auto refresh stopped</div>');
f=false;
i=null;
e=null;
a=null;
o.removeClass(d.styles.bulletinBoardPolling).addClass(d.styles.bulletinBoardStopped)
};
var k=function(){var n=$("body").is(":visible");
if(!n){f=false
}if(f){j().done(function(){if(f){setTimeout(k,d.pollInterval*1000)
}})
}};
var j=function(){var r={};
if(nf.Common.isDefinedAndNotNull(i)){r.after=i
}else{r.limit=10
}var p=$("#bulletin-board-container");
var n=$("#bulletin-board-filter");
if(!n.hasClass(d.styles.filterList)){var q=n.val();
if(q!==""){var s=$("#bulletin-board-filter-type").combo("getSelectedOption");
r[s.value]=q;
if(e!==q||a!==s.text){var o=$('<div class="bulletin-action"></div>').text("Filter "+s.text+" matching '"+q+"'");
g(p,o.get(0));
e=q;
a=s.text
}}else{if(e!==null){g(p,'<div class="bulletin-action">Filter removed</div>');
e=null;
a=null
}}}return $.ajax({type:"GET",url:d.urls.bulletinBoard,data:r,dataType:"json"}).done(function(t){if(nf.Common.isDefinedAndNotNull(t.bulletinBoard)){var u=t.bulletinBoard;
$("#bulletin-board-last-refreshed").text(u.generated);
var y=t.bulletinBoard.bulletins;
var x=[];
$.each(y,function(C,A){var F="bulletin-normal";
if(A.level==="ERROR"){F="bulletin-error"
}else{if(A.level==="WARN"||A.level==="WARNING"){F="bulletin-warn"
}}var E;
if(nf.Common.isDefinedAndNotNull(A.sourceId)&&nf.Common.isDefinedAndNotNull(A.groupId)&&top!==window){E=$('<div class="bulletin-source bulletin-link"></div>').text(A.sourceId).on("click",function(){l(A.groupId,A.sourceId)
})
}else{var D=A.sourceId;
if(nf.Common.isUndefined(D)||nf.Common.isNull(D)){D=""
}E=$('<div class="bulletin-source"></div>').text(D)
}var B=$('<div class="bulletin"></div>');
var z=$('<div class="bulletin-info"></div>').appendTo(B);
$('<div class="bulletin-timestamp"></div>').text(A.timestamp).appendTo(z);
$('<div class="bulletin-severity"></div>').addClass(F).text(A.level).appendTo(z);
E.appendTo(z);
$('<div class="clear"></div>').appendTo(z);
if(nf.Common.isDefinedAndNotNull(A.nodeAddress)){$('<div class="bulletin-node"></div>').text(A.nodeAddress).appendTo(B)
}$('<pre class="bulletin-message"></pre>').text(A.message).appendTo(B);
$('<div class="clear"></div>').appendTo(B);
x.push(B.get(0));
if(C+1===y.length){i=A.id
}});
g(p,x);
var w=p.contents();
var v=w.length;
if(v>d.maxBulletins){w.slice(0,v-d.maxBulletins).remove();
p.prepend('<div class="bulletin-action">&#8230;</div>')
}}}).fail(function(v,t,u){if(v.status===404){$("#bulletin-error-message").text(v.responseText).show();
h()
}else{nf.Common.handleAjaxError(v,t,u)
}})
};
var g=function(n,o){n.append(o).animate({scrollTop:n[0].scrollHeight},"slow")
};
var l=function(n,o){if(top!==window){if(nf.Common.isDefinedAndNotNull(parent.nf)&&nf.Common.isDefinedAndNotNull(parent.nf.CanvasUtils)&&nf.Common.isDefinedAndNotNull(parent.nf.Shell)){parent.nf.CanvasUtils.showComponent(n,o);
parent.$("#shell-close-button").click()
}}};
return{init:function(){c().done(function(){b()
})
}}
}());