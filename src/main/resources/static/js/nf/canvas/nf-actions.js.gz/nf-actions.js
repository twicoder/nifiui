nf.Actions=(function(){var b={urls:{controller:"../nifi-api/controller"}};
var c=function(e,f){var d=nf.Client.getRevision();
f.version=d.version;
f.clientId=d.clientId;
return $.ajax({type:"PUT",url:e,data:f,dataType:"json"}).done(function(g){nf.Client.setRevision(g.revision)
}).fail(function(i,g,h){if(i.status===400||i.status===404||i.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(i.responseText),overlayBackground:true})
}})
};
var a=function(d){if(nf.Common.isDefinedAndNotNull(d.processGroup)){if(nf.Common.isDefinedAndNotNull(d.processGroup.contents)){var e=d.processGroup.contents;
nf.Graph.set(e);
$.each(e.processGroups,function(f,h){var g=nf.Connection.getComponentConnections(h.id);
$.each(g,function(j,i){nf.Connection.reload(i)
})
})
}}};
return{enterGroup:function(d){if(d.size()===1&&nf.CanvasUtils.isProcessGroup(d)){var e=d.datum();
nf.CanvasUtils.enterGroup(e.component.id)
}},leaveGroup:function(){nf.CanvasUtils.enterGroup(nf.Canvas.getParentGroupId())
},refreshRemoteFlow:function(f){if(f.size()===1&&nf.CanvasUtils.isRemoteProcessGroup(f)){var i=f.datum();
var j=i.component.flowRefreshed;
var e=function(d){i.component.flowRefreshed=d;
if(f.classed("visible")){f.select("text.remote-process-group-last-refresh").text(function(){return d
})
}};
var h=function(d){$.ajax({type:"GET",url:i.component.uri,dataType:"json"}).done(function(k){var m=k.remoteProcessGroup;
if(j===m.flowRefreshed){g(d)
}else{nf.RemoteProcessGroup.set(k.remoteProcessGroup);
var l=nf.Connection.getComponentConnections(m.id);
$.each(l,function(o,n){nf.Connection.reload(n)
})
}})
};
var g=function(d){if(d<=32){setTimeout(function(){h(d*2)
},d*1000)
}else{e(j)
}};
e("Refreshing...");
h(1)
}},openUri:function(d){if(d.size()===1&&nf.CanvasUtils.isRemoteProcessGroup(d)){var f=d.datum();
var e=f.component.targetUri;
if(!nf.Common.isBlank(e)){window.open(encodeURI(e))
}else{nf.Dialog.showOkDialog({dialogContent:"No target URI defined."})
}}},showSource:function(d){if(d.size()===1&&nf.CanvasUtils.isConnection(d)){var f=d.datum();
if(f.component.source.groupId!==nf.Canvas.getGroupId()){nf.CanvasUtils.showComponent(f.component.source.groupId,f.component.source.id)
}else{var e=d3.select("#id-"+f.component.source.id);
nf.Actions.show(e)
}}},showDestination:function(e){if(e.size()===1&&nf.CanvasUtils.isConnection(e)){var f=e.datum();
if(f.component.destination.groupId!==nf.Canvas.getGroupId()){nf.CanvasUtils.showComponent(f.component.destination.groupId,f.component.destination.id)
}else{var d=d3.select("#id-"+f.component.destination.id);
nf.Actions.show(d)
}}},showDownstream:function(d){if(d.size()===1&&!nf.CanvasUtils.isConnection(d)){if(nf.CanvasUtils.isProcessor(d)){nf.GoTo.showDownstreamFromProcessor(d)
}else{if(nf.CanvasUtils.isFunnel(d)){nf.GoTo.showDownstreamFromFunnel(d)
}else{if(nf.CanvasUtils.isInputPort(d)){nf.GoTo.showDownstreamFromInputPort(d)
}else{if(nf.CanvasUtils.isOutputPort(d)){nf.GoTo.showDownstreamFromOutputPort(d)
}else{if(nf.CanvasUtils.isProcessGroup(d)||nf.CanvasUtils.isRemoteProcessGroup(d)){nf.GoTo.showDownstreamFromGroup(d)
}}}}}}},showUpstream:function(d){if(d.size()===1&&!nf.CanvasUtils.isConnection(d)){if(nf.CanvasUtils.isProcessor(d)){nf.GoTo.showUpstreamFromProcessor(d)
}else{if(nf.CanvasUtils.isFunnel(d)){nf.GoTo.showUpstreamFromFunnel(d)
}else{if(nf.CanvasUtils.isInputPort(d)){nf.GoTo.showUpstreamFromInputPort(d)
}else{if(nf.CanvasUtils.isOutputPort(d)){nf.GoTo.showUpstreamFromOutputPort(d)
}else{if(nf.CanvasUtils.isProcessGroup(d)||nf.CanvasUtils.isRemoteProcessGroup(d)){nf.GoTo.showUpstreamFromGroup(d)
}}}}}}},show:function(d){if(d.size()===1){var e=nf.CanvasUtils.getSelection();
e.classed("selected",false);
d.classed("selected",true);
nf.Actions.center(d)
}},select:function(d){d.classed("selected",true)
},selectAll:function(){nf.Actions.select(d3.selectAll("g.component, g.connection"))
},center:function(g){if(g.size()===1){var h;
if(nf.CanvasUtils.isConnection(g)){var e,m;
var l=g.datum();
if(l.bends.length>0){var f=Math.min(Math.max(0,l.labelIndex),l.bends.length-1);
e=l.bends[f].x;
m=l.bends[f].y
}else{e=(l.start.x+l.end.x)/2;
m=(l.start.y+l.end.y)/2
}h={x:e,y:m,width:1,height:1}
}else{var j=g.datum();
var k=j.component.position;
h={x:k.x,y:k.y,width:j.dimensions.width,height:j.dimensions.height}
}nf.CanvasUtils.centerBoundingBox(h);
nf.Canvas.View.refresh({transition:true})
}},enable:function(){var d=d3.selectAll("g.component.selected").filter(function(f){var e=d3.select(this);
return(nf.CanvasUtils.isProcessor(e)||nf.CanvasUtils.isInputPort(e)||nf.CanvasUtils.isOutputPort(e))&&nf.CanvasUtils.supportsModification(e)
});
if(d.empty()){nf.Dialog.showOkDialog({dialogContent:"No eligible components are selected. Please select the components to be enabled and ensure they are no longer running.",overlayBackground:true})
}else{d.each(function(f){var e=d3.select(this);
c(f.component.uri,{state:"STOPPED"}).done(function(g){if(nf.CanvasUtils.isProcessor(e)){nf.Processor.set(g.processor)
}else{if(nf.CanvasUtils.isInputPort(e)){nf.Port.set(g.inputPort)
}else{if(nf.CanvasUtils.isOutputPort(e)){nf.Port.set(g.outputPort)
}}}})
})
}},disable:function(){var d=d3.selectAll("g.component.selected").filter(function(f){var e=d3.select(this);
return(nf.CanvasUtils.isProcessor(e)||nf.CanvasUtils.isInputPort(e)||nf.CanvasUtils.isOutputPort(e))&&nf.CanvasUtils.supportsModification(e)
});
if(d.empty()){nf.Dialog.showOkDialog({dialogContent:"No eligible components are selected. Please select the components to be disabled and ensure they are no longer running.",overlayBackground:true})
}else{d.each(function(f){var e=d3.select(this);
c(f.component.uri,{state:"DISABLED"}).done(function(g){if(nf.CanvasUtils.isProcessor(e)){nf.Processor.set(g.processor)
}else{if(nf.CanvasUtils.isInputPort(e)){nf.Port.set(g.inputPort)
}else{if(nf.CanvasUtils.isOutputPort(e)){nf.Port.set(g.outputPort)
}}}})
})
}},start:function(d){if(d.empty()){c(b.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId()),{running:true}).done(a)
}else{var e=d.filter(function(f){return nf.CanvasUtils.isRunnable(d3.select(this))
});
if(e.empty()){nf.Dialog.showOkDialog({dialogContent:"No eligible components are selected. Please select the components to be started and ensure they are no longer running.",overlayBackground:true})
}else{e.each(function(h){var f=d3.select(this);
var g={};
if(nf.CanvasUtils.isProcessor(f)||nf.CanvasUtils.isInputPort(f)||nf.CanvasUtils.isOutputPort(f)){g.state="RUNNING"
}else{g.running=true
}c(h.component.uri,g).done(function(i){if(nf.CanvasUtils.isProcessor(f)){nf.Processor.set(i.processor)
}else{if(nf.CanvasUtils.isProcessGroup(f)){nf.ProcessGroup.set(i.processGroup);
var j=nf.Connection.getComponentConnections(i.processGroup.id);
$.each(j,function(l,k){nf.Connection.reload(k)
})
}else{if(nf.CanvasUtils.isInputPort(f)){nf.Port.set(i.inputPort)
}else{if(nf.CanvasUtils.isOutputPort(f)){nf.Port.set(i.outputPort)
}}}}})
})
}}},stop:function(d){if(d.empty()){c(b.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId()),{running:false}).done(a)
}else{var e=d.filter(function(f){return nf.CanvasUtils.isStoppable(d3.select(this))
});
if(e.empty()){nf.Dialog.showOkDialog({dialogContent:"No eligible components are selected. Please select the components to be stopped.",overlayBackground:true})
}else{e.each(function(h){var f=d3.select(this);
var g={};
if(nf.CanvasUtils.isProcessor(f)||nf.CanvasUtils.isInputPort(f)||nf.CanvasUtils.isOutputPort(f)){g.state="STOPPED"
}else{g.running=false
}c(h.component.uri,g).done(function(i){if(nf.CanvasUtils.isProcessor(f)){nf.Processor.set(i.processor)
}else{if(nf.CanvasUtils.isProcessGroup(f)){nf.ProcessGroup.set(i.processGroup);
var j=nf.Connection.getComponentConnections(i.processGroup.id);
$.each(j,function(l,k){nf.Connection.reload(k)
})
}else{if(nf.CanvasUtils.isInputPort(f)){nf.Port.set(i.inputPort)
}else{if(nf.CanvasUtils.isOutputPort(f)){nf.Port.set(i.outputPort)
}}}}})
})
}}},enableTransmission:function(d){var e=d.filter(function(f){return nf.CanvasUtils.canStartTransmitting(d3.select(this))
});
e.each(function(f){c(f.component.uri,{transmitting:true}).done(function(g){nf.RemoteProcessGroup.set(g.remoteProcessGroup)
})
})
},disableTransmission:function(e){var d=e.filter(function(f){return nf.CanvasUtils.canStopTransmitting(d3.select(this))
});
d.each(function(f){c(f.component.uri,{transmitting:false}).done(function(g){nf.RemoteProcessGroup.set(g.remoteProcessGroup)
})
})
},showConfiguration:function(d){if(d.size()===1){if(nf.CanvasUtils.isProcessor(d)){nf.ProcessorConfiguration.showConfiguration(d)
}else{if(nf.CanvasUtils.isLabel(d)){nf.LabelConfiguration.showConfiguration(d)
}else{if(nf.CanvasUtils.isProcessGroup(d)){nf.ProcessGroupConfiguration.showConfiguration(d)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(d)){nf.RemoteProcessGroupConfiguration.showConfiguration(d)
}else{if(nf.CanvasUtils.isInputPort(d)||nf.CanvasUtils.isOutputPort(d)){if(nf.Canvas.getParentGroupId()===null&&nf.Canvas.isSecureSiteToSite()){nf.SecurePortConfiguration.showConfiguration(d)
}else{nf.PortConfiguration.showConfiguration(d)
}}else{if(nf.CanvasUtils.isConnection(d)){nf.ConnectionConfiguration.showConfiguration(d)
}}}}}}}},showDetails:function(d){if(d.size()===1){var e=d.datum();
if(nf.CanvasUtils.isProcessor(d)){nf.ProcessorDetails.showDetails(nf.Canvas.getGroupId(),e.component.id)
}else{if(nf.CanvasUtils.isProcessGroup(d)){nf.ProcessGroupDetails.showDetails(d)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(d)){nf.RemoteProcessGroupDetails.showDetails(d)
}else{if(nf.CanvasUtils.isInputPort(d)||nf.CanvasUtils.isOutputPort(d)){if(nf.Canvas.getParentGroupId()===null&&nf.Canvas.isSecureSiteToSite()){nf.SecurePortDetails.showDetails(d)
}else{nf.PortDetails.showDetails(d)
}}else{if(nf.CanvasUtils.isConnection(d)){nf.ConnectionDetails.showDetails(nf.Canvas.getGroupId(),e.component.id)
}}}}}}},showUsage:function(d){if(d.size()===1&&nf.CanvasUtils.isProcessor(d)){var e=d.datum();
nf.Shell.showPage("../nifi-docs/documentation?"+$.param({select:nf.Common.substringAfterLast(e.component.type,".")}))
}},showStats:function(d){if(d.size()===1){var e=d.datum();
if(nf.Canvas.isClustered()){if(nf.CanvasUtils.isProcessor(d)){nf.StatusHistory.showClusterProcessorChart(nf.Canvas.getGroupId(),e.component.id)
}else{if(nf.CanvasUtils.isProcessGroup(d)){nf.StatusHistory.showClusterProcessGroupChart(nf.Canvas.getGroupId(),e.component.id)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(d)){nf.StatusHistory.showClusterRemoteProcessGroupChart(nf.Canvas.getGroupId(),e.component.id)
}else{if(nf.CanvasUtils.isConnection(d)){nf.StatusHistory.showClusterConnectionChart(nf.Canvas.getGroupId(),e.component.id)
}}}}}else{if(nf.CanvasUtils.isProcessor(d)){nf.StatusHistory.showStandaloneProcessorChart(nf.Canvas.getGroupId(),e.component.id)
}else{if(nf.CanvasUtils.isProcessGroup(d)){nf.StatusHistory.showStandaloneProcessGroupChart(nf.Canvas.getGroupId(),e.component.id)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(d)){nf.StatusHistory.showStandaloneRemoteProcessGroupChart(nf.Canvas.getGroupId(),e.component.id)
}else{if(nf.CanvasUtils.isConnection(d)){nf.StatusHistory.showStandaloneConnectionChart(nf.Canvas.getGroupId(),e.component.id)
}}}}}}},remotePorts:function(d){if(d.size()===1&&nf.CanvasUtils.isRemoteProcessGroup(d)){nf.RemoteProcessGroupPorts.showPorts(d)
}},hideDialogs:function(){var d=$(".cancellable");
$.each(d,function(){if($(this).is(":visible")){$(this).modal("hide")
}})
},reloadStatus:function(){nf.Canvas.reloadStatus()
},"delete":function(e){if(nf.Common.isUndefined(e)||e.empty()){nf.Dialog.showOkDialog({dialogContent:"No eligible components are selected. Please select the components to be deleted.",overlayBackground:true})
}else{if(e.size()===1){var f=e.datum();
var d=nf.Client.getRevision();
$.ajax({type:"DELETE",url:f.component.uri+"?"+$.param({version:d.version,clientId:d.clientId}),dataType:"json"}).done(function(k){nf.Client.setRevision(k.revision);
nf[f.type].remove(f.component.id);
if(nf.CanvasUtils.isConnection(e)){var o=nf.CanvasUtils.getConnectionSourceComponentId(f.component);
var i=d3.select("#id-"+o);
var l=i.datum();
if(nf.CanvasUtils.isProcessor(i)){nf.Processor.reload(l.component)
}else{if(nf.CanvasUtils.isInputPort(i)){nf.Port.reload(l.component)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(i)){nf.RemoteProcessGroup.reload(l.component)
}}}var m=nf.CanvasUtils.getConnectionDestinationComponentId(f.component);
var n=d3.select("#id-"+m);
var j=n.datum();
if(nf.CanvasUtils.isRemoteProcessGroup(n)){nf.RemoteProcessGroup.reload(j.component)
}}else{var p=nf.Connection.getComponentConnections(f.component.id);
if(p.length>0){var h=[];
$.each(p,function(r,q){h.push(q.id)
});
nf.Connection.remove(h)
}}nf.Birdseye.refresh();
nf.CanvasToolbar.refresh()
}).fail(nf.Common.handleAjaxError)
}else{var g=nf.Snippet.marshal(e,true);
nf.Snippet.create(g).done(function(h){var i=h.snippet;
nf.Snippet.remove(i.id).done(function(){var k=d3.map();
var j=function(l,m){if(!k.has(l)){k.set(l,[])
}k.get(l).push(m)
};
e.each(function(m){j(m.type,m.component.id);
if(m.type!=="Connection"){var l=nf.Connection.getComponentConnections(m.component.id);
if(l.length>0){$.each(l,function(o,n){j("Connection",n.id)
})
}}});
k.forEach(function(m,l){nf[m].remove(l)
});
if(i.connections>0){e.filter(function(l){return l.type==="Connection"
}).each(function(r){var q=nf.CanvasUtils.getConnectionSourceComponentId(r.component);
var o=d3.select("#id-"+q);
var n=o.datum();
if(nf.CanvasUtils.isProcessor(o)){nf.Processor.reload(n.component)
}else{if(nf.CanvasUtils.isInputPort(o)){nf.Port.reload(n.component)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(o)){nf.RemoteProcessGroup.reload(n.component)
}}}var p=nf.CanvasUtils.getConnectionDestinationComponentId(r.component);
var l=d3.select("#id-"+p);
var m=l.datum();
if(nf.CanvasUtils.isRemoteProcessGroup(l)){nf.RemoteProcessGroup.reload(m.component)
}})
}nf.Birdseye.refresh();
nf.CanvasToolbar.refresh()
}).fail(function(l,j,k){nf.Snippet.unlink(i.id).done(function(){nf.Snippet.remove(i.id)
});
nf.Common.handleAjaxError(l,j,k)
})
}).fail(nf.Common.handleAjaxError)
}}},fillColor:function(e){if(e.size()===1&&(nf.CanvasUtils.isProcessor(e)||nf.CanvasUtils.isLabel(e))){var f=e.datum();
var d=nf[f.type].defaultColor();
if(nf.Common.isDefinedAndNotNull(f.component.style["background-color"])){d=f.component.style["background-color"]
}$("#fill-color-value").minicolors("value",d);
if(nf.CanvasUtils.isProcessor(e)){$("#fill-color-processor-preview").show();
$("#fill-color-label-preview").hide()
}else{$("#fill-color-processor-preview").hide();
$("#fill-color-label-preview").show()
}$("#fill-color-dialog").modal("show")
}},group:function(){var d=nf.CanvasUtils.getSelection();
if(d.empty()){return
}$.when(nf.CanvasUtils.eligibleForMove(d)).done(function(){var e=nf.CanvasUtils.getOrigin(d);
var f={x:e.x,y:e.y};
$.when(nf.CanvasToolbox.promptForGroupName(f)).done(function(g){var h=d3.select("#id-"+g.id);
nf.CanvasUtils.moveComponents(d,h)
})
})
},template:function(){var d=nf.CanvasUtils.getSelection();
if(d.empty()){d=d3.selectAll("g.component, g.connection")
}if(d.empty()){nf.Dialog.showOkDialog({dialogContent:"The current selection is not valid to create a template.",overlayBackground:false});
return
}d=nf.CanvasUtils.trimDanglingEdges(d);
if(d.empty()){nf.Dialog.showOkDialog({dialogContent:"The current selection is not valid to create a template.",overlayBackground:false});
return
}$("#new-template-dialog").modal("setButtonModel",[{buttonText:"Create",handler:{click:function(){$("#new-template-dialog").modal("hide");
var e=$("#new-template-name").val();
var g=$("#new-template-description").val();
var f=nf.Snippet.marshal(d,false);
nf.Snippet.create(f).done(function(h){var i=h.snippet;
$.ajax({type:"POST",url:b.urls.controller+"/templates",data:{name:e,description:g,snippetId:i.id},dataType:"json"}).done(function(){nf.Dialog.showOkDialog({dialogContent:"Template '"+nf.Common.escapeHtml(e)+"' was successfully created.",overlayBackground:false})
}).always(function(){nf.Snippet.remove(i.id);
$("#new-template-name").val("");
$("#new-template-description").val("")
}).fail(nf.Common.handleAjaxError)
}).fail(nf.Common.handleAjaxError)
}}},{buttonText:"Cancel",handler:{click:function(){$("#new-template-dialog").modal("hide")
}}}]).modal("show");
$("#new-template-name").focus()
},copy:function(e){if(e.empty()){return
}var d=nf.CanvasUtils.getOrigin(e);
nf.Clipboard.copy({snippet:nf.Snippet.marshal(e,false),origin:d})
},paste:function(k,l){if(nf.Common.isDefinedAndNotNull(l)){var f=nf.Canvas.View.scale();
var d=nf.Canvas.View.translate();
var g=l.pageX;
var e=l.pageY-nf.Canvas.CANVAS_OFFSET;
var j=(g/f)-(d[0]/f);
var i=(e/f)-(d[1]/f);
var h={x:j,y:i}
}nf.Clipboard.paste().done(function(n){var m=$.Deferred(function(o){var p=function(){o.reject()
};
nf.Snippet.create(n.snippet).done(function(s){var t=s.snippet;
var r=h;
var q=n.origin;
if(!nf.Common.isDefinedAndNotNull(r)){q.x+=25;
q.y+=25;
r=q
}nf.Snippet.copy(t.id,nf.Canvas.getGroupId(),r).done(function(v){var u=v.contents;
nf.Graph.add(u,true);
nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh();
nf.CanvasToolbar.refresh();
nf.Snippet.remove(t.id).fail(p)
}).fail(function(){nf.Canvas.reload().done(function(){nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh();
nf.CanvasToolbar.refresh()
});
p()
})
}).fail(p)
}).promise();
m.fail(function(){nf.Dialog.showOkDialog({dialogContent:"An error occurred while attempting to copy and paste.",overlayBackground:true})
})
})
},toFront:function(g){if(g.size()!==1||!nf.CanvasUtils.isConnection(g)){return
}var d=g.datum();
var f=-1;
$.each(nf.Connection.get(),function(i,j){if(d.component.id!==j.component.id&&j.component.zIndex>f){f=j.component.zIndex
}});
if(f>=0){var h=f+1;
var e=nf.Client.getRevision();
$.ajax({type:"PUT",url:d.component.uri,data:{version:e.version,clientId:e.clientId,zIndex:h},dataType:"json"}).done(function(i){nf.Connection.set(i.connection);
nf.Connection.reorder();
nf.Client.setRevision(i.revision)
})
}}}
}());