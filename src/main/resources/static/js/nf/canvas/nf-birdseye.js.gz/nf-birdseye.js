nf.Birdseye=(function(){var d;
var b;
var a=function(x){var v=nf.Canvas.View.translate();
var M=nf.Canvas.View.scale();
v=[v[0]/M,v[1]/M];
var p=d3.select("#canvas").node().getBoundingClientRect();
var e=(p.left/M)-v[0];
var r=((p.top-nf.Canvas.CANVAS_OFFSET)/M)-v[1];
var w=(p.right/M)-v[0];
var k=(p.bottom/M)-v[1];
var z=$("#canvas-container");
var A=z.width()/M;
var K=z.height()/M;
var q=-v[0];
var E=-v[1];
var L=q+A;
var n=E+K;
var C=Math.min(e,q);
var F=Math.min(r,E);
var h=Math.max(w,L);
var I=Math.max(k,n);
var J=h-C;
var f=I-F;
var u=$("#birdseye");
var t=u.width();
var m=u.height();
var D=t/J;
var l=m/f;
var B=Math.min(D,l);
var j=[0,0];
var g=[0,0];
if(v[0]<0&&v[1]<0){j=[0,0];
g=[-v[0],-v[1]]
}else{if(v[0]>=0&&v[1]<0){j=[v[0],0];
g=[0,-v[1]]
}else{if(v[0]<0&&v[1]>=0){j=[0,v[1]];
g=[-v[0],0]
}else{j=[v[0],v[1]];
g=[0,0]
}}}var H=0;
var o=-e;
if(v[0]<0){if(v[0]<o){H=o
}else{H=o-(o-v[0])
}}else{if(v[0]<o){H=o-v[0]
}}var G=0;
var y=-r;
if(v[1]<0){if(v[1]<y){G=y
}else{G=y-(y-v[1])
}}else{if(v[1]<y){G=y-v[1]
}}j=[j[0]+H,j[1]+G];
g=[g[0]+H,g[1]+G];
d.attr("transform","scale("+B+")");
b.attr("transform","translate("+j+")");
d3.select("rect.birdseye-brush").attr({width:A,height:K,"stroke-width":(2/B),transform:function(N){N.x=g[0];
N.y=g[1];
return"translate("+g+")"
}});
var s=d3.select("#birdseye-canvas").node();
var i=s.getContext("2d");
i.save();
i.setTransform(1,0,0,1,0,0);
i.clearRect(0,0,s.width,s.height);
i.restore();
i.save();
i.translate(j[0]*B,j[1]*B);
i.scale(B,B);
$.each(x.labels,function(O,P){var N=nf.Label.defaultColor();
if(nf.Common.isDefinedAndNotNull(P.component.style["background-color"])){N=P.component.style["background-color"]
}i.fillStyle=N;
i.fillRect(P.component.position.x,P.component.position.y,P.dimensions.width,P.dimensions.height)
});
i.fillStyle="#9f6000";
$.each(x.funnels,function(N,O){i.fillRect(O.component.position.x,O.component.position.y,O.dimensions.width,O.dimensions.height)
});
i.fillStyle="#aaa";
$.each(x.ports,function(N,O){i.fillRect(O.component.position.x,O.component.position.y,O.dimensions.width,O.dimensions.height)
});
i.fillStyle="#294c58";
$.each(x.remoteProcessGroups,function(N,O){i.fillRect(O.component.position.x,O.component.position.y,O.dimensions.width,O.dimensions.height)
});
i.fillStyle="#294c58";
$.each(x.processGroups,function(N,O){i.fillRect(O.component.position.x,O.component.position.y,O.dimensions.width,O.dimensions.height)
});
$.each(x.processors,function(O,P){var N=nf.Processor.defaultColor();
if(nf.Common.isDefinedAndNotNull(P.component.style["background-color"])){N=P.component.style["background-color"]
}i.fillStyle=N;
i.fillRect(P.component.position.x,P.component.position.y,P.dimensions.width,P.dimensions.height)
});
i.restore()
};
var c=true;
return{init:function(){var h=$("#birdseye");
var g=$("#birdseye-container");
$("#birdseye-collapse").click(function(){if(h.is(":visible")){$(this).removeClass("birdseye-expanded-hover").addClass("birdseye-collapsed-hover");
h.hide();
g.hide();
c=false;
$("#controller-counts").css("margin-right","-13px")
}else{$(this).removeClass("birdseye-collapsed-hover").addClass("birdseye-expanded-hover");
$("#controller-counts").css("margin-right","195px");
h.show();
g.show();
c=true;
a(nf.Graph.get())
}}).mouseover(function(){if(h.is(":visible")){$(this).removeClass("birdseye-expanded").addClass("birdseye-expanded-hover")
}else{$(this).removeClass("birdseye-collapsed").addClass("birdseye-collapsed-hover")
}}).mouseout(function(){if(h.is(":visible")){$(this).removeClass("birdseye-expanded-hover").addClass("birdseye-expanded")
}else{$(this).removeClass("birdseye-collapsed-hover").addClass("birdseye-collapsed")
}});
d3.select("#birdseye").append("canvas").attr("id","birdseye-canvas").attr("width",h.width()).attr("height",h.height());
var f=d3.select("#birdseye").append("svg").attr("width",h.width()).attr("height",h.height());
d=f.append("g").attr("class","birdseye");
b=d.append("g").attr("pointer-events","none");
var e=d3.behavior.drag().origin(function(i){return{x:i.x,y:i.y}
}).on("dragstart",function(){nf.ContextMenu.hide()
}).on("drag",function(k){k.x+=d3.event.dx;
k.y+=d3.event.dy;
d3.select(this).attr("transform",function(){return"translate("+k.x+", "+k.y+")"
});
var j=nf.Canvas.View.scale();
var i=nf.Canvas.View.translate();
i=[(-d3.event.dx*j)+i[0],(-d3.event.dy*j)+i[1]];
nf.Canvas.View.translate(i);
nf.Canvas.View.refresh({persist:false,transition:false,refreshComponents:false,refreshBirdseye:false})
}).on("dragend",function(){nf.Canvas.View.updateVisibility();
nf.CanvasUtils.persistUserView();
nf.Birdseye.refresh()
});
d.append("g").attr({"pointer-events":"all","class":"birdseye-brush-container"}).append("rect").attr("class","birdseye-brush moveable").datum({x:0,y:0}).call(e)
},refresh:function(){if(c){a(nf.Graph.get())
}}}
}());