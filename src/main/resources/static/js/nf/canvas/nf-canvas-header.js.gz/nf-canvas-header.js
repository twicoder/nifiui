nf.CanvasHeader=(function(){var a={urls:{helpDocument:"../nifi-docs/documentation",controllerAbout:"../nifi-api/controller/about"}};
return{init:function(){nf.Common.addHoverEffect("#reporting-link","reporting-link","reporting-link-hover").click(function(){nf.Shell.showPage("summary")
});
nf.Common.addHoverEffect("#counters-link","counters-link","counters-link-hover").click(function(){nf.Shell.showPage("counters")
});
nf.Common.addHoverEffect("#history-link","history-link","history-link-hover").click(function(){nf.Shell.showPage("history")
});
if(nf.Common.canAccessProvenance()){nf.Common.addHoverEffect("#provenance-link","provenance-link","provenance-link-hover").click(function(){nf.Shell.showPage("provenance")
})
}else{$("#provenance-link").addClass("provenance-link-disabled")
}nf.Common.addHoverEffect("#templates-link","templates-link","templates-link-hover").click(function(){nf.Shell.showPage("templates")
});
if(nf.Common.isDFM()){nf.Common.addHoverEffect("#flow-settings-link","flow-settings-link","flow-settings-link-hover").click(function(){nf.Settings.showSettings()
})
}else{$("#flow-settings-link").addClass("flow-settings-link-disabled")
}if(nf.Common.isAdmin()){nf.Common.addHoverEffect("#users-link","users-link","users-link-hover").click(function(){nf.Shell.showPage("users")
})
}else{$("#users-link").addClass("users-link-disabled")
}if(nf.Canvas.isClustered()){nf.Common.addHoverEffect("#cluster-link","cluster-link","cluster-link-hover").click(function(){nf.Shell.showPage("cluster")
});
$("#connected-nodes-element").show();
$("#cluster-indicator").show();
$("#data-flow-title-viewport").css("left","113px")
}else{$("#cluster-link").hide()
}nf.Common.addHoverEffect("#bulletin-board-link","bulletin-board-link","bulletin-board-hover").click(function(){nf.Shell.showPage("bulletin-board")
});
$("#refresh-required-icon").qtip($.extend({content:"This flow has been modified by another user. Please refresh."},nf.CanvasUtils.config.systemTooltipConfig));
$("#refresh-required-link").click(function(){nf.Canvas.reload().done(function(){nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh();
$("#stats-last-refreshed").removeClass("alert");
$("#refresh-required-container").hide()
}).fail(function(){nf.Dialog.showOkDialog({dialogContent:"Unable to refresh the current group.",overlayBackground:true})
})
});
$.ajax({type:"GET",url:a.urls.controllerAbout,dataType:"json"}).done(function(c){var b=c.about;
document.title=b.title;
$("#nf-version").text(b.version)
}).fail(nf.Common.handleAjaxError);
$("#nf-about").modal({overlayBackground:true,buttons:[{buttonText:"Ok",handler:{click:function(){$("#nf-about").modal("hide")
}}}]});
$("#about-link").click(function(){$("#nf-about").modal("show")
});
$("#help-link").click(function(){nf.Shell.showPage(a.urls.helpDocument)
});
$("#new-template-dialog").modal({headerText:"Create Template",overlayBackground:false});
$("#fill-color-dialog").modal({headerText:"Fill",overlayBackground:false,buttons:[{buttonText:"Apply",handler:{click:function(){$("#fill-color-dialog").modal("hide");
var d=nf.CanvasUtils.getSelection();
if(d.size()===1&&(nf.CanvasUtils.isProcessor(d)||nf.CanvasUtils.isLabel(d))){var c=nf.Client.getRevision();
var e=d.datum();
var b=$("#fill-color-value").val();
$.ajax({type:"PUT",url:e.component.uri,data:{version:c.version,clientId:c.clientId,"style[background-color]":b},dataType:"json"}).done(function(f){nf.Client.setRevision(f.revision);
if(nf.CanvasUtils.isProcessor(d)){nf.Processor.set(f.processor)
}else{nf.Label.set(f.label)
}}).fail(function(h,f,g){if(h.status===400||h.status===404||h.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(h.responseText),overlayBackground:true})
}})
}}}},{buttonText:"Cancel",handler:{click:function(){$("#fill-color-dialog").modal("hide")
}}}]});
$("#fill-color-value").minicolors({inline:true,change:function(c,b){$("#fill-color-processor-preview, #fill-color-label-preview").css({"border-color":c,background:"linear-gradient(to bottom, #ffffff, "+c+")",filter:"progid:DXImageTransform.Microsoft.gradient(gradientType=0, startColorstr=#ffffff, endColorstr="+c+")"})
}});
$("#data-flow-title-viewport").on("DOMMouseScroll mousewheel",function(o,h){if(nf.Common.isUndefinedOrNull(o.originalEvent)){return
}var i=$("#data-flow-title-container");
var b=i.position();
var m=i.outerWidth();
var f=b.left+m;
var j=$("#breadcrumbs-right-border").width();
var g=$("#data-flow-title-viewport");
var e=g.width();
var c=e-j;
if(m>e){var l=false;
var n=0;
if(nf.Common.isDefinedAndNotNull(o.originalEvent.detail)){n=-o.originalEvent.detail
}else{if(nf.Common.isDefinedAndNotNull(evnt.originalEvent.wheelDelta)){n=o.originalEvent.wheelDelta
}}if(n>0&&f>c){var k=-25;
l=true
}else{if(n<0&&(b.left-j)<0){k=25;
if(b.left+k>j){k=j-b.left
}l=true
}}if(l){i.css("left",(b.left+k)+"px")
}}})
}}
}());