nf.CanvasToolbar=(function(){var a;
return{init:function(){a={};
var d=$("<div/>").addClass("control-separator");
var b=$("<div/>").addClass("control-border");
var c=$("#global-controls")[0];
b.clone().appendTo(c);
a.enable=new nf.ToolbarAction(c,"enable","action-enable","enable-all","enable-all-hover","enable-all-disable","Enable");
b.clone().appendTo(c);
a.disable=new nf.ToolbarAction(c,"disable","action-disable","disable-all","disable-all-hover","disable-all-disable","Disable");
b.clone().appendTo(c);
d.clone().appendTo(c);
b.clone().appendTo(c);
a.start=new nf.ToolbarAction(c,"start","action-start","start-all","start-all-hover","start-all-disable","Start");
b.clone().appendTo(c);
a.stop=new nf.ToolbarAction(c,"stop","action-stop","stop-all","stop-all-hover","stop-all-disable","Stop");
b.clone().appendTo(c);
d.clone().appendTo(c);
b.clone().appendTo(c);
a.template=new nf.ToolbarAction(c,"template","action-template","template","template-hover","template-disable","Create Template");
b.clone().appendTo(c);
d.clone().appendTo(c);
b.clone().appendTo(c);
a.copy=new nf.ToolbarAction(c,"copy","action-copy","copy","copy-hover","copy-disable","Copy");
b.clone().appendTo(c);
a.paste=new nf.ToolbarAction(c,"paste","action-paste","paste","paste-hover","paste-disable","Paste");
b.clone().appendTo(c);
d.clone().appendTo(c);
b.clone().appendTo(c);
a.group=new nf.ToolbarAction(c,"group","action-group","group","group-hover","group-disable","Group");
b.appendTo(c);
d.clone().appendTo(c);
b.clone().appendTo(c);
a.fill=new nf.ToolbarAction(c,"fillColor","action-fill","fill","fill-hover","fill-disable","Change Color");
b.clone().appendTo(c);
d.clone().appendTo(c);
b.clone().appendTo(c);
a["delete"]=new nf.ToolbarAction(c,"delete","action-delete","delete","delete-hover","delete-disable","Delete");
b.appendTo(c);
d.appendTo(c);
if(nf.Common.isDFM()){a.start.enable();
a.stop.enable();
a.template.enable()
}else{a.start.disable();
a.stop.disable();
a.template.disable()
}a.enable.disable();
a.disable.disable();
a.copy.disable();
a.paste.disable();
a.fill.disable();
a["delete"].disable();
a.group.disable();
if(nf.Common.isDFM()){nf.Clipboard.addListener(this,function(f,e){if(nf.Clipboard.isCopied()){a.paste.enable()
}else{a.paste.disable()
}})
}},refresh:function(){if(nf.Common.isUndefined(a)){return
}if(nf.Common.isDFM()){var e=nf.CanvasUtils.getSelection();
if(!e.empty()){var b=true;
e.each(function(f){if(!nf.CanvasUtils.isDeletable(d3.select(this))){b=false;
return false
}});
if(b){a["delete"].enable()
}else{a["delete"].disable()
}}else{a["delete"].disable()
}if(nf.CanvasUtils.isCopyable(e)){a.copy.enable()
}else{a.copy.disable()
}if(!e.empty()&&nf.CanvasUtils.isDisconnected(e)){a.group.enable()
}else{a.group.disable()
}var d=e.filter(function(g){var f=d3.select(this);
return nf.CanvasUtils.isProcessor(f)||nf.CanvasUtils.isLabel(f)
});
if(d.size()===1&&d.size()===e.size()){a.fill.enable()
}else{a.fill.disable()
}var c=e.filter(function(g){var f=d3.select(this);
return nf.CanvasUtils.isProcessor(f)||nf.CanvasUtils.isInputPort(f)||nf.CanvasUtils.isOutputPort(f)
});
if(!c.empty()&&c.size()===e.size()){a.enable.enable();
a.disable.enable()
}else{a.enable.disable();
a.disable.disable()
}}}}
}());