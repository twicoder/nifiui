nf.CanvasToolbox=(function(){var s={maxTags:25,maxTagFontSize:2,minTagFontSize:1,minWidth:20,filterText:"Filter",type:{processor:"Processor",inputPort:"Input Port",outputPort:"Output Port",processGroup:"Process Group",remoteProcessGroup:"Remote Process Group",connection:"Connection",funnel:"Funnel",template:"Template",label:"Label"},styles:{filterList:"filter-list"},urls:{controller:"../nifi-api/controller",processorTypes:"../nifi-api/controller/processor-types",templates:"../nifi-api/controller/templates"}};
var d=function(C,D,z,y,x,B){var A=C+"-icon";
$("<div/>").attr("id",A).attr("title",C).addClass(z).addClass("pointer").addClass("toolbox-icon").hover(function(){$(this).removeClass(z).addClass(y)
},function(){$(this).removeClass(y).addClass(z)
}).draggable({zIndex:1011,helper:function(){return $('<div class="toolbox-icon"></div>').addClass(x).appendTo("body")
},containment:"body",start:function(F,E){nf.ContextMenu.hide()
},stop:function(I,H){var K=nf.Canvas.View.translate();
var J=nf.Canvas.View.scale();
var G=I.originalEvent.pageX;
var F=I.originalEvent.pageY-nf.Canvas.CANVAS_OFFSET;
if(G>=0&&F>=0){var E=(G/J)-(K[0]/J);
var L=(F/J)-(K[1]/J);
B({x:E,y:L})
}}}).appendTo(D)
};
var w=function(x){var z=$("#tag-filter");
var C=false;
z.find("li div.selected-tag-text").each(function(){if(x===$(this).text()){C=true;
return false
}});
if(!C){var B=$('<div class="selected-tag-text"></div>').text(x);
var y=$('<img src="images/iconDelete.png" class="remove-selected-tag pointer"></img>').click(function(){$(this).closest("li").remove();
v()
});
var A=$("<div></div>").append(B).append(y);
$("<li></li>").append(A).appendTo(z);
v()
}};
var v=function(){var x=$("#processor-types-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(x)){var y=x.getData();
y.setFilterArgs({searchString:q(),property:$("#processor-type-filter-options").combo("getSelectedOption").value});
y.refresh()
}};
var u=function(y,x){if(x.searchString===""){return true
}try{var A=new RegExp(x.searchString,"i")
}catch(z){return false
}return y[x.property].search(A)>=0
};
var h=function(C,z){var y=u(C,z);
var x=true;
if(y){var A=$("#tag-filter li");
var B=A.length>0;
if(B){x=i(A,C.tags)
}}var D=y&&x;
if(D===false&&$("#selected-processor-type").text()===C.type){$("#processor-type-description").text("");
$("#processor-type-name").text("");
$("#selected-processor-name").text("");
$("#selected-processor-type").text("");
var E=$("#processor-types-table").data("gridInstance");
E.resetActiveCell()
}return D
};
var i=function(z,x){var y=[];
z.each(function(){y.push($(this).text())
});
var A=x.toLowerCase();
var B=true;
$.each(y,function(C,D){if(A.indexOf(D)===-1){B=false;
return false
}});
return B
};
var r=function(x,z){var y=function(C,A){var B=nf.Common.isDefinedAndNotNull(C[x.columnId])?C[x.columnId]:"";
var D=nf.Common.isDefinedAndNotNull(A[x.columnId])?A[x.columnId]:"";
return B===D?0:B>D?1:-1
};
z.sort(y,x.sortAsc)
};
var q=function(){var y="";
var x=$("#processor-type-filter");
if(!x.hasClass(s.styles.filterList)){y=x.val()
}return y
};
var f=function(){var x=$("#tag-filter");
x.empty();
$("#processor-type-filter").addClass(s.styles.filterList).val(s.filterText);
v();
$("#processor-type-description").text("");
$("#processor-type-name").text("");
$("#selected-processor-name").text("");
$("#selected-processor-type").text("");
var y=$("#processor-types-table").data("gridInstance");
y.setSelectedRows([]);
y.resetActiveCell()
};
var k=function(A){var z=function(){var B=$("#selected-processor-name").text();
var C=$("#selected-processor-type").text();
if(B===""||C===""){nf.Dialog.showOkDialog({dialogContent:"The type of processor to create must be selected.",overlayBackground:false})
}else{g(B,C,A)
}$("#new-processor-dialog").modal("hide")
};
var y=$("#processor-types-table").data("gridInstance");
var x=function(C,B){var D=y.getDataItem(B.row);
$("#selected-processor-name").text(D.label);
$("#selected-processor-type").text(D.type);
z()
};
y.onDblClick.subscribe(x);
$("#new-processor-dialog").modal("setButtonModel",[{buttonText:"Add",handler:{click:z}},{buttonText:"Cancel",handler:{click:function(){$("#new-processor-dialog").modal("hide")
}}}]);
$("#new-processor-dialog").modal("setHandler",{close:function(){y.onDblClick.unsubscribe(x);
f()
}});
$("#new-processor-dialog").modal("show");
y.resizeCanvas()
};
var g=function(y,A,z){var x=nf.Client.getRevision();
$.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/processors",data:{version:x.version,clientId:x.clientId,name:y,type:A,x:z.x,y:z.y},dataType:"json"}).done(function(B){if(nf.Common.isDefinedAndNotNull(B.processor)){nf.Client.setRevision(B.revision);
nf.Graph.add({processors:[B.processor]},true);
nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh()
}}).fail(nf.Common.handleAjaxError)
};
var b=function(y){var x=function(){$("#new-port-dialog").modal("hide");
var z=$("#new-port-name").val();
$("#new-port-name").val("");
m(z,y)
};
$("#new-port-dialog").modal("setButtonModel",[{buttonText:"Add",handler:{click:x}},{buttonText:"Cancel",handler:{click:function(){$("#new-port-dialog").modal("hide")
}}}]);
$("#new-port-type").text("Input");
$("#new-port-dialog").modal("show");
$("#new-port-name").focus().off("keyup").on("keyup",function(A){var z=A.keyCode?A.keyCode:A.which;
if(z===$.ui.keyCode.ENTER){x()
}})
};
var m=function(z,y){var x=nf.Client.getRevision();
$.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/input-ports",data:{version:x.version,clientId:x.clientId,name:z,x:y.x,y:y.y},dataType:"json"}).done(function(A){if(nf.Common.isDefinedAndNotNull(A.inputPort)){nf.Client.setRevision(A.revision);
nf.Graph.add({inputPorts:[A.inputPort]},true);
nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh()
}}).fail(nf.Common.handleAjaxError)
};
var a=function(y){var x=function(){$("#new-port-dialog").modal("hide");
var z=$("#new-port-name").val();
$("#new-port-name").val("");
j(z,y)
};
$("#new-port-dialog").modal("setButtonModel",[{buttonText:"Add",handler:{click:x}},{buttonText:"Cancel",handler:{click:function(){$("#new-port-dialog").modal("hide")
}}}]);
$("#new-port-type").text("Output");
$("#new-port-dialog").modal("show");
$("#new-port-name").focus().off("keyup").on("keyup",function(A){var z=A.keyCode?A.keyCode:A.which;
if(z===$.ui.keyCode.ENTER){x()
}})
};
var j=function(z,y){var x=nf.Client.getRevision();
$.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/output-ports",data:{version:x.version,clientId:x.clientId,name:z,x:y.x,y:y.y},dataType:"json"}).done(function(A){if(nf.Common.isDefinedAndNotNull(A.outputPort)){nf.Client.setRevision(A.revision);
nf.Graph.add({outputPorts:[A.outputPort]},true);
nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh()
}}).fail(nf.Common.handleAjaxError)
};
var p=function(z,y){var x=nf.Client.getRevision();
return $.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/process-group-references",data:{version:x.version,clientId:x.clientId,name:z,x:y.x,y:y.y},dataType:"json"}).done(function(A){if(nf.Common.isDefinedAndNotNull(A.processGroup)){nf.Client.setRevision(A.revision);
nf.Graph.add({processGroups:[A.processGroup]},true);
nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh()
}}).fail(nf.Common.handleAjaxError)
};
var c=function(y){var x=function(){$("#new-remote-process-group-dialog").modal("hide");
var z=$("#new-remote-process-group-uri").val();
$("#new-remote-process-group-uri").val("");
e(z,y)
};
$("#new-remote-process-group-dialog").modal("setButtonModel",[{buttonText:"Add",handler:{click:x}},{buttonText:"Cancel",handler:{click:function(){$("#new-remote-process-group-dialog").modal("hide")
}}}]);
$("#new-remote-process-group-dialog").modal("show");
$("#new-remote-process-group-uri").focus().off("keyup").on("keyup",function(A){var z=A.keyCode?A.keyCode:A.which;
if(z===$.ui.keyCode.ENTER){x()
}})
};
var e=function(z,y){var x=nf.Client.getRevision();
$.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/remote-process-groups",data:{version:x.version,clientId:x.clientId,uri:z,x:y.x,y:y.y},dataType:"json"}).done(function(A){if(nf.Common.isDefinedAndNotNull(A.remoteProcessGroup)){nf.Client.setRevision(A.revision);
nf.Graph.add({remoteProcessGroups:[A.remoteProcessGroup]},true);
nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh()
}}).fail(nf.Common.handleAjaxError)
};
var n=function(y){var x=nf.Client.getRevision();
$.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/funnels",data:{version:x.version,clientId:x.clientId,x:y.x,y:y.y},dataType:"json"}).done(function(z){if(nf.Common.isDefinedAndNotNull(z.funnel)){nf.Client.setRevision(z.revision);
nf.Graph.add({funnels:[z.funnel]},true);
nf.Birdseye.refresh()
}}).fail(nf.Common.handleAjaxError)
};
var t=function(x){$.ajax({type:"GET",url:s.urls.templates,dataType:"json"}).done(function(y){var A=y.templates;
if(nf.Common.isDefinedAndNotNull(A)&&A.length>0){var z=[];
$.each(A,function(B,C){z.push({text:C.name,value:C.id,description:nf.Common.escapeHtml(C.description)})
});
$("#available-templates").combo({maxHeight:300,options:z});
$("#instantiate-template-dialog").modal("setButtonModel",[{buttonText:"Add",handler:{click:function(){var C=$("#available-templates").combo("getSelectedOption");
var B=C.value;
$("#instantiate-template-dialog").modal("hide");
l(B,x)
}}},{buttonText:"Cancel",handler:{click:function(){$("#instantiate-template-dialog").modal("hide")
}}}]);
$("#instantiate-template-dialog").modal("show")
}else{nf.Dialog.showOkDialog({headerText:"Instantiate Template",dialogContent:"No templates have been loaded into this NiFi.",overlayBackground:false})
}}).fail(nf.Common.handleAjaxError)
};
var l=function(y,z){var x=nf.Client.getRevision();
$.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/template-instance",data:{version:x.version,clientId:x.clientId,templateId:y,originX:z.x,originY:z.y},dataType:"json"}).done(function(A){nf.Client.setRevision(A.revision);
nf.Graph.add(A.contents,true);
nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh()
}).fail(nf.Common.handleAjaxError)
};
var o=function(y){var x=nf.Client.getRevision();
$.ajax({type:"POST",url:s.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/labels",data:{version:x.version,clientId:x.clientId,x:y.x,y:y.y,width:nf.Label.config.width,height:nf.Label.config.height},dataType:"json"}).done(function(z){if(nf.Common.isDefinedAndNotNull(z.label)){nf.Client.setRevision(z.revision);
nf.Label.add(z.label,true);
nf.Birdseye.refresh()
}}).fail(nf.Common.handleAjaxError)
};
return{init:function(){var A=$("#toolbox");
if(nf.Common.isDFM()){d(s.type.processor,A,"processor-icon","processor-icon-hover","processor-icon-drag",k);
d(s.type.inputPort,A,"input-port-icon","input-port-icon-hover","input-port-icon-drag",b);
d(s.type.outputPort,A,"output-port-icon","output-port-icon-hover","output-port-icon-drag",a);
d(s.type.processGroup,A,"process-group-icon","process-group-icon-hover","process-group-icon-drag",nf.CanvasToolbox.promptForGroupName);
d(s.type.remoteProcessGroup,A,"remote-process-group-icon","remote-process-group-icon-hover","remote-process-group-icon-drag",c);
d(s.type.funnel,A,"funnel-icon","funnel-icon-hover","funnel-icon-drag",n);
d(s.type.template,A,"template-icon","template-icon-hover","template-icon-drag",t);
d(s.type.label,A,"label-icon","label-icon-hover","label-icon-drag",o);
$("#processor-type-filter-options").combo({options:[{text:"by type",value:"label"},{text:"by tag",value:"tags"}],select:function(C){v()
}});
var y=[{id:"type",name:"Type",field:"label",sortable:true,resizable:true},{id:"tags",name:"Tags",field:"tags",sortable:true,resizable:true}];
var B={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var z=new Slick.Data.DataView({inlineFilters:false});
z.setItems([]);
z.setFilterArgs({searchString:q(),property:$("#processor-type-filter-options").combo("getSelectedOption").value});
z.setFilter(h);
r({columnId:"type",sortAsc:true},z);
var x=new Slick.Grid("#processor-types-table",z,y,B);
x.setSelectionModel(new Slick.RowSelectionModel());
x.registerPlugin(new Slick.AutoTooltips());
x.setSortColumn("type",true);
x.onSort.subscribe(function(D,C){r({columnId:C.sortCol.field,sortAsc:C.sortAsc},z)
});
x.onSelectedRowsChanged.subscribe(function(E,D){if($.isArray(D.rows)&&D.rows.length===1){var C=D.rows[0];
var F=x.getDataItem(C);
if(nf.Common.isBlank(F.description)){$("#processor-type-description").attr("title","").html('<span class="unset">No description specified</span>')
}else{$("#processor-type-description").text(F.description).ellipsis()
}$("#processor-type-name").text(F.label).ellipsis();
$("#selected-processor-name").text(F.label);
$("#selected-processor-type").text(F.type)
}});
$("#processor-types-table").data("gridInstance",x);
$.ajax({type:"GET",url:s.urls.processorTypes,dataType:"json"}).done(function(C){var E={};
var D=[];
z.beginUpdate();
$.each(C.processorTypes,function(G,I){var H=I.type;
z.addItem({id:G,label:nf.Common.substringAfterLast(H,"."),type:H,description:nf.Common.escapeHtml(I.description),tags:I.tags.join(", ")});
$.each(I.tags,function(L,J){var M=J.toLowerCase();
if(nf.Common.isDefinedAndNotNull(E[M])){E[M].count=E[M].count+1
}else{var K={term:M,count:1};
D.push(K);
E[M]=K
}})
});
z.endUpdate();
$("#total-processor-types, #displayed-processor-types").text(C.processorTypes.length);
if(D.length>0){D.sort(function(H,G){return G.count-H.count
});
if(D.length>s.maxTags){D=D.slice(0,s.maxTags)
}var F=D[0].count;
D.sort(function(H,G){var J=H.term.toUpperCase();
var I=G.term.toUpperCase();
return(J<I)?-1:(J>I)?1:0
});
$.each(D,function(H,G){var J=Math.log(G.count)/Math.log(F)*(s.maxTagFontSize-s.minTagFontSize)+s.minTagFontSize;
var I=s.minWidth*J;
$("<li></li>").append($('<span class="link"></span>').text(G.term).css({"font-size":J+"em"})).css({"min-width":I+"px"}).click(function(){if($("#tag-filter").children("li").length<5){var K=$(this).children("span").text();
w(K)
}}).appendTo("#tag-cloud").ellipsis()
})
}else{$('<li><span class="unset">No tags specified</span></li>').appendTo("#tag-cloud")
}z.onRowCountChanged.subscribe(function(H,G){x.updateRowCount();
x.render();
$("#displayed-processor-types").text(G.current)
});
z.onRowsChanged.subscribe(function(H,G){x.invalidateRows(G.rows);
x.render()
});
z.syncGridSelection(x,false)
}).fail(nf.Common.handleAjaxError);
$("#processor-type-filter").keyup(function(){v()
}).focus(function(){if($(this).hasClass(s.styles.filterList)){$(this).removeClass(s.styles.filterList).val("")
}}).blur(function(){if($(this).val()===""){$(this).addClass(s.styles.filterList).val(s.filterText)
}}).addClass(s.styles.filterList).val(s.filterText);
$("#new-processor-dialog").modal({headerText:"Add Processor",overlayBackground:false});
$("#new-port-dialog").modal({headerText:"Add Port",overlayBackground:false});
$("#new-process-group-dialog").modal({headerText:"Add Process Group",overlayBackground:false});
$("#new-remote-process-group-dialog").modal({headerText:"Add Remote Process Group",overlayBackground:false});
$("#instantiate-template-dialog").modal({headerText:"Instantiate Template",overlayBackgroud:false})
}else{$("<div/>").attr("title",s.type.processor).addClass("processor-icon-disable").addClass("toolbox-icon").appendTo(A);
$("<div/>").attr("title",s.type.inputPort).addClass("input-port-icon-disable").addClass("toolbox-icon").appendTo(A);
$("<div/>").attr("title",s.type.outputPort).addClass("output-port-icon-disable").addClass("toolbox-icon").appendTo(A);
$("<div/>").attr("title",s.type.processGroup).addClass("process-group-icon-disable").addClass("toolbox-icon").appendTo(A);
$("<div/>").attr("title",s.type.remoteProcessGroup).addClass("remote-process-group-icon-disable").addClass("toolbox-icon").appendTo(A);
$("<div/>").attr("title",s.type.funnel).addClass("funnel-icon-disable").addClass("toolbox-icon").appendTo(A);
$("<div/>").attr("title",s.type.template).addClass("template-icon-disable").addClass("toolbox-icon").appendTo(A);
$("<div/>").attr("title",s.type.label).addClass("label-icon-disable").addClass("toolbox-icon").appendTo(A)
}},promptForGroupName:function(x){return $.Deferred(function(y){var z=function(){$("#new-process-group-dialog").modal("hide");
var A=$("#new-process-group-name").val();
$("#new-process-group-name").val("");
p(A,x).done(function(B){y.resolve(B.processGroup)
}).fail(function(){y.reject()
})
};
$("#new-process-group-dialog").modal("setButtonModel",[{buttonText:"Add",handler:{click:z}},{buttonText:"Cancel",handler:{click:function(){y.reject();
$("#new-process-group-dialog").modal("hide")
}}}]);
$("#new-process-group-dialog").modal("show");
$("#new-process-group-name").focus().off("keyup").on("keyup",function(B){var A=B.keyCode?B.keyCode:B.which;
if(A===$.ui.keyCode.ENTER){z()
}})
}).promise()
}}
}());