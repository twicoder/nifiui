nf.CanvasUtils=(function(){var a={storage:{namePrefix:"nifi-view-"},urls:{controller:"../nifi-api/controller"}};
var b=2*Math.PI;
var c=function(h,f){var e=0;
var i=h-1;
var g;
var d=0;
while(e<=i){g=~~((e+i)/2);
d=f(g);
if(d<0){i=g-1
}else{if(d>0){e=g+1
}else{break
}}}return g
};
return{config:{systemTooltipConfig:{style:{classes:"nifi-tooltip"},show:{solo:true,effect:false},hide:{effect:false},position:{at:"bottom right",my:"top left",adjust:{method:"flipinvert flipinvert"}}}},getPerimeterPoint:function(d,m){var e=Math.atan2(m.height,m.width);
var j=m.width/2;
var i=m.height/2;
var h=m.x+j;
var f=m.y+i;
var n=d.x-h;
var l=d.y-f;
var g=Math.atan2(l,n);
g=g%b;
if(g<0){g+=b
}var k=(Math.PI/2)-g;
if((g>=0&&g<e)||(g>=(b-e)&&g<b)){return{x:m.x+m.width,y:f+Math.tan(g)*j}
}else{if(g>=e&&g<(Math.PI-e)){return{x:h+Math.tan(k)*i,y:m.y+m.height}
}else{if(g>=(Math.PI-e)&&g<(Math.PI+e)){return{x:m.x,y:f-Math.tan(g)*j}
}else{return{x:h-Math.tan(k)*i,y:m.y}
}}}},showComponent:function(e,d){if(nf.Common.isDefinedAndNotNull(e)){var f=$.Deferred(function(g){if(e!==nf.Canvas.getGroupId()){nf.Canvas.setGroupId(e);
nf.Canvas.reload().done(function(){g.resolve()
}).fail(function(){nf.Dialog.showOkDialog({dialogContent:"Unable to load the group for the specified component.",overlayBackground:false});
g.reject()
})
}else{g.resolve()
}}).promise();
f.done(function(){var g=d3.select("#id-"+d);
if(!g.empty()){nf.Actions.show(g)
}else{nf.Dialog.showOkDialog({dialogContent:"Unable to find the specified component.",overlayBackground:false})
}})
}},getSelection:function(){return d3.selectAll("g.component.selected, g.connection.selected")
},centerBoundingBox:function(e){var g=nf.Canvas.View.scale();
var i=$("#canvas-container");
var f=i.width()/g;
var h=i.height()/g;
var d=[(f/2)-(e.width/2),(h/2)-(e.height/2)];
nf.Canvas.View.translate([(d[0]-e.x)*g,(d[1]-e.y)*g])
},position:function(d){if(d.empty()){return
}d.attr("transform",function(e){return"translate("+e.component.position.x+", "+e.component.position.y+")"
})
},ellipsis:function(f,h){var e=parseInt(f.attr("width"),10);
var g=f.node();
f.text(h);
if(g.getSubStringLength(0,h.length-1)>e){e-=5;
var d=c(h.length,function(i){var j=g.getSubStringLength(0,i);
if(j>e){return -1
}else{if(j<e){return 1
}}return 0
});
f.text(h.substring(0,d)+String.fromCharCode(8230))
}},multilineEllipsis:function(l,o,n){var f=1;
var g=n.split(/\s+/).reverse();
var k=parseInt(l.attr("x"),10);
var j=parseInt(l.attr("y"),10);
var e=parseInt(l.attr("width"),10);
var p=[];
var h=l.append("tspan").attr({x:k,y:j,width:e});
var d=g.pop();
while(nf.Common.isDefinedAndNotNull(d)){p.push(d);
h.text(p.join(" "));
if(h.node().getComputedTextLength()>e){p.pop();
h.text(p.join(" "));
h=l.append("tspan").attr({x:k,dy:"1.2em",width:e});
if(++f>=o){var m=[d].concat(g);
nf.CanvasUtils.ellipsis(h,m.join(" "));
break
}else{h.text(d);
p=[d]
}}d=g.pop()
}},activeThreadCount:function(e,g,h){if(nf.Common.isDefinedAndNotNull(g.status)&&g.status.activeThreadCount>0){var f=e.select("text.active-thread-count").text(function(){return g.status.activeThreadCount
}).style("display","block").each(function(){var d=this.getBBox();
d3.select(this).attr("x",function(){return g.dimensions.width-d.width-2
})
});
e.select("rect.active-thread-count-background").attr("width",function(){var d=f.node().getBBox();
return d.width+4
}).attr("x",function(){var d=f.node().getBBox();
if(typeof h==="function"){h(d.width+6)
}return g.dimensions.width-d.width-4
}).style("display","block")
}else{e.selectAll("text.active-thread-count, rect.active-thread-count-background").style("display","none")
}},disableImageHref:function(d){d.on("click.disableImageHref",function(){if(d3.event.ctrlKey){d3.event.preventDefault()
}})
},bulletins:function(e,h,i,g){g=nf.Common.isDefinedAndNotNull(g)?g:0;
var f=d3.select("#bulletin-tip-"+h.component.id);
if(!f.empty()){f.remove()
}if(nf.Common.isDefinedAndNotNull(h.status)&&!nf.Common.isEmpty(h.status.bulletins)){e.select("image.bulletin-icon").style("display","block").each(function(){var d=this.getBBox();
var j=d3.select(this);
j.attr("x",function(){return h.dimensions.width-g-d.width-4
});
f=i().append("div").attr("id",function(){return"bulletin-tip-"+h.component.id
}).attr("class","tooltip nifi-tooltip").html(function(){var l=nf.Common.getFormattedBulletins(h.status.bulletins);
var k=nf.Common.formatUnorderedList(l);
if(k===null||k.length===0){return""
}else{return $("<div></div>").append(k).html()
}});
nf.CanvasUtils.canvasTooltip(f,j)
})
}else{e.selectAll("image.bulletin-icon").style("display","none")
}},canvasTooltip:function(d,e){e.on("mouseenter",function(){d.style("top",(d3.event.pageY+15)+"px").style("left",(d3.event.pageX+15)+"px").style("display","block")
}).on("mousemove",function(){d.style("top",(d3.event.pageY+15)+"px").style("left",(d3.event.pageX+15)+"px")
}).on("mouseleave",function(){d.style("display","none")
})
},isConnection:function(d){return d.classed("connection")
},isRemoteProcessGroup:function(d){return d.classed("remote-process-group")
},isProcessor:function(d){return d.classed("processor")
},isLabel:function(d){return d.classed("label")
},isInputPort:function(d){return d.classed("input-port")
},isOutputPort:function(d){return d.classed("output-port")
},isProcessGroup:function(d){return d.classed("process-group")
},isFunnel:function(d){return d.classed("funnel")
},areRunnable:function(d){if(d.empty()){return false
}var e=true;
d.each(function(){if(!nf.CanvasUtils.isRunnable(d3.select(this))){e=false;
return false
}});
return e
},isRunnable:function(d){var f=false;
var e=d.datum();
if(nf.CanvasUtils.isProcessor(d)){f=nf.CanvasUtils.supportsModification(d)&&nf.Common.isEmpty(e.component.validationErrors)
}else{if(nf.CanvasUtils.isInputPort(d)||nf.CanvasUtils.isOutputPort(d)){f=nf.CanvasUtils.supportsModification(d)
}else{if(nf.CanvasUtils.isProcessGroup(d)){f=true
}}}return f
},areStoppable:function(d){if(d.empty()){return false
}var e=true;
d.each(function(){if(!nf.CanvasUtils.isStoppable(d3.select(this))){e=false;
return false
}});
return e
},isStoppable:function(d){var f=false;
var e=d.datum();
if(nf.CanvasUtils.isProcessor(d)||nf.CanvasUtils.isInputPort(d)||nf.CanvasUtils.isOutputPort(d)){f=e.component.state==="RUNNING"
}else{if(nf.CanvasUtils.isProcessGroup(d)){f=true
}}return f
},canAllStartTransmitting:function(d){if(d.empty()){return false
}var e=true;
d.each(function(){if(!nf.CanvasUtils.canStartTransmitting(d3.select(this))){e=false;
return false
}});
return e
},canStartTransmitting:function(d){return nf.CanvasUtils.isRemoteProcessGroup(d)
},canAllStopTransmitting:function(d){if(d.empty()){return false
}var e=true;
d.each(function(){if(!nf.CanvasUtils.canStopTransmitting(d3.select(this))){e=false;
return false
}});
return e
},canStopTransmitting:function(d){return nf.CanvasUtils.isRemoteProcessGroup(d)
},isDeletable:function(d){if(d.empty()){return false
}return nf.CanvasUtils.supportsModification(d)
},supportsModification:function(k){var i=k.datum();
var g=false;
if(nf.CanvasUtils.isProcessor(k)||nf.CanvasUtils.isInputPort(k)||nf.CanvasUtils.isOutputPort(k)){if(nf.Common.isDefinedAndNotNull(i.status)){g=!(i.component.state==="RUNNING"||nf.Common.isDefinedAndNotNull(i.status.activeThreadCount)&&i.status.activeThreadCount>0)
}else{g=i.component.state!=="RUNNING"
}}else{if(nf.CanvasUtils.isRemoteProcessGroup(k)){if(nf.Common.isDefinedAndNotNull(i.status)){g=!(i.component.transmitting===true||nf.Common.isDefinedAndNotNull(i.status.activeThreadCount)&&i.status.activeThreadCount>0)
}else{g=i.component.transmitting!==true
}}else{if(nf.CanvasUtils.isProcessGroup(k)){g=true
}else{if(nf.CanvasUtils.isFunnel(k)){g=true
}else{if(nf.CanvasUtils.isLabel(k)){g=true
}else{if(nf.CanvasUtils.isConnection(k)){var j=false;
var e=false;
var l=nf.CanvasUtils.getConnectionSourceComponentId(i.component);
var d=d3.select("#id-"+l);
if(!d.empty()){if(nf.CanvasUtils.isRemoteProcessGroup(d)||nf.CanvasUtils.isProcessGroup(d)){j=true
}else{j=nf.CanvasUtils.supportsModification(d)
}}var f=nf.CanvasUtils.getConnectionDestinationComponentId(i.component);
var h=d3.select("#id-"+f);
if(!h.empty()){if(nf.CanvasUtils.isRemoteProcessGroup(h)||nf.CanvasUtils.isProcessGroup(h)){e=true
}else{e=nf.CanvasUtils.supportsModification(h)
}}g=j&&e
}}}}}}return g
},getConnectableTypeForSource:function(e){var d;
if(nf.CanvasUtils.isProcessor(e)){d="PROCESSOR"
}else{if(nf.CanvasUtils.isRemoteProcessGroup(e)){d="REMOTE_OUTPUT_PORT"
}else{if(nf.CanvasUtils.isProcessGroup(e)){d="OUTPUT_PORT"
}else{if(nf.CanvasUtils.isInputPort(e)){d="INPUT_PORT"
}else{if(nf.CanvasUtils.isFunnel(e)){d="FUNNEL"
}}}}}return d
},getConnectableTypeForDestination:function(e){var d;
if(nf.CanvasUtils.isProcessor(e)){d="PROCESSOR"
}else{if(nf.CanvasUtils.isRemoteProcessGroup(e)){d="REMOTE_INPUT_PORT"
}else{if(nf.CanvasUtils.isProcessGroup(e)){d="INPUT_PORT"
}else{if(nf.CanvasUtils.isOutputPort(e)){d="OUTPUT_PORT"
}else{if(nf.CanvasUtils.isFunnel(e)){d="FUNNEL"
}}}}}return d
},isCopyable:function(e){if(e.empty()){return false
}var d=e.filter(function(i){var g=d3.select(this);
if(nf.CanvasUtils.isConnection(g)){var f=!e.filter(function(j){var k=nf.CanvasUtils.getConnectionSourceComponentId(i.component);
return k===j.component.id
}).empty();
var h=!e.filter(function(j){var k=nf.CanvasUtils.getConnectionDestinationComponentId(i.component);
return k===j.component.id
}).empty();
return f&&h
}else{return nf.CanvasUtils.isProcessor(g)||nf.CanvasUtils.isFunnel(g)||nf.CanvasUtils.isLabel(g)||nf.CanvasUtils.isProcessGroup(g)||nf.CanvasUtils.isRemoteProcessGroup(g)||nf.CanvasUtils.isInputPort(g)||nf.CanvasUtils.isOutputPort(g)
}});
return e.size()===d.size()
},isPastable:function(){return nf.Clipboard.isCopied()
},persistUserView:function(){var d=a.storage.namePrefix+nf.Canvas.getGroupId();
var f=nf.Canvas.View.translate();
var e={scale:nf.Canvas.View.scale(),translateX:f[0],translateY:f[1]};
nf.Storage.setItem(d,e)
},formatConnectionName:function(d){if(!nf.Common.isBlank(d.name)){return d.name
}else{if(nf.Common.isDefinedAndNotNull(d.selectedRelationships)){return d.selectedRelationships.join(", ")
}}return""
},getConnectionSourceComponentId:function(d){var e=d.source.id;
if(d.source.groupId!==nf.Canvas.getGroupId()){e=d.source.groupId
}return e
},getConnectionDestinationComponentId:function(d){var e=d.destination.id;
if(d.destination.groupId!==nf.Canvas.getGroupId()){e=d.destination.groupId
}return e
},restoreUserView:function(){var g=false;
try{var d=a.storage.namePrefix+nf.Canvas.getGroupId();
var f=nf.Storage.getItem(d);
if(nf.Common.isDefinedAndNotNull(f)){if(isFinite(f.scale)&&isFinite(f.translateX)&&isFinite(f.translateY)){nf.Canvas.View.translate([f.translateX,f.translateY]);
nf.Canvas.View.scale(f.scale);
nf.Canvas.View.refresh({transition:true});
g=true
}}}catch(h){}return g
},enterGroup:function(d){nf.Canvas.setGroupId(d);
nf.Graph.removeAll();
return nf.Canvas.reload().done(function(){var e=nf.CanvasUtils.restoreUserView();
if(e===false){nf.Canvas.View.fit();
nf.Canvas.View.refresh({transition:true})
}}).fail(function(){nf.Dialog.showOkDialog({dialogContent:"Unable to enter the selected group.",overlayBackground:false})
})
},getOrigin:function(e){var d={};
e.each(function(g){var f=d3.select(this);
if(!nf.CanvasUtils.isConnection(f)){if(nf.Common.isUndefined(d.x)||g.component.position.x<d.x){d.x=g.component.position.x
}if(nf.Common.isUndefined(d.y)||g.component.position.y<d.y){d.y=g.component.position.y
}}});
return d
},moveComponents:function(e,f){var d=f.datum();
nf.CanvasUtils.eligibleForMove(e,f).done(function(){var g=nf.Snippet.marshal(e,true);
nf.Snippet.create(g).done(function(h){var i=h.snippet;
nf.Snippet.move(i.id,d.component.id).done(function(){var k=d3.map();
var j=function(l,m){if(!k.has(l)){k.set(l,[])
}k.get(l).push(m)
};
e.each(function(l){j(l.type,l.component.id)
});
k.forEach(function(m,l){nf[m].remove(l)
});
nf.ProcessGroup.reload(d.component)
}).fail(nf.Common.handleAjaxError).always(function(){nf.Snippet.unlink(i.id).done(function(){nf.Snippet.remove(i.id)
})
})
}).fail(nf.Common.handleAjaxError)
})
},trimDanglingEdges:function(d){var e=function(f){var j=nf.CanvasUtils.getConnectionSourceComponentId(f);
var i=nf.CanvasUtils.getConnectionDestinationComponentId(f);
var h=false;
var g=false;
d.each(function(k){if(k.component.id===j){h=true
}if(k.component.id===i){g=true
}});
return h&&g
};
return d.filter(function(f){if(f.type==="Connection"){return e(f.component)
}else{return true
}})
},isDisconnected:function(f){var e=d3.map();
var g=d3.map();
var d=true;
f.filter(function(h){return h.type==="Connection"
}).each(function(h){e.set(h.component.id,h.component)
});
f.filter(function(h){return h.type!=="Connection"
}).each(function(h){g.set(h.component.id,h.component);
$.each(nf.Connection.getComponentConnections(h.component.id),function(j,i){if(!e.has(i.id)){d=false;
return false
}})
});
if(d){e.forEach(function(i,h){if(d){d=g.has(nf.CanvasUtils.getConnectionSourceComponentId(h))&&g.has(nf.CanvasUtils.getConnectionDestinationComponentId(h))
}})
}return d
},eligibleForMove:function(f,g){var d=[];
var e=[];
f.each(function(i){var h=d3.select(this);
if(nf.CanvasUtils.isInputPort(h)){d.push(h.datum())
}else{if(nf.CanvasUtils.isOutputPort(h)){e.push(h.datum())
}}});
return $.Deferred(function(h){if(d.length>0||e.length>0){var j=function(){return $.Deferred(function(k){if(nf.Canvas.getParentGroupId()===null){nf.Dialog.showOkDialog({dialogContent:"Ports in the root group cannot be moved into another group.",overlayBackground:false});
k.reject()
}else{$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getParentGroupId())+"/connections",dataType:"json"}).done(function(l){var n=l.connections;
var m=[];
if(!nf.Common.isEmpty(n)){$.each(d,function(p,o){$.each(n,function(r,q){if(o.component.id===q.destination.id){m.push(nf.Common.escapeHtml(o.component.name))
}})
});
$.each(e,function(o,p){$.each(n,function(r,q){if(p.component.id===q.source.id){m.push(nf.Common.escapeHtml(p.component.name))
}})
})
}if(m.length>0){nf.Dialog.showOkDialog({dialogContent:"The following ports are currently connected outside of this group: <b>"+m.join("</b>, <b>")+"</b>",overlayBackground:false});
k.reject()
}else{k.resolve()
}}).fail(function(){k.reject()
})
}}).promise()
};
var i=function(){return $.Deferred(function(l){var k=g.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(k.component.id),data:{verbose:true},dataType:"json"}).done(function(n){var p=n.processGroup;
var q=p.contents;
var o=[];
var m=function(r,s){if(r.length>0&&!nf.Common.isEmpty(s)){$.each(r,function(u,t){$.each(s,function(w,v){if(t.component.name===v.name){o.push(nf.Common.escapeHtml(v.name))
}})
})
}};
m(d,q.inputPorts);
m(e,q.outputPorts);
if(o.length>0){nf.Dialog.showOkDialog({dialogContent:"The following ports already exist in the target process group: <b>"+o.join("</b>, <b>")+"</b>",overlayBackground:false});
l.reject()
}else{l.resolve()
}}).fail(function(){l.reject()
})
}).promise()
};
j().done(function(){if(nf.Common.isDefinedAndNotNull(g)){$.when(i()).done(function(){h.resolve()
}).fail(function(){h.reject()
})
}else{h.resolve()
}}).fail(function(){h.reject()
})
}else{h.resolve()
}}).promise()
},isValidConnectionSource:function(d){if(d.size()!==1){return false
}return nf.CanvasUtils.isProcessor(d)||nf.CanvasUtils.isProcessGroup(d)||nf.CanvasUtils.isRemoteProcessGroup(d)||nf.CanvasUtils.isInputPort(d)||nf.CanvasUtils.isFunnel(d)
},isValidConnectionDestination:function(d){if(d.size()!==1){return false
}return nf.CanvasUtils.isProcessor(d)||nf.CanvasUtils.isProcessGroup(d)||nf.CanvasUtils.isRemoteProcessGroup(d)||nf.CanvasUtils.isOutputPort(d)||nf.CanvasUtils.isFunnel(d)
}}
}());