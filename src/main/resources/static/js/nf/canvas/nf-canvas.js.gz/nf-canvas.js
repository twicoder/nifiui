$(document).ready(function(){if(nf.Canvas.SUPPORTS_SVG){nf.Canvas.init()
}else{$("#message-title").text("Unsupported Browser");
$("#message-content").text("Flow graphs are shown using SVG. Please use a browser that supports rendering SVG.");
$("#message-pane").show();
nf.Canvas.hideSplash()
}});
nf.Canvas=(function(){var p=1;
var h=[0,0];
var w=1.2;
var D=8;
var s=0.2;
var d=0.6;
var t=false;
var g=false;
var k="root";
var n=null;
var q=null;
var j=false;
var b=false;
var r=null;
var f=null;
var u=false;
var i=false;
var C={urls:{authorities:"../nifi-api/controller/authorities",revision:"../nifi-api/controller/revision",status:"../nifi-api/controller/status",bulletinBoard:"../nifi-api/controller/bulletin-board",banners:"../nifi-api/controller/banners",controller:"../nifi-api/controller",controllerConfig:"../nifi-api/controller/config",cluster:"../nifi-api/cluster",d3Script:"js/d3/d3.min.js"}};
var A=function(F){var E=$('<span class="link"></span>').text(F.name).click(function(){nf.CanvasUtils.enterGroup(F.id)
});
if(nf.Canvas.getGroupId()===F.id){E.css("font-weight","bold")
}if(nf.Common.isDefinedAndNotNull(F.parent)){var G=$("<span>&raquo;</span>").css({color:"#598599",margin:"0 10px"});
$("#data-flow-title-container").append(A(F.parent)).append(G)
}$("#data-flow-title-container").append(E);
return E
};
var o=function(){return nf.Common.cachedScript(C.urls.d3Script)
};
var m=function(E){t=true;
B(E)
};
var B=function(E){if(t){y().done(function(){setTimeout(function(){B(E)
},E*1000)
})
}};
var a=function(E){g=true;
z(E)
};
var z=function(E){if(g){nf.Canvas.reloadStatus().done(function(){setTimeout(function(){z(E)
},E*1000)
})
}};
var y=function(){return $.ajax({type:"GET",url:C.urls.revision,dataType:"json"}).done(function(E){if(nf.Common.isDefinedAndNotNull(E.revision)){var F=E.revision;
var H=nf.Client.getRevision();
if(F.version>H.version&&F.clientId!==H.clientId){var G=$("#refresh-required-container");
if(!G.is(":visible")){$("#stats-last-refreshed").addClass("alert");
G.show()
}}}}).fail(nf.Common.handleAjaxError)
};
var l=function(){var K=$("#canvas-container");
r=d3.select("#canvas-container").append("svg").on("contextmenu",function(){u=false;
nf.CanvasUtils.getSelection().classed("selected",false);
nf.ContextMenu.show();
d3.event.preventDefault()
});
var E=r.append("defs");
E.selectAll("marker").data(["normal","ghost"]).enter().append("marker").attr({id:function(L){return L
},viewBox:"0 0 6 6",refX:5,refY:3,markerWidth:6,markerHeight:6,orient:"auto",fill:function(L){if(L==="ghost"){return"#aaaaaa"
}else{return"#000000"
}}}).append("path").attr("d","M2,3 L0,6 L6,3 L0,0 z");
var H=E.append("linearGradient").attr({id:"process-group-stats-background",x1:"0%",y1:"100%",x2:"0%",y2:"0%"});
H.append("stop").attr({offset:"0%","stop-color":"#dedede"});
H.append("stop").attr({offset:"50%","stop-color":"#ffffff"});
H.append("stop").attr({offset:"100%","stop-color":"#dedede"});
var I=E.append("linearGradient").attr({id:"processor-stats-background",x1:"0%",y1:"100%",x2:"0%",y2:"0%"});
I.append("stop").attr({offset:"0%","stop-color":"#6f97ac"});
I.append("stop").attr({offset:"100%","stop-color":"#30505c"});
var J=E.append("linearGradient").attr({id:"port-background",x1:"0%",y1:"100%",x2:"0%",y2:"0%"});
J.append("stop").attr({offset:"0%","stop-color":"#aaaaaa"});
J.append("stop").attr({offset:"100%","stop-color":"#ffffff"});
var G=E.append("linearGradient").attr({id:"expiration",x1:"0%",y1:"0%",x2:"0%",y2:"100%"});
G.append("stop").attr({offset:"0%","stop-color":"#aeafb1"});
G.append("stop").attr({offset:"100%","stop-color":"#87888a"});
f=r.append("g").attr({transform:"translate("+h+") scale("+p+")","pointer-events":"all",id:"canvas"});
r.on("mousedown.selection",function(){u=true;
if(d3.event.button!==0){d3.event.stopImmediatePropagation();
return
}if(d3.event.shiftKey){var L=d3.mouse(f.node());
f.append("rect").attr("rx",6).attr("ry",6).attr("x",L[0]).attr("y",L[1]).attr("class","selection").attr("width",0).attr("height",0).attr("stroke-width",function(){return 1/nf.Canvas.View.scale()
}).attr("stroke-dasharray",function(){return 4/nf.Canvas.View.scale()
}).datum(L);
d3.event.stopImmediatePropagation();
d3.event.preventDefault()
}}).on("mousemove.selection",function(){if(d3.event.shiftKey){var M=d3.select("rect.selection");
if(!M.empty()){var N=M.datum();
var L=d3.mouse(f.node());
var O={};
if(N[0]<L[0]){O.x=N[0];
O.width=L[0]-N[0]
}else{O.x=L[0];
O.width=N[0]-L[0]
}if(N[1]<L[1]){O.y=N[1];
O.height=L[1]-N[1]
}else{O.y=L[1];
O.height=N[1]-L[1]
}M.attr(O)
}d3.event.stopPropagation()
}}).on("mouseup.selection",function(){if(u===false){return
}u=false;
var L=d3.select("rect.selection");
if(!L.empty()){var M={x:parseInt(L.attr("x"),10),y:parseInt(L.attr("y"),10),width:parseInt(L.attr("width"),10),height:parseInt(L.attr("height"),10)};
d3.selectAll("g.component").classed("selected",function(N){return d3.select(this).classed("selected")||N.component.position.x>=M.x&&(N.component.position.x+N.dimensions.width)<=(M.x+M.width)&&N.component.position.y>=M.y&&(N.component.position.y+N.dimensions.height)<=(M.y+M.height)
});
d3.selectAll("g.connection").classed("selected",function(P){var O=[P.start].concat(P.bends,[P.end]);
var N=d3.extent(O,function(R){return R.x
});
var Q=d3.extent(O,function(R){return R.y
});
return d3.select(this).classed("selected")||N[0]>=M.x&&N[1]<=(M.x+M.width)&&Q[0]>=M.y&&Q[1]<=(M.y+M.height)
});
L.remove()
}else{if(i===false){nf.CanvasUtils.getSelection().classed("selected",false)
}}nf.CanvasToolbar.refresh()
});
var F=function(){var P=$("#banner-footer");
var L=0;
if(P.is(":visible")){L=P.height()
}var N=parseInt(K.css("top"),10);
var O=$(window).height();
var M=(O-(L+N));
K.css({height:M+"px",bottom:L+"px"});
r.attr({height:K.height(),width:K.width()});
$("#canvas-body").css({height:O+"px",width:$(window).width()+"px"})
};
$(window).on("resize",function(){F()
}).on("keydown",function(L){if($(".dialog").is(":visible")){return
}if(L.ctrlKey||L.metaKey){if(L.keyCode===82){nf.Actions.reloadStatus();
L.preventDefault()
}else{if(L.keyCode===65){nf.Actions.selectAll();
nf.CanvasToolbar.refresh();
L.preventDefault()
}else{if(L.keyCode===67){nf.Actions.copy(nf.CanvasUtils.getSelection());
L.preventDefault()
}else{if(L.keyCode===86){nf.Actions.paste();
L.preventDefault()
}}}}}else{if(L.keyCode===46){nf.Actions["delete"](nf.CanvasUtils.getSelection());
L.preventDefault()
}else{if(L.keyCode===27){nf.Actions.hideDialogs();
L.preventDefault()
}}}});
$.ajax({type:"GET",url:C.urls.banners,dataType:"json"}).done(function(N){if(nf.Common.isDefinedAndNotNull(N.banners)){if(nf.Common.isDefinedAndNotNull(N.banners.headerText)&&N.banners.headerText!==""){$("#banner-header").addClass("banner-header-background").text(N.banners.headerText)
}if(nf.Common.isDefinedAndNotNull(N.banners.footerText)&&N.banners.footerText!==""){var L=$("#banner-footer").text(N.banners.footerText).show();
var M=function(O){var P=$("#"+O);
P.css("bottom",parseInt(L.css("height"),10)+"px")
};
M("graph")
}}F()
}).fail(nf.Common.handleAjaxError)
};
var c=function(F,H){var E=d3.select("defs");
var G=E.selectAll("linearGradient."+H+"-background").data(F,function(J){return J
});
var I=G.enter().append("linearGradient").attr({id:function(J){return H+"-background-"+J
},"class":H+"-background",x1:"0%",y1:"100%",x2:"0%",y2:"0%"});
I.append("stop").attr({offset:"0%","stop-color":function(J){return"#"+J
}});
I.append("stop").attr({offset:"100%","stop-color":"#ffffff"});
G.exit().remove()
};
var e=function(){return $.ajax({type:"GET",url:C.urls.status,dataType:"json"}).done(function(G){if(nf.Common.isDefinedAndNotNull(G.controllerStatus)){var E=G.controllerStatus;
$("#active-thread-count").text(E.activeThreadCount);
$("#total-queued").text(E.queued);
if(nf.Common.isDefinedAndNotNull(E.connectedNodes)){var F=E.connectedNodes.split(" / ");
if(F.length===2&&F[0]!==F[1]){$("#connected-nodes-count").addClass("alert")
}else{$("#connected-nodes-count").removeClass("alert")
}$("#connected-nodes-count").text(E.connectedNodes)
}if(nf.Common.isDefinedAndNotNull(E.activeRemotePortCount)){$("#controller-transmitting-count").text(E.activeRemotePortCount)
}else{$("#controller-transmitting-count").text("-")
}if(nf.Common.isDefinedAndNotNull(E.inactiveRemotePortCount)){$("#controller-not-transmitting-count").text(E.inactiveRemotePortCount)
}else{$("#controller-not-transmitting-count").text("-")
}if(nf.Common.isDefinedAndNotNull(E.runningCount)){$("#controller-running-count").text(E.runningCount)
}else{$("#controller-running-count").text("-")
}if(nf.Common.isDefinedAndNotNull(E.stoppedCount)){$("#controller-stopped-count").text(E.stoppedCount)
}else{$("#controller-stopped-count").text("-")
}if(nf.Common.isDefinedAndNotNull(E.invalidCount)){$("#controller-invalid-count").text(E.invalidCount)
}else{$("#controller-invalid-count").text("-")
}if(nf.Common.isDefinedAndNotNull(E.disabledCount)){$("#controller-disabled-count").text(E.disabledCount)
}else{$("#controller-disabled-count").text("-")
}var I=$("#controller-bulletins");
var K=I.data("bulletins");
if(nf.Common.doBulletinsDiffer(K,E.bulletins)){I.data("bulletins",E.bulletins);
var J=nf.Common.getFormattedBulletins(E.bulletins);
if(J.length===0){if(I.data("qtip")){I.removeClass("has-bulletins").qtip("destroy")
}I.hide()
}else{var H=nf.Common.formatUnorderedList(J);
if(I.data("qtip")){I.qtip("option","content.text",H)
}else{I.addClass("has-bulletins").qtip($.extend({content:H},nf.CanvasUtils.config.systemTooltipConfig))
}I.show()
}}if(E.hasPendingAccounts===true){$("#has-pending-accounts").show()
}else{$("#has-pending-accounts").hide()
}}}).fail(nf.Common.handleAjaxError)
};
var v=function(E){return $.ajax({type:"GET",url:C.urls.controller+"/process-groups/"+encodeURIComponent(E),data:{verbose:true},dataType:"json"}).done(function(F){nf.Client.setRevision(F.revision);
var G=F.processGroup;
nf.Canvas.setGroupId(G.id);
nf.Canvas.setGroupName(G.name);
$("#data-flow-title-container").empty();
A(G);
if(nf.Common.isDefinedAndNotNull(G.parent)){nf.Canvas.setParentGroupId(G.parent.id)
}else{nf.Canvas.setParentGroupId(null)
}nf.Graph.removeAll();
nf.Graph.add(G.contents,false);
nf.CanvasToolbar.refresh()
}).fail(nf.Common.handleAjaxError)
};
var x=function(E){return $.Deferred(function(F){$.ajax({type:"GET",url:C.urls.controller+"/process-groups/"+encodeURIComponent(E)+"/status",data:{recursive:false},dataType:"json"}).done(function(G){if(nf.Common.isDefinedAndNotNull(G.processGroupStatus)){var H=G.processGroupStatus;
nf.Graph.setStatus(H);
$("#stats-last-refreshed").text(H.statsLastRefreshed)
}F.resolve()
}).fail(function(I,G,H){if(!nf.Canvas.isClustered()||I.status!==404){nf.Common.handleAjaxError(I,G,H);
F.reject()
}else{F.resolve()
}})
}).promise()
};
return{CANVAS_OFFSET:0,SUPPORTS_SVG:!!document.createElementNS&&!!document.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect,hideSplash:function(){$("#splash").fadeOut()
},stopRevisionPolling:function(){t=false
},stopStatusPolling:function(){g=false
},reload:function(){return $.Deferred(function(F){nf.ContextMenu.hide();
var E=v(nf.Canvas.getGroupId());
var G=e();
$.when(E,G).done(function(J){var N=$("#data-flow-title-container");
var H=N.position();
var P=N.outerWidth();
var K=H.left+P;
var O=$("#breadcrumbs-right-border").width();
var M=$("#data-flow-title-viewport");
var L=M.width();
var I=L-O;
if(K>I){N.css("left",(H.left-(K-I))+"px")
}else{N.css("left","10px")
}x(nf.Canvas.getGroupId()).done(function(){F.resolve(J)
}).fail(function(){F.reject()
})
})
}).promise()
},reloadStatus:function(){return $.Deferred(function(E){$.when(x(nf.Canvas.getGroupId()),e()).done(function(){E.resolve()
}).fail(function(){E.reject()
})
}).promise()
},init:function(){nf.Registration.init();
var G=$.ajax({type:"GET",url:C.urls.controllerConfig,dataType:"json"});
var E=$.Deferred(function(H){$.ajax({type:"HEAD",url:C.urls.cluster}).done(function(J,I,K){b=true;
H.resolve(J,I,K)
}).fail(function(K,I,J){if(K.status===404){b=false;
H.resolve("","success",K)
}else{H.reject(K,I,J)
}})
}).promise();
var F=$.ajax({type:"GET",url:C.urls.authorities,dataType:"json"});
$.when(F,G).done(function(M,I){var L=M[0];
var J=I[0];
nf.Common.setAuthorities(L.authorities);
var K=$("#canvas-container");
nf.Canvas.CANVAS_OFFSET=K.offset().top;
var H=J.config;
E.done(function(){var N=parseInt(H.autoRefreshIntervalSeconds,10);
j=H.siteToSiteSecure;
o().done(function(){nf.Storage.init();
l();
nf.Canvas.View.init();
nf.ContextMenu.init();
nf.CanvasHeader.init();
nf.CanvasToolbox.init();
nf.CanvasToolbar.init();
nf.GraphControl.init();
nf.Search.init();
nf.Settings.init();
nf.Draggable.init();
nf.Selectable.init();
nf.Connectable.init();
nf.StatusHistory.init(H.timeOffset);
nf.Birdseye.init();
nf.ConnectionConfiguration.init();
nf.ProcessorConfiguration.init();
nf.ProcessGroupConfiguration.init();
nf.RemoteProcessGroupConfiguration.init();
nf.RemoteProcessGroupPorts.init();
nf.PortConfiguration.init();
nf.SecurePortConfiguration.init();
nf.LabelConfiguration.init();
nf.ProcessorDetails.init();
nf.ProcessGroupDetails.init();
nf.PortDetails.init();
nf.SecurePortDetails.init();
nf.ConnectionDetails.init();
nf.RemoteProcessGroupDetails.init();
nf.GoTo.init();
nf.Graph.init().done(function(){var O=N/2;
m(N);
setTimeout(function(){a(N)
},O*1000);
nf.Canvas.hideSplash()
}).fail(nf.Common.handleAjaxError)
}).fail(nf.Common.handleAjaxError)
}).fail(nf.Common.handleAjaxError)
}).fail(nf.Common.handleAjaxError)
},defineProcessorColors:function(E){c(E,"processor")
},defineLabelColors:function(E){c(E,"label")
},isClustered:function(){return b===true
},isSecureSiteToSite:function(){return j
},setGroupId:function(E){k=E
},getGroupId:function(){return k
},setGroupName:function(E){n=E
},getGroupName:function(){return n
},setParentGroupId:function(E){q=E
},getParentGroupId:function(){return q
},View:(function(){var F=function(){var O=$("#canvas-container");
var J=nf.Canvas.View.translate();
var K=nf.Canvas.View.scale();
J=[J[0]/K,J[1]/K];
var G=O.width()/K;
var H=O.height()/K;
var L=-J[0]-G;
var I=-J[1]-H;
var Q=L+(G*3);
var S=I+(H*3);
var N=function(X){if(!nf.Canvas.View.shouldRenderPerScale()){return false
}var W=X.component.position.x;
var V=X.component.position.y;
var U=W+X.dimensions.width;
var T=V+X.dimensions.height;
return L<U&&Q>W&&I<T&&S>V
};
var P=function(V){if(!nf.Canvas.View.shouldRenderPerScale()){return false
}var T,W;
if(V.bends.length>0){var U=Math.min(Math.max(0,V.labelIndex),V.bends.length-1);
T=V.bends[U].x;
W=V.bends[U].y
}else{T=(V.start.x+V.end.x)/2;
W=(V.start.y+V.end.y)/2
}return L<T&&Q>T&&I<W&&S>W
};
var M=function(X,T){var V=d3.select("#id-"+X.component.id);
var W=T(X);
var U=V.classed("visible");
V.classed("visible",W).classed("entering",function(){return W&&!U
}).classed("leaving",function(){return !W&&U
})
};
var R=nf.Graph.get();
$.each(R.processors,function(T,U){M(U,N)
});
$.each(R.ports,function(T,U){M(U,N)
});
$.each(R.processGroups,function(T,U){M(U,N)
});
$.each(R.remoteProcessGroups,function(T,U){M(U,N)
});
$.each(R.connections,function(T,U){M(U,P)
})
};
var E;
return{init:function(){var G;
var H=false;
E=d3.behavior.zoom().scaleExtent([s,D]).translate(h).scale(p).on("zoomstart",function(){nf.ContextMenu.hide()
}).on("zoom",function(){if(H){i=true
}else{H=true
}var I=d3.event.sourceEvent.type==="wheel"||d3.event.sourceEvent.type==="mousewheel";
G=nf.Canvas.View.refresh({persist:false,transition:I,refreshComponents:false,refreshBirdseye:false})
}).on("zoomend",function(){if(nf.Common.isDefinedAndNotNull(G)){nf.Canvas.View.updateVisibility();
G.done(function(){nf.Birdseye.refresh()
});
nf.CanvasUtils.persistUserView();
G=null
}i=false;
H=false
});
r.call(E).on("dblclick.zoom",null)
},shouldRenderPerScale:function(){return nf.Canvas.View.scale()>=d
},updateVisibility:function(){F();
nf.Graph.pan()
},translate:function(G){if(nf.Common.isUndefined(G)){return E.translate()
}else{E.translate(G)
}},scale:function(G){if(nf.Common.isUndefined(G)){return E.scale()
}else{E.scale(G)
}},zoomIn:function(){var I=nf.Canvas.View.translate();
var H=nf.Canvas.View.scale();
var L=Math.min(H*w,D);
var K=$("#canvas-container");
var G=K.width()/H;
var J=K.height()/H;
nf.Canvas.View.scale(L);
nf.CanvasUtils.centerBoundingBox({x:(G/2)-(I[0]/H),y:(J/2)-(I[1]/H),width:1,height:1})
},zoomOut:function(){var I=nf.Canvas.View.translate();
var H=nf.Canvas.View.scale();
var L=Math.max(H/w,s);
var K=$("#canvas-container");
var G=K.width()/H;
var J=K.height()/H;
nf.Canvas.View.scale(L);
nf.CanvasUtils.centerBoundingBox({x:(G/2)-(I[0]/H),y:(J/2)-(I[1]/H),width:1,height:1})
},fit:function(){var I=nf.Canvas.View.translate();
var K=nf.Canvas.View.scale();
var N;
var M=$("#canvas-container");
var J=M.width();
var L=M.height();
var P=d3.select("#canvas").node().getBoundingClientRect();
var Q=P.width/K;
var H=P.height/K;
var O=P.left/K;
var G=(P.top-nf.Canvas.CANVAS_OFFSET)/K;
if(Q>J||H>L){N=Math.min(J/Q,L/H);
N=Math.min(Math.max(N,s),D)
}else{N=1;
O-=100;
G-=50
}nf.Canvas.View.scale(N);
nf.CanvasUtils.centerBoundingBox({x:O-(I[0]/K),y:G-(I[1]/K),width:J/N,height:L/N})
},actualSize:function(){var L=nf.Canvas.View.translate();
var K=nf.Canvas.View.scale();
var H=nf.CanvasUtils.getSelection();
nf.Canvas.View.scale(1);
var I;
if(!H.empty()){var G=H.node().getBoundingClientRect();
I={x:(G.left/K)-(L[0]/K),y:((G.top-nf.Canvas.CANVAS_OFFSET)/K)-(L[1]/K),width:G.width/K,height:G.height/K}
}else{var N=$("#canvas-container");
var J=N.width()/K;
var M=N.height()/K;
I={x:(J/2)-(L[0]/K),y:(M/2)-(L[1]/K),width:1,height:1}
}nf.CanvasUtils.centerBoundingBox(I)
},refresh:function(G){return $.Deferred(function(H){var I=true;
var K=false;
var J=true;
var L=true;
if(nf.Common.isDefinedAndNotNull(G)){I=nf.Common.isDefinedAndNotNull(G.persist)?G.persist:I;
K=nf.Common.isDefinedAndNotNull(G.transition)?G.transition:K;
J=nf.Common.isDefinedAndNotNull(G.refreshComponents)?G.refreshComponents:J;
L=nf.Common.isDefinedAndNotNull(G.refreshBirdseye)?G.refreshBirdseye:L
}if(J){nf.Canvas.View.updateVisibility()
}if(I===true){nf.CanvasUtils.persistUserView()
}if(K===true){f.transition().duration(500).attr("transform",function(){return"translate("+E.translate()+") scale("+E.scale()+")"
}).each("end",function(){if(L===true){nf.Birdseye.refresh()
}H.resolve()
})
}else{f.attr("transform",function(){return"translate("+E.translate()+") scale("+E.scale()+")"
});
if(L===true){nf.Birdseye.refresh()
}H.resolve()
}}).promise()
}}
}())}
}());