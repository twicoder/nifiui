nf.Clipboard=(function(){var a="copy";
var d="paste";
var c=null;
var b={};
return{addListener:function(f,e){b[f]=e
},removeListener:function(e){if(nf.Common.isDefinedAndNotNull(b[e])){delete b[e]
}},copy:function(f){c=f;
for(var e in b){b[e].call(e,a,c)
}},isCopied:function(){return nf.Common.isDefinedAndNotNull(c)
},paste:function(){return $.Deferred(function(e){if(nf.Common.isDefinedAndNotNull(c)){var g=c;
e.resolve(g);
c=null;
for(var f in b){b[f].call(f,d,g)
}}else{e.reject()
}}).promise()
}}
}());