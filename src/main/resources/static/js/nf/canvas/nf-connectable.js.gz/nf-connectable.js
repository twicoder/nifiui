nf.Connectable=(function(){var b;
var c;
var a;
return{init:function(){c=d3.select("#canvas");
b=d3.behavior.drag().origin(function(e){a=d3.mouse(c.node());
return{x:a[0],y:a[1]}
}).on("dragstart",function(h){d3.event.sourceEvent.stopPropagation();
nf.CanvasUtils.getSelection().classed("selected",false);
var g=d3.select(this.parentNode).classed("selected",true);
d3.select(this).classed("dragging",true);
var f=g.datum();
var e=d3.mouse(c.node());
c.insert("path",":first-child").datum({sourceId:f.component.id,sourceWidth:f.dimensions.width,x:e[0],y:e[1]}).attr({"class":"connector",d:function(d){return"M"+d.x+" "+d.y+"L"+d.x+" "+d.y
}});
d3.select(this).attr("transform",function(){return"translate("+e[0]+", "+(e[1]+20)+")"
});
c.node().appendChild(this)
}).on("drag",function(f){d3.select(this).attr("transform",function(){return"translate("+d3.event.x+", "+(d3.event.y+20)+")"
});
var e=d3.select("g.hover").classed("connectable-destination",function(){return(Math.abs(a[0]-d3.event.x)>10||Math.abs(a[1]-d3.event.y)>10)&&nf.CanvasUtils.isValidConnectionDestination(d3.select(this))
});
d3.select("path.connector").classed("connectable",function(){if(e.empty()){return false
}return e.classed("connectable-destination")
}).attr("d",function(h){if(!e.empty()&&e.classed("connectable-destination")){var g=e.datum();
var d=nf.CanvasUtils.getPerimeterPoint(h,{x:g.component.position.x,y:g.component.position.y,width:g.dimensions.width,height:g.dimensions.height});
return"M"+h.x+" "+h.y+"L"+d.x+" "+d.y
}else{return"M"+h.x+" "+h.y+"L"+d3.event.x+" "+d3.event.y
}})
}).on("dragend",function(i){d3.event.sourceEvent.stopPropagation();
var f=d3.select("path.connector");
var e=d3.select("g.connectable-destination");
if(e.empty()){f.remove()
}else{var h=f.datum();
var g=e.datum();
if(h.sourceId===g.component.id){f.attr("d",function(n){var d=n.x;
var m=n.y;
var k=n.sourceWidth/2;
var j=nf.Connection.config.selfLoopXOffset;
var l=nf.Connection.config.selfLoopYOffset;
return"M"+d+" "+m+"L"+(d+k+j)+" "+(m-l)+"L"+(d+k+j)+" "+(m+l)+"Z"
})
}nf.ConnectionConfiguration.createConnection(h.sourceId,g.component.id)
}d3.select(this).remove()
})
},activate:function(d){d.on("mouseenter.connectable",function(h){if(!d3.event.shiftKey&&d3.select("rect.drag-selection").empty()){var f=d3.select(this);
if(nf.CanvasUtils.isValidConnectionSource(f)){var g=d3.select("image.add-connect");
if(g.empty()){var e=(h.dimensions.width/2)-14;
var i=(h.dimensions.height/2)-14;
f.append("image").call(b).call(nf.CanvasUtils.disableImageHref).attr({"class":"add-connect","xlink:href":"images/addConnect.png",width:28,height:28,transform:"translate("+e+", "+i+")"})
}}}}).on("mouseleave.connectable",function(){var e=d3.select(this).select("image.add-connect");
if(!e.empty()&&!e.classed("dragging")){e.remove()
}}).on("mouseover.connectable",function(){var e=d3.select(this);
e.classed("hover",function(){return !d3.event.shiftKey&&!e.classed("hover")&&d3.select("rect.drag-selection").empty()
})
}).on("mouseout.connection",function(){d3.select(this).classed("hover connectable-destination",false)
})
}}
}());