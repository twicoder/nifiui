nf.ConnectionConfiguration=(function(){var u=75;
var f=200;
var w={urls:{controller:"../nifi-api/controller",prioritizers:"../nifi-api/controller/prioritizers"}};
var j=function(){d3.select("path.connector").remove()
};
var b=function(z){if(nf.CanvasUtils.isProcessor(z)){return $.Deferred(function(A){i(z).done(function(C){if(!nf.Common.isEmpty(C.relationships)){$.each(C.relationships,function(D,E){r(E.name)
});
var B=$("#relationship-names").children("div");
if(B.length===1){B.children("div.available-relationship").removeClass("checkbox-unchecked").addClass("checkbox-checked")
}$("#connection-configuration").modal("setButtonModel",[{buttonText:"Add",handler:{click:function(){var D=l();
if(D.length>0){o(D)
}else{nf.Dialog.showOkDialog({dialogContent:"The connection must have at least one relationship selected.",overlayBackground:false})
}$("#connection-configuration").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#connection-configuration").modal("hide")
}}}]);
A.resolve()
}else{nf.Dialog.showOkDialog({dialogContent:"'"+nf.Common.escapeHtml(C.name)+"' does not support any relationships."});
e();
A.reject()
}}).fail(function(){A.reject()
})
}).promise()
}else{return $.Deferred(function(B){var A;
if(nf.CanvasUtils.isInputPort(z)){A=c(z)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(z)){A=k(z)
}else{if(nf.CanvasUtils.isProcessGroup(z)){A=s(z)
}else{A=g(z)
}}}A.done(function(){$("#connection-configuration").modal("setButtonModel",[{buttonText:"Add",handler:{click:function(){o();
$("#connection-configuration").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#connection-configuration").modal("hide")
}}}]);
B.resolve()
}).fail(function(){B.reject()
})
}).promise()
}};
var c=function(z){return $.Deferred(function(B){var A=z.datum();
$("#input-port-source").show();
$("#input-port-source-name").text(A.component.name);
$("#connection-source-id").val(A.component.id);
$("#connection-source-component-id").val(A.component.id);
$("#connection-source-group-id").val(nf.Canvas.getGroupId());
$("#connection-source-group-name").text(nf.Canvas.getGroupName());
B.resolve()
}).promise()
};
var g=function(z){return $.Deferred(function(B){var A=z.datum();
$("#funnel-source").show();
$("#connection-source-id").val(A.component.id);
$("#connection-source-component-id").val(A.component.id);
$("#connection-source-group-id").val(nf.Canvas.getGroupId());
$("#connection-source-group-name").text(nf.Canvas.getGroupName());
B.resolve()
}).promise()
};
var i=function(z){return $.Deferred(function(B){var A=z.datum();
$("#processor-source").show();
$("#processor-source-name").text(A.component.name);
$("#processor-source-type").text(nf.Common.substringAfterLast(A.component.type,"."));
$("#connection-source-id").val(A.component.id);
$("#connection-source-component-id").val(A.component.id);
$("#connection-source-group-id").val(nf.Canvas.getGroupId());
$("#connection-source-group-name").text(nf.Canvas.getGroupName());
$("#relationship-names-container").show();
B.resolve(A.component)
})
};
var s=function(z){return $.Deferred(function(A){var B=z.datum();
$.ajax({type:"GET",url:w.urls.controller+"/process-groups/"+encodeURIComponent(B.component.id),data:{verbose:true},dataType:"json"}).done(function(C){var E=C.processGroup;
var F=E.contents;
if(!nf.Common.isEmpty(F.outputPorts)){$("#output-port-source").show();
var D=[];
$.each(F.outputPorts,function(G,H){D.push({text:H.name,value:H.id,description:nf.Common.escapeHtml(H.comments)})
});
D.sort(function(H,G){return H.text.localeCompare(G.text)
});
$("#output-port-options").combo({options:D,maxHeight:300,select:function(G){$("#connection-source-id").val(G.value)
}});
$("#connection-source-component-id").val(E.id);
$("#connection-source-group-id").val(E.id);
$("#connection-source-group-name").text(E.name);
A.resolve()
}else{nf.Dialog.showOkDialog({dialogContent:"'"+nf.Common.escapeHtml(E.name)+"' does not have any output ports."});
e();
A.reject()
}}).fail(function(E,C,D){nf.Common.handleAjaxError(E,C,D);
A.reject()
})
}).promise()
};
var k=function(z){return $.Deferred(function(A){var B=z.datum();
$.ajax({type:"GET",url:B.component.uri,data:{verbose:true},dataType:"json"}).done(function(C){var E=C.remoteProcessGroup;
var F=E.contents;
if(!nf.Common.isEmpty(F.outputPorts)){$("#output-port-source").show();
var D=[];
$.each(F.outputPorts,function(G,H){D.push({text:H.name,value:H.id,disabled:H.exists===false,description:nf.Common.escapeHtml(H.comments)})
});
D.sort(function(H,G){return H.text.localeCompare(G.text)
});
$("#output-port-options").combo({options:D,maxHeight:300,select:function(G){$("#connection-source-id").val(G.value)
}});
$("#connection-source-component-id").val(E.id);
$("#connection-source-group-id").val(E.id);
$("#connection-source-group-name").text(E.name);
A.resolve()
}else{nf.Dialog.showOkDialog({dialogContent:"'"+nf.Common.escapeHtml(E.name)+"' does not have any output ports."});
e();
A.reject()
}}).fail(function(E,C,D){nf.Common.handleAjaxError(E,C,D);
A.reject()
})
}).promise()
};
var q=function(z){if(nf.CanvasUtils.isOutputPort(z)){return n(z)
}else{if(nf.CanvasUtils.isProcessor(z)){return v(z)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(z)){return t(z)
}else{if(nf.CanvasUtils.isFunnel(z)){return d(z)
}else{return m(z)
}}}}};
var n=function(z){return $.Deferred(function(A){var B=z.datum();
$("#output-port-destination").show();
$("#output-port-destination-name").text(B.component.name);
$("#connection-destination-id").val(B.component.id);
$("#connection-destination-component-id").val(B.component.id);
$("#connection-destination-group-id").val(nf.Canvas.getGroupId());
$("#connection-destination-group-name").text(nf.Canvas.getGroupName());
A.resolve()
}).promise()
};
var d=function(z){return $.Deferred(function(B){var A=z.datum();
$("#funnel-destination").show();
$("#connection-destination-id").val(A.component.id);
$("#connection-destination-component-id").val(A.component.id);
$("#connection-destination-group-id").val(nf.Canvas.getGroupId());
$("#connection-destination-group-name").text(nf.Canvas.getGroupName());
B.resolve()
}).promise()
};
var v=function(z){return $.Deferred(function(B){var A=z.datum();
$("#processor-destination").show();
$("#processor-destination-name").text(A.component.name);
$("#processor-destination-type").text(nf.Common.substringAfterLast(A.component.type,"."));
$("#connection-destination-id").val(A.component.id);
$("#connection-destination-component-id").val(A.component.id);
$("#connection-destination-group-id").val(nf.Canvas.getGroupId());
$("#connection-destination-group-name").text(nf.Canvas.getGroupName());
B.resolve()
}).promise()
};
var m=function(z){return $.Deferred(function(A){var B=z.datum();
$.ajax({type:"GET",url:w.urls.controller+"/process-groups/"+encodeURIComponent(B.component.id),data:{verbose:true},dataType:"json"}).done(function(C){var E=C.processGroup;
var F=E.contents;
if(!nf.Common.isEmpty(F.inputPorts)){$("#input-port-destination").show();
var D=[];
$.each(F.inputPorts,function(H,G){D.push({text:G.name,value:G.id,description:nf.Common.escapeHtml(G.comments)})
});
D.sort(function(H,G){return H.text.localeCompare(G.text)
});
$("#input-port-options").combo({options:D,maxHeight:300,select:function(G){$("#connection-destination-id").val(G.value)
}});
$("#connection-destination-component-id").val(E.id);
$("#connection-destination-group-id").val(E.id);
$("#connection-destination-group-name").text(E.name);
A.resolve()
}else{nf.Dialog.showOkDialog({dialogContent:"'"+nf.Common.escapeHtml(E.name)+"' does not have any input ports."});
e();
A.reject()
}}).fail(function(E,C,D){nf.Common.handleAjaxError(E,C,D);
A.reject()
})
}).promise()
};
var t=function(z){return $.Deferred(function(A){var B=z.datum();
$.ajax({type:"GET",url:B.component.uri,data:{verbose:true},dataType:"json"}).done(function(C){var E=C.remoteProcessGroup;
var F=E.contents;
if(!nf.Common.isEmpty(F.inputPorts)){$("#input-port-destination").show();
var D=[];
$.each(F.inputPorts,function(H,G){D.push({text:G.name,value:G.id,disabled:G.exists===false,description:nf.Common.escapeHtml(G.comments)})
});
D.sort(function(H,G){return H.text.localeCompare(G.text)
});
$("#input-port-options").combo({options:D,maxHeight:300,select:function(G){$("#connection-destination-id").val(G.value)
}});
$("#connection-destination-component-id").val(E.id);
$("#connection-destination-group-id").val(E.id);
$("#connection-destination-group-name").text(E.name);
A.resolve()
}else{nf.Dialog.showOkDialog({dialogContent:"'"+nf.Common.escapeHtml(E.name)+"' does not have any input ports."});
e();
A.reject()
}}).fail(function(E,C,D){nf.Common.handleAjaxError(E,C,D);
A.reject()
})
}).promise()
};
var a=function(z){return $.Deferred(function(A){var B=z.datum();
$("#read-only-output-port-source").show();
$("#connection-source-component-id").val(B.component.id);
$("#connection-source-group-id").val(B.component.id);
$("#connection-source-group-name").text(B.component.name);
A.resolve()
}).promise()
};
var p=function(z){if(nf.CanvasUtils.isProcessor(z)){return i(z)
}else{if(nf.CanvasUtils.isInputPort(z)){return c(z)
}else{if(nf.CanvasUtils.isFunnel(z)){return g(z)
}else{return a(z)
}}}};
var h=function(z){if(nf.CanvasUtils.isProcessor(z)){return v(z)
}else{if(nf.CanvasUtils.isOutputPort(z)){return n(z)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(z)){return t(z)
}else{if(nf.CanvasUtils.isFunnel(z)){return d(z)
}else{return m(z)
}}}}};
var r=function(A){var z=$('<div class="relationship-name ellipsis"></div>').text(A);
var B=$('<span class="relationship-name-value hidden"></span>').text(A);
return $('<div class="available-relationship-container"><div class="available-relationship nf-checkbox checkbox-unchecked"></div></div>').append(z).append(B).appendTo("#relationship-names")
};
var o=function(B){var V=$("#connection-source-id").val();
var S=$("#connection-destination-id").val();
var Z=$("#connection-source-component-id").val();
var P=d3.select("#id-"+Z);
var T=$("#connection-destination-component-id").val();
var I=d3.select("#id-"+T);
var af=P.datum();
var J=I.datum();
var C=[];
if(Z===T){var O={x:af.component.position.x+(af.dimensions.width),y:af.component.position.y+(af.dimensions.height/2)};
var U=nf.Connection.config.selfLoopXOffset;
var W=nf.Connection.config.selfLoopYOffset;
C.push((O.x+U)+","+(O.y-W));
C.push((O.x+U)+","+(O.y+W))
}else{var ad=[];
var Y=nf.Connection.getComponentConnections(Z);
$.each(Y,function(aj,am){var ak=nf.CanvasUtils.getConnectionSourceComponentId(am);
var al=nf.CanvasUtils.getConnectionDestinationComponentId(am);
if((ak===Z&&al===T)||(al===Z&&ak===T)){ad.push(am)
}});
if(ad.length>0){var D=false;
$.each(ad,function(aj,ak){if(nf.Common.isEmpty(ak.bends)){D=true;
return false
}});
if(D===true){var Q=[af.component.position.x+(af.dimensions.width/2),af.component.position.y+(af.dimensions.height/2)];
var A=[J.component.position.x+(J.dimensions.width/2),J.component.position.y+(J.dimensions.height/2)];
var N=((Q[1]-A[1])/(Q[0]-A[0]));
var ab=N<=1&&N>=-1;
var X=function(aj,al){var ak=false;
$.each(ad,function(am,an){if(!nf.Common.isEmpty(an.bends)){if(ab){if(an.bends[0].y===al){ak=true;
return false
}}else{if(an.bends[0].x===aj){ak=true;
return false
}}}});
return ak
};
var G=(Q[0]+A[0])/2;
var K=(Q[1]+A[1])/2;
var aa=ab?0:f;
var M=ab?u:0;
var ac=false;
while(ac===false){if(X(G-aa,K-M)===false){C.push((G-aa)+","+(K-M));
ac=true
}else{if(X(G+aa,K+M)===false){C.push((G+aa)+","+(K+M));
ac=true
}}if(ab){M+=u
}else{aa+=f
}}}}}var F=$("#connection-source-group-id").val();
var z=$("#connection-destination-group-id").val();
var ag=nf.CanvasUtils.getConnectableTypeForSource(P);
var L=nf.CanvasUtils.getConnectableTypeForDestination(I);
var H=$("#connection-name").val();
var E=$("#flow-file-expiration").val();
var ae=$("#back-pressure-object-threshold").val();
var ai=$("#back-pressure-data-size-threshold").val();
var R=$("#prioritizer-selected").sortable("toArray");
if(x()){var ah=nf.Client.getRevision();
$.ajax({type:"POST",url:w.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getGroupId())+"/connections",data:{version:ah.version,clientId:ah.clientId,sourceId:V,sourceGroupId:F,sourceType:ag,relationships:B,bends:C,name:H,flowFileExpiration:E,backPressureObjectThreshold:ae,backPressureDataSizeThreshold:ai,prioritizers:R,destinationId:S,destinationGroupId:z,destinationType:L},dataType:"json"}).done(function(aj){nf.Client.setRevision(aj.revision);
nf.Graph.add({connections:[aj.connection]},true);
if(nf.CanvasUtils.isProcessor(P)){nf.Processor.reload(af.component)
}else{if(nf.CanvasUtils.isInputPort(P)){nf.Port.reload(af.component)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(P)){nf.RemoteProcessGroup.reload(af.component)
}}}if(nf.CanvasUtils.isRemoteProcessGroup(I)){nf.RemoteProcessGroup.reload(J.component)
}nf.Canvas.View.updateVisibility();
nf.Birdseye.refresh()
}).fail(function(al,aj,ak){nf.Common.handleAjaxError(al,aj,ak)
})
}};
var y=function(H){var C=$("#connection-uri").val();
var P=$("#connection-source-component-id").val();
var z=d3.select("#id-"+P);
var G=z.datum();
var K=$("#connection-destination-component-id").val();
var M=d3.select("#id-"+K);
var B=M.datum();
var I=nf.CanvasUtils.getConnectableTypeForDestination(M);
var A=$("#connection-destination-id").val();
var J=$("#connection-destination-group-id").val();
var F=$("#connection-name").val();
var D=$("#flow-file-expiration").val();
var O=$("#back-pressure-object-threshold").val();
var E=$("#back-pressure-data-size-threshold").val();
var N=$("#prioritizer-selected").sortable("toArray");
if(x()){var L=nf.Client.getRevision();
return $.ajax({type:"PUT",url:C,data:{version:L.version,clientId:L.clientId,relationships:H,name:F,flowFileExpiration:D,backPressureObjectThreshold:O,backPressureDataSizeThreshold:E,prioritizers:N,destinationId:A,destinationType:I,destinationGroupId:J},dataType:"json"}).done(function(R){if(nf.Common.isDefinedAndNotNull(R.connection)){var Q=R.connection;
nf.Client.setRevision(R.revision);
nf.Connection.set(Q);
if(nf.CanvasUtils.isProcessor(z)){nf.Processor.reload(G.component)
}else{if(nf.CanvasUtils.isInputPort(z)){nf.Port.reload(G.component)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(z)){nf.RemoteProcessGroup.reload(G.component)
}}}if(nf.CanvasUtils.isRemoteProcessGroup(M)){nf.RemoteProcessGroup.reload(B.component)
}}}).fail(function(S,Q,R){if(S.status===400||S.status===404||S.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(S.responseText),overlayBackground:true})
}else{nf.Common.handleAjaxError(S,Q,R)
}})
}else{return $.Deferred(function(Q){Q.reject()
}).promise()
}};
var l=function(){var A=$("#relationship-names");
var z=[];
$.each(A.children(),function(B,E){var D=$(E);
var C=D.children("div.available-relationship");
if(C.hasClass("checkbox-checked")){z.push(D.children("span.relationship-name-value").text())
}});
return z
};
var x=function(){var z=[];
if(nf.Common.isBlank($("#flow-file-expiration").val())){z.push("File expiration must be specified")
}if(!$.isNumeric($("#back-pressure-object-threshold").val())){z.push("Back pressure object threshold must be an integer value")
}if(nf.Common.isBlank($("#back-pressure-data-size-threshold").val())){z.push("Back pressure data size threshold must be specified")
}if(z.length>0){nf.Dialog.showOkDialog({dialogContent:nf.Common.formatUnorderedList(z),overlayBackground:false,headerText:"Configuration Error"});
return false
}else{return true
}};
var e=function(){var B=$("#prioritizer-selected");
var z=$("#prioritizer-available");
B.children().detach().appendTo(z);
var A=z.children("li").get();
A.sort(function(D,C){var F=$(D).text().toUpperCase();
var E=$(C).text().toUpperCase();
return(F<E)?-1:(F>E)?1:0
});
$.each(A,function(){$(this).detach()
});
$.each(A,function(){$(this).appendTo(z)
});
$("#connection-name").val("");
$("#relationship-names").css("border-width","0").empty();
$("#relationship-names-container").hide();
nf.Common.clearField("connection-id");
$("#processor-source").hide();
$("#input-port-source").hide();
$("#output-port-source").hide();
$("#read-only-output-port-source").hide();
$("#funnel-source").hide();
$("#processor-destination").hide();
$("#input-port-destination").hide();
$("#output-port-destination").hide();
$("#funnel-destination").hide();
$("#connection-source-id").val("");
$("#connection-source-component-id").val("");
$("#connection-source-group-id").val("");
$("#connection-destination-id").val("");
$("#connection-destination-component-id").val("");
$("#connection-destination-group-id").val("");
$("#output-port-options").empty();
$("#input-port-options").empty();
j()
};
return{init:function(){$("#relationship-names-container").hide();
$("#connection-configuration").modal({headerText:"Configure Connection",overlayBackground:true,handler:{close:function(){e()
}}}).draggable({containment:"parent",handle:".dialog-header"});
$("#connection-configuration-tabs").tabbs({tabStyle:"tab",selectedTabStyle:"selected-tab",tabs:[{name:"Details",tabContentId:"connection-details-tab-content"},{name:"Settings",tabContentId:"connection-settings-tab-content"}]});
$.ajax({type:"GET",url:w.urls.prioritizers,dataType:"json"}).done(function(z){$.each(z.prioritizerTypes,function(A,B){nf.ConnectionConfiguration.addAvailablePrioritizer("#prioritizer-available",B)
});
$("#prioritizer-available, #prioritizer-selected").sortable({connectWith:"ul",placeholder:"ui-state-highlight",scroll:true,opacity:0.6});
$("#prioritizer-available, #prioritizer-selected").disableSelection()
}).fail(nf.Common.handleAjaxError)
},addAvailablePrioritizer:function(E,C){var B=C.type;
var A=nf.Common.substringAfterLast(B,".");
var D=$(E);
var z=$("<li></li>").append($('<span style="float: left;"></span>').text(A)).attr("id",B).addClass("ui-state-default").appendTo(D);
if(nf.Common.isDefinedAndNotNull(C.description)){$('<img class="icon-info" style="float: right; margin-right: 5px;" src="images/iconInfo.png"></img>').appendTo(z).qtip($.extend({content:nf.Common.escapeHtml(C.description)},nf.Common.config.tooltipConfig))
}},createConnection:function(B,C){var A=d3.select("#id-"+B);
var z=d3.select("#id-"+C);
if(A.empty()||z.empty()){return
}$.when(b(A),q(z)).done(function(){$("#flow-file-expiration").val("0 sec");
$("#back-pressure-object-threshold").val("0");
$("#back-pressure-data-size-threshold").val("0 MB");
$("#connection-configuration-tabs").find("li:first").click();
$("#connection-configuration").modal("setHeaderText","Create Connection").modal("show");
$("#connection-configuration div.relationship-name").ellipsis();
nf.Common.populateField("connection-id",null);
var D=$("#relationship-names");
if(D.is(":visible")&&D.get(0).scrollHeight>D.innerHeight()){D.css("border-width","1px")
}}).fail(function(){j()
})
},showConfiguration:function(A,z){return $.Deferred(function(C){var E=A.datum();
var B=E.component;
var G=nf.CanvasUtils.getConnectionSourceComponentId(B);
var D=d3.select("#id-"+G);
if(nf.Common.isUndefinedOrNull(z)){var F=nf.CanvasUtils.getConnectionDestinationComponentId(B);
z=d3.select("#id-"+F)
}$.when(p(D),h(z)).done(function(){var J=B.availableRelationships;
var I=B.selectedRelationships;
if(nf.Common.isDefinedAndNotNull(J)||nf.Common.isDefinedAndNotNull(I)){$.each(J,function(M,L){r(L)
});
$.each(I,function(N,L){if($.inArray(L,J)===-1){var O=r(L);
$(O).children("div.relationship-name").addClass("undefined")
}var M=$("#relationship-names").children("div");
$.each(M,function(P,R){var Q=$(R).children("span.relationship-name-value");
if(Q.text()===L){$(R).children("div.available-relationship").removeClass("checkbox-unchecked").addClass("checkbox-checked")
}})
})
}if(nf.CanvasUtils.isProcessGroup(D)||nf.CanvasUtils.isRemoteProcessGroup(D)){$("#connection-source-id").val(B.source.id);
$("#read-only-output-port-name").text(B.source.name)
}if(nf.CanvasUtils.isProcessGroup(z)||nf.CanvasUtils.isRemoteProcessGroup(z)){var H=z.datum();
if(B.destination.groupId===H.component.id){$("#input-port-options").combo("setSelectedOption",{value:B.destination.id})
}}$("#connection-name").val(B.name);
$("#flow-file-expiration").val(B.flowFileExpiration);
$("#back-pressure-object-threshold").val(B.backPressureObjectThreshold);
$("#back-pressure-data-size-threshold").val(B.backPressureDataSizeThreshold);
nf.Common.populateField("connection-id",B.id);
$.each(B.prioritizers,function(L,M){$("#prioritizer-available").children('li[id="'+M+'"]').detach().appendTo("#prioritizer-selected")
});
$("#connection-uri").val(B.uri);
$("#connection-configuration").modal("setButtonModel",[{buttonText:"Apply",handler:{click:function(){var L=l();
if(nf.CanvasUtils.isProcessor(D)){if(L.length>0){y(L).done(function(){C.resolve()
}).fail(function(){C.reject()
})
}else{nf.Dialog.showOkDialog({dialogContent:"The connection must have at least one relationship selected.",overlayBackground:false});
C.reject()
}}else{y(undefined).done(function(){C.resolve()
}).fail(function(){C.reject()
})
}$("#connection-configuration").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#connection-configuration").modal("hide");
C.reject()
}}}]);
$("#connection-configuration-tabs").find("li:first").click();
$("#connection-configuration").modal("setHeaderText","Configure Connection").modal("show");
$("#connection-configuration div.relationship-name").ellipsis();
var K=$("#relationship-names");
if(K.is(":visible")&&K.get(0).scrollHeight>K.innerHeight()){K.css("border-width","1px")
}}).fail(function(){C.reject()
})
}).promise()
}}
}());