nf.Connection=(function(){var e={width:188};
var j=function(A){var C=A.datum();
var z,D;
if(C.bends.length>0){var B=Math.min(Math.max(0,C.labelIndex),C.bends.length-1);
z=C.bends[B].x;
D=C.bends[B].y
}else{z=(C.start.x+C.end.x)/2;
D=(C.start.y+C.end.y)/2
}z-=(e.width/2);
D-=(A.attr("height")/2);
return{x:z,y:D}
};
var r;
var b;
var w;
var x;
var n;
var d;
var m=function(z,y){return Math.pow(z.x-y.x,2)+Math.pow(z.y-y.y,2)
};
var i=function(z,y){return Math.sqrt(m(z,y))
};
var c=function(C,B,z){var y=m(B,z);
if(y===0){return Math.sqrt(m(C,B))
}var A=((C.x-B.x)*(z.x-B.x)+(C.y-B.y)*(z.y-B.y))/y;
if(A<0){return Math.sqrt(m(C,B))
}if(A>1){return Math.sqrt(m(C,z))
}return Math.sqrt(m(C,{x:B.x+A*(z.x-B.x),y:B.y+A*(z.y-B.y)}))
};
var u=function(C,E){if(E.bends.length===0){return 0
}var A;
var z;
var y=[E.start].concat(E.bends,[E.end]);
for(var B=0;
B<y.length;
B++){if(B+1<y.length){var D=c(C,y[B],y[B+1]);
if(nf.Common.isUndefined(A)||D<A){A=D;
z=B
}}}return z
};
var o=function(y){return y.indexOf("INPUT_PORT")>=0
};
var a=function(y){return y.indexOf("OUTPUT_PORT")>=0
};
var l=function(y){return y.groupId!==nf.Canvas.getGroupId()&&(o(y.type)||a(y.type))
};
var g=function(y){if(nf.Common.isDefinedAndNotNull(y.flowFileExpiration)){var z=y.flowFileExpiration.match(/^(\d+).*/);
if(z!==null&&z.length>0){if(parseInt(z[0],10)>0){return true
}}}return false
};
var t=function(y){y.sort(function(A,z){return A.component.zIndex===z.component.zIndex?0:A.component.zIndex>z.component.zIndex?1:-1
})
};
var p=function(){return b.selectAll("g.connection").data(r.values(),function(y){return y.component.id
})
};
var v=function(B,A){if(B.empty()){return
}var z=B.append("g").attr({id:function(C){return"id-"+C.component.id
},"class":"connection"}).classed("selected",A);
z.append("path").attr({"class":"connection-path","pointer-events":"none"});
z.append("path").attr({"class":"connection-selection-path","pointer-events":"none"});
var y=z.append("path").attr({"class":"connection-path-selectable","pointer-events":"stroke"}).on("mousedown.selection",function(){nf.Selectable.select(d3.select(this.parentNode))
}).call(nf.ContextMenu.activate);
if(nf.Common.isDFM()){y.on("dblclick",function(H){var C=d3.mouse(this.parentNode);
var F=u({x:C[0],y:C[1]},H);
var E=H.component.bends.slice();
E.splice(F,0,{x:C[0],y:C[1]});
var D={id:H.component.id,bends:E};
var G=H.component.labelIndex;
if(E.length===1){D.labelIndex=0
}else{if(F<=G){D.labelIndex=G+1
}}s(H,D);
d3.event.stopPropagation()
})
}z.call(q,true,false)
};
var h=function(z){var y=false;
if(nf.Common.isDefinedAndNotNull(z.component.selectedRelationships)&&nf.Common.isDefinedAndNotNull(z.component.availableRelationships)){$.each(z.component.selectedRelationships,function(A,B){if($.inArray(B,z.component.availableRelationships)===-1){y=true;
return false
}})
}return y
};
var q=function(y,z,A){if(y.empty()){return
}if(z===true){y.classed("grouped",function(C){var B=false;
if(nf.Common.isDefinedAndNotNull(C.component.selectedRelationships)&&C.component.selectedRelationships.length>1){B=true
}return B
}).classed("ghost",function(C){var B=false;
if(h(C)){B=true
}return B
})
}y.each(function(V){var O=d3.select(this);
if(z===true){var U=nf.CanvasUtils.getConnectionSourceComponentId(V.component);
var F=d3.select("#id-"+U).datum();
var G;
var L;
if(V.bends.length>0){L=V.bends[V.bends.length-1]
}else{L={x:F.component.position.x+(F.dimensions.width/2),y:F.component.position.y+(F.dimensions.height/2)}
}if(nf.Common.isDefinedAndNotNull(V.end)&&V.end.dragging===true){G=V.end;
var W=d3.select("g.hover.connectable-destination");
if(!W.empty()){var S=W.datum();
var B=nf.CanvasUtils.getPerimeterPoint(L,{x:S.component.position.x,y:S.component.position.y,width:S.dimensions.width,height:S.dimensions.height});
G.x=B.x;
G.y=B.y
}}else{var D=nf.CanvasUtils.getConnectionDestinationComponentId(V.component);
var Y=d3.select("#id-"+D).datum();
G=nf.CanvasUtils.getPerimeterPoint(L,{x:Y.component.position.x,y:Y.component.position.y,width:Y.dimensions.width,height:Y.dimensions.height})
}var M;
if(V.bends.length>0){M=V.bends[0]
}else{M=G
}var I=nf.CanvasUtils.getPerimeterPoint(M,{x:F.component.position.x,y:F.component.position.y,width:F.dimensions.width,height:F.dimensions.height});
V.start=I;
V.end=G;
O.select("path.connection-path").attr({d:function(){var Z=[V.start].concat(V.bends,[V.end]);
return d(Z)
},"marker-end":function(){var Z="normal";
if(h(V)){Z="ghost"
}return"url(#"+Z+")"
}});
O.select("path.connection-selection-path").attr({d:function(){var Z=[V.start].concat(V.bends,[V.end]);
return d(Z)
}});
O.select("path.connection-path-selectable").attr({d:function(){var Z=[V.start].concat(V.bends,[V.end]);
return d(Z)
}});
if(nf.Common.isDFM()){var K=O.selectAll("rect.startpoint").data([V.start]);
K.enter().append("rect").attr({"class":"startpoint linepoint","pointer-events":"all",width:8,height:8}).on("mousedown.selection",function(){nf.Selectable.select(d3.select(this.parentNode))
}).call(nf.ContextMenu.activate);
K.attr("transform",function(Z){return"translate("+(Z.x-4)+", "+(Z.y-4)+")"
});
K.exit().remove();
var J=O.selectAll("rect.endpoint").data([V.end]);
J.enter().append("rect").call(x).attr({"class":"endpoint linepoint","pointer-events":"all",width:8,height:8}).on("mousedown.selection",function(){nf.Selectable.select(d3.select(this.parentNode))
}).call(nf.ContextMenu.activate);
J.attr("transform",function(Z){return"translate("+(Z.x-4)+", "+(Z.y-4)+")"
});
J.exit().remove();
var Q=O.selectAll("rect.midpoint").data(V.bends);
Q.enter().append("rect").attr({"class":"midpoint linepoint","pointer-events":"all",width:8,height:8}).call(w).on("dblclick",function(ac){d3.event.stopPropagation();
var af=nf.CanvasUtils.getConnectionSourceComponentId(V.component);
var ae=nf.CanvasUtils.getConnectionDestinationComponentId(V.component);
if(af===ae&&V.component.bends.length<=2){nf.Dialog.showOkDialog({dialogContent:"Looping connections must have at least two bend points.",overlayBackground:false});
return
}var ab=[];
var aa=-1;
$.each(V.component.bends,function(ah,ag){if(ac.x!==ag.x&&ac.y!==ag.y){ab.push(ag)
}else{aa=ah
}});
if(aa<0){return
}var Z={id:V.component.id,bends:ab};
var ad=V.component.labelIndex;
if(ab.length<=1){Z.labelIndex=0
}else{if(aa<=ad){Z.labelIndex=Math.max(0,ad-1)
}}s(V,Z)
}).on("mousedown.selection",function(){nf.Selectable.select(d3.select(this.parentNode))
}).call(nf.ContextMenu.activate);
Q.attr("transform",function(Z){return"translate("+(Z.x-4)+", "+(Z.y-4)+")"
});
Q.exit().remove()
}}if(A===true){var H=O.select("g.connection-label-container");
if(O.classed("visible")){if(H.empty()){H=O.insert("g","rect.startpoint").attr({"class":"connection-label-container","pointer-events":"all"}).on("mousedown.selection",function(){nf.Selectable.select(d3.select(this.parentNode))
}).call(nf.ContextMenu.activate);
H.append("rect").attr({"class":"connection-label",width:e.width,x:0,y:0})
}var P=0;
var N=H.select("g.connection-from-container");
if(l(V.component.source)){if(N.empty()){N=H.append("g").attr({"class":"connection-from-container"});
N.append("text").attr({"class":"connection-stats-label",x:0,y:10}).text("From");
N.append("text").attr({"class":"connection-stats-value connection-from",x:33,y:10,width:130});
N.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"connection-from-run-status",width:10,height:10,x:167,y:1})
}N.attr("transform",function(){var Z=5+(15*P++);
return"translate(5, "+Z+")"
});
N.select("text.connection-from").each(function(){var Z=d3.select(this);
Z.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(Z,V.component.source.name)
}).append("title").text(function(){return V.component.source.name
});
N.select("image.connection-from-run-status").attr("xlink:href",function(){if(V.component.source.exists===false){return"images/portRemoved.png"
}else{if(V.component.source.running===true){return"images/portRunning.png"
}else{return"images/portStopped.png"
}}})
}else{if(!N.empty()){N.remove()
}}var X=H.select("g.connection-to-container");
if(l(V.component.destination)){if(X.empty()){X=H.append("g").attr({"class":"connection-to-container"});
X.append("text").attr({"class":"connection-stats-label",x:0,y:10}).text("To");
X.append("text").attr({"class":"connection-stats-value connection-to",x:18,y:10,width:145});
X.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"connection-to-run-status",width:10,height:10,x:167,y:1})
}X.attr("transform",function(){var Z=5+(15*P++);
return"translate(5, "+Z+")"
});
X.select("text.connection-to").each(function(aa){var Z=d3.select(this);
Z.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(Z,aa.component.destination.name)
}).append("title").text(function(Z){return Z.component.destination.name
});
X.select("image.connection-to-run-status").attr("xlink:href",function(){if(V.component.destination.exists===false){return"images/portRemoved.png"
}else{if(V.component.destination.running===true){return"images/portRunning.png"
}else{return"images/portStopped.png"
}}})
}else{if(!X.empty()){X.remove()
}}var E=nf.CanvasUtils.formatConnectionName(V.component);
var R=H.select("g.connection-name-container");
if(!nf.Common.isBlank(E)){if(R.empty()){R=H.append("g").attr({"class":"connection-name-container"});
R.append("text").attr({"class":"connection-stats-label",x:0,y:10}).text("Name");
R.append("text").attr({"class":"connection-stats-value connection-name",x:35,y:10,width:142})
}R.attr("transform",function(){var Z=5+(15*P++);
return"translate(5, "+Z+")"
});
R.select("text.connection-name").each(function(){var Z=d3.select(this);
Z.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(Z,E)
}).append("title").text(function(){return E
})
}else{if(!R.empty()){R.remove()
}}var C=H.select("g.queued-container");
if(C.empty()){C=H.append("g").attr({"class":"queued-container"});
C.append("text").attr({"class":"connection-stats-label",x:0,y:10}).text("Queued");
C.append("text").attr({"class":"connection-stats-value queued",x:46,y:10});
var T=C.append("g").attr({"class":"expiration-icon",transform:"translate(167, 2)"});
T.append("circle").attr({cx:5,cy:5,r:4.75,"stroke-width":0.5,stroke:"#87888a",fill:"url(#expiration)"});
T.append("line").attr({x1:6,y1:5,x2:3,y2:4,stroke:"#fff","stroke-width":1});
T.append("line").attr({x1:6,y1:5,x2:3,y2:7,stroke:"#fff","stroke-width":1});
T.append("title")
}C.attr("transform",function(){var Z=5+(15*P++);
return"translate(5, "+Z+")"
});
H.select("rect.connection-label").attr("height",function(){return 5+(15*P)+3
});
H.select("g.expiration-icon").classed("hidden",function(){return !g(V.component)
}).select("title").text(function(){return"Expires FlowFiles older than "+V.component.flowFileExpiration
});
if(nf.Common.isDFM()){H.call(n)
}O.call(k)
}else{if(!H.empty()){H.remove()
}}}O.select("g.connection-label-container").attr("transform",function(){var aa=d3.select(this).select("rect.connection-label");
var Z=j(aa);
return"translate("+Z.x+", "+Z.y+")"
})
})
};
var k=function(y){if(y.empty()){return
}y.select("text.queued").text(function(z){if(nf.Common.isDefinedAndNotNull(z.status)){return z.status.queued
}else{return"- / -"
}})
};
var s=function(B,z){var A=nf.Client.getRevision();
var y={revision:A,connection:z};
return $.ajax({type:"PUT",url:B.component.uri,data:JSON.stringify(y),dataType:"json",contentType:"application/json"}).done(function(C){nf.Client.setRevision(C.revision);
nf.Connection.set(C.connection)
}).fail(function(E,C,D){if(E.status===400||E.status===404||E.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(E.responseText),overlayBackground:true})
}else{nf.Common.handleAjaxError(E,C,D)
}})
};
var f=function(y){y.remove()
};
return{config:{selfLoopXOffset:(e.width/2)+5,selfLoopYOffset:25},init:function(){r=d3.map();
b=d3.select("#canvas").append("g").attr({"pointer-events":"stroke","class":"connections"});
d=d3.svg.line().x(function(y){return y.x
}).y(function(y){return y.y
}).interpolate("linear");
w=d3.behavior.drag().on("dragstart",function(){d3.event.sourceEvent.stopPropagation()
}).on("drag",function(y){y.x=d3.event.x;
y.y=d3.event.y;
d3.select(this.parentNode).call(q,true,false)
}).on("dragend",function(){var y=d3.select(this.parentNode);
var C=y.datum();
var A=y.selectAll("rect.midpoint").data();
if(A.length===C.component.bends.length){var B=false;
for(var z=0;
z<A.length&&!B;
z++){if(A[z].x!==C.component.bends[z].x||A[z].y!==C.component.bends[z].y){B=true
}}if(B){s(C,{id:C.component.id,bends:A}).fail(function(){C.bends=$.map(C.component.bends,function(D){return{x:D.x,y:D.y}
});
y.call(q,true,false)
})
}}d3.event.sourceEvent.stopPropagation()
});
x=d3.behavior.drag().on("dragstart",function(y){y.dragging=true;
d3.event.sourceEvent.stopPropagation()
}).on("drag",function(y){y.x=d3.event.x-8;
y.y=d3.event.y-8;
d3.select("g.hover").classed("connectable-destination",function(){return nf.CanvasUtils.isValidConnectionDestination(d3.select(this))
});
d3.select(this.parentNode).call(q,true,false)
}).on("dragend",function(F){F.dragging=false;
var y=d3.select(this.parentNode);
var I=y.datum();
var H=d3.select("g.connectable-destination");
if(H.empty()){y.call(q,true,false)
}else{if(nf.CanvasUtils.isProcessGroup(H)||nf.CanvasUtils.isRemoteProcessGroup(H)){nf.ConnectionConfiguration.showConfiguration(y,H).fail(function(){y.call(q,true,false)
})
}else{var G=nf.Client.getRevision();
var B=H.datum();
var D=nf.CanvasUtils.getConnectableTypeForDestination(H);
var C={version:G.version,clientId:G.clientId,destinationId:B.component.id,destinationType:D,destinationGroupId:nf.Canvas.getGroupId()};
if(I.bends.length<2&&I.component.source.id===B.component.id){var z={x:B.component.position.x+(B.dimensions.width),y:B.component.position.y+(B.dimensions.height/2)};
var E=nf.Connection.config.selfLoopXOffset;
var A=nf.Connection.config.selfLoopYOffset;
C.bends=[];
C.bends.push((z.x+E)+","+(z.y-A));
C.bends.push((z.x+E)+","+(z.y+A))
}$.ajax({type:"PUT",url:I.component.uri,data:C,dataType:"json"}).done(function(J){var K=J.connection;
nf.Client.setRevision(J.revision);
nf.Connection.set(K)
}).fail(function(L,J,K){if(L.status===400||L.status===404||L.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(L.responseText),overlayBackground:true});
y.call(q,true,false)
}else{nf.Common.handleAjaxError(L,J,K)
}})
}}d3.event.sourceEvent.stopPropagation()
});
n=d3.behavior.drag().on("dragstart",function(y){d3.event.sourceEvent.stopPropagation()
}).on("drag",function(D){if(D.bends.length>1){var A=d3.select("rect.label-drag");
if(A.empty()){var C=d3.select(this).select("rect.connection-label");
var B=j(C);
var y=e.width;
var H=C.attr("height");
A=d3.select("#canvas").append("rect").attr("rx",6).attr("ry",6).attr("x",B.x).attr("y",B.y).attr("class","label-drag").attr("width",y).attr("height",H).attr("stroke-width",function(){return 1/nf.Canvas.View.scale()
}).attr("stroke-dasharray",function(){return 4/nf.Canvas.View.scale()
}).datum({x:B.x,y:B.y,width:y,height:H})
}else{A.attr("x",function(I){I.x+=d3.event.dx;
return I.x
}).attr("y",function(I){I.y+=d3.event.dy;
return I.y
})
}var E=A.datum();
var G={x:E.x+(E.width/2),y:E.y+(E.height/2)};
var z=-1;
var F;
$.each(D.bends,function(K,J){var I={x:J.x,y:J.y};
var L=i(G,I);
if(z===-1||L<F){z=K;
F=L
}});
D.labelIndex=z;
d3.select(this.parentNode).call(q,true,false)
}}).on("dragend",function(A){if(A.bends.length>1){var z=d3.select("rect.label-drag");
if(!z.empty()){z.remove()
}if(A.labelIndex!==A.component.labelIndex){var y=d3.select(this.parentNode);
s(A,{id:A.component.id,labelIndex:A.labelIndex}).fail(function(){A.labelIndex=A.component.labelIndex;
y.call(q,true,false)
})
}}d3.event.sourceEvent.stopPropagation()
})
},add:function(y,z){z=nf.Common.isDefinedAndNotNull(z)?z:false;
var A=function(B){r.set(B.id,{type:"Connection",component:B,bends:$.map(B.bends,function(C){return{x:C.x,y:C.y}
}),labelIndex:B.labelIndex})
};
if($.isArray(y)){$.each(y,function(C,B){A(B)
})
}else{A(y)
}p().enter().call(v,z)
},reorder:function(){d3.selectAll("g.connection").call(t)
},set:function(y){var z=function(B){if(r.has(B.id)){var A=r.get(B.id);
A.component=B;
A.bends=$.map(B.bends,function(C){return{x:C.x,y:C.y}
});
A.labelIndex=B.labelIndex;
d3.select("#id-"+B.id).call(q,true,true)
}};
if($.isArray(y)){$.each(y,function(A,B){z(B)
})
}else{z(y)
}},setStatus:function(y){if(nf.Common.isEmpty(y)){return
}$.each(y,function(B,z){if(r.has(z.id)){var A=r.get(z.id);
A.status=z
}});
d3.selectAll("g.connection.visible").call(k)
},refresh:function(y){if(nf.Common.isDefinedAndNotNull(y)){d3.select("#id-"+y).call(q,true,true)
}else{d3.selectAll("g.connection").call(q,true,true)
}},pan:function(){d3.selectAll("g.connection.entering, g.connection.leaving").call(q,false,true)
},remove:function(y){if($.isArray(y)){$.each(y,function(A,z){r.remove(z)
})
}else{r.remove(y)
}p().exit().call(f)
},removeAll:function(){nf.Connection.remove(r.keys())
},reload:function(y){if(r.has(y.id)){return $.ajax({type:"GET",url:y.uri,dataType:"json"}).done(function(z){nf.Connection.set(z.connection)
})
}},getComponentConnections:function(z){var y=[];
r.forEach(function(B,C){var A=C.component;
if(nf.CanvasUtils.getConnectionSourceComponentId(A)===z||nf.CanvasUtils.getConnectionDestinationComponentId(A)===z){y.push(A)
}});
return y
},get:function(y){if(nf.Common.isUndefined(y)){return r.values()
}else{return r.get(y)
}}}
}());