nf.ContextMenu=(function(){var j=function(z){return nf.Canvas.getParentGroupId()!==null&&z.empty()
};
var t=function(z){if(z.size()!==1){return false
}var A=nf.CanvasUtils.isLabel(z)||nf.CanvasUtils.isProcessGroup(z);
if(!A){if(nf.CanvasUtils.isProcessor(z)||nf.CanvasUtils.isInputPort(z)||nf.CanvasUtils.isOutputPort(z)||nf.CanvasUtils.isRemoteProcessGroup(z)||nf.CanvasUtils.isConnection(z)){A=nf.CanvasUtils.supportsModification(z)
}}return A&&nf.Common.isDFM()
};
var a=function(z){if(z.size()!==1){return false
}if(nf.Common.isDFM()){if(nf.CanvasUtils.isProcessor(z)||nf.CanvasUtils.isInputPort(z)||nf.CanvasUtils.isOutputPort(z)||nf.CanvasUtils.isRemoteProcessGroup(z)||nf.CanvasUtils.isConnection(z)){return !nf.CanvasUtils.supportsModification(z)
}}else{return nf.CanvasUtils.isProcessor(z)||nf.CanvasUtils.isConnection(z)||nf.CanvasUtils.isProcessGroup(z)||nf.CanvasUtils.isInputPort(z)||nf.CanvasUtils.isOutputPort(z)||nf.CanvasUtils.isRemoteProcessGroup(z)
}return false
};
var c=function(z){return nf.Common.isDFM()&&nf.CanvasUtils.isDeletable(z)
};
var f=function(z){return nf.Common.isDFM()&&nf.CanvasUtils.areRunnable(z)
};
var b=function(z){return nf.Common.isDFM()&&nf.CanvasUtils.areStoppable(z)
};
var u=function(z){if(z.size()!==1){return false
}return nf.CanvasUtils.isProcessor(z)||nf.CanvasUtils.isProcessGroup(z)||nf.CanvasUtils.isRemoteProcessGroup(z)||nf.CanvasUtils.isConnection(z)
};
var g=function(z){if(z.size()!==1){return false
}return nf.CanvasUtils.isProcessor(z)
};
var p=function(z){return z.size()===1&&!nf.CanvasUtils.isConnection(z)
};
var e=function(z){return nf.Common.isDFM()&&nf.CanvasUtils.isCopyable(z)
};
var s=function(z){return nf.Common.isDFM()&&nf.CanvasUtils.isPastable()
};
var l=function(z){return z.empty()
};
var d=function(z){if(z.size()!==1){return false
}return nf.Common.isDFM()&&nf.CanvasUtils.isConnection(z)
};
var n=function(z){if(z.size()!==1){return false
}return nf.Common.isDFM()&&(nf.CanvasUtils.isProcessor(z)||nf.CanvasUtils.isLabel(z))
};
var v=function(z){if(z.size()!==1){return false
}return nf.CanvasUtils.isConnection(z)
};
var x=function(z){if(z.size()!==1){return false
}return nf.CanvasUtils.isFunnel(z)||nf.CanvasUtils.isProcessor(z)||nf.CanvasUtils.isProcessGroup(z)||nf.CanvasUtils.isRemoteProcessGroup(z)||nf.CanvasUtils.isInputPort(z)||(nf.CanvasUtils.isOutputPort(z)&&nf.Canvas.getParentGroupId()!==null)
};
var w=function(z){if(z.size()!==1){return false
}return nf.CanvasUtils.isFunnel(z)||nf.CanvasUtils.isProcessor(z)||nf.CanvasUtils.isProcessGroup(z)||nf.CanvasUtils.isRemoteProcessGroup(z)||nf.CanvasUtils.isOutputPort(z)||(nf.CanvasUtils.isInputPort(z)&&nf.Canvas.getParentGroupId()!==null)
};
var m=function(z){if(z.size()!==1){return false
}return nf.CanvasUtils.isProcessGroup(z)
};
var y=function(z){if(z.size()!==1){return false
}return nf.CanvasUtils.isRemoteProcessGroup(z)
};
var q=function(z){return nf.Common.isDFM()&&nf.CanvasUtils.canAllStartTransmitting(z)
};
var k=function(z){return nf.Common.isDFM()&&nf.CanvasUtils.canAllStopTransmitting(z)
};
var i=function(z,B){if(typeof B.click==="function"){var A=$('<div class="context-menu-item"></div>').on("click",B.click).on("contextmenu",function(C){B.click(C);
C.preventDefault();
C.stopPropagation()
}).on("mouseenter",function(){$(this).addClass("hover")
}).on("mouseleave",function(){$(this).removeClass("hover")
}).appendTo(z);
$('<img class="context-menu-item-img"></img>').attr("src",B.img).appendTo(A);
$('<div class="context-menu-item-text"></div>').text(B.text).appendTo(A);
$('<div class="clear"></div>').appendTo(A)
}};
var r=function(A,z){A.css({left:z.x+"px",top:z.y+"px"}).show()
};
var o=function(B,A,z){nf.Actions[B](A,z);
nf.ContextMenu.hide()
};
var h=[{condition:l,menuItem:{img:"images/iconRefresh.png",text:"Refresh status",action:"reloadStatus"}},{condition:j,menuItem:{img:"images/iconGoTo.png",text:"Leave group",action:"leaveGroup"}},{condition:t,menuItem:{img:"images/iconConfigure.png",text:"Configure",action:"showConfiguration"}},{condition:a,menuItem:{img:"images/iconConfigure.png",text:"View configuration",action:"showDetails"}},{condition:m,menuItem:{img:"images/iconGoTo.png",text:"Enter group",action:"enterGroup"}},{condition:f,menuItem:{img:"images/iconRun.png",text:"Start",action:"start"}},{condition:b,menuItem:{img:"images/iconStop.png",text:"Stop",action:"stop"}},{condition:y,menuItem:{img:"images/iconRemotePorts.png",text:"Remote ports",action:"remotePorts"}},{condition:q,menuItem:{img:"images/iconTransmissionActive.png",text:"Enable transmission",action:"enableTransmission"}},{condition:k,menuItem:{img:"images/iconTransmissionInactive.png",text:"Disable transmission",action:"disableTransmission"}},{condition:u,menuItem:{img:"images/iconChart.png",text:"Stats",action:"showStats"}},{condition:d,menuItem:{img:"images/iconToFront.png",text:"Bring to front",action:"toFront"}},{condition:v,menuItem:{img:"images/iconGoTo.png",text:"Go to source",action:"showSource"}},{condition:v,menuItem:{img:"images/iconGoTo.png",text:"Go to destination",action:"showDestination"}},{condition:w,menuItem:{img:"images/iconSmallRelationship.png",text:"Upstream connections",action:"showUpstream"}},{condition:x,menuItem:{img:"images/iconSmallRelationship.png",text:"Downstream connections",action:"showDownstream"}},{condition:g,menuItem:{img:"images/iconUsage.png",text:"Usage",action:"showUsage"}},{condition:y,menuItem:{img:"images/iconRefresh.png",text:"Refresh flow",action:"refreshRemoteFlow"}},{condition:y,menuItem:{img:"images/iconGoTo.png",text:"Go to",action:"openUri"}},{condition:n,menuItem:{img:"images/iconColor.png",text:"Change color",action:"fillColor"}},{condition:p,menuItem:{img:"images/iconCenterView.png",text:"Center in view",action:"center"}},{condition:e,menuItem:{img:"images/iconCopy.png",text:"Copy",action:"copy"}},{condition:s,menuItem:{img:"images/iconPaste.png",text:"Paste",action:"paste"}},{condition:c,menuItem:{img:"images/iconDelete.png",text:"Delete",action:"delete"}}];
var r=function(A,z){A.css({left:z.x+"px",top:z.y+"px"}).show()
};
return{init:function(){$("#context-menu").on("contextmenu",function(z){z.preventDefault();
z.stopPropagation()
})
},show:function(){var C=$("#canvas-body").get(0);
var A=$("#context-menu").empty();
var B=nf.CanvasUtils.getSelection();
$.each(h,function(D,F){if(F.condition(B)){var E=F.menuItem;
i(A,{img:E.img,text:E.text,click:function(G){o(E.action,B,G)
}})
}});
var z=d3.mouse(C);
r(A,{x:z[0],y:z[1]})
},hide:function(){$("#context-menu").hide()
},activate:function(z){z.on("contextmenu.selection",function(){nf.ContextMenu.show();
d3.event.preventDefault();
d3.event.stopPropagation()
})
}}
}());