nf.CustomProcessorUi={showCustomUi:function(e,c,b){$("#shell-close-button");
var a=nf.Client.getRevision();
var d={processorId:e,revision:a.version,clientId:a.clientId,editable:b};
return nf.Shell.showPage(".."+c+"?"+$.param(d),false)
}};