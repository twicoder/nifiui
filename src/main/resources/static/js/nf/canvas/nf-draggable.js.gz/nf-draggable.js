nf.Draggable=(function(){var a;
var b=function(e){var f=nf.Client.getRevision();
var h=d3.map();
var g=e.datum();
var j={x:g.x-g.original.x,y:g.y-g.original.y};
if(j.x===0&&j.y===0){return
}var i=function(l){var k={x:l.component.position.x+j.x,y:l.component.position.y+j.y};
return $.Deferred(function(m){$.ajax({type:"PUT",url:l.component.uri,data:{version:f.version,clientId:f.clientId,x:k.x,y:k.y},dataType:"json"}).done(function(n){nf.Client.setRevision(n.revision);
l.component.position=k;
m.resolve({type:l.type,id:l.component.id})
}).fail(function(p,n,o){if(p.status===400||p.status===404||p.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(p.responseText),overlayBackground:true})
}else{nf.Common.handleAjaxError(p,n,o)
}m.reject()
})
}).promise()
};
var d=function(m){if(m.component.bends.length===0){return null
}var l=$.map(m.component.bends,function(n){return{x:n.x+j.x,y:n.y+j.y}
});
var k={revision:f,connection:{id:m.component.id,bends:l}};
return $.Deferred(function(n){$.ajax({type:"PUT",url:m.component.uri,data:JSON.stringify(k),dataType:"json",contentType:"application/json"}).done(function(o){nf.Client.setRevision(o.revision);
m.component.bends=o.connection.bends;
m.bends=$.map(m.component.bends,function(p){return{x:p.x,y:p.y}
});
n.resolve({type:m.type,id:m.component.id})
}).fail(function(q,o,p){if(q.status===400||q.status===404||q.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(q.responseText),overlayBackground:true})
}else{nf.Common.handleAjaxError(q,o,p)
}n.reject()
})
}).promise()
};
d3.selectAll("g.connection.selected").each(function(l){var k=d(l);
if(k!==null){h.set(l.component.id,k)
}});
d3.selectAll("g.component.selected").each(function(l){var k=nf.Connection.getComponentConnections(l.component.id);
$.each(k,function(o,n){if(!h.has(n.id)&&nf.CanvasUtils.getConnectionSourceComponentId(n)===nf.CanvasUtils.getConnectionDestinationComponentId(n)){var m=d(nf.Connection.get(n.id));
if(m!==null){h.set(n.id,m)
}}});
h.set(l.component.id,i(l))
});
$.when.apply(window,h.values()).done(function(){var k=$.makeArray(arguments);
var l=d3.set();
$.each(k,function(o,n){if(n.type==="Connection"){l.add(n.id)
}else{var m=nf.Connection.getComponentConnections(n.id);
$.each(m,function(q,p){l.add(p.id)
});
nf[n.type].position(n.id)
}});
l.forEach(function(m){nf.Connection.refresh(m)
})
})
};
var c=function(){var d=d3.selectAll("g.component.selected, g.connection.selected");
var e=d3.select("g.drop");
nf.CanvasUtils.moveComponents(d,e)
};
return{init:function(){a=d3.behavior.drag().on("dragstart",function(){d3.event.sourceEvent.stopPropagation()
}).on("drag",function(){var e=d3.select("rect.drag-selection");
if(e.empty()){var f=d3.selectAll("g.component.selected");
var d=null,h=null,i=null,g=null;
f.each(function(l){if(d===null||l.component.position.x<d){d=l.component.position.x
}if(i===null||l.component.position.y<i){i=l.component.position.y
}var k=l.component.position.x+l.dimensions.width;
var j=l.component.position.y+l.dimensions.height;
if(h===null||k>h){h=k
}if(g===null||j>g){g=j
}});
d3.select("#canvas").append("rect").attr("rx",6).attr("ry",6).attr("x",d).attr("y",i).attr("class","drag-selection").attr("pointer-events","none").attr("width",h-d).attr("height",g-i).attr("stroke-width",function(){return 1/nf.Canvas.View.scale()
}).attr("stroke-dasharray",function(){return 4/nf.Canvas.View.scale()
}).datum({original:{x:d,y:i},x:d,y:i})
}else{e.attr("x",function(j){j.x+=d3.event.dx;
return j.x
}).attr("y",function(j){j.y+=d3.event.dy;
return j.y
})
}}).on("dragend",function(){d3.event.sourceEvent.stopPropagation();
var d=d3.select("rect.drag-selection");
if(d.empty()){return
}if(d3.select("g.drop").empty()){b(d)
}else{c()
}d.remove()
})
},activate:function(d){d.classed("moveable",true).call(a)
}}
}());