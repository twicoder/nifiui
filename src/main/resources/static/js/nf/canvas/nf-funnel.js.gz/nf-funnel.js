nf.Funnel=(function(){var e={width:61,height:61};
var c;
var f;
var b=function(){return f.selectAll("g.funnel").data(c.values(),function(h){return h.component.id
})
};
var a=function(j,i){if(j.empty()){return j
}var h=j.append("g").attr({id:function(k){return"id-"+k.component.id
},"class":"funnel component"}).classed("selected",i).call(nf.CanvasUtils.position);
h.append("rect").attr({"class":"border",width:function(k){return k.dimensions.width
},height:function(k){return k.dimensions.height
},fill:"transparent","stroke-opacity":0.8,"stroke-width":1});
h.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconFunnel.png",width:41,height:41,x:10,y:10});
h.call(nf.Selectable.activate).call(nf.ContextMenu.activate);
if(nf.Common.isDFM()){h.call(nf.Draggable.activate).call(nf.Connectable.activate)
}return h
};
var d=function(h){};
var g=function(h){h.remove()
};
return{init:function(){c=d3.map();
f=d3.select("#canvas").append("g").attr({"pointer-events":"all","class":"funnels"})
},add:function(h,i){i=nf.Common.isDefinedAndNotNull(i)?i:false;
var j=function(k){c.set(k.id,{type:"Funnel",component:k,dimensions:e})
};
if($.isArray(h)){$.each(h,function(l,k){j(k)
})
}else{j(h)
}b().enter().call(a,i)
},get:function(h){if(nf.Common.isUndefined(h)){return c.values()
}else{return c.get(h)
}},refresh:function(h){if(nf.Common.isDefinedAndNotNull(h)){d3.select("#id-"+h).call(d)
}else{d3.selectAll("g.funnel").call(d)
}},reload:function(h){if(c.has(h.id)){return $.ajax({type:"GET",url:h.uri,dataType:"json"}).done(function(i){nf.Funnel.set(i.funnel)
})
}},position:function(h){d3.select("#id-"+h).call(nf.CanvasUtils.position)
},set:function(h){var i=function(j){if(c.has(j.id)){var k=c.get(j.id);
k.component=j;
d3.select("#id-"+j.id).call(d)
}};
if($.isArray(h)){$.each(h,function(k,j){i(j)
})
}else{i(h)
}},remove:function(h){if($.isArray(h)){$.each(h,function(j,i){c.remove(i)
})
}else{c.remove(h)
}b().exit().call(g)
},removeAll:function(){nf.Funnel.remove(c.keys())
}}
}());