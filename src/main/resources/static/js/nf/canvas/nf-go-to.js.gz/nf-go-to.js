nf.GoTo=(function(){var a={urls:{controller:"../nifi-api/controller",processGroups:"../nifi-api/controller/process-groups/"}};
var f=function(k){return $.ajax({type:"GET",url:a.urls.processGroups+encodeURIComponent(k),dataType:"json"})
};
var j=function(k,l){return $.ajax({type:"GET",url:a.urls.processGroups+encodeURIComponent(k)+"/remote-process-groups/"+encodeURIComponent(l),dataType:"json"})
};
var b=function(l){var k=$('<div class="source-destination-connection"></div>').appendTo("#connections-container");
var m;
if(l.source.type==="OUTPUT_PORT"){m=c(k,l)
}else{if(l.source.type==="REMOTE_OUTPUT_PORT"){m=e(k,l)
}else{m=d(k,l)
}}m.done(function(){var p=$('<div class="connection-entry"></div>').appendTo(k);
var o="";
var q=nf.CanvasUtils.formatConnectionName(l);
if(q===""){o="unset";
q="Connection"
}$('<div class="search-result-icon connection-small-icon"></div>').appendTo(p);
$('<div class="connection-entry-name go-to-link"></div>').attr("title",q).addClass(o).text(q).on("click",function(){nf.CanvasUtils.showComponent(l.parentGroupId,l.id);
$("#connections-dialog").modal("hide")
}).appendTo(p);
$('<div class="clear"></div>').appendTo(p);
var n;
if(l.destination.type==="INPUT_PORT"){n=i(k,l)
}else{if(l.destination.type==="REMOTE_INPUT_PORT"){n=g(k,l)
}else{n=h(k,l)
}}n.done(function(){$('<div class="clear"></div>').appendTo(k)
})
})
};
var h=function(k,l){return $.Deferred(function(m){var n="";
if(l.destination.type==="PROCESSOR"){n="processor-small-icon"
}else{if(l.destination.type==="OUTPUT_PORT"){n="output-port-small-icon"
}}var o=$('<div class="destination-component"></div>').appendTo(k);
$('<div class="search-result-icon"></div>').addClass(n).appendTo(o);
$('<div class="destination-component-name go-to-link"></div>').attr("title",l.destination.name).text(l.destination.name).on("click",function(){nf.CanvasUtils.showComponent(l.destination.groupId,l.destination.id);
$("#connections-dialog").modal("hide")
}).appendTo(o);
$('<div class="clear"></div>').appendTo(o);
m.resolve()
}).promise()
};
var i=function(k,l){return f(l.destination.groupId).done(function(m){var n=m.processGroup;
var p=$('<div class="destination-component"></div>').appendTo(k);
$('<div class="search-result-icon process-group-small-icon"></div>').appendTo(p);
$('<div class="destination-component-name go-to-link"></div>').attr("title",n.name).text(n.name).on("click",function(){nf.CanvasUtils.showComponent(n.parentGroupId,n.id);
$("#connections-dialog").modal("hide")
}).appendTo(p);
$('<div class="clear"></div>').appendTo(p);
var o=$('<div class="destination-input-port"></div>').appendTo(p);
$('<div class="search-result-icon input-port-small-icon"></div>').appendTo(o);
$('<div class="destination-input-port-name go-to-link"></div>').attr("title",l.destination.name).text(l.destination.name).on("click",function(){nf.CanvasUtils.showComponent(l.destination.groupId,l.destination.id);
$("#connections-dialog").modal("hide")
}).appendTo(o);
$('<div class="clear"></div>').appendTo(p)
})
};
var g=function(k,l){return j(l.parentGroupId,l.destination.groupId).done(function(m){var n=m.remoteProcessGroup;
var p=$('<div class="destination-component"></div>').appendTo(k);
$('<div class="search-result-icon remote-process-group-small-icon"></div>').appendTo(p);
$('<div class="destination-component-name go-to-link"></div>').attr("title",n.name).text(n.name).on("click",function(){nf.CanvasUtils.showComponent(n.parentGroupId,n.id);
$("#connections-dialog").modal("hide")
}).appendTo(p);
$('<div class="clear"></div>').appendTo(p);
var o=$('<div class="destination-input-port"></div>').appendTo(p);
$('<div class="search-result-icon input-port-small-icon"></div>').appendTo(o);
$('<div class="destination-input-port-name"></div>').attr("title",l.destination.name).text(l.destination.name).appendTo(o);
$('<div class="clear"></div>').appendTo(p)
})
};
var d=function(k,l){return $.Deferred(function(m){var o="";
if(l.source.type==="PROCESSOR"){o="processor-small-icon"
}else{if(l.source.type==="INPUT_PORT"){o="input-port-small-icon"
}}var n=$('<div class="source-component"></div>').appendTo(k);
$('<div class="search-result-icon"></div>').addClass(o).appendTo(n);
$('<div class="source-component-name go-to-link"></div>').attr("title",l.source.name).text(l.source.name).on("click",function(){nf.CanvasUtils.showComponent(l.source.groupId,l.source.id);
$("#connections-dialog").modal("hide")
}).appendTo(n);
m.resolve()
}).promise()
};
var c=function(k,l){return f(l.source.groupId).done(function(m){var o=m.processGroup;
var n=$('<div class="source-component"></div>').appendTo(k);
$('<div class="search-result-icon process-group-small-icon"></div>').appendTo(n);
$('<div class="source-component-name go-to-link"></div>').attr("title",o.name).text(o.name).on("click",function(){nf.CanvasUtils.showComponent(o.parentGroupId,o.id);
$("#connections-dialog").modal("hide")
}).appendTo(n);
$('<div class="clear"></div>').appendTo(n);
var p=$('<div class="source-output-port"></div>').appendTo(n);
$('<div class="search-result-icon output-port-small-icon"></div>').appendTo(p);
$('<div class="source-output-port-name go-to-link"></div>').attr("title",l.source.name).text(l.source.name).on("click",function(){nf.CanvasUtils.showComponent(l.source.groupId,l.source.id);
$("#connections-dialog").modal("hide")
}).appendTo(p)
})
};
var e=function(k,l){return j(l.parentGroupId,l.source.groupId).done(function(m){var o=m.remoteProcessGroup;
var n=$('<div class="source-component"></div>').appendTo(k);
$('<div class="search-result-icon remote-process-group-small-icon"></div>').appendTo(n);
$('<div class="source-component-name go-to-link"></div>').attr("title",o.name).text(o.name).on("click",function(){nf.CanvasUtils.showComponent(o.parentGroupId,o.id);
$("#connections-dialog").modal("hide")
}).appendTo(n);
$('<div class="clear"></div>').appendTo(n);
var p=$('<div class="source-output-port"></div>').appendTo(n);
$('<div class="search-result-icon output-port-small-icon"></div>').appendTo(p);
$('<div class="source-output-port-name"></div>').attr("title",l.source.name).text(l.source.name).appendTo(p)
})
};
return{init:function(){$("#connections-dialog").modal({overlayBackground:false,buttons:[{buttonText:"Close",handler:{click:function(){$("#connections-dialog").modal("hide")
}}}],handler:{close:function(){$("#connections-context").empty();
$("#connections-container").empty()
}}})
},showDownstreamFromProcessor:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon processor-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.source.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No downstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Downstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showUpstreamFromProcessor:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon processor-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.destination.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No upstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Upstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showDownstreamFromGroup:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon process-group-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.source.groupId===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No downstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Downstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showUpstreamFromGroup:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon process-group-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.destination.groupId===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No upstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Upstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showDownstreamFromInputPort:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon input-port-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.source.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No downstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Downstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showUpstreamFromInputPort:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getParentGroupId())+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon process-group-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(nf.Canvas.getGroupName())).append('<div class="clear"></div>').append('<div class="search-result-icon input-port-small-icon" style="margin-left: 20px;"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.destination.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No upstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Upstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showDownstreamFromOutputPort:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(nf.Canvas.getParentGroupId())+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon process-group-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(nf.Canvas.getGroupName())).append('<div class="clear"></div>').append('<div class="search-result-icon output-port-small-icon" style="margin-left: 20px;"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.source.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No downstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Downstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showUpstreamFromOutputPort:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append('<div class="search-result-icon input-port-small-icon"></div>').append($('<div class="connections-component-name"></div>').text(l.component.name)).append('<div class="clear"></div>');
$.each(n,function(p,o){if(o.destination.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No upstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Upstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showDownstreamFromFunnel:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append($('<div class="connections-component-name"></div>').text("Funnel"));
$.each(n,function(p,o){if(o.source.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No downstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Downstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
},showUpstreamFromFunnel:function(k){var l=k.datum();
$.ajax({type:"GET",url:a.urls.controller+"/process-groups/"+encodeURIComponent(l.component.parentGroupId)+"/connections",dataType:"json"}).done(function(m){var n=m.connections;
$("#connections-context").append($('<div class="upstream-destination-name"></div>').text("Funnel"));
$.each(n,function(p,o){if(o.destination.id===l.component.id){b(o)
}});
if($("#connections-container").is(":empty")){$("#connections-container").html('<span class="unset">No upstream components</span>')
}$("#connections-dialog").modal("setHeaderText","Upstream Connections").modal("show")
}).fail(nf.Common.handleAjaxError)
}}
}());