nf.GraphControl=(function(){var a={translateIncrement:20};
return{init:function(){nf.Common.addHoverEffect("#pan-up-button","pan-up","pan-up-hover").on("click",function(){var b=nf.Canvas.View.translate();
nf.Canvas.View.translate([b[0],b[1]+a.translateIncrement]);
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
});
nf.Common.addHoverEffect("#pan-down-button","pan-down","pan-down-hover").on("click",function(){var b=nf.Canvas.View.translate();
nf.Canvas.View.translate([b[0],b[1]-a.translateIncrement]);
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
});
nf.Common.addHoverEffect("#pan-left-button","pan-left","pan-left-hover").on("click",function(){var b=nf.Canvas.View.translate();
nf.Canvas.View.translate([b[0]+a.translateIncrement,b[1]]);
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
});
nf.Common.addHoverEffect("#pan-right-button","pan-right","pan-right-hover").on("click",function(){var b=nf.Canvas.View.translate();
nf.Canvas.View.translate([b[0]-a.translateIncrement,b[1]]);
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
});
nf.Common.addHoverEffect("#zoom-in-button","zoom-in","zoom-in-hover").on("click",function(){nf.Canvas.View.zoomIn();
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
});
nf.Common.addHoverEffect("#zoom-out-button","zoom-out","zoom-out-hover").on("click",function(){nf.Canvas.View.zoomOut();
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
});
nf.Common.addHoverEffect("#zoom-fit-button","fit-image","fit-image-hover").on("click",function(){nf.Canvas.View.fit();
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
});
nf.Common.addHoverEffect("#zoom-actual-button","actual-size","actual-size-hover").on("click",function(){nf.Canvas.View.actualSize();
nf.ContextMenu.hide();
nf.Canvas.View.refresh({transition:true})
})
}}
}());