nf.Graph=(function(){var b=function(c){if(nf.Common.isDefinedAndNotNull(c.inputPorts)&&nf.Common.isDefinedAndNotNull(c.outputPorts)){return c.inputPorts.concat(c.outputPorts)
}else{if(nf.Common.isDefinedAndNotNull(c.inputPorts)){return c.inputPorts
}else{if(nf.Common.isDefinedAndNotNull(c.outputPorts)){return c.outputPorts
}else{return[]
}}}};
var a=function(c){if(nf.Common.isDefinedAndNotNull(c.inputPortStatus)&&nf.Common.isDefinedAndNotNull(c.outputPortStatus)){return c.inputPortStatus.concat(c.outputPortStatus)
}else{if(nf.Common.isDefinedAndNotNull(c.inputPortStatus)){return c.inputPortStatus
}else{if(nf.Common.isDefinedAndNotNull(c.outputPortStatus)){return c.outputPortStatus
}else{return[]
}}}};
return{init:function(){nf.Label.init();
nf.Funnel.init();
nf.Port.init();
nf.RemoteProcessGroup.init();
nf.ProcessGroup.init();
nf.Processor.init();
nf.Connection.init();
return nf.CanvasUtils.enterGroup(nf.Canvas.getGroupId())
},add:function(d,c){c=nf.Common.isDefinedAndNotNull(c)?c:false;
if(c){nf.CanvasUtils.getSelection().classed("selected",false)
}var e=b(d);
if(!nf.Common.isEmpty(d.labels)){nf.Label.add(d.labels,c)
}if(!nf.Common.isEmpty(d.funnels)){nf.Funnel.add(d.funnels,c)
}if(!nf.Common.isEmpty(d.remoteProcessGroups)){nf.RemoteProcessGroup.add(d.remoteProcessGroups,c)
}if(!nf.Common.isEmpty(e)){nf.Port.add(e,c)
}if(!nf.Common.isEmpty(d.processGroups)){nf.ProcessGroup.add(d.processGroups,c)
}if(!nf.Common.isEmpty(d.processors)){nf.Processor.add(d.processors,c)
}if(!nf.Common.isEmpty(d.connections)){nf.Connection.add(d.connections,c)
}},get:function(){return{labels:nf.Label.get(),funnels:nf.Funnel.get(),ports:nf.Port.get(),remoteProcessGroups:nf.RemoteProcessGroup.get(),processGroups:nf.ProcessGroup.get(),processors:nf.Processor.get(),connections:nf.Connection.get()}
},set:function(c){var d=b(c);
if(!nf.Common.isEmpty(c.labels)){nf.Label.set(c.labels)
}if(!nf.Common.isEmpty(c.funnels)){nf.Funnel.set(c.funnels)
}if(!nf.Common.isEmpty(d)){nf.Port.set(d)
}if(!nf.Common.isEmpty(c.remoteProcessGroups)){nf.RemoteProcessGroup.set(c.remoteProcessGroups)
}if(!nf.Common.isEmpty(c.processGroups)){nf.ProcessGroup.set(c.processGroups)
}if(!nf.Common.isEmpty(c.processors)){nf.Processor.set(c.processors)
}if(!nf.Common.isEmpty(c.connections)){nf.Connection.set(c.connections)
}},setStatus:function(d){var c=a(d);
nf.Port.setStatus(c);
nf.RemoteProcessGroup.setStatus(d.remoteProcessGroupStatus);
nf.ProcessGroup.setStatus(d.processGroupStatus);
nf.Processor.setStatus(d.processorStatus);
nf.Connection.setStatus(d.connectionStatus)
},removeAll:function(){nf.Label.removeAll();
nf.Funnel.removeAll();
nf.Port.removeAll();
nf.RemoteProcessGroup.removeAll();
nf.ProcessGroup.removeAll();
nf.Processor.removeAll();
nf.Connection.removeAll()
},pan:function(){nf.Port.pan();
nf.RemoteProcessGroup.pan();
nf.ProcessGroup.pan();
nf.Processor.pan();
nf.Connection.pan()
}}
}());