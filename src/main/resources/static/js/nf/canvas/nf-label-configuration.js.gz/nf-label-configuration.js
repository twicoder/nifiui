nf.LabelConfiguration=(function(){var a="";
return{init:function(){var b=function(){var g=nf.Client.getRevision();
var f=$("#label-value").val();
var h=$("#label-font-size").combo("getSelectedOption");
$.ajax({type:"PUT",url:a,data:{version:g.version,clientId:g.clientId,label:f,"style[font-size]":h.value},dataType:"json"}).done(function(i){nf.Client.setRevision(i.revision);
nf.Label.set(i.label)
}).fail(nf.Common.handleAjaxError);
a="";
$("#label-configuration").hide()
};
var e=function(){a="";
$("#label-configuration").hide()
};
$("#label-configuration").draggable({containment:"parent",cancel:"textarea, .button, .combo"}).on("click","#label-configuration-apply",b).on("click","#label-configuration-cancel",e);
var d=[];
for(var c=12;
c<=24;
c+=2){d.push({text:c+"px",value:c+"px"})
}$("#label-font-size").combo({options:d,selectedOption:{value:"12px"},select:function(g){var f=$("#label-value");
f.css({"font-size":g.value,"line-height":g.value}).val(f.val())
}})
},showConfiguration:function(c){if(nf.CanvasUtils.isLabel(c)){var e=c.datum();
var b="";
if(nf.Common.isDefinedAndNotNull(e.component.label)){b=e.component.label
}var d="12px";
if(nf.Common.isDefinedAndNotNull(e.component.style["font-size"])){d=e.component.style["font-size"]
}a=e.component.uri;
$("#label-value").val(b);
$("#label-font-size").combo("setSelectedOption",{value:d});
$("#label-configuration").center().show()
}}}
}());