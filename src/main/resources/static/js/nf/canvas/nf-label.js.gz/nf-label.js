nf.Label=(function(){var a={width:150,height:150};
var g=20;
var b=64;
var f;
var j;
var h;
var i=function(){return j.selectAll("g.label").data(f.values(),function(l){return l.component.id
})
};
var c=function(n,m){if(n.empty()){return
}var l=n.append("g").attr({id:function(o){return"id-"+o.component.id
},"class":"label component"}).classed("selected",m).call(d);
l.append("rect").attr({"class":"border",fill:"transparent","stroke-opacity":0.8,"stroke-width":1});
l.append("rect").attr({"class":"body","fill-opacity":0.8,"stroke-opacity":0.8,"stroke-width":0});
l.append("text").attr({"xml:space":"preserve","font-weight":"bold",fill:"black","class":"label-value"});
l.call(nf.Selectable.activate).call(nf.ContextMenu.activate);
if(nf.Common.isDFM()){l.call(nf.Draggable.activate)
}l.call(k)
};
var d=function(l){if(l.empty()){return
}l.attr("transform",function(m){return"translate("+m.component.position.x+", "+m.component.position.y+")"
})
};
var k=function(m){if(m.empty()){return
}var l=d3.set();
l.add(nf.Common.substringAfterLast(nf.Label.defaultColor(),"#"));
f.forEach(function(p,o){var n=o.component.style["background-color"];
if(nf.Common.isDefinedAndNotNull(n)){l.add(nf.Common.substringAfterLast(n,"#"))
}});
nf.Canvas.defineLabelColors(l.values());
m.select("rect.border").attr({stroke:function(o){var n=nf.Label.defaultColor();
if(nf.Common.isDefinedAndNotNull(o.component.style["background-color"])){n=o.component.style["background-color"]
}return n
},width:function(n){return n.dimensions.width
},height:function(n){return n.dimensions.height
}});
m.select("rect.body").attr({fill:function(o){var n=nf.Label.defaultColor();
if(nf.Common.isDefinedAndNotNull(o.component.style["background-color"])){n=o.component.style["background-color"]
}n=nf.Common.substringAfterLast(n,"#");
return"url(#label-background-"+n+")"
},width:function(n){return n.dimensions.width
},height:function(n){return n.dimensions.height
}});
m.each(function(r){var s=d3.select(this);
var p=s.select("text.label-value");
p.attr("font-size",function(){var t="12px";
if(nf.Common.isDefinedAndNotNull(r.component.style["font-size"])){t=r.component.style["font-size"]
}return t
});
p.selectAll("tspan").remove();
var o=[];
if(nf.Common.isDefinedAndNotNull(r.component.label)){o=r.component.label.split("\n")
}else{o.push("")
}$.each(o,function(u,t){p.append("tspan").attr("x","0.4em").attr("dy","1.2em").text(function(){return t
})
});
if(nf.Common.isDFM()){var n=[{x:r.dimensions.width,y:r.dimensions.height}];
var q=s.selectAll("rect.labelpoint").data(n);
q.enter().append("rect").attr({"class":"labelpoint",width:10,height:10}).call(h);
q.attr("transform",function(t){return"translate("+(t.x-10)+", "+(t.y-10)+")"
});
q.exit().remove()
}})
};
var e=function(l){l.remove()
};
return{config:{width:a.width,height:a.height},init:function(){f=d3.map();
j=d3.select("#canvas").append("g").attr({"pointer-events":"all","class":"labels"});
h=d3.behavior.drag().on("dragstart",function(){d3.event.sourceEvent.stopPropagation()
}).on("drag",function(){var l=d3.select(this.parentNode);
var m=l.datum();
m.dimensions.width=Math.max(b,d3.event.x);
m.dimensions.height=Math.max(g,d3.event.y);
k(l)
}).on("dragend",function(){var m=d3.select(this.parentNode);
var n=m.datum();
var o=false;
if(nf.Common.isDefinedAndNotNull(n.component.width)||n.dimensions.width!==n.component.width){o=true
}if(!o&&nf.Common.isDefinedAndNotNull(n.component.height)||n.dimensions.height!==n.component.height){o=true
}if(o){var l=nf.Client.getRevision();
$.ajax({type:"PUT",url:n.component.uri,data:{version:l.version,clientId:l.clientId,width:n.dimensions.width,height:n.dimensions.height},dataType:"json"}).done(function(p){nf.Client.setRevision(p.revision);
nf.Label.set(p.label)
}).fail(function(){var q=a.width;
if(nf.Common.isDefinedAndNotNull(n.component.width)){q=n.component.width
}var p=a.height;
if(nf.Common.isDefinedAndNotNull(n.component.height)){p=n.component.height
}n.dimensions={width:q,height:p};
m.call(k)
})
}d3.event.sourceEvent.stopPropagation()
})
},add:function(n,l){l=nf.Common.isDefinedAndNotNull(l)?l:false;
var m=function(p){var q=a.width;
if(nf.Common.isDefinedAndNotNull(p.width)){q=p.width
}var o=a.height;
if(nf.Common.isDefinedAndNotNull(p.height)){o=p.height
}f.set(p.id,{type:"Label",component:p,dimensions:{width:q,height:o}})
};
if($.isArray(n)){$.each(n,function(p,o){m(o)
})
}else{m(n)
}i().enter().call(c,l)
},get:function(l){if(nf.Common.isUndefined(l)){return f.values()
}else{return f.get(l)
}},refresh:function(l){if(nf.Common.isDefinedAndNotNull(l)){d3.select("#id-"+l).call(k)
}else{d3.selectAll("g.label").call(k)
}},reload:function(l){if(f.has(l.id)){return $.ajax({type:"GET",url:l.uri,dataType:"json"}).done(function(m){nf.Label.set(m.label)
})
}},position:function(l){d3.select("#id-"+l).call(d)
},set:function(m){var l=function(p){if(f.has(p.id)){var q=a.width;
if(nf.Common.isDefinedAndNotNull(p.width)){q=p.width
}var n=a.height;
if(nf.Common.isDefinedAndNotNull(p.height)){n=p.height
}var o=f.get(p.id);
o.component=p;
o.dimensions={width:q,height:n};
d3.select("#id-"+p.id).call(k)
}};
if($.isArray(m)){$.each(m,function(o,n){l(n)
})
}else{l(m)
}},remove:function(l){if($.isArray(l)){$.each(l,function(n,m){f.remove(m)
})
}else{f.remove(l)
}i().exit().call(e)
},removeAll:function(){nf.Label.remove(f.keys())
},defaultColor:function(){return"#ffde93"
}}
}());