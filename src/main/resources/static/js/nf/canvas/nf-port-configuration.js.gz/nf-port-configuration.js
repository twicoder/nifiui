nf.PortConfiguration=(function(){var a=function(){$("#port-configuration").modal({headerText:"Configure Port",overlayBackground:true,buttons:[{buttonText:"Apply",handler:{click:function(){var c=nf.Client.getRevision();
var d=$("#port-id").text();
var b=d3.select("#id-"+d).datum();
var e={version:c.version,clientId:c.clientId,name:$("#port-name").val(),comments:$("#port-comments").val()};
if($("#port-concurrent-task-container").is(":visible")){e.concurrentlySchedulableTaskCount=$("#port-concurrent-tasks").val()
}if($("#port-enabled").hasClass("checkbox-unchecked")){e.state="DISABLED"
}else{if($("#port-enabled").hasClass("checkbox-checked")){e.state="STOPPED"
}}$.ajax({type:"PUT",data:e,url:b.component.uri,dataType:"json"}).done(function(g){nf.Client.setRevision(g.revision);
var f;
if(nf.Common.isDefinedAndNotNull(g.inputPort)){f=g.inputPort
}else{f=g.outputPort
}nf.Port.set(f);
$("#port-configuration").modal("hide")
}).fail(function(i,f,g){if(i.status===400){var j=i.responseText.split("\n");
var h;
if(j.length===1){h=$("<span></span>").text(j[0])
}else{h=nf.Common.formatUnorderedList(j)
}nf.Dialog.showOkDialog({dialogContent:h,overlayBackground:false,headerText:"Configuration Error"})
}else{$("#port-configuration").modal("hide");
nf.Common.handleAjaxError(i,f,g)
}})
}}},{buttonText:"Cancel",handler:{click:function(){$("#port-configuration").modal("hide")
}}}],handler:{close:function(){$("#port-id").text("");
$("#port-name").val("");
$("#port-enabled").removeClass("checkbox-unchecked checkbox-checked");
$("#port-concurrent-tasks").val("");
$("#port-comments").val("")
}}}).draggable({containment:"parent",handle:".dialog-header"})
};
return{init:function(){a()
},showConfiguration:function(c){if(nf.CanvasUtils.isInputPort(c)||nf.CanvasUtils.isOutputPort(c)){var d=c.datum();
var b="checkbox-checked";
if(d.component.state==="DISABLED"){b="checkbox-unchecked"
}if(nf.Canvas.getParentGroupId()===null){$("#port-concurrent-task-container").show()
}else{$("#port-concurrent-task-container").hide()
}$("#port-id").text(d.component.id);
$("#port-name").val(d.component.name);
$("#port-enabled").removeClass("checkbox-unchecked checkbox-checked").addClass(b);
$("#port-concurrent-tasks").val(d.component.concurrentlySchedulableTaskCount);
$("#port-comments").val(d.component.comments);
$("#port-configuration").modal("show")
}}}
}());