nf.PortDetails=(function(){return{init:function(){$("#port-details").modal({headerText:"Port Details",overlayBackground:true,buttons:[{buttonText:"Ok",handler:{click:function(){$("#port-details").modal("hide")
}}}],handler:{close:function(){nf.Common.clearField("read-only-port-name");
nf.Common.clearField("read-only-port-id");
nf.Common.clearField("read-only-port-comments")
}}}).draggable({containment:"parent",handle:".dialog-header"})
},showDetails:function(a){if(nf.CanvasUtils.isInputPort(a)||nf.CanvasUtils.isOutputPort(a)){var b=a.datum();
nf.Common.populateField("read-only-port-name",b.component.name);
nf.Common.populateField("read-only-port-id",b.component.id);
nf.Common.populateField("read-only-port-comments",b.component.comments);
$("#port-details").modal("show")
}}}
}());