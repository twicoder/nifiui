nf.Port=(function(){var k=15;
var l=12;
var d={width:160,height:40};
var h={width:160,height:56};
var g;
var a;
var i=function(){return a.selectAll("g.input-port, g.output-port").data(g.values(),function(m){return m.component.id
})
};
var f=function(o,n){if(o.empty()){return
}var m=o.append("g").attr({id:function(q){return"id-"+q.component.id
},"class":function(q){if(q.component.type==="INPUT_PORT"){return"input-port component"
}else{return"output-port component"
}}}).classed("selected",n).call(nf.CanvasUtils.position);
m.append("rect").attr({"class":"border",width:function(q){return q.dimensions.width
},height:function(q){return q.dimensions.height
},fill:"transparent","stroke-opacity":0.8,"stroke-width":1,stroke:"#aaaaaa"});
var p=0;
if(nf.Canvas.getParentGroupId()===null){p=l;
m.append("rect").attr({"class":"remote-banner",width:function(q){return q.dimensions.width
},height:p,fill:"#294c58","fill-opacity":0.95})
}m.append("rect").attr({x:0,y:p,"class":"port-body",width:function(q){return q.dimensions.width
},height:function(q){return q.dimensions.height-p
},fill:"url(#port-background)","fill-opacity":0.8,"stroke-opacity":0.8,"stroke-width":0,stroke:"#aaaaaa"});
m.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":function(q){if(q.component.type==="INPUT_PORT"){return"images/iconInputPort.png"
}else{return"images/iconOutputPort.png"
}},width:46,height:31,x:function(q){if(q.component.type==="INPUT_PORT"){return 0
}else{return 114
}},y:5+p});
m.append("text").attr({x:function(q){if(q.component.type==="INPUT_PORT"){return 52
}else{return 5
}},y:18+p,width:95,height:30,"font-size":"10px","font-weight":"bold",fill:"#294c58","class":"port-name"});
m.call(nf.Selectable.activate).call(nf.ContextMenu.activate);
if(nf.Common.isDFM()){m.call(nf.Draggable.activate).call(nf.Connectable.activate)
}m.call(e)
};
var e=function(m){if(m.empty()){return
}m.each(function(){var n=d3.select(this);
var o=n.select("g.port-details");
if(n.classed("visible")){if(o.empty()){o=n.append("g").attr("class","port-details");
var p=0;
if(nf.Canvas.getParentGroupId()===null){p=l;
o.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"port-transmission-icon",width:10,height:10,x:3,y:1});
o.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"bulletin-icon","xlink:href":"images/iconBulletin.png",width:12,height:12,x:147,y:0})
}o.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"port-run-status-icon",width:16,height:16,x:function(q){if(q.component.type==="INPUT_PORT"){return 33
}else{return 107
}},y:function(){return 24+p
}});
o.append("rect").attr({"class":"active-thread-count-background",height:11,y:0,fill:"#fff","fill-opacity":"0.65",stroke:"#aaa","stroke-width":"1"});
o.append("text").attr({"class":"active-thread-count",height:11,y:9,fill:"#000"})
}o.select("image.port-run-status-icon").attr("xlink:href",function(r){var q="";
if(r.component.state==="DISABLED"){q="images/iconDisable.png"
}else{if(!nf.Common.isEmpty(r.component.validationErrors)){q="images/iconAlert.png"
}else{if(r.component.state==="RUNNING"){q="images/iconRun.png"
}else{if(r.component.state==="STOPPED"){q="images/iconStop.png"
}}}}return q
}).each(function(r){var q=d3.select("#run-status-tip-"+r.component.id);
if(!q.empty()){q.remove()
}if(!nf.Common.isEmpty(r.component.validationErrors)){q=d3.select("#port-tooltips").append("div").attr("id",function(){return"run-status-tip-"+r.component.id
}).attr("class","tooltip nifi-tooltip").html(function(){var s=nf.Common.formatUnorderedList(r.component.validationErrors);
if(s===null||s.length===0){return""
}else{return $("<div></div>").append(s).html()
}});
nf.CanvasUtils.canvasTooltip(q,d3.select(this))
}});
n.select("text.port-name").each(function(t){var s=d3.select(this);
var q=t.component.name;
var r=q.split(/\s+/);
s.text(null).selectAll("tspan, title").remove();
if(r.length===1){nf.CanvasUtils.ellipsis(s,q)
}else{nf.CanvasUtils.multilineEllipsis(s,2,q)
}}).append("title").text(function(q){return q.component.name
});
n.call(b)
}else{n.select("text.port-name").text(function(r){var q=r.component.name;
if(q.length>k){return q.substring(0,k)+String.fromCharCode(8230)
}else{return q
}});
n.call(j);
if(!o.empty()){o.remove()
}}})
};
var b=function(m){if(m.empty()){return
}m.select("image.port-transmission-icon").attr("xlink:href",function(n){if(n.status.transmitting===true){return"images/iconPortTransmitting.png"
}else{return"images/iconPortNotTransmitting.png"
}});
m.each(function(p){var n=d3.select(this);
var o=0;
nf.CanvasUtils.activeThreadCount(n,p,function(q){o=q
});
nf.CanvasUtils.bulletins(n,p,function(){return d3.select("#port-tooltips")
},o)
})
};
var c=function(m){if(m.empty()){return
}m.call(j).remove()
};
var j=function(m){m.each(function(n){$("#run-status-tip-"+n.component.id).remove();
$("#bulletin-tip-"+n.component.id).remove()
})
};
return{init:function(){g=d3.map();
a=d3.select("#canvas").append("g").attr({"pointer-events":"all","class":"ports"})
},add:function(p,n){n=nf.Common.isDefinedAndNotNull(n)?n:false;
var m=d;
if(nf.Canvas.getParentGroupId()===null){m=h
}var o=function(q){g.set(q.id,{type:"Port",component:q,dimensions:m,status:{activeThreadCount:0}})
};
if($.isArray(p)){$.each(p,function(r,q){o(q)
})
}else{o(p)
}i().enter().call(f,n)
},get:function(m){if(nf.Common.isUndefined(m)){return g.values()
}else{return g.get(m)
}},refresh:function(m){if(nf.Common.isDefinedAndNotNull(m)){d3.select("#id-"+m).call(e)
}else{d3.selectAll("g.input-port, g.output-port").call(e)
}},pan:function(){d3.selectAll("g.input-port.entering, g.output-port.entering, g.input-port.leaving, g.output-port.leaving").call(e)
},reload:function(m){if(g.has(m.id)){return $.ajax({type:"GET",url:m.uri,dataType:"json"}).done(function(n){if(nf.Common.isDefinedAndNotNull(n.inputPort)){nf.Port.set(n.inputPort)
}else{nf.Port.set(n.outputPort)
}})
}},position:function(m){d3.select("#id-"+m).call(nf.CanvasUtils.position)
},set:function(n){var m=function(o){if(g.has(o.id)){var p=g.get(o.id);
p.component=o;
d3.select("#id-"+o.id).call(e)
}};
if($.isArray(n)){$.each(n,function(p,o){m(o)
})
}else{m(n)
}},setStatus:function(m){if(nf.Common.isEmpty(m)){return
}$.each(m,function(p,n){if(g.has(n.id)){var o=g.get(n.id);
o.status=n
}});
d3.selectAll("g.input-port.visible, g.output-port.visible").call(b)
},remove:function(m){if($.isArray(m)){$.each(m,function(o,n){g.remove(n)
})
}else{g.remove(m)
}i().exit().call(c)
},removeAll:function(){nf.Port.remove(g.keys())
}}
}());