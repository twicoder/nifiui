nf.ProcessGroupConfiguration=(function(){return{init:function(){$("#process-group-configuration").modal({headerText:"Configure Process Group",overlayBackground:true,buttons:[{buttonText:"Apply",handler:{click:function(){var b=nf.Client.getRevision();
var a=$("#process-group-id").text();
var c=d3.select("#id-"+a).datum();
$.ajax({type:"PUT",data:{version:b.version,clientId:b.clientId,name:$("#process-group-name").val(),comments:$("#process-group-comments").val()},url:c.component.uri,dataType:"json"}).done(function(d){if(nf.Common.isDefinedAndNotNull(d.processGroup)){nf.Client.setRevision(d.revision);
nf.ProcessGroup.set(d.processGroup);
$("#process-group-configuration").modal("hide")
}}).fail(function(f,d,e){$("#process-group-configuration").modal("hide");
nf.Common.handleAjaxError(f,d,e)
})
}}},{buttonText:"Cancel",handler:{click:function(){$("#process-group-configuration").modal("hide")
}}}],handler:{close:function(){$("#process-group-id").text("");
$("#process-group-name").val("");
$("#process-group-comments").val("")
}}}).draggable({containment:"parent",handle:".dialog-header"})
},showConfiguration:function(a){if(nf.CanvasUtils.isProcessGroup(a)){var b=a.datum();
$("#process-group-id").text(b.component.id);
$("#process-group-name").val(b.component.name);
$("#process-group-comments").val(b.component.comments);
$("#process-group-configuration").modal("show")
}}}
}());