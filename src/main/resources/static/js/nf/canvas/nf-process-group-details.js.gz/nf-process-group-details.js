nf.ProcessGroupDetails=(function(){return{init:function(){$("#process-group-details").modal({headerText:"Process Group Details",overlayBackground:true,buttons:[{buttonText:"Ok",handler:{click:function(){$("#process-group-details").modal("hide")
}}}],handler:{close:function(){nf.Common.clearField("read-only-process-group-name");
nf.Common.clearField("read-only-process-group-comments")
}}}).draggable({containment:"parent",handle:".dialog-header"})
},showDetails:function(a){if(nf.CanvasUtils.isProcessGroup(a)){var b=a.datum();
nf.Common.populateField("read-only-process-group-name",b.component.name);
nf.Common.populateField("read-only-process-group-comments",b.component.comments);
$("#process-group-details").modal("show")
}}}
}());