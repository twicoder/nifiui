nf.ProcessGroup=(function(){var l=30;
var a={width:365,height:142};
var g;
var f;
var i=function(m){if(nf.Common.isBlank(m.component.comments)){return"No comments specified"
}else{return m.component.comments
}};
var j=function(){return f.selectAll("g.process-group").data(g.values(),function(m){return m.component.id
})
};
var h=function(o,m){if(o.empty()){return
}var n=o.append("g").attr({id:function(p){return"id-"+p.component.id
},"class":"process-group component"}).classed("selected",m).call(nf.CanvasUtils.position);
n.append("rect").attr({rx:6,ry:6,"class":"border",width:function(p){return p.dimensions.width
},height:function(p){return p.dimensions.height
},fill:"transparent","stroke-opacity":0.8,"stroke-width":2,stroke:"#294c58"});
n.append("rect").attr({rx:6,ry:6,"class":"body",width:function(p){return p.dimensions.width
},height:function(p){return p.dimensions.height
},fill:"#294c58","fill-opacity":0.8,"stroke-width":0});
n.append("text").attr({x:10,y:15,width:316,height:16,"font-size":"10pt","font-weight":"bold",fill:"#ffffff","class":"process-group-name"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/bgProcessGroupDetailsArea.png",width:352,height:113,x:6,y:22,"class":"process-group-preview"});
n.on("dblclick",function(p){nf.CanvasUtils.enterGroup(p.component.id)
}).call(nf.Selectable.activate).call(nf.ContextMenu.activate);
if(nf.Common.isDFM()){n.on("mouseover.drop",function(t){var r=d3.select(this);
if(!r.classed("drop")){var s=r.datum();
var q=d3.select("rect.drag-selection");
if(!q.empty()){var p=nf.CanvasUtils.getSelection().filter(function(u){return s.component.id===u.component.id
});
if(p.empty()){r.classed("drop",function(){return nf.CanvasUtils.isDisconnected(nf.CanvasUtils.getSelection())
})
}}}}).on("mouseout.drop",function(p){d3.select(this).classed("drop",false)
}).call(nf.Draggable.activate).call(nf.Connectable.activate)
}n.call(c)
};
var e=5;
var c=function(m){if(m.empty()){return
}m.each(function(){var C=d3.select(this);
var z=C.select("g.process-group-details");
if(C.classed("visible")){if(z.empty()){z=C.append("g").attr("class","process-group-details");
z.append("rect").attr({x:6,y:22,width:352,height:113,"stroke-width":1,stroke:"#6f97ac",fill:"#ffffff"});
z.append("rect").attr({x:6,y:22,width:352,height:22,"stroke-width":1,stroke:"#6f97ac",fill:"url(#process-group-stats-background)","class":"process-group-contents-container"});
z.append("rect").attr({x:6,y:104,width:352,height:33,"stroke-width":1,stroke:"#6f97ac",fill:"url(#process-group-stats-background)"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconInputPortSmall.png",width:16,height:16,x:10,y:25});
z.append("text").attr({x:29,y:37,"class":"process-group-input-port-count process-group-contents-count"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconOutputPortSmall.png",width:16,height:16,y:25,"class":"process-group-output-port"});
z.append("text").attr({y:37,"class":"process-group-output-port-count process-group-contents-count"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconTransmissionActive.png",width:16,height:16,y:25,"class":"process-group-transmitting"});
z.append("text").attr({y:37,"class":"process-group-transmitting-count process-group-contents-count"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconTransmissionInactive.png",width:16,height:16,y:25,"class":"process-group-not-transmitting"});
z.append("text").attr({y:37,"class":"process-group-not-transmitting-count process-group-contents-count"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconRun.png",width:16,height:16,y:25,"class":"process-group-running"});
z.append("text").attr({y:37,"class":"process-group-running-count process-group-contents-count"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconStop.png",width:16,height:16,y:25,"class":"process-group-stopped"});
z.append("text").attr({y:37,"class":"process-group-stopped-count process-group-contents-count"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconAlert.png",width:16,height:16,y:25,"class":"process-group-invalid"});
z.append("text").attr({y:37,"class":"process-group-invalid-count process-group-contents-count"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconDisable.png",width:16,height:16,y:25,"class":"process-group-disabled"});
z.append("text").attr({y:37,"class":"process-group-disabled-count process-group-contents-count"});
var y=z.append("g").attr({transform:"translate(6, 54)"});
y.append("text").attr({width:73,height:10,x:4,y:4,"class":"process-group-stats-label"}).text("Queued");
y.append("text").attr({width:73,height:10,x:4,y:17,"class":"process-group-stats-label"}).text("In");
y.append("text").attr({width:73,height:10,x:4,y:30,"class":"process-group-stats-label"}).text("Read/Write");
y.append("text").attr({width:73,height:10,x:4,y:43,"class":"process-group-stats-label"}).text("Out");
var o=z.append("g").attr({transform:"translate(95, 54)"});
o.append("text").attr({width:180,height:10,x:4,y:4,"class":"process-group-queued process-group-stats-value"});
o.append("text").attr({width:180,height:10,x:4,y:17,"class":"process-group-in process-group-stats-value"});
o.append("text").attr({width:180,height:10,x:4,y:30,"class":"process-group-read-write process-group-stats-value"});
o.append("text").attr({width:180,height:10,x:4,y:43,"class":"process-group-out process-group-stats-value"});
var u=z.append("g").attr({transform:"translate(314, 54)"});
u.append("text").attr({width:25,height:10,x:4,y:17,"class":"process-group-stats-info"}).text("(5 min)");
u.append("text").attr({width:25,height:10,x:4,y:30,"class":"process-group-stats-info"}).text("(5 min)");
u.append("text").attr({width:25,height:10,x:4,y:43,"class":"process-group-stats-info"}).text("(5 min)");
z.append("text").attr({x:10,y:118,width:342,height:22,"class":"process-group-comments"});
z.append("rect").attr({"class":"active-thread-count-background",height:13,y:2,fill:"#fff","fill-opacity":"0.65",stroke:"#aaa","stroke-width":"1"});
z.append("text").attr({"class":"active-thread-count",height:13,y:12,fill:"#000"});
z.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"bulletin-icon","xlink:href":"images/iconBulletin.png",width:12,height:12,y:2})
}var q=z.select("text.process-group-input-port-count").text(function(G){return G.component.inputPortCount
});
var v=z.select("image.process-group-output-port").attr("x",function(){var G=parseInt(q.attr("x"),10);
return G+q.node().getComputedTextLength()+e
});
z.select("text.process-group-output-port-count").attr("x",function(){var H=parseInt(v.attr("x"),10);
var G=parseInt(v.attr("width"),10);
return H+G+e
}).text(function(G){return G.component.outputPortCount
});
var x=z.select("rect.process-group-contents-container");
var A=z.select("text.process-group-disabled-count").text(function(G){return G.component.disabledCount
}).attr("x",function(){var G=parseInt(x.attr("x"),10);
var H=parseInt(x.attr("width"),10);
return G+H-this.getComputedTextLength()-e
});
var s=z.select("image.process-group-disabled").attr("x",function(){var H=parseInt(A.attr("x"),10);
var G=parseInt(d3.select(this).attr("width"),10);
return H-G-e
});
var w=z.select("text.process-group-invalid-count").text(function(G){return G.component.invalidCount
}).attr("x",function(){var G=parseInt(s.attr("x"),10);
return G-this.getComputedTextLength()-e
});
var B=z.select("image.process-group-invalid").attr("x",function(){var G=parseInt(w.attr("x"),10);
var H=parseInt(d3.select(this).attr("width"),10);
return G-H-e
});
var E=z.select("text.process-group-stopped-count").text(function(G){return G.component.stoppedCount
}).attr("x",function(){var G=parseInt(B.attr("x"),10);
return G-this.getComputedTextLength()-e
});
var r=z.select("image.process-group-stopped").attr("x",function(){var H=parseInt(E.attr("x"),10);
var G=parseInt(d3.select(this).attr("width"),10);
return H-G-e
});
var t=z.select("text.process-group-running-count").text(function(G){return G.component.runningCount
}).attr("x",function(){var G=parseInt(r.attr("x"),10);
return G-this.getComputedTextLength()-e
});
var p=z.select("image.process-group-running").attr("x",function(){var H=parseInt(t.attr("x"),10);
var G=parseInt(d3.select(this).attr("width"),10);
return H-G-e
});
var D=z.select("text.process-group-not-transmitting-count").text(function(G){return G.component.inactiveRemotePortCount
}).attr("x",function(){var G=parseInt(p.attr("x"),10);
return G-this.getComputedTextLength()-e
});
var n=z.select("image.process-group-not-transmitting").attr("x",function(){var H=parseInt(D.attr("x"),10);
var G=parseInt(d3.select(this).attr("width"),10);
return H-G-e
});
var F=z.select("text.process-group-transmitting-count").text(function(G){return G.component.activeRemotePortCount
}).attr("x",function(){var G=parseInt(n.attr("x"),10);
return G-this.getComputedTextLength()-e
});
z.select("image.process-group-transmitting").attr("x",function(){var H=parseInt(F.attr("x"),10);
var G=parseInt(d3.select(this).attr("width"),10);
return H-G-e
});
z.select("text.process-group-comments").each(function(H){var G=d3.select(this);
G.text(null).selectAll("tspan, title").remove();
nf.CanvasUtils.multilineEllipsis(G,2,i(H))
}).classed("unset",function(G){return nf.Common.isBlank(G.component.comments)
}).append("title").text(function(G){return i(G)
});
C.select("text.process-group-name").each(function(H){var G=d3.select(this);
G.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(G,H.component.name)
}).append("title").text(function(G){return G.component.name
});
C.select("image.process-group-preview").style("display","none");
C.call(d)
}else{C.select("text.process-group-name").text(function(H){var G=H.component.name;
if(G.length>l){return G.substring(0,l)+String.fromCharCode(8230)
}else{return G
}});
C.select("image.process-group-preview").style("display","block");
C.call(k);
if(!z.empty()){z.remove()
}}})
};
var d=function(m){if(m.empty()){return
}m.select("text.process-group-queued").text(function(n){if(nf.Common.isDefinedAndNotNull(n.status)){return n.status.queued
}else{return"- / -"
}});
m.select("text.process-group-in").text(function(n){if(nf.Common.isDefinedAndNotNull(n.status)){return n.status.input
}else{return"- / -"
}});
m.select("text.process-group-read-write").text(function(n){if(nf.Common.isDefinedAndNotNull(n.status)){return n.status.read+" / "+n.status.written
}else{return"- / -"
}});
m.select("text.process-group-out").text(function(n){if(nf.Common.isDefinedAndNotNull(n.status)){return n.status.output
}else{return"- / -"
}});
m.each(function(p){var n=d3.select(this);
var o=0;
nf.CanvasUtils.activeThreadCount(n,p,function(q){o=q
});
nf.CanvasUtils.bulletins(n,p,function(){return d3.select("#process-group-tooltips")
},o)
})
};
var b=function(m){if(m.empty()){return
}m.call(k).remove()
};
var k=function(m){m.each(function(n){$("#bulletin-tip-"+n.component.id).remove()
})
};
return{init:function(){g=d3.map();
f=d3.select("#canvas").append("g").attr({"pointer-events":"all","class":"process-groups"})
},add:function(m,n){n=nf.Common.isDefinedAndNotNull(n)?n:false;
var o=function(p){g.set(p.id,{type:"ProcessGroup",component:p,dimensions:a})
};
if($.isArray(m)){$.each(m,function(p,q){o(q)
})
}else{o(m)
}j().enter().call(h,n)
},get:function(m){if(nf.Common.isUndefined(m)){return g.values()
}else{return g.get(m)
}},refresh:function(m){if(nf.Common.isDefinedAndNotNull(m)){d3.select("#id-"+m).call(c)
}else{d3.selectAll("g.process-group").call(c)
}},pan:function(){d3.selectAll("g.process-group.entering, g.process-group.leaving").call(c)
},reload:function(m){if(g.has(m.id)){return $.ajax({type:"GET",url:m.uri,dataType:"json"}).done(function(n){nf.ProcessGroup.set(n.processGroup)
})
}},position:function(m){d3.select("#id-"+m).call(nf.CanvasUtils.position)
},set:function(m){var n=function(o){if(g.has(o.id)){var p=g.get(o.id);
p.component=o;
d3.select("#id-"+o.id).call(c)
}};
if($.isArray(m)){$.each(m,function(o,p){n(p)
})
}else{n(m)
}},setStatus:function(m){if(nf.Common.isEmpty(m)){return
}$.each(m,function(o,n){if(g.has(n.id)){var p=g.get(n.id);
p.status=n
}});
d3.selectAll("g.process-group.visible").call(d)
},remove:function(m){if($.isArray(m)){$.each(m,function(n,o){g.remove(o)
})
}else{g.remove(m)
}j().exit().call(b)
},removeAll:function(){nf.ProcessGroup.remove(g.keys())
}}
}());