nf.ProcessorConfiguration=(function(){var i=[0,25,50,100,250,500,1000,2000];
var h=function(j){var k=[{text:"Timer driven",value:"TIMER_DRIVEN",description:"Processor will be scheduled to run on an interval defined by the run schedule."}];
if(j.supportsEventDriven===true){k.push({text:"Event driven",value:"EVENT_DRIVEN",description:"Processor will be scheduled to run when triggered by an event (e.g. a FlowFile enters an incoming queue). This scheduling strategy is experimental."})
}else{if(j.config.schedulingStrategy==="EVENT_DRIVEN"){k.push({text:"Event driven",value:"EVENT_DRIVEN",description:"Processor will be scheduled to run when triggered by an event (e.g. a FlowFile enters an incoming queue). This scheduling strategy is experimental.",disabled:true})
}}if(nf.Canvas.isClustered()){k.push({text:"On primary node",value:"PRIMARY_NODE_ONLY",description:"Processor will be scheduled on the primary node on an interval defined by the run schedule."})
}else{if(j.config.schedulingStrategy==="PRIMARY_NODE_ONLY"){k.push({text:"On primary node",value:"PRIMARY_NODE_ONLY",description:"Processor will be scheduled on the primary node on an interval defined by the run schedule.",disabled:true})
}}k.push({text:"CRON driven",value:"CRON_DRIVEN",description:"Processor will be scheduled to run on at specific times based on the specified CRON string."});
return k
};
var b=function(m,j,k){if(m.status===400){var n=m.responseText.split("\n");
var l;
if(n.length===1){l=$("<span></span>").text(n[0])
}else{l=nf.Common.formatUnorderedList(n)
}nf.Dialog.showOkDialog({dialogContent:l,overlayBackground:false,headerText:"Configuration Error"})
}else{nf.Common.handleAjaxError(m,j,k)
}};
var g=function(o){var j=$('<div class="relationship-name ellipsis"></div>').text(o.name);
var l=$('<span class="relationship-name-value hidden"></span>').text(o.name);
var m=$('<div class="processor-relationship nf-checkbox"></div>');
if(o.autoTerminate===true){m.addClass("checkbox-checked")
}else{m.addClass("checkbox-unchecked")
}var n=$('<div class="processor-relationship-container"></div>').append(m).append(j).append(l).appendTo("#auto-terminate-relationship-names");
if(!nf.Common.isBlank(o.description)){var k=$('<div class="relationship-description"></div>').text(o.description);
n.append(k)
}return n
};
var d=function(){var l=$("#processor-configuration").data("processorDetails");
var m=false;
var n=f();
$.each(l.relationships,function(p,q){if(q.autoTerminate===true){if($.inArray(q.name,n)===-1){m=true;
return false
}}else{if(q.autoTerminate===false){if($.inArray(q.name,n)>=0){m=true;
return false
}}}});
if(m){return true
}var o=$("#scheduling-strategy-combo").combo("getSelectedOption").value;
if(o!==(l.config.schedulingStrategy+"")){return true
}if(l.supportsParallelProcessing===true){var j;
if(o==="EVENT_DRIVEN"){j=$("#event-driven-concurrently-schedulable-tasks")
}else{if(o==="CRON_DRIVEN"){j=$("#cron-driven-concurrently-schedulable-tasks")
}else{j=$("#timer-driven-concurrently-schedulable-tasks")
}}if(j.val()!==(l.config.concurrentlySchedulableTaskCount+"")){return true
}}var k;
if(o==="CRON_DRIVEN"){k=$("#cron-driven-scheduling-period")
}else{if(o!=="EVENT_DRIVEN"){k=$("#timer-driven-scheduling-period")
}}if(nf.Common.isDefinedAndNotNull(k)&&k.val()!==(l.config.schedulingPeriod+"")){return true
}if($("#processor-name").val()!==l.name){return true
}if($("#processor-enabled").hasClass("checkbox-checked")&&l.state==="DISABLED"){return true
}else{if($("#processor-enabled").hasClass("checkbox-unchecked")&&(l.state==="RUNNING"||l.state==="STOPPED")){return true
}}if($("#penalty-duration").val()!==(l.config.penaltyDuration+"")){return true
}if($("#yield-duration").val()!==(l.config.yieldDuration+"")){return true
}if($("#bulletin-level-combo").combo("getSelectedOption").value!==(l.config.bulletinLevel+"")){return true
}if($("#processor-comments").val()!==l.config.comments){return true
}return nf.ProcessorPropertyTable.isSaveRequired()
};
var c=function(){var l={};
var p=$("#scheduling-strategy-combo").combo("getSelectedOption").value;
var j;
if(p==="EVENT_DRIVEN"){j=$("#event-driven-concurrently-schedulable-tasks")
}else{if(p==="CRON_DRIVEN"){j=$("#cron-driven-concurrently-schedulable-tasks")
}else{j=$("#timer-driven-concurrently-schedulable-tasks")
}}if(!j.is(":disabled")){l.concurrentlySchedulableTaskCount=j.val()
}var k;
if(p==="CRON_DRIVEN"){k=$("#cron-driven-scheduling-period")
}else{if(p!=="EVENT_DRIVEN"){k=$("#timer-driven-scheduling-period")
}}if(nf.Common.isDefinedAndNotNull(k)){l.schedulingPeriod=k.val()
}l.penaltyDuration=$("#penalty-duration").val();
l.yieldDuration=$("#yield-duration").val();
l.bulletinLevel=$("#bulletin-level-combo").combo("getSelectedOption").value;
l.schedulingStrategy=p;
l.comments=$("#processor-comments").val();
var n=$("#run-duration-slider").slider("value");
l.runDurationMillis=i[n];
l.autoTerminatedRelationships=f();
var m=nf.ProcessorPropertyTable.marshalProperties();
if($.isEmptyObject(m)===false){l.properties=m
}var q={};
q.id=$("#processor-id").text();
q.name=$("#processor-name").val();
q.config=l;
if($("#processor-enabled").hasClass("checkbox-unchecked")){q.state="DISABLED"
}else{if($("#processor-enabled").hasClass("checkbox-checked")){q.state="STOPPED"
}}var o={};
o.revision=nf.Client.getRevision();
o.processor=q;
return o
};
var f=function(){var k=$("#auto-terminate-relationship-names");
var j=[];
$.each(k.children(),function(l,o){var n=$(o);
var m=n.children("div.processor-relationship");
if(m.hasClass("checkbox-checked")){j.push(n.children("span.relationship-name-value").text())
}});
return j
};
var a=function(k){var m=[];
var l=k.processor;
var j=l.config;
if(nf.Common.isDefinedAndNotNull(j.concurrentlySchedulableTaskCount)&&!$.isNumeric(j.concurrentlySchedulableTaskCount)){m.push("Concurrent tasks must be an integer value")
}if(nf.Common.isDefinedAndNotNull(j.schedulingPeriod)&&nf.Common.isBlank(j.schedulingPeriod)){m.push("Run schedule must be specified")
}if(nf.Common.isBlank(j.penaltyDuration)){m.push("Penalty duration must be specified")
}if(nf.Common.isBlank(j.yieldDuration)){m.push("Yield duration must be specified")
}if(m.length>0){nf.Dialog.showOkDialog({dialogContent:nf.Common.formatUnorderedList(m),overlayBackground:false,headerText:"Configuration Error"});
return false
}else{return true
}};
var e=function(k){var j=nf.Connection.getComponentConnections(k.id);
$.each(j,function(m,l){if(l.source.id===k.id){nf.Connection.reload(l)
}})
};
return{init:function(){$("#processor-configuration-tabs").tabbs({tabStyle:"tab",selectedTabStyle:"selected-tab",tabs:[{name:"Settings",tabContentId:"configuration-standard-settings-tab-content"},{name:"Scheduling",tabContentId:"configuration-scheduling-tab-content"},{name:"Properties",tabContentId:"configuration-processor-properties-tab-content"},{name:"Comments",tabContentId:"configuration-comments-tab-content"}],select:function(){if($(this).text()==="Properties"){nf.ProcessorPropertyTable.resetTableSize()
}nf.ProcessorPropertyTable.saveRow();
var j=$("#auto-terminate-relationship-names");
if(j.is(":visible")&&j.get(0).scrollHeight>j.innerHeight()){j.css("border-width","1px")
}}});
$("#processor-configuration").modal({headerText:"Configure Processor",overlayBackground:true,handler:{close:function(){$("#auto-terminate-relationship-names").css("border-width","0").empty();
$("#processor-property-dialog").hide();
nf.ProcessorPropertyTable.cancelEdit();
nf.ProcessorPropertyTable.clear();
$("#processor-configuration").removeData("processorDetails");
$("#processor-configuration").removeData("processorHistory")
}}}).draggable({containment:"parent",handle:".dialog-header"});
$("#bulletin-level-combo").combo({options:[{text:"DEBUG",value:"DEBUG"},{text:"INFO",value:"INFO"},{text:"WARN",value:"WARN"},{text:"ERROR",value:"ERROR"}]});
$("#run-duration-slider").slider({min:0,max:i.length-1});
nf.ProcessorPropertyTable.init()
},showConfiguration:function(p){if(nf.CanvasUtils.isProcessor(p)){var o=p.datum();
var j=o.component;
$("#processor-configuration").data("processorDetails",j);
var l="checkbox-checked";
if(j.state==="DISABLED"){l="checkbox-unchecked"
}$("#processor-id").text(j.id);
$("#processor-type").text(nf.Common.substringAfterLast(j.type,"."));
$("#processor-name").val(j.name);
$("#processor-enabled").removeClass("checkbox-unchecked checkbox-checked").addClass(l);
$("#penalty-duration").val(j.config.penaltyDuration);
$("#yield-duration").val(j.config.yieldDuration);
$("#processor-comments").val(j.config.comments);
var q=i.indexOf(j.config.runDurationMillis);
$("#run-duration-slider").slider("value",q);
$("#bulletin-level-combo").combo("setSelectedOption",{value:j.config.bulletinLevel});
$("#scheduling-strategy-combo").combo({options:h(j),selectedOption:{value:j.config.schedulingStrategy},select:function(s){if(s.value==="EVENT_DRIVEN"){$("#event-driven-warning").show();
$("#timer-driven-options").hide();
$("#event-driven-options").show();
$("#cron-driven-options").hide()
}else{$("#event-driven-warning").hide();
if(s.value==="CRON_DRIVEN"){$("#timer-driven-options").hide();
$("#event-driven-options").hide();
$("#cron-driven-options").show()
}else{$("#timer-driven-options").show();
$("#event-driven-options").hide();
$("#cron-driven-options").hide()
}}}});
var r=j.config.defaultConcurrentTasks;
$("#timer-driven-concurrently-schedulable-tasks").val(r.TIMER_DRIVEN);
$("#event-driven-concurrently-schedulable-tasks").val(r.EVENT_DRIVEN);
$("#cron-driven-concurrently-schedulable-tasks").val(r.CRON_DRIVEN);
var n;
if(j.config.schedulingStrategy==="EVENT_DRIVEN"){n=$("#event-driven-concurrently-schedulable-tasks").val(j.config.concurrentlySchedulableTaskCount)
}else{if(j.config.schedulingStrategy==="CRON_DRIVEN"){n=$("#cron-driven-concurrently-schedulable-tasks").val(j.config.concurrentlySchedulableTaskCount)
}else{n=$("#timer-driven-concurrently-schedulable-tasks").val(j.config.concurrentlySchedulableTaskCount)
}}if(nf.Common.isDefinedAndNotNull(n)){if(j.supportsParallelProcessing===true){n.prop("disabled",false)
}else{n.prop("disabled",true)
}}var k=j.config.defaultSchedulingPeriod;
$("#cron-driven-scheduling-period").val(k.CRON_DRIVEN);
$("#timer-driven-scheduling-period").val(k.TIMER_DRIVEN);
if(j.config.schedulingStrategy==="CRON_DRIVEN"){$("#cron-driven-scheduling-period").val(j.config.schedulingPeriod)
}else{if(j.config.schedulingStrategy!=="EVENT_DRIVEN"){$("#timer-driven-scheduling-period").val(j.config.schedulingPeriod)
}}nf.ProcessorPropertyTable.loadProperties(j.config.properties,j.config.descriptors);
if(!nf.Common.isEmpty(j.relationships)){$.each(j.relationships,function(s,t){g(t)
})
}else{$("#auto-terminate-relationship-names").append('<div class="unset">This processor has no relationships.</div>')
}var m=[{buttonText:"Apply",handler:{click:function(){nf.ProcessorPropertyTable.saveRow();
var s=c();
if(a(s)){$.ajax({type:"PUT",data:JSON.stringify(s),url:j.uri,dataType:"json",processData:false,contentType:"application/json"}).done(function(t){if(nf.Common.isDefinedAndNotNull(t.processor)){nf.Client.setRevision(t.revision);
nf.Processor.set(t.processor);
e(j);
$("#processor-configuration").modal("hide")
}}).fail(b)
}}}},{buttonText:"Cancel",handler:{click:function(){$("#processor-configuration").modal("hide")
}}}];
if(nf.Common.isDefinedAndNotNull(j.config.customUiUrl)&&j.config.customUiUrl!==""){m.push({buttonText:"Advanced",handler:{click:function(){var s=function(){$("#processor-configuration").modal("hide");
nf.CustomProcessorUi.showCustomUi($("#processor-id").text(),j.config.customUiUrl,true).done(function(){nf.Processor.reload(j);
e(j)
})
};
nf.ProcessorPropertyTable.saveRow();
if(d()){nf.Dialog.showYesNoDialog({dialogContent:"Save changes before opening the advanced configuration?",overlayBackground:false,noHandler:s,yesHandler:function(){var t=c();
if(a(t)){$.ajax({type:"PUT",data:JSON.stringify(t),url:j.uri,dataType:"json",processData:false,contentType:"application/json"}).done(function(u){if(nf.Common.isDefinedAndNotNull(u.processor)){nf.Client.setRevision(u.revision);
s()
}}).fail(b)
}}})
}else{s()
}}}})
}$("#processor-configuration").modal("setButtonModel",m);
$.ajax({type:"GET",url:"../nifi-api/controller/history/processors/"+encodeURIComponent(j.id),dataType:"json"}).done(function(s){var t=s.processorHistory;
$("#processor-configuration").data("processorHistory",t);
$("#processor-configuration").modal("show");
$("#processor-configuration div.relationship-name").ellipsis();
var u=$("#auto-terminate-relationship-names");
if(u.is(":visible")&&u.get(0).scrollHeight>u.innerHeight()){u.css("border-width","1px")
}}).fail(nf.Common.handleAjaxError)
}}}
}());