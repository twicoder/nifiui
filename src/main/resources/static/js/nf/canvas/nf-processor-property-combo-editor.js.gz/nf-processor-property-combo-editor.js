nf.ProcessorPropertyComboEditor=function(b){var c=this;
var a=null;
var e;
var d;
this.init=function(){var h=$("body");
e=$("<div></div>").css({"z-index":1999,position:"absolute",background:"white",padding:"5px",overflow:"hidden",border:"3px solid #365C6A","box-shadow":"4px 4px 6px rgba(0, 0, 0, 0.9)",cursor:"move"}).draggable({cancel:".button, .combo",containment:"parent"}).appendTo(h);
var g=$("#processor-configuration").data("processorDetails");
var j=g.config.descriptors[b.item.property];
var l=nf.ProcessorPropertyTable.getAllowableValues(j);
var i=[];
if(j.required===false){i.push({text:"No value",optionClass:"unset"})
}if($.isArray(l)){$.each(l,function(o,n){i.push({text:n.displayName,value:n.value,description:nf.Common.escapeHtml(n.description)})
})
}if(i.length===0){i.push({text:"No value",optionClass:"unset",disabled:true})
}var f=b.position;
var m=$(window).height();
var k=m-f.bottom-16;
d=$('<div class="value-combo combo"></div>').combo({options:i,maxHeight:k}).width(f.width-16).appendTo(e);
$('<div class="button button-normal">Cancel</div>').css({margin:"0 0 0 5px","float":"left"}).on("click",c.cancel).appendTo(e);
$('<div class="button button-normal">Ok</div>').css({margin:"0 0 0 5px","float":"left"}).on("click",c.save).appendTo(e);
c.position(f)
};
this.save=function(){b.commitChanges()
};
this.cancel=function(){b.cancelChanges()
};
this.hide=function(){e.hide()
};
this.show=function(){e.show()
};
this.position=function(f){e.css({top:f.top-5,left:f.left-5})
};
this.destroy=function(){e.remove()
};
this.focus=function(){};
this.loadValue=function(h){var f=$("#processor-configuration").data("processorDetails");
var g=f.config.descriptors[h.property];
if(nf.Common.isDefinedAndNotNull(h.value)){a=h.value;
d.combo("setSelectedOption",{value:h.value})
}else{if(nf.Common.isDefinedAndNotNull(g.defaultValue)){a=g.defaultValue;
d.combo("setSelectedOption",{value:g.defaultValue})
}}};
this.serializeValue=function(){var f=d.combo("getSelectedOption");
return f.value
};
this.applyValue=function(f,g){f[b.column.field]=g
};
this.isValueChanged=function(){var f=d.combo("getSelectedOption");
return(!(f.value===""&&a===null))&&(f.value!==a)
};
this.validate=function(){return{valid:true,msg:null}
};
this.init()
};