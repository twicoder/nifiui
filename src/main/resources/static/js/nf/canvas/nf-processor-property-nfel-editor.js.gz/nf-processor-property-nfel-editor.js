nf.ProcessorPropertyNfelEditor=function(d){var f=this;
var a="";
var b;
var c;
var g;
var h;
var e;
this.init=function(){var l=$("body");
var o=$("#processor-configuration").data("processorDetails");
c=o.config.descriptors[d.item.property];
var k=nf.ProcessorPropertyTable.isSensitiveProperty(c);
b=d.item[d.column.field];
var n="nfel";
var j=n+"-editor";
h=$("<div></div>").addClass("slickgrid-nfel-editor").css({"z-index":14000,position:"absolute",background:"white",padding:"5px",overflow:"hidden",border:"3px solid #365C6A","box-shadow":"4px 4px 6px rgba(0, 0, 0, 0.9)",cursor:"move"}).draggable({cancel:"input, textarea, pre, .nf-checkbox, .button, ."+j,containment:"parent"}).appendTo(l);
e=$("<div></div>").addClass(j).appendTo(h).nfeditor({languageId:n,width:d.position.width,minWidth:175,minHeight:100,resizable:true,sensitive:k,escape:function(){f.cancel()
},enter:function(){f.save()
}});
var i=$('<div class="string-check-container">');
g=$('<div class="nf-checkbox string-check"/>').appendTo(i);
$('<span class="string-check-label">&nbsp;Empty</span>').appendTo(i);
var m=$('<div class="button button-normal">Ok</div>').on("click",f.save);
var p=$('<div class="button button-normal">Cancel</div>').on("click",f.cancel);
$("<div></div>").css({position:"absolute",bottom:"0",left:"0",right:"0",padding:"0 3px 5px 1px"}).append(i).append(m).append(p).append('<div class="clear"></div>').appendTo(h);
f.position(d.position);
e.nfeditor("focus").nfeditor("selectAll")
};
this.save=function(){d.commitChanges()
};
this.cancel=function(){e.nfeditor("setValue",a);
d.cancelChanges()
};
this.hide=function(){h.hide()
};
this.show=function(){h.show();
e.nfeditor("setSize",d.position.width,null).nfeditor("refresh")
};
this.position=function(i){h.css({top:i.top-5,left:i.left-5})
};
this.destroy=function(){e.nfeditor("destroy");
h.remove()
};
this.focus=function(){e.nfeditor("focus")
};
this.loadValue=function(k){var l=false;
var i=nf.ProcessorPropertyTable.isSensitiveProperty(c);
if(nf.Common.isDefinedAndNotNull(k[d.column.field])){if(i){a=nf.ProcessorPropertyTable.config.sensitiveText
}else{a=k[d.column.field];
l=a===""
}}var j=l?"checkbox-checked":"checkbox-unchecked";
g.addClass(j);
e.nfeditor("setValue",a).nfeditor("selectAll")
};
this.serializeValue=function(){var i=e.nfeditor("getValue");
if(i===""){if(g.hasClass("checkbox-checked")){return""
}else{if(nf.ProcessorPropertyTable.isRequiredProperty(c)){if(nf.Common.isBlank(c.defaultValue)){return b
}else{return c.defaultValue
}}else{return null
}}}else{if(e.nfeditor("isModified")===false){return b
}else{return i
}}};
this.applyValue=function(i,j){i[d.column.field]=j
};
this.isValueChanged=function(){return f.serializeValue()!==b
};
this.validate=function(){return{valid:true,msg:null}
};
this.init()
};