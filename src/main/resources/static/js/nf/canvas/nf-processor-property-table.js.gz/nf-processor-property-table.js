nf.ProcessorPropertyTable=(function(){var c=function(){var e="nfel";
var d=e+"-editor";
nf.Common.addHoverEffect("#add-property-icon","add-icon-bg","add-icon-bg-hover");
var g=function(){var i=$.trim($("#new-property-name").val());
var h=$("#new-property-value").nfeditor("getValue");
if(i!==""){var j=$("#processor-properties").data("gridInstance");
var k=j.getData();
k.addItem({id:k.getLength(),hidden:false,property:i,displayName:i,previousValue:null,value:h,type:"userDefined"})
}else{nf.Dialog.showOkDialog({dialogContent:"Property name must be specified.",overlayBackground:false})
}$("#processor-property-dialog").hide()
};
var f=function(){$("#processor-property-dialog").hide()
};
$("#new-property-value").addClass(d).nfeditor({languageId:e,width:318,minWidth:318,height:106,minHeight:106,resizable:true,escape:f,enter:g});
$("#add-property-icon").on("click",function(){nf.ProcessorPropertyTable.saveRow();
$("#new-property-name").val("");
$("#new-property-value").nfeditor("setValue","");
$("#new-property-value").nfeditor("setSize",318,106);
$("#processor-property-dialog").center().show();
$("#new-property-value").nfeditor("refresh");
$("#new-property-name").focus()
});
$("#processor-property-dialog").draggable({cancel:"input, textarea, pre, .button, ."+d,containment:"parent"}).on("click","#new-property-ok",g).on("click","#new-property-cancel",f);
$("#new-property-name").on("keydown",function(h){if(h.which===$.ui.keyCode.ENTER&&!h.shiftKey){g()
}else{if(h.which===$.ui.keyCode.ESCAPE){h.preventDefault();
f()
}}})
};
var b=function(){var i=function(t,s,r,o,m){var q=10;
var l=$("<div></div>");
var n=$("<span/>").addClass("table-cell").text(r).appendTo(l);
if(m.type==="required"){n.addClass("required")
}var k=$("#processor-configuration").data("processorDetails");
var p=k.config.descriptors[m.property];
if(nf.Common.isDefinedAndNotNull(p)){if(!nf.Common.isBlank(p.description)||!nf.Common.isBlank(p.defaultValue)||!nf.Common.isBlank(p.supportsEl)){$('<img class="icon-info" src="images/iconInfo.png" alt="Info" title="" style="float: right; margin-right: 6px; margin-top: 4px;" />').appendTo(l);
$('<span class="hidden property-descriptor-name"></span>').text(m.property).appendTo(l);
q=26
}}n.width(o.width-q).ellipsis();
return l.html()
};
var d=function(t,s,r,n,l){var q;
if(nf.Common.isDefinedAndNotNull(r)){var k=$("#processor-configuration").data("processorDetails");
var p=k.config.descriptors[l.property];
if(nf.ProcessorPropertyTable.isSensitiveProperty(p)){q='<span class="table-cell sensitive">Sensitive value set</span>'
}else{var m=nf.ProcessorPropertyTable.getAllowableValues(p);
if($.isArray(m)){$.each(m,function(u,v){if(r===v.value){r=v.displayName;
return false
}})
}if(r===""){q='<span class="table-cell blank">Empty string set</span>'
}else{q='<div class="table-cell value"><pre class="ellipsis">'+nf.Common.escapeHtml(r)+"</pre></div>"
}}}else{q='<span class="unset">No value set</span>'
}var o=$(q);
if(l.type==="required"){o.addClass("required")
}o.find(".ellipsis").width(n.width-10).ellipsis();
return $("<div/>").append(o).html()
};
var h=function(p,l,o,n,k){var m="";
if(k.type==="userDefined"){m='<img src="images/iconDelete.png" title="Delete" class="pointer" style="margin-top: 2px" onclick="javascript:nf.ProcessorPropertyTable.deleteProperty(\''+p+"');\"/>"
}return m
};
var g=[{id:"property",field:"displayName",name:"Property",sortable:false,resizable:true,rerenderOnResize:true,formatter:i},{id:"value",field:"value",name:"Value",sortable:false,resizable:true,cssClass:"pointer",rerenderOnResize:true,formatter:d},{id:"actions",name:"&nbsp;",minWidth:20,width:20,formatter:h}];
var e={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,editable:true,enableAddRow:false,autoEdit:false};
var j=new Slick.Data.DataView({inlineFilters:false});
j.setItems([]);
j.setFilterArgs({searchString:"",property:"hidden"});
j.setFilter(a);
j.getItemMetadata=function(m){var n=j.getItem(m);
var k=$("#processor-configuration").data("processorDetails");
var l=k.config.descriptors[n.property];
if(nf.Common.isUndefinedOrNull(l)||nf.ProcessorPropertyTable.supportsEl(l)){return{columns:{value:{editor:nf.ProcessorPropertyNfelEditor}}}
}else{var o=nf.ProcessorPropertyTable.getAllowableValues(l);
if($.isArray(o)){return{columns:{value:{editor:nf.ProcessorPropertyComboEditor}}}
}else{return{columns:{value:{editor:nf.ProcessorPropertyTextEditor}}}
}}};
var f=new Slick.Grid("#processor-properties",j,g,e);
f.setSelectionModel(new Slick.RowSelectionModel());
f.onClick.subscribe(function(l,k){f.gotoCell(k.row,k.cell,true);
l.stopImmediatePropagation()
});
j.onRowCountChanged.subscribe(function(l,k){f.updateRowCount();
f.render()
});
j.onRowsChanged.subscribe(function(l,k){f.invalidateRows(k.rows);
f.render()
});
$("#processor-properties").data("gridInstance",f).on("mouseenter","div.slick-cell",function(r){var n=$(this).find("img.icon-info");
if(n.length&&!n.data("qtip")){var q=$(this).find("span.property-descriptor-name").text();
var m=$("#processor-configuration").data("processorDetails");
var k=m.config.descriptors[q];
var l=$("#processor-configuration").data("processorHistory");
var o=l.propertyHistory[q];
var p=nf.Common.formatPropertyTooltip(k,o);
if(nf.Common.isDefinedAndNotNull(p)){n.qtip($.extend({content:p},nf.Common.config.tooltipConfig))
}}})
};
var a=function(e,d){return e.hidden===false
};
return{config:{sensitiveText:"Sensitive value set"},init:function(){c();
b()
},isSensitiveProperty:function(d){if(nf.Common.isDefinedAndNotNull(d)){return d.sensitive===true
}else{return false
}},isRequiredProperty:function(d){if(nf.Common.isDefinedAndNotNull(d)){return d.required===true
}else{return false
}},isDynamicProperty:function(d){if(nf.Common.isDefinedAndNotNull(d)){return d.dynamic===true
}else{return false
}},getAllowableValues:function(d){if(nf.Common.isDefinedAndNotNull(d)){return d.allowableValues
}else{return null
}},supportsEl:function(d){if(nf.Common.isDefinedAndNotNull(d)){return d.supportsEl===true
}else{return false
}},saveRow:function(){var e=$("#processor-properties").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(e)){var d=e.getEditController();
d.commitCurrentEdit()
}},cancelEdit:function(){var e=$("#processor-properties").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(e)){var d=e.getEditController();
d.cancelCurrentEdit()
}},deleteProperty:function(g){var d=$("#processor-properties").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(d)){var e=d.getData();
var f=e.getItem(g);
f.hidden=true;
e.updateItem(f.id,f)
}},resetTableSize:function(){var d=$("#processor-properties").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(d)){d.resizeCanvas()
}},loadProperties:function(f,g){var d=$("#processor-properties").data("gridInstance");
var h=d.getData();
if(nf.Common.isDefinedAndNotNull(f)){h.beginUpdate();
var e=0;
$.each(f,function(j,l){var m=g[j];
var k="userDefined";
var i=j;
if(nf.Common.isDefinedAndNotNull(m)){if(nf.ProcessorPropertyTable.isRequiredProperty(m)){k="required"
}else{if(nf.ProcessorPropertyTable.isDynamicProperty(m)){k="userDefined"
}else{k="optional"
}}i=m.displayName;
if(nf.Common.isNull(l)&&nf.Common.isDefinedAndNotNull(m.defaultValue)){l=m.defaultValue
}}h.addItem({id:e++,hidden:false,property:j,displayName:i,previousValue:l,value:l,type:k})
});
h.endUpdate()
}},isSaveRequired:function(){var d=$("#processor-properties").data("gridInstance");
var e=d.getData();
var f=false;
$.each(e.getItems(),function(){if(this.value!==this.previousValue){f=true;
return false
}});
return f
},marshalProperties:function(){var e={};
var d=$("#processor-properties").data("gridInstance");
var f=d.getData();
$.each(f.getItems(),function(){if(this.hidden===true){e[this.property]=null
}else{if(this.value!==this.previousValue){e[this.property]=this.value
}}});
return e
},clear:function(){var d=$("#processor-properties");
nf.Common.cleanUpTooltips(d,"img.icon-info");
var e=d.data("gridInstance");
var f=e.getData();
f.setItems([])
}}
}());