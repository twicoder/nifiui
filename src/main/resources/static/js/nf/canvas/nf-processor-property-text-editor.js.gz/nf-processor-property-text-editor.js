nf.ProcessorPropertyTextEditor=function(e){var f=this;
var a="";
var b;
var d;
var h;
var g;
var c;
this.init=function(){var j=$("body");
var l=$("#processor-configuration").data("processorDetails");
d=l.config.descriptors[e.item.property];
b=e.item[e.column.field];
h=$("<div></div>").css({"z-index":100000,position:"absolute",background:"white",padding:"5px",overflow:"hidden",border:"3px solid #365C6A","box-shadow":"4px 4px 6px rgba(0, 0, 0, 0.9)",cursor:"move"}).draggable({cancel:".button, textarea, .nf-checkbox",containment:"parent"}).appendTo(j);
c=$('<textarea hidefocus rows="5"/>').css({background:"white",width:e.position.width+"px","min-width":"150px",height:"80px","border-width":"0",outline:"0","overflow-y":"auto",resize:"both","margin-bottom":"28px"}).tab().on("keydown",f.handleKeyDown).appendTo(h);
var i=$('<div class="string-check-container">');
g=$('<div class="nf-checkbox string-check"/>').appendTo(i);
$('<span class="string-check-label">&nbsp;Empty</span>').appendTo(i);
var k=$('<div class="button button-normal">Ok</div>').on("click",f.save);
var m=$('<div class="button button-normal">Cancel</div>').on("click",f.cancel);
$("<div></div>").css({position:"absolute",bottom:"0",left:"0",right:"0",padding:"0 3px 5px"}).append(i).append(k).append(m).append('<div class="clear"></div>').appendTo(h);
f.position(e.position);
c.focus().select()
};
this.handleKeyDown=function(i){if(i.which===$.ui.keyCode.ENTER&&!i.shiftKey){f.save()
}else{if(i.which===$.ui.keyCode.ESCAPE){i.preventDefault();
f.cancel()
}}};
this.save=function(){e.commitChanges()
};
this.cancel=function(){c.val(a);
e.cancelChanges()
};
this.hide=function(){h.hide()
};
this.show=function(){h.show()
};
this.position=function(i){h.css({top:i.top-5,left:i.left-5})
};
this.destroy=function(){h.remove()
};
this.focus=function(){c.focus()
};
this.loadValue=function(k){var l=false;
var i=nf.ProcessorPropertyTable.isSensitiveProperty(d);
if(nf.Common.isDefinedAndNotNull(k[e.column.field])){if(i){a=nf.ProcessorPropertyTable.config.sensitiveText
}else{a=k[e.column.field];
l=a===""
}}var j=l?"checkbox-checked":"checkbox-unchecked";
g.addClass(j);
if(i){c.addClass("sensitive").keydown(function(){var m=$(this);
if(m.hasClass("sensitive")){m.removeClass("sensitive");
if(m.val()===nf.ProcessorPropertyTable.config.sensitiveText){m.val("")
}}})
}c.val(a);
c.select()
};
this.serializeValue=function(){if(c.val()===""){if(g.hasClass("checkbox-checked")){return""
}else{if(nf.ProcessorPropertyTable.isRequiredProperty(d)){if(nf.Common.isBlank(d.defaultValue)){return b
}else{return d.defaultValue
}}else{return null
}}}else{if(c.hasClass("sensitive")){return b
}else{return c.val()
}}};
this.applyValue=function(i,j){i[e.column.field]=j
};
this.isValueChanged=function(){return f.serializeValue()!==b
};
this.validate=function(){return{valid:true,msg:null}
};
this.init()
};