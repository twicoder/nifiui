nf.Processor=(function(){var h=25;
var a={width:310,height:100};
var i;
var b;
var f=function(){return b.selectAll("g.processor").data(i.values(),function(k){return k.component.id
})
};
var d=function(m,l){if(m.empty()){return
}var k=m.append("g").attr({id:function(n){return"id-"+n.component.id
},"class":"processor component"}).classed("selected",l).call(nf.CanvasUtils.position);
k.append("rect").attr({"class":"border",width:function(n){return n.dimensions.width
},height:function(n){return n.dimensions.height
},fill:"transparent","stroke-opacity":0.8,"stroke-width":1});
k.append("rect").attr({"class":"body",width:function(n){return n.dimensions.width
},height:function(n){return n.dimensions.height
},"fill-opacity":0.8,"stroke-opacity":0.8,"stroke-width":0});
k.append("text").attr({x:25,y:18,width:220,height:16,"font-size":"10pt","font-weight":"bold",fill:"black","class":"processor-name"});
k.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconProcessor.png",width:28,height:26,x:276,y:5});
k.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/bgProcessorStatArea.png",width:294,height:58,x:8,y:35,"class":"processor-stats-preview"});
k.call(nf.Selectable.activate).call(nf.ContextMenu.activate);
if(nf.Common.isDFM()){k.call(nf.Draggable.activate).call(nf.Connectable.activate)
}k.call(e)
};
var e=function(l){if(l.empty()){return
}l.each(function(){var p=d3.select(this);
var n=p.select("g.processor-details");
if(p.classed("visible")){if(n.empty()){n=p.append("g").attr("class","processor-details");
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"run-status-icon",width:16,height:16,x:5,y:5});
n.append("text").attr({x:25,y:30,width:246,height:16,"font-size":"8pt","font-weight":"normal",fill:"black"}).each(function(s){var r=d3.select(this);
r.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(r,nf.Common.substringAfterLast(s.component.type,"."))
}).append("title").text(function(r){return nf.Common.substringAfterLast(r.component.type,".")
});
n.append("rect").attr({width:294,height:59,x:8,y:35,fill:"#ffffff","stroke-width":1,stroke:"#6f97ac","stroke-opacity":0.8});
n.append("rect").attr({width:73,height:59,x:8,y:35,fill:"url(#processor-stats-background)","stroke-width":0});
var q=n.append("g").attr({transform:"translate(8, 45)"});
q.append("text").attr({width:73,height:10,x:4,y:4,"class":"processor-stats-label"}).text("In");
q.append("text").attr({width:73,height:10,x:4,y:17,"class":"processor-stats-label"}).text("Read/Write");
q.append("text").attr({width:73,height:10,x:4,y:30,"class":"processor-stats-label"}).text("Out");
q.append("text").attr({width:73,height:10,x:4,y:43,"class":"processor-stats-label"}).text("Tasks/Time");
var m=n.append("g").attr({transform:"translate(80, 45)"});
m.append("text").attr({width:180,height:10,x:4,y:4,"class":"processor-in processor-stats-value"});
m.append("text").attr({width:180,height:10,x:4,y:17,"class":"processor-read-write processor-stats-value"});
m.append("text").attr({width:180,height:10,x:4,y:30,"class":"processor-out processor-stats-value"});
m.append("text").attr({width:180,height:10,x:4,y:43,"class":"processor-tasks-time processor-stats-value"});
var o=n.append("g").attr("transform","translate(258, 45)");
o.append("text").attr({width:25,height:10,x:4,y:4,"class":"processor-stats-info"}).text("(5 min)");
o.append("text").attr({width:25,height:10,x:4,y:17,"class":"processor-stats-info"}).text("(5 min)");
o.append("text").attr({width:25,height:10,x:4,y:30,"class":"processor-stats-info"}).text("(5 min)");
o.append("text").attr({width:25,height:10,x:4,y:43,"class":"processor-stats-info"}).text("(5 min)");
n.append("rect").attr({"class":"active-thread-count-background",height:13,y:0,fill:"#fff","fill-opacity":"0.65",stroke:"#aaa","stroke-width":"1"});
n.append("text").attr({"class":"active-thread-count",height:13,y:10,fill:"#000"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"bulletin-icon","xlink:href":"images/iconBulletin.png",width:12,height:12,x:8,y:20})
}n.select("image.run-status-icon").attr("xlink:href",function(s){var r="";
if(s.component.state==="DISABLED"){r="images/iconDisable.png"
}else{if(!nf.Common.isEmpty(s.component.validationErrors)){r="images/iconAlert.png"
}else{if(s.component.state==="RUNNING"){r="images/iconRun.png"
}else{if(s.component.state==="STOPPED"){r="images/iconStop.png"
}}}}return r
}).each(function(s){var r=d3.select("#run-status-tip-"+s.component.id);
if(!r.empty()){r.remove()
}if(!nf.Common.isEmpty(s.component.validationErrors)){r=d3.select("#processor-tooltips").append("div").attr("id",function(){return"run-status-tip-"+s.component.id
}).attr("class","tooltip nifi-tooltip").html(function(){var t=nf.Common.formatUnorderedList(s.component.validationErrors);
if(t===null||t.length===0){return""
}else{return $("<div></div>").append(t).html()
}});
nf.CanvasUtils.canvasTooltip(r,d3.select(this))
}});
p.select("text.processor-name").each(function(s){var r=d3.select(this);
r.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(r,s.component.name)
}).append("title").text(function(r){return r.component.name
});
p.select("image.processor-stats-preview").style("display","none");
p.call(c)
}else{p.select("text.processor-name").text(function(s){var r=s.component.name;
if(r.length>h){return r.substring(0,h)+String.fromCharCode(8230)
}else{return r
}});
p.select("image.processor-stats-preview").style("display","block");
p.call(g);
if(!n.empty()){n.remove()
}}});
var k=d3.set();
k.add(nf.Common.substringAfterLast(nf.Processor.defaultColor(),"#"));
i.forEach(function(o,n){var m=n.component.style["background-color"];
if(nf.Common.isDefinedAndNotNull(m)){k.add(nf.Common.substringAfterLast(m,"#"))
}});
nf.Canvas.defineProcessorColors(k.values());
l.select("rect.border").attr("stroke",function(n){var m=nf.Processor.defaultColor();
if(nf.Common.isDefinedAndNotNull(n.component.style["background-color"])){m=n.component.style["background-color"]
}return m
});
l.select("rect.body").attr("fill",function(n){var m=nf.Processor.defaultColor();
if(nf.Common.isDefinedAndNotNull(n.component.style["background-color"])){m=n.component.style["background-color"]
}m=nf.Common.substringAfterLast(m,"#");
return"url(#processor-background-"+m+")"
})
};
var c=function(k){if(k.empty()){return
}k.select("text.processor-in").text(function(l){if(nf.Common.isDefinedAndNotNull(l.status)){return l.status.input
}else{return"- / -"
}});
k.select("text.processor-read-write").text(function(l){if(nf.Common.isDefinedAndNotNull(l.status)){return l.status.read+" / "+l.status.written
}else{return"- / -"
}});
k.select("text.processor-out").text(function(l){if(nf.Common.isDefinedAndNotNull(l.status)){return l.status.output
}else{return"- / -"
}});
k.select("text.processor-tasks-time").text(function(l){if(nf.Common.isDefinedAndNotNull(l.status)){return l.status.tasks+" / "+l.status.tasksDuration
}else{return"- / -"
}});
k.each(function(m){var l=d3.select(this);
nf.CanvasUtils.activeThreadCount(l,m);
nf.CanvasUtils.bulletins(l,m,function(){return d3.select("#processor-tooltips")
},286)
})
};
var j=function(k){if(k.empty()){return
}k.call(g).remove()
};
var g=function(k){k.each(function(l){$("#run-status-tip-"+l.component.id).remove();
$("#bulletin-tip-"+l.component.id).remove()
})
};
return{init:function(){i=d3.map();
b=d3.select("#canvas").append("g").attr({"pointer-events":"all","class":"processors"})
},add:function(k,l){l=nf.Common.isDefinedAndNotNull(l)?l:false;
var m=function(n){i.set(n.id,{type:"Processor",component:n,dimensions:a})
};
if($.isArray(k)){$.each(k,function(n,o){m(o)
})
}else{m(k)
}f().enter().call(d,l)
},get:function(k){if(nf.Common.isUndefined(k)){return i.values()
}else{return i.get(k)
}},refresh:function(k){if(nf.Common.isDefinedAndNotNull(k)){d3.select("#id-"+k).call(e)
}else{d3.selectAll("g.processor").call(e)
}},position:function(k){d3.select("#id-"+k).call(nf.CanvasUtils.position)
},pan:function(){d3.selectAll("g.processor.entering, g.processor.leaving").call(e)
},reload:function(k){if(i.has(k.id)){return $.ajax({type:"GET",url:k.uri,dataType:"json"}).done(function(l){nf.Processor.set(l.processor)
})
}},set:function(k){var l=function(n){if(i.has(n.id)){var m=i.get(n.id);
m.component=n;
d3.select("#id-"+n.id).call(e)
}};
if($.isArray(k)){$.each(k,function(m,n){l(n)
})
}else{l(k)
}},remove:function(k){if($.isArray(k)){$.each(k,function(l,m){i.remove(m)
})
}else{i.remove(k)
}f().exit().call(j)
},removeAll:function(){nf.Processor.remove(i.keys())
},setStatus:function(k){if(nf.Common.isEmpty(k)){return
}$.each(k,function(m,l){if(i.has(l.id)){var n=i.get(l.id);
n.status=l
}});
d3.selectAll("g.processor.visible").call(c)
},defaultColor:function(){return"#aaaaaa"
}}
}());