nf.Registration=(function(){var a={urls:{users:"../nifi-api/controller/users"}};
return{init:function(){$("#registration-justification").count({charCountField:"#remaining-characters"});
$("#expand-registration-button, #expand-registration-text").click(function(){var b=$("#registration-form");
if(b.is(":visible")){$("#expand-registration-button").removeClass("registration-expanded").addClass("registration-collapsed")
}else{$("#expand-registration-button").removeClass("registration-collapsed").addClass("registration-expanded")
}b.toggle()
});
$("#registration-form-submit").one("click",function(){var b=$("#registration-justification").val();
$.ajax({type:"POST",url:a.urls.users,data:{justification:b}}).done(function(c){$("#registration-pane").hide();
$("#message-pane").show();
$("#message-title").text("Thanks");
$("#message-content").text("Your request will be processed shortly.")
}).fail(nf.Common.handleAjaxError)
})
}}
}());