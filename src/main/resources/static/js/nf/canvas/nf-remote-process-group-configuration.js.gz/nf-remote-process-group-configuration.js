nf.RemoteProcessGroupConfiguration=(function(){return{init:function(){$("#remote-process-group-configuration").modal({headerText:"Configure Remote Process Group",overlayBackground:true,buttons:[{buttonText:"Apply",handler:{click:function(){var a=$("#remote-process-group-id").text();
var b=d3.select("#id-"+a).datum();
var c={revision:nf.Client.getRevision(),remoteProcessGroup:{id:a,communicationsTimeout:$("#remote-process-group-timeout").val(),yieldDuration:$("#remote-process-group-yield-duration").val()}};
$.ajax({type:"PUT",data:JSON.stringify(c),url:b.component.uri,dataType:"json",processData:false,contentType:"application/json"}).done(function(d){nf.Client.setRevision(d.revision);
$("#remote-process-group-configuration").modal("hide")
}).fail(function(g,d,e){if(g.status===400){var h=g.responseText.split("\n");
var f;
if(h.length===1){f=$("<span></span>").text(h[0])
}else{f=nf.Common.formatUnorderedList(h)
}nf.Dialog.showOkDialog({dialogContent:f,overlayBackground:false,headerText:"Configuration Error"})
}else{nf.Common.handleAjaxError(g,d,e)
}})
}}},{buttonText:"Cancel",handler:{click:function(){$("#remote-process-group-configuration").modal("hide")
}}}],handler:{close:function(){$("#remote-process-group-id").text("");
$("#remote-process-group-name").text("");
$("#remote-process-group-url").text("");
$("#remote-process-group-timeout").val("");
$("#remote-process-group-yield-duration").val("")
}}}).draggable({containment:"parent",handle:".dialog-header"})
},showConfiguration:function(a){if(nf.CanvasUtils.isRemoteProcessGroup(a)){var b=a.datum();
$("#remote-process-group-id").text(b.component.id);
$("#remote-process-group-name").text(b.component.name);
$("#remote-process-group-url").text(b.component.targetUri);
$("#remote-process-group-timeout").val(b.component.communicationsTimeout);
$("#remote-process-group-yield-duration").val(b.component.yieldDuration);
$("#remote-process-group-configuration").modal("show")
}}}
}());