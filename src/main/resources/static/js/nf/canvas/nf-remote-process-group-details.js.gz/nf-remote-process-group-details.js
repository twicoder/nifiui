nf.RemoteProcessGroupDetails=(function(){return{init:function(){$("#remote-process-group-details").modal({headerText:"Remote Process Group Details",overlayBackground:true,buttons:[{buttonText:"Ok",handler:{click:function(){$("#remote-process-group-details").modal("hide")
}}}],handler:{close:function(){$("#read-only-remote-process-group-name").text("");
$("#read-only-remote-process-group-url").text("");
$("#read-only-remote-process-group-timeout").val("");
$("#read-only-remote-process-group-yield-duration").val("")
}}}).draggable({containment:"parent",handle:".dialog-header"})
},showDetails:function(a){if(nf.CanvasUtils.isRemoteProcessGroup(a)){var b=a.datum();
$("#read-only-remote-process-group-name").text(b.component.name);
$("#read-only-remote-process-group-url").text(b.component.targetUri);
$("#read-only-remote-process-group-timeout").text(b.component.communicationsTimeout);
$("#read-only-remote-process-group-yield-duration").text(b.component.yieldDuration);
$("#remote-process-group-details").modal("show")
}}}
}());