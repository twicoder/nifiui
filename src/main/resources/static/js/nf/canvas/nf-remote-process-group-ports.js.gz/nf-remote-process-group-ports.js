nf.RemoteProcessGroupPorts=(function(){var b=function(){$("#remote-port-configuration").modal({headerText:"Configure Remote Port",overlayBackground:false,buttons:[{buttonText:"Apply",handler:{click:function(){var f=$("#remote-port-concurrent-tasks").val();
if($.isNumeric(f)){var e=$("#remote-process-group-ports-id").text();
var j=d3.select("#id-"+e).datum();
var i=$("#remote-port-id").text();
var h={revision:nf.Client.getRevision(),remoteProcessGroupPort:{id:i,useCompression:$("#remote-port-use-compression").hasClass("checkbox-checked"),concurrentlySchedulableTaskCount:f}};
var g="/output-ports/";
if($("#remote-port-type").text()==="input"){g="/input-ports/"
}$.ajax({type:"PUT",data:JSON.stringify(h),url:j.component.uri+g+encodeURIComponent(i),dataType:"json",processData:false,contentType:"application/json"}).done(function(k){nf.Client.setRevision(k.revision);
var l=k.remoteProcessGroupPort;
var m="No";
if(l.useCompression===true){m="Yes"
}$("#"+i+"-concurrent-tasks").text(l.concurrentlySchedulableTaskCount);
$("#"+i+"-compression").text(m)
}).fail(function(n,k,l){if(n.status===400){var o=n.responseText.split("\n");
var m;
if(o.length===1){m=$("<span></span>").text(o[0])
}else{m=nf.Common.formatUnorderedList(o)
}nf.Dialog.showOkDialog({dialogContent:m,overlayBackground:false,headerText:"Configuration Error"})
}else{nf.Common.handleAjaxError(n,k,l)
}}).always(function(){$("#remote-port-configuration").modal("hide")
})
}else{nf.Dialog.showOkDialog({dialogContent:"Concurrent tasks must be an integer value.",overlayBackground:false});
$("#remote-port-configuration").modal("hide")
}}}},{buttonText:"Cancel",handler:{click:function(){$("#remote-port-configuration").modal("hide")
}}}],handler:{close:function(){$("#remote-port-id").text("");
$("#remote-port-name").text("");
$("#remote-port-concurrent-tasks").val("");
$("#remote-port-use-compression").removeClass("checkbox-checked checkbox-unchecked")
}}})
};
var a=function(){$("#remote-process-group-ports").modal({headerText:"Remote Process Group Ports",overlayBackground:true,buttons:[{buttonText:"Close",handler:{click:function(){if(nf.Common.isDFM()){var e=$("#remote-process-group-ports-id").text();
var f=d3.select("#id-"+e).datum();
nf.RemoteProcessGroup.reload(f.component)
}$("#remote-process-group-ports").modal("hide")
}}}],handler:{close:function(){$("#remote-process-group-ports-id").text("");
$("#remote-process-group-ports-name").text("");
$("#remote-process-group-ports-url").text("");
var e=$("#remote-process-group-ports");
nf.Common.cleanUpTooltips(e,"div.remote-port-removed");
nf.Common.cleanUpTooltips(e,"img.concurrent-tasks-info");
$("#remote-process-group-input-ports-container").empty();
$("#remote-process-group-output-ports-container").empty()
}}}).draggable({containment:"parent",handle:".dialog-header"})
};
var c=function(h,k,i){var l=nf.Common.escapeHtml(k.id);
var f=$('<div class="remote-port-container"></div>').appendTo(h);
var q=$('<div class="remote-port-edit-container"></div>').appendTo(f);
var g=$('<div class="remote-port-details-container"></div>').appendTo(f);
if(nf.Common.isDFM()){var e;
if(k.connected===true){if(k.transmitting===true){e=$('<div class="enabled-transmission-switch enabled-active-transmission"></div>').appendTo(q)
}else{if(k.exists===true){e=$('<div class="enabled-transmission-switch enabled-inactive-transmission"></div>').appendTo(q)
}else{$('<div class="disabled-transmission-switch disabled-inactive-transmission"></div>').appendTo(q)
}}}else{if(k.transmitting===true){$('<div class="disabled-transmission-switch disabled-active-transmission"></div>').appendTo(q)
}else{$('<div class="disabled-transmission-switch disabled-inactive-transmission"></div>').appendTo(q)
}}if(k.exists===true&&k.connected===true){var j=$('<div class="edit-button edit-remote-port"></div>').on("mouseenter",function(){$(this).removeClass("edit-remote-port").addClass("edit-remote-port-hover")
}).on("mouseleave",function(){$(this).removeClass("edit-remote-port-hover").addClass("edit-remote-port")
}).click(function(){var t=$("#"+l+"-name").text();
var s=$("#"+l+"-concurrent-tasks").text();
var r=$("#"+l+"-compression").text()==="Yes";
d(k.id,t,s,r,i)
}).appendTo(q);
if(k.transmitting===true){j.hide()
}else{j.show()
}}else{if(k.exists===false){$('<div class="remote-port-removed"/>').appendTo(q).qtip($.extend({content:"This port has been removed."},nf.Common.config.tooltipConfig))
}}if(nf.Common.isDefinedAndNotNull(e)){e.click(function(){var r=$("#remote-process-group-ports-id").text();
var u=d3.select("#id-"+r).datum();
var v=false;
if(e.hasClass("enabled-inactive-transmission")){v=true
}var t={revision:nf.Client.getRevision(),remoteProcessGroupPort:{id:k.id,transmitting:v}};
var s="/output-ports/";
if(i==="input"){s="/input-ports/"
}$.ajax({type:"PUT",data:JSON.stringify(t),url:u.component.uri+s+encodeURIComponent(k.id),dataType:"json",processData:false,contentType:"application/json"}).done(function(w){nf.Client.setRevision(w.revision);
var x=w.remoteProcessGroupPort;
if(x.exists===false){e.removeClass("enabled-active-transmission enabled-inactive-transmission enabled-transmission-switch").addClass("disabled-transmission-switch disabled-inactive-transmission").off("click");
if(nf.Common.isDefinedAndNotNull(j)){j.hide()
}}else{if(x.transmitting===true){e.removeClass("enabled-active-transmission enabled-inactive-transmission").addClass("enabled-active-transmission");
if(nf.Common.isDefinedAndNotNull(j)){j.hide()
}}else{e.removeClass("enabled-active-transmission enabled-inactive-transmission").addClass("enabled-inactive-transmission");
if(nf.Common.isDefinedAndNotNull(j)){j.show()
}}}}).fail(function(z,w,x){if(z.status===400){var A=z.responseText.split("\n");
var y;
if(A.length===1){y=$("<span></span>").text(A[0])
}else{y=nf.Common.formatUnorderedList(A)
}nf.Dialog.showOkDialog({dialogContent:y,overlayBackground:false,headerText:"Configuration Error"})
}else{nf.Common.handleAjaxError(z,w,x)
}})
})
}}else{if(k.transmitting===true){$('<div class="disabled-transmission-switch disabled-active-transmission"></div>').appendTo(q)
}else{$('<div class="disabled-transmission-switch disabled-inactive-transmission"></div>').appendTo(q)
}}$('<div id="'+l+'-id" class="remote-port-id hidden"></div>').text(k.id).appendTo(g);
$('<div id="'+l+'-name" class="remote-port-name ellipsis"></div>').text(k.name).appendTo(g);
$('<div class="clear"></div>').appendTo(g);
if(nf.Common.isBlank(k.comments)){$('<div class="remote-port-description unset">No description specified.</div>').appendTo(g)
}else{$('<div class="remote-port-description"></div>').text(k.comments).appendTo(g)
}$('<div class="clear"></div>').appendTo(g);
var m=$('<div class="concurrent-task-container"></div>').appendTo(g);
var n=$('<div class="setting-value"></div>').append($('<div id="'+l+'-concurrent-tasks"></div>').text(k.concurrentlySchedulableTaskCount));
$('<div><div class="setting-name">Concurrent tasks<img class="processor-setting concurrent-tasks-info" src="images/iconInfo.png" alt="Info"/></div></div>').append(n).appendTo(m).find("img.concurrent-tasks-info").qtip($.extend({content:"The number of tasks that should be concurrently scheduled for this port."},nf.Common.config.tooltipConfig));
var o=$('<div class="compression-container"></div>').appendTo(g);
var p="No";
if(k.useCompression===true){p="Yes"
}$('<div><div class="setting-name">Compressed</div><div class="setting-value"><div id="'+l+'-compression">'+p+"</div></div></div>").appendTo(o);
$('<div class="clear"></div>').appendTo(f);
f.find(".ellipsis").ellipsis()
};
var d=function(g,j,i,f,e){$("#remote-port-id").text(g);
$("#remote-port-type").text(e);
var h="checkbox-unchecked";
if(f===true){h="checkbox-checked"
}$("#remote-port-use-compression").addClass(h);
$("#remote-port-concurrent-tasks").val(i);
$("#remote-port-name").text(j).ellipsis();
$("#remote-port-configuration").modal("show")
};
return{init:function(){b();
a()
},showPorts:function(e){if(nf.CanvasUtils.isRemoteProcessGroup(e)){var f=e.datum();
$.ajax({type:"GET",url:f.component.uri,data:{verbose:true},dataType:"json"}).done(function(h){var k=h.remoteProcessGroup;
nf.RemoteProcessGroup.set(k);
$("#remote-process-group-ports-id").text(k.id);
$("#remote-process-group-ports-name").text(k.name);
$("#remote-process-group-ports-url").text(k.targetUri);
var g=k.contents;
if(nf.Common.isDefinedAndNotNull(g)){var n=[];
var i=[];
var m=$("#remote-process-group-input-ports-container");
$.each(g.inputPorts,function(q,p){if(p.connected===true){n.push(p)
}else{i.push(p)
}});
$.each(n,function(q,p){c(m,p,"input")
});
$.each(i,function(q,p){c(m,p,"input")
});
var j=[];
var o=[];
var l=$("#remote-process-group-output-ports-container");
$.each(g.outputPorts,function(p,q){if(q.connected===true){j.push(q)
}else{o.push(q)
}});
$.each(j,function(p,q){c(l,q,"output")
});
$.each(o,function(p,q){c(l,q,"output")
})
}$("#remote-process-group-ports").modal("show")
}).fail(nf.Common.handleAjaxError)
}}}
}());