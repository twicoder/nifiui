nf.RemoteProcessGroup=(function(){var l=30;
var a={width:365,height:140};
var j;
var b;
var g=function(m){if(nf.Common.isBlank(m.component.comments)){return"No comments specified"
}else{return m.component.comments
}};
var h=function(){return b.selectAll("g.remote-process-group").data(j.values(),function(m){return m.component.id
})
};
var k=function(o,m){if(o.empty()){return
}var n=o.append("g").attr({id:function(p){return"id-"+p.component.id
},"class":"remote-process-group component"}).classed("selected",m).call(nf.CanvasUtils.position);
n.append("rect").attr({rx:6,ry:6,"class":"border",width:function(p){return p.dimensions.width
},height:function(p){return p.dimensions.height
},fill:"transparent","stroke-opacity":0.8,"stroke-width":2,stroke:"#294c58"});
n.append("rect").attr({rx:6,ry:6,"class":"body",width:function(p){return p.dimensions.width
},height:function(p){return p.dimensions.height
},fill:"#294c58","fill-opacity":0.8,"stroke-width":0});
n.append("text").attr({x:25,y:17,width:305,height:16,"font-size":"10pt","font-weight":"bold",fill:"#ffffff","class":"remote-process-group-name"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/bgRemoteProcessGroupDetailsArea.png",width:352,height:89,x:6,y:38,"class":"remote-process-group-preview"});
n.call(nf.Selectable.activate).call(nf.ContextMenu.activate);
if(nf.Common.isDFM()){n.call(nf.Draggable.activate).call(nf.Connectable.activate)
}n.call(f)
};
var d=5;
var f=function(m){if(m.empty()){return
}m.each(function(){var t=d3.select(this);
var n=t.select("g.remote-process-group-details");
if(t.classed("visible")){if(n.empty()){n=t.append("g").attr("class","remote-process-group-details");
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"remote-process-group-transmission-status",width:16,height:16,x:5,y:5});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"remote-process-group-transmission-secure",width:14,height:12,x:7,y:23});
n.append("text").attr({x:25,y:32,width:305,height:12,"font-size":"8pt",fill:"#91b9ce","class":"remote-process-group-uri"}).each(function(B){var A=d3.select(this);
A.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(A,B.component.targetUri)
}).append("title").text(function(A){return A.component.name
});
n.append("rect").attr({x:6,y:38,width:352,height:89,"stroke-width":1,stroke:"#6f97ac",fill:"#ffffff"});
n.append("rect").attr({x:6,y:38,width:176,height:22,"stroke-width":1,stroke:"#6f97ac",fill:"url(#process-group-stats-background)","class":"remote-process-group-input-container"});
n.append("rect").attr({x:182,y:38,width:176,height:22,"stroke-width":1,stroke:"#6f97ac",fill:"url(#process-group-stats-background)","class":"remote-process-group-output-container"});
n.append("rect").attr({x:6,y:94,width:352,height:33,"stroke-width":1,stroke:"#6f97ac",fill:"url(#process-group-stats-background)"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconInputPortSmall.png",width:16,height:16,x:10,y:41});
n.append("text").attr({x:30,y:53,"class":"remote-process-group-input-port-count process-group-contents-count"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconTransmissionActive.png",width:16,height:16,y:41,"class":"remote-process-group-input-transmitting"});
n.append("text").attr({y:53,"class":"remote-process-group-input-transmitting-count process-group-contents-count"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconTransmissionInactive.png",width:16,height:16,y:41,"class":"remote-process-group-input-not-transmitting"});
n.append("text").attr({y:53,"class":"remote-process-group-input-not-transmitting-count process-group-contents-count"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconOutputPortSmall.png",width:16,height:16,x:186,y:41,"class":"remote-process-group-output-port"});
n.append("text").attr({x:206,y:53,"class":"remote-process-group-output-port-count process-group-contents-count"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconTransmissionActive.png",width:16,height:16,y:41,"class":"remote-process-group-output-transmitting"});
n.append("text").attr({y:53,"class":"remote-process-group-output-transmitting-count process-group-contents-count"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"xlink:href":"images/iconTransmissionInactive.png",width:16,height:16,y:41,"class":"remote-process-group-output-not-transmitting"});
n.append("text").attr({y:53,"class":"remote-process-group-output-not-transmitting-count process-group-contents-count"});
var o=n.append("g").attr({transform:"translate(6, 70)"});
o.append("text").attr({width:73,height:10,x:4,y:4,"class":"process-group-stats-label"}).text("Sent");
o.append("text").attr({width:73,height:10,x:4,y:17,"class":"process-group-stats-label"}).text("Received");
var p=n.append("g").attr({transform:"translate(95, 70)"});
p.append("text").attr({width:180,height:10,x:4,y:4,"class":"remote-process-group-sent process-group-stats-value"});
p.append("text").attr({width:180,height:10,x:4,y:17,"class":"remote-process-group-received process-group-stats-value"});
var z=n.append("g").attr({transform:"translate(315, 70)"});
z.append("text").attr({width:25,height:10,x:4,y:4,"class":"process-group-stats-info"}).text("(5 min)");
z.append("text").attr({width:25,height:10,x:4,y:17,"class":"process-group-stats-info"}).text("(5 min)");
n.append("text").attr({x:10,y:108,width:342,height:22,"class":"remote-process-group-comments"});
n.append("text").attr({x:358,y:137,"class":"remote-process-group-last-refresh"});
n.append("rect").attr({"class":"active-thread-count-background",height:13,y:0,fill:"#fff","fill-opacity":"0.65",stroke:"#aaa","stroke-width":"1"});
n.append("text").attr({"class":"active-thread-count",height:13,y:10,fill:"#000"});
n.append("image").call(nf.CanvasUtils.disableImageHref).attr({"class":"bulletin-icon","xlink:href":"images/iconBulletin.png",width:12,height:12,y:2})
}n.select("image.remote-process-group-transmission-status").attr("xlink:href",function(B){var A="";
if(nf.Common.isDefinedAndNotNull(B.status)&&!nf.Common.isEmpty(B.status.authorizationIssues)){A="images/iconAlert.png"
}else{if(B.component.transmitting===true){A="images/iconTransmissionActive.png"
}else{A="images/iconTransmissionInactive.png"
}}return A
}).each(function(B){var A=d3.select("#authorization-issues-"+B.component.id);
if(!A.empty()){A.remove()
}if(nf.Common.isDefinedAndNotNull(B.status)&&!nf.Common.isEmpty(B.status.authorizationIssues)){A=d3.select("#remote-process-group-tooltips").append("div").attr("id",function(){return"authorization-issues-"+B.component.id
}).attr("class","tooltip nifi-tooltip").html(function(){var C=nf.Common.formatUnorderedList(B.status.authorizationIssues);
if(C===null||C.length===0){return""
}else{return $("<div></div>").append(C).html()
}});
nf.CanvasUtils.canvasTooltip(A,d3.select(this))
}});
n.select("image.remote-process-group-transmission-secure").attr("xlink:href",function(B){var A="";
if(B.component.targetSecure===true){A="images/iconSecure.png"
}else{A="images/iconNotSecure.png"
}return A
}).each(function(B){var A=d3.select("#transmission-secure-"+B.component.id);
if(!A.empty()){A.remove()
}A=d3.select("#remote-process-group-tooltips").append("div").attr("id",function(){return"transmission-secure-"+B.component.id
}).attr("class","tooltip nifi-tooltip").text(function(){if(B.component.targetSecure===true){return"Site-to-Site is secure."
}else{return"Site-to-Site is NOT secure."
}});
nf.CanvasUtils.canvasTooltip(A,d3.select(this))
});
n.select("text.remote-process-group-input-port-count").text(function(A){return A.component.inputPortCount
});
var y=n.select("rect.remote-process-group-input-container");
var w=n.select("text.remote-process-group-input-not-transmitting-count").text(function(A){return A.component.inactiveRemoteInputPortCount
}).attr("x",function(){var A=parseInt(y.attr("x"),10);
var B=parseInt(y.attr("width"),10);
return A+B-this.getComputedTextLength()-d
});
var s=n.select("image.remote-process-group-input-not-transmitting").attr("x",function(){var B=parseInt(w.attr("x"),10);
var A=parseInt(d3.select(this).attr("width"),10);
return B-A-d
});
var u=n.select("text.remote-process-group-input-transmitting-count").text(function(A){return A.component.activeRemoteInputPortCount
}).attr("x",function(){var A=parseInt(s.attr("x"),10);
return A-this.getComputedTextLength()-d
});
n.select("image.remote-process-group-input-transmitting").attr("x",function(){var B=parseInt(u.attr("x"),10);
var A=parseInt(d3.select(this).attr("width"),10);
return B-A-d
});
n.select("text.remote-process-group-output-port-count").text(function(A){return A.component.outputPortCount
});
var v=n.select("rect.remote-process-group-output-container");
var q=n.select("text.remote-process-group-output-not-transmitting-count").text(function(A){return A.component.inactiveRemoteOutputPortCount
}).attr("x",function(){var A=parseInt(v.attr("x"),10);
var B=parseInt(v.attr("width"),10);
return A+B-this.getComputedTextLength()-d
});
var x=n.select("image.remote-process-group-output-not-transmitting").attr("x",function(){var A=parseInt(q.attr("x"),10);
var B=parseInt(d3.select(this).attr("width"),10);
return A-B-d
});
var r=n.select("text.remote-process-group-output-transmitting-count").text(function(A){return A.component.activeRemoteOutputPortCount
}).attr("x",function(){var A=parseInt(x.attr("x"),10);
return A-this.getComputedTextLength()-d
});
n.select("image.remote-process-group-output-transmitting").attr("x",function(){var B=parseInt(r.attr("x"),10);
var A=parseInt(d3.select(this).attr("width"),10);
return B-A-d
});
n.select("text.remote-process-group-comments").each(function(B){var A=d3.select(this);
A.text(null).selectAll("tspan, title").remove();
nf.CanvasUtils.multilineEllipsis(A,2,g(B))
}).classed("unset",function(A){return nf.Common.isBlank(A.component.comments)
}).append("title").text(function(A){return g(A)
});
n.select("text.remote-process-group-last-refresh").text(function(A){if(nf.Common.isDefinedAndNotNull(A.component.flowRefreshed)){return A.component.flowRefreshed
}else{return"Remote flow not current"
}});
t.select("text.remote-process-group-name").each(function(B){var A=d3.select(this);
A.text(null).selectAll("title").remove();
nf.CanvasUtils.ellipsis(A,B.component.name)
}).append("title").text(function(A){return A.component.name
});
t.select("image.remote-process-group-preview").style("display","none");
t.call(c)
}else{t.select("text.remote-process-group-name").text(function(B){var A=B.component.name;
if(A.length>l){return A.substring(0,l)+String.fromCharCode(8230)
}else{return A
}});
t.select("image.remote-process-group-preview").style("display","block");
t.call(i);
if(!n.empty()){n.remove()
}}})
};
var c=function(m){if(m.empty()){return
}m.select("text.remote-process-group-sent").text(function(n){if(nf.Common.isDefinedAndNotNull(n.status)){return n.status.sent
}else{return"- / -"
}});
m.select("text.remote-process-group-received").text(function(n){if(nf.Common.isDefinedAndNotNull(n.status)){return n.status.received
}else{return"- / -"
}});
m.each(function(p){var n=d3.select(this);
var o=0;
nf.CanvasUtils.activeThreadCount(n,p,function(q){o=q
});
nf.CanvasUtils.bulletins(n,p,function(){return d3.select("#remote-process-group-tooltips")
},o)
})
};
var e=function(m){if(m.empty()){return
}m.call(i).remove()
};
var i=function(m){m.each(function(n){$("#bulletin-tip-"+n.component.id).remove();
$("#authorization-issues-"+n.component.id).remove();
$("#transmission-secure-"+n.component.id).remove()
})
};
return{init:function(){j=d3.map();
b=d3.select("#canvas").append("g").attr({"pointer-events":"all","class":"remote-process-groups"})
},add:function(m,n){n=nf.Common.isDefinedAndNotNull(n)?n:false;
var o=function(p){j.set(p.id,{type:"RemoteProcessGroup",component:p,dimensions:a})
};
if($.isArray(m)){$.each(m,function(p,q){o(q)
})
}else{o(m)
}h().enter().call(k,n)
},get:function(m){if(nf.Common.isUndefined(m)){return j.values()
}else{return j.get(m)
}},refresh:function(m){if(nf.Common.isDefinedAndNotNull(m)){d3.select("#id-"+m).call(f)
}else{d3.selectAll("g.remote-process-group").call(f)
}},pan:function(){d3.selectAll("g.remote-process-group.entering, g.remote-process-group.leaving").call(f)
},reload:function(m){if(j.has(m.id)){return $.ajax({type:"GET",url:m.uri,dataType:"json"}).done(function(n){nf.RemoteProcessGroup.set(n.remoteProcessGroup);
var o=nf.Connection.getComponentConnections(m.id);
$.each(o,function(q,p){nf.Connection.reload(p)
})
})
}},position:function(m){d3.select("#id-"+m).call(nf.CanvasUtils.position)
},set:function(m){var n=function(o){if(j.has(o.id)){var p=j.get(o.id);
p.component=o;
d3.select("#id-"+o.id).call(f)
}};
if($.isArray(m)){$.each(m,function(o,p){n(p)
})
}else{n(m)
}},setStatus:function(m){if(nf.Common.isEmpty(m)){return
}$.each(m,function(o,n){if(j.has(n.id)){var p=j.get(n.id);
p.status=n
}});
d3.selectAll("g.remote-process-group.visible").call(c)
},remove:function(m){if($.isArray(m)){$.each(m,function(n,o){j.remove(o)
})
}else{j.remove(m)
}h().exit().call(e)
},removeAll:function(){nf.RemoteProcessGroup.remove(j.keys())
}}
}());