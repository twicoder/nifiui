nf.Search=(function(){var a={search:"Search",urls:{search:"../nifi-api/controller/search-results"}};
return{init:function(){$.widget("nf.searchAutocomplete",$.ui.autocomplete,{reset:function(){this.term=null
},_resizeMenu:function(){var b=this.menu.element;
b.width(399)
},_normalize:function(c){var b=[];
b.push(c);
return b
},_renderMenu:function(d,c){var b=this;
var e=c[0];
if(!nf.Common.isEmpty(e.processorResults)){d.append('<li class="search-header"><div class="search-result-icon processor-small-icon"></div>Processors</li>');
$.each(e.processorResults,function(g,f){b._renderItem(d,f)
})
}if(!nf.Common.isEmpty(e.processGroupResults)){d.append('<li class="search-header"><div class="search-result-icon process-group-small-icon"></div>Process Groups</li>');
$.each(e.processGroupResults,function(g,f){b._renderItem(d,f)
})
}if(!nf.Common.isEmpty(e.remoteProcessGroupResults)){d.append('<li class="search-header"><div class="search-result-icon remote-process-group-small-icon"></div>Remote Process Groups</li>');
$.each(e.remoteProcessGroupResults,function(f,g){b._renderItem(d,g)
})
}if(!nf.Common.isEmpty(e.connectionResults)){d.append('<li class="search-header"><div class="search-result-icon connection-small-icon"></div>Connections</li>');
$.each(e.connectionResults,function(g,f){b._renderItem(d,f)
})
}if(!nf.Common.isEmpty(e.inputPortResults)){d.append('<li class="search-header"><div class="search-result-icon input-port-small-icon"></div>Input Ports</li>');
$.each(e.inputPortResults,function(f,g){b._renderItem(d,g)
})
}if(!nf.Common.isEmpty(e.outputPortResults)){d.append('<li class="search-header"><div class="search-result-icon output-port-small-icon"></div>Output Ports</li>');
$.each(e.outputPortResults,function(f,g){b._renderItem(d,g)
})
}if(!nf.Common.isEmpty(e.funnelResults)){d.append('<li class="search-header"><div class="search-result-icon funnel-small-icon"></div>Funnels</li>');
$.each(e.funnelResults,function(g,f){b._renderItem(d,f)
})
}if(d.children().length===0){d.append('<li class="unset search-no-matches">No results matched the search terms</li>')
}},_renderItem:function(c,b){var d=$("<a></a>").append($('<div class="search-match-header"></div>').text(b.name));
$.each(b.matches,function(f,e){d.append($('<div class="search-match"></div>').text(e))
});
return $("<li></li>").data("ui-autocomplete-item",b).append(d).appendTo(c)
}});
$("#search-field").zIndex(1250).searchAutocomplete({appendTo:"#search-flow-results",position:{my:"right top",at:"right bottom",offset:"1 1"},source:function(c,b){$.ajax({type:"GET",data:{q:c.term},dataType:"json",url:a.urls.search}).done(function(d){b(d.searchResultsDTO)
})
},select:function(c,d){var b=d.item;
nf.CanvasUtils.showComponent(b.groupId,b.id);
$(this).blur();
return false
},open:function(b,c){var d=$(this);
$('<div class="search-glass-pane"></div>').one("click",function(){d.blur()
}).appendTo("body")
},close:function(b,c){$(this).searchAutocomplete("reset");
$("div.search-glass-pane").remove()
}}).focus(function(){nf.ContextMenu.hide();
$(this).val("").removeClass("search-flow")
}).blur(function(){$(this).val(a.search).addClass("search-flow")
}).val(a.search).addClass("search-flow")
}}
}());