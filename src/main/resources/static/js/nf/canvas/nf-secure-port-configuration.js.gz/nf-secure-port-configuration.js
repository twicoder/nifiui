nf.SecurePortConfiguration=(function(){var f="";
var b={search:"User DNs, groups, etc"};
var g=function(){$("#secure-port-configuration-tabs").tabbs({tabStyle:"tab",selectedTabStyle:"selected-tab",tabs:[{name:"Settings",tabContentId:"secure-port-settings-tab-content"},{name:"Access Control",tabContentId:"secure-port-access-control-tab-content"}]});
$("#secure-port-configuration").modal({headerText:"Configure Secure Port",overlayBackground:true,buttons:[{buttonText:"Apply",handler:{click:function(){var j=$("#secure-port-id").text();
var h=$("#secure-port-type").text();
var k={};
k.id=j;
k.name=$("#secure-port-name").val();
k.comments=$("#secure-port-comments").val();
k.groupAccessControl=a();
k.userAccessControl=c();
if($("#secure-port-concurrent-task-container").is(":visible")){k.concurrentlySchedulableTaskCount=$("#secure-port-concurrent-tasks").val()
}if($("#secure-port-enabled").hasClass("checkbox-unchecked")){k.state="DISABLED"
}else{if($("#secure-port-enabled").hasClass("checkbox-checked")){k.state="STOPPED"
}}var i={};
i.revision=nf.Client.getRevision();
i[h]=k;
$.ajax({type:"PUT",data:JSON.stringify(i),contentType:"application/json",url:f,dataType:"json"}).done(function(m){nf.Client.setRevision(m.revision);
var l;
if(nf.Common.isDefinedAndNotNull(m.inputPort)){l=m.inputPort
}else{l=m.outputPort
}nf.Port.set(l);
$("#secure-port-configuration").modal("hide")
}).fail(function(n,l,m){$("#secure-port-configuration").modal("hide");
nf.Common.handleAjaxError(n,l,m)
})
}}},{buttonText:"Cancel",handler:{click:function(){$("#secure-port-configuration").modal("hide")
}}}],handler:{close:function(){f="";
$("#secure-port-id").text("");
$("#secure-port-type").text("");
$("#secure-port-name").val("");
$("#secure-port-enabled").removeClass("checkbox-unchecked checkbox-checked");
$("#secure-port-concurrent-tasks").val("");
$("#secure-port-comments").val("");
$("#allowed-users").empty();
$("#allowed-groups").empty()
}}}).draggable({containment:"parent",handle:".dialog-header"});
$(document).on("click","div.remove-allowed-entity",function(){$(this).closest("li").remove();
$(this).closest("ul").sortable("refresh")
});
$.widget("nf.userSearchAutocomplete",$.ui.autocomplete,{_normalize:function(i){var h=[];
h.push(i);
return h
},_resizeMenu:function(){var h=this.menu.element;
h.width(700)
},_renderMenu:function(m,i){var h=this;
var l=i[0];
if(!nf.Common.isEmpty(l.userGroupResults)){var k=a();
var j=false;
$.each(l.userGroupResults,function(p,q){if($.inArray(q.group,k)===-1){if(!j){m.append('<li class="search-users-header">Groups</li>');
j=true
}h._renderGroupItem(m,q)
}})
}if(!nf.Common.isEmpty(l.userResults)){var n=c();
var o=false;
$.each(l.userResults,function(p,q){if($.inArray(q.userDn,n)===-1){if(!o){m.append('<li class="search-users-header">Users</li>');
o=true
}h._renderUserItem(m,q)
}})
}if(m.children().length===0){m.append('<li class="unset search-users-no-matches">No users or groups match</li>')
}},_renderGroupItem:function(h,j){var i=$("<a></a>").append($('<div class="search-users-match-header"></div>').text(j.group));
return $("<li></li>").data("ui-autocomplete-item",j).append(i).appendTo(h)
},_renderUserItem:function(i,j){var h=$("<a></a>").append($('<div class="search-users-match-header"></div>').text(j.userDn));
return $("<li></li>").data("ui-autocomplete-item",j).append(h).appendTo(i)
}});
$("#secure-port-access-control").userSearchAutocomplete({minLength:0,appendTo:"#search-users-results",position:{my:"left top",at:"left bottom",offset:"0 1"},source:function(i,h){$.ajax({type:"GET",data:{q:i.term},dataType:"json",url:"../nifi-api/controller/users/search-results"}).done(function(j){h(j)
})
},select:function(i,j){var h=j.item;
if(nf.Common.isDefinedAndNotNull(h.group)){d(h.group)
}else{e(h.userDn)
}$(this).blur();
return false
}}).focus(function(){if($(this).val()===b.search){$(this).val("").removeClass("search-users")
}}).blur(function(){$(this).val(b.search).addClass("search-users")
}).val(b.search).addClass("search-users")
};
var e=function(k){var i=$("#allowed-users");
var h=$("<span></span>").addClass("allowed-entity ellipsis").text(k).ellipsis();
var j=$("<div></div>").addClass("remove-allowed-entity");
$("<li></li>").data("user",k).append(h).append(j).appendTo(i)
};
var d=function(j){var i=$("#allowed-groups");
var k=$("<span></span>").addClass("allowed-entity ellipsis").text(j).ellipsis();
var h=$("<div></div>").addClass("remove-allowed-entity");
$("<li></li>").data("group",j).append(k).append(h).appendTo(i)
};
var c=function(){var h=[];
$("#allowed-users").children("li").each(function(j,k){var i=$(k).data("user");
if(nf.Common.isDefinedAndNotNull(i)){h.push(i)
}});
return h
};
var a=function(){var h=[];
$("#allowed-groups").children("li").each(function(j,i){var k=$(i).data("group");
if(nf.Common.isDefinedAndNotNull(k)){h.push(k)
}});
return h
};
return{init:function(){g()
},showConfiguration:function(i){if(nf.CanvasUtils.isInputPort(i)||nf.CanvasUtils.isOutputPort(i)){var j=i.datum();
if(j.component.type==="INPUT_PORT"){$("#secure-port-type").text("inputPort")
}else{$("#secure-port-type").text("outputPort")
}f=j.component.uri;
if(nf.Canvas.getParentGroupId()===null){$("#secure-port-concurrent-task-container").show()
}else{$("#secure-port-concurrent-task-container").hide()
}var h="checkbox-checked";
if(j.component.state==="DISABLED"){h="checkbox-unchecked"
}$("#secure-port-id").text(j.component.id);
$("#secure-port-name").val(j.component.name);
$("#secure-port-enabled").removeClass("checkbox-unchecked checkbox-checked").addClass(h);
$("#secure-port-concurrent-tasks").val(j.component.concurrentlySchedulableTaskCount);
$("#secure-port-comments").val(j.component.comments);
$.each(j.component.userAccessControl,function(k,l){e(l)
});
$.each(j.component.groupAccessControl,function(l,k){d(k)
});
$("#secure-port-configuration").modal("show")
}}}
}());