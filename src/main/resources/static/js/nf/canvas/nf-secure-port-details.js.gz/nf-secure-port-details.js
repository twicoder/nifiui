nf.SecurePortDetails=(function(){var b=function(e){var d=$("#read-only-allowed-users");
var c=$("<span></span>").addClass("allowed-entity ellipsis").text(e).ellipsis();
$("<li></li>").data("user",e).append(c).appendTo(d)
};
var a=function(d){var c=$("#read-only-allowed-groups");
var e=$("<span></span>").addClass("allowed-entity ellipsis").text(d).ellipsis();
$("<li></li>").data("group",d).append(e).appendTo(c)
};
return{init:function(){$("#secure-port-details-tabs").tabbs({tabStyle:"tab",selectedTabStyle:"selected-tab",tabs:[{name:"Settings",tabContentId:"read-only-secure-port-settings-tab-content"},{name:"Access Control",tabContentId:"read-only-secure-port-access-control-tab-content"}]});
$("#secure-port-details").modal({headerText:"Secure Port Details",overlayBackground:true,buttons:[{buttonText:"Ok",handler:{click:function(){$("#secure-port-details").modal("hide")
}}}],handler:{close:function(){nf.Common.clearField("read-only-secure-port-name");
nf.Common.clearField("read-only-secure-port-id");
nf.Common.clearField("read-only-secure-port-comments");
nf.Common.clearField("read-only-secure-port-concurrent-tasks");
$("#read-only-allowed-users").empty();
$("#read-only-allowed-groups").empty()
}}}).draggable({containment:"parent",handle:".dialog-header"})
},showDetails:function(c){if(nf.CanvasUtils.isInputPort(c)||nf.CanvasUtils.isOutputPort(c)){var d=c.datum();
nf.Common.populateField("read-only-secure-port-name",d.component.name);
nf.Common.populateField("read-only-secure-port-id",d.component.id);
nf.Common.populateField("read-only-secure-port-concurrent-tasks",d.component.concurrentlySchedulableTaskCount);
nf.Common.populateField("read-only-secure-port-comments",d.component.comments);
$.each(d.component.userAccessControl,function(e,f){b(f)
});
$.each(d.component.groupAccessControl,function(f,e){a(e)
});
$("#secure-port-details").modal("show")
}}}
}());