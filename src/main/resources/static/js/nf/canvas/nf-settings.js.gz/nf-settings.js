nf.Settings=(function(){var a={urls:{controllerConfig:"../nifi-api/controller/config",controllerArchive:"../nifi-api/controller/archive"}};
var b=function(){var c={};
c.name=$("#data-flow-title-field").val();
c.comments=$("#data-flow-comments-field").val();
c.maxTimerDrivenThreadCount=$("#maximum-timer-driven-thread-count-field").val();
c.maxEventDrivenThreadCount=$("#maximum-event-driven-thread-count-field").val();
return c
};
return{init:function(){$("#archive-flow-link").click(function(){var c=nf.Client.getRevision();
$.ajax({type:"POST",url:a.urls.controllerArchive,data:{version:c.version,clientId:c.clientId},dataType:"json"}).done(function(d){nf.Client.setRevision(d.revision);
nf.Dialog.showOkDialog({dialogContent:"A new flow archive was successfully created.",overlayBackground:false})
}).fail(function(f,d,e){$("#settings-cancel").click();
nf.Common.handleAjaxError(f,d,e)
})
});
$("#settings-save").click(function(){var c=nf.Client.getRevision();
var d=b();
d.version=c.version;
d.clientId=c.clientId;
$.ajax({type:"PUT",url:a.urls.controllerConfig,data:d,dataType:"json"}).done(function(e){nf.Client.setRevision(e.revision);
document.title=e.config.name;
$("#data-flow-title-container").children("span.link:first-child").text(e.config.name);
$("#shell-close-button").click()
}).fail(function(g,e,f){$("#settings-cancel").click();
nf.Common.handleAjaxError(g,e,f)
})
});
$("#settings-cancel").click(function(){$("#shell-close-button").click()
})
},showSettings:function(){$.ajax({type:"GET",url:a.urls.controllerConfig,dataType:"json"}).done(function(c){if(nf.Common.isDefinedAndNotNull(c.config)){$("#settings-header-text").text(c.config.name+" Settings");
$("#data-flow-title-field").val(c.config.name);
$("#data-flow-comments-field").val(c.config.comments);
$("#maximum-timer-driven-thread-count-field").val(c.config.maxTimerDrivenThreadCount);
$("#maximum-event-driven-thread-count-field").val(c.config.maxEventDrivenThreadCount)
}nf.Shell.showContent("#settings").done(function(){$("#settings-save, #settings-cancel").mouseout()
})
}).fail(nf.Common.handleAjaxError)
}}
}());