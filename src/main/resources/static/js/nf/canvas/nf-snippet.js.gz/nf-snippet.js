nf.Snippet=(function(){var a={urls:{snippets:"../nifi-api/controller/snippets",processGroups:"../nifi-api/controller/process-groups"}};
return{marshal:function(b,d){var c={parentGroupId:nf.Canvas.getGroupId(),linked:nf.Common.isDefinedAndNotNull(d)?d:false,processorIds:[],funnelIds:[],inputPortIds:[],outputPortIds:[],remoteProcessGroupIds:[],processGroupIds:[],connectionIds:[],labelIds:[]};
b.each(function(f){var e=d3.select(this);
if(nf.CanvasUtils.isProcessor(e)){c.processorIds.push(f.component.id)
}else{if(nf.CanvasUtils.isFunnel(e)){c.funnelIds.push(f.component.id)
}else{if(nf.CanvasUtils.isLabel(e)){c.labelIds.push(f.component.id)
}else{if(nf.CanvasUtils.isInputPort(e)){c.inputPortIds.push(f.component.id)
}else{if(nf.CanvasUtils.isOutputPort(e)){c.outputPortIds.push(f.component.id)
}else{if(nf.CanvasUtils.isProcessGroup(e)){c.processGroupIds.push(f.component.id)
}else{if(nf.CanvasUtils.isRemoteProcessGroup(e)){c.remoteProcessGroupIds.push(f.component.id)
}else{if(nf.CanvasUtils.isConnection(e)){c.connectionIds.push(f.component.id)
}}}}}}}}});
return c
},create:function(c){var b=nf.Client.getRevision();
return $.ajax({type:"POST",url:a.urls.snippets,data:$.extend({version:b.version,clientId:b.clientId},c),dataType:"json"}).done(function(d){nf.Client.setRevision(d.revision)
})
},copy:function(e,d,b){var c=nf.Client.getRevision();
return $.ajax({type:"POST",url:a.urls.processGroups+"/"+encodeURIComponent(d)+"/snippet-instance",data:{version:c.version,clientId:c.clientId,snippetId:e,originX:b.x,originY:b.y},dataType:"json"}).done(function(f){nf.Client.setRevision(f.revision)
})
},remove:function(c){var b=nf.Client.getRevision();
return $.ajax({type:"DELETE",url:a.urls.snippets+"/"+encodeURIComponent(c)+"?"+$.param({version:b.version,clientId:b.clientId})}).done(function(d){nf.Client.setRevision(d.revision)
})
},move:function(c,d){var b=nf.Client.getRevision();
return $.ajax({type:"PUT",url:a.urls.snippets+"/"+encodeURIComponent(c),data:{version:b.version,clientId:b.clientId,parentGroupId:d},dataType:"json"}).done(function(e){nf.Client.setRevision(e.revision)
})
},unlink:function(c){var b=nf.Client.getRevision();
return $.ajax({type:"PUT",url:a.urls.snippets+"/"+encodeURIComponent(c),data:{version:b.version,clientId:b.clientId,linked:false},dataType:"json"}).done(function(d){nf.Client.setRevision(d.revision)
})
},link:function(c){var b=nf.Client.getRevision();
return $.ajax({type:"PUT",url:a.urls.snippets+"/"+encodeURIComponent(c),data:{version:b.version,clientId:b.clientId,linked:true},dataType:"json"}).done(function(d){nf.Client.setRevision(d.revision)
})
}}
}());