nf.Storage=(function(){var c=86400000*2;
var a;
var b=(function(){var f="test";
try{localStorage.setItem(f,f);
localStorage.removeItem(f);
return true
}catch(d){return false
}}());
return{init:function(){if(b){for(var h=0;
h<localStorage.length;
h++){try{var g=localStorage.key(h);
var j=JSON.parse(localStorage.getItem(g));
var d=new Date(j.expires);
var f=new Date();
if(d.valueOf()<f.valueOf()){localStorage.removeItem(g)
}}catch(k){}}}else{a=d3.map()
}},setItem:function(e,g){if(b){var d=new Date().valueOf()+c;
var f={expires:d,item:g};
localStorage.setItem(e,JSON.stringify(f))
}else{a.set(e,g)
}},getItem:function(d){if(b){try{var f=JSON.parse(localStorage.getItem(d));
if(nf.Common.isDefinedAndNotNull(f)&&nf.Common.isDefinedAndNotNull(f.item)){return f.item
}else{return null
}}catch(g){return null
}}else{return a.get(d)
}},removeItem:function(d){if(b){localStorage.removeItem(d)
}else{a.remove(d)
}}}
}());