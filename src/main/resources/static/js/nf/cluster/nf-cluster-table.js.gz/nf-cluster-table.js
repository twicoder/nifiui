nf.ClusterTable=(function(){var b={filterText:"Filter",styles:{filterList:"cluster-filter-list"},urls:{cluster:"../nifi-api/cluster",nodes:"../nifi-api/cluster/nodes"}};
var h,f;
var c=function(l,n){var m=function(z,y){if(l.columnId==="heartbeat"||l.columnId==="uptime"){var s=nf.Common.parseDateTime(z[l.columnId]);
var p=nf.Common.parseDateTime(y[l.columnId]);
return s.getTime()-p.getTime()
}else{if(l.columnId==="queued"){var t=z[l.columnId].split(/ \/ /);
var w=y[l.columnId].split(/ \/ /);
var x=f%4;
if(x<2){$("#cluster-table span.queued-title").addClass("sorted");
var q=nf.Common.parseCount(t[0]);
var v=nf.Common.parseCount(w[0]);
return q-v
}else{$("#cluster-table span.queued-size-title").addClass("sorted");
var C=nf.Common.parseSize(t[1]);
var B=nf.Common.parseSize(w[1]);
return C-B
}}else{if(l.columnId==="status"){var u=nf.Common.isDefinedAndNotNull(z[l.columnId])?z[l.columnId]:"";
if(z.primary===true){u+=", PRIMARY"
}var A=nf.Common.isDefinedAndNotNull(y[l.columnId])?y[l.columnId]:"";
if(y.primary===true){A+=", PRIMARY"
}return u===A?0:u>A?1:-1
}else{if(l.columnId==="node"){var r=g(z);
var o=g(y);
return r===o?0:r>o?1:-1
}else{var u=nf.Common.isDefinedAndNotNull(z[l.columnId])?z[l.columnId]:"";
var A=nf.Common.isDefinedAndNotNull(y[l.columnId])?y[l.columnId]:"";
return u===A?0:u>A?1:-1
}}}}};
$("#cluster-table span.queued-title").removeClass("sorted");
$("#cluster-table span.queued-size-title").removeClass("sorted");
if(h!==l.columnId){f=0
}else{f++
}n.sort(m,l.sortAsc);
h=l.columnId
};
var g=function(l){return nf.Common.escapeHtml(l.address)+":"+nf.Common.escapeHtml(l.apiPort)
};
var k=function(l){$.ajax({type:"PUT",url:b.urls.nodes+"/"+encodeURIComponent(l),data:{status:"CONNECTING"},dataType:"json"}).done(function(n){var o=n.node;
var p=$("#cluster-table").data("gridInstance");
var m=p.getData();
m.updateItem(o.nodeId,o)
}).fail(nf.Common.handleAjaxError)
};
var j=function(l){$.ajax({type:"PUT",url:b.urls.nodes+"/"+encodeURIComponent(l),data:{status:"DISCONNECTING"},dataType:"json"}).done(function(n){var o=n.node;
var p=$("#cluster-table").data("gridInstance");
var m=p.getData();
m.updateItem(o.nodeId,o)
}).fail(nf.Common.handleAjaxError)
};
var d=function(l){$.ajax({type:"DELETE",url:b.urls.nodes+"/"+encodeURIComponent(l),dataType:"json"}).done(function(){var n=$("#cluster-table").data("gridInstance");
var m=n.getData();
m.deleteItem(l)
}).fail(nf.Common.handleAjaxError)
};
var i=function(){var m="";
var l=$("#cluster-filter");
if(!l.hasClass(b.styles.filterList)){m=l.val()
}return m
};
var e=function(){var m=$("#cluster-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(m)){var l=m.getData();
l.setFilterArgs({searchString:i(),property:$("#cluster-filter-type").combo("getSelectedOption").value});
l.refresh()
}};
var a=function(m,l){if(l.searchString===""){return true
}try{var o=new RegExp(l.searchString,"i")
}catch(n){return false
}return m[l.property].search(o)>=0
};
return{init:function(){$("#node-details-dialog").modal({headerText:"Node Details",overlayBackground:false,buttons:[{buttonText:"Ok",handler:{click:function(){$("#node-details-dialog").modal("hide")
}}}],handler:{close:function(){$("#node-address").text("");
$("#node-id").text("");
$("#node-events").empty()
}}});
$("#cluster-filter").keyup(function(){e()
}).focus(function(){if($(this).hasClass(b.styles.filterList)){$(this).removeClass(b.styles.filterList).val("")
}}).blur(function(){if($(this).val()===""){$(this).addClass(b.styles.filterList).val(b.filterText)
}}).addClass(b.styles.filterList).val(b.filterText);
$("#cluster-filter-type").combo({options:[{text:"by address",value:"address"},{text:"by status",value:"status"}],select:function(u){e()
}});
$(window).resize(function(){nf.ClusterTable.resetTableSize()
});
var t=function(y,v,x,w,u){return'<img src="images/iconDetails.png" title="View Details" class="pointer" style="margin-top: 4px;" onclick="javascript:nf.ClusterTable.showNodeDetails(\''+y+"');\"/>"
};
var o=function(y,v,x,w,u){return g(u)
};
var l=function(y,v,x,w,u){if(u.primary===true){return x+", PRIMARY"
}else{return x
}};
var r=function(y,v,x,w,u){return nf.Common.formatValue(x)
};
var p=[{id:"moreDetails",name:"&nbsp;",sortable:false,resizable:false,formatter:t,width:50,maxWidth:50},{id:"node",field:"node",name:"Node Address",formatter:o,resizable:true,sortable:true},{id:"activeThreadCount",field:"activeThreadCount",name:"Active Thread Count",resizable:true,sortable:true},{id:"queued",field:"queued",name:'<span class="queued-title">Queue</span>&nbsp;/&nbsp;<span class="queued-size-title">Size</span>',resizable:true,sortable:true},{id:"status",field:"status",name:"Status",formatter:l,resizable:true,sortable:true},{id:"uptime",field:"nodeStartTime",name:"Uptime",formatter:r,resizable:true,sortable:true},{id:"heartbeat",field:"heartbeat",name:"Last Heartbeat",formatter:r,resizable:true,sortable:true}];
if(nf.Common.isAdmin()){var q=function(D,C,B,y,v){var z=false;
var x=false;
var u=false;
var A=v.primary;
if(v.status==="CONNECTED"||v.status==="CONNECTING"){if(A===false&&v.status==="CONNECTED"){u=true
}z=true
}else{if(v.status==="DISCONNECTED"){x=true
}}if(x){return'<img src="images/iconConnect.png" title="Connect" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.ClusterTable.promptForConnect(\''+D+'\');"/>&nbsp;<img src="images/iconDelete.png" title="Remove" class="pointer" onclick="javascript:nf.ClusterTable.promptForRemoval(\''+D+"');\"/>"
}else{if(z){var w='<img src="images/iconDisconnect.png" title="Disconnect" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.ClusterTable.promptForDisconnect(\''+D+"');\"/>";
if(u){w+='&nbsp;<img src="images/iconPrimary.png" title="Make Primary" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.ClusterTable.makePrimary(\''+D+"');\"/>"
}return w
}else{return'<div style="width: 16px; height: 16px;">&nbsp;</div>'
}}};
p.push({id:"action",label:"&nbsp;",formatter:q,resizable:false,sortable:false,width:80,maxWidth:80})
}var m={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:false,enableColumnReorder:false,autoEdit:false};
var n=new Slick.Data.DataView({inlineFilters:false});
n.setItems([],"nodeId");
n.setFilterArgs({searchString:i(),property:$("#cluster-filter-type").combo("getSelectedOption").value});
n.setFilter(a);
c({columnId:"userName",sortAsc:true},n);
var s=new Slick.Grid("#cluster-table",n,p,m);
s.setSelectionModel(new Slick.RowSelectionModel());
s.setSortColumn("node",true);
s.onSort.subscribe(function(v,u){c({columnId:u.sortCol.field,sortAsc:u.sortAsc},n)
});
n.onRowCountChanged.subscribe(function(v,u){s.updateRowCount();
s.render();
$("#displayed-nodes").text(u.current)
});
n.onRowsChanged.subscribe(function(v,u){s.invalidateRows(u.rows);
s.render()
});
$("#cluster-table").data("gridInstance",s);
$("#displayed-nodes").text("0")
},promptForConnect:function(o){var l=$("#cluster-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(l)){var n=l.getData();
var m=n.getItem(o);
nf.Dialog.showYesNoDialog({dialogContent:"Connect '"+g(m)+"' to this cluster?",overlayBackground:false,yesHandler:function(){k(m.nodeId)
}})
}},promptForDisconnect:function(o){var l=$("#cluster-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(l)){var n=l.getData();
var m=n.getItem(o);
nf.Dialog.showYesNoDialog({dialogContent:"Disconnect '"+g(m)+"' from the cluster?",overlayBackground:false,yesHandler:function(){j(m.nodeId)
}})
}},makePrimary:function(o){var l=$("#cluster-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(l)){var n=l.getData();
var m=n.getItem(o);
$.ajax({type:"PUT",url:b.urls.nodes+"/"+encodeURIComponent(m.nodeId),data:{primary:true},dataType:"json"}).done(function(p){var q=p.node;
n.beginUpdate();
n.updateItem(q.nodeId,q);
var r=n.getItems();
$.each(r,function(t,s){if(q.nodeId!==s.nodeId&&s.primary===true){s.primary=false;
s.status="CONNECTED";
n.updateItem(s.nodeId,s);
return false
}});
n.endUpdate()
}).fail(nf.Common.handleAjaxError)
}},promptForRemoval:function(o){var l=$("#cluster-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(l)){var n=l.getData();
var m=n.getItem(o);
nf.Dialog.showYesNoDialog({dialogContent:"Remove '"+g(m)+"' from the cluster?",overlayBackground:false,yesHandler:function(){d(m.nodeId)
}})
}},resetTableSize:function(){var l=$("#cluster-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(l)){l.resizeCanvas()
}},loadClusterTable:function(){return $.ajax({type:"GET",url:b.urls.cluster,dataType:"json"}).done(function(n){var l=n.cluster;
if(nf.Common.isDefinedAndNotNull(l.nodes)){var o=$("#cluster-table").data("gridInstance");
var m=o.getData();
m.setItems(l.nodes);
m.reSort();
o.invalidate();
$("#cluster-last-refreshed").text(l.generated);
$("#total-nodes").text(l.nodes.length)
}else{$("#total-nodes").text("0")
}}).fail(nf.Common.handleAjaxError)
},showNodeDetails:function(o){var l=$("#cluster-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(l)){var n=l.getData();
var m=n.getItem(o);
$.ajax({type:"GET",url:b.urls.nodes+"/"+encodeURIComponent(m.nodeId),dataType:"json"}).done(function(q){var s=q.node;
$("#node-id").text(s.nodeId);
$("#node-address").text(g(s));
var r=$("#node-events");
if($.isArray(s.events)&&s.events.length>0){var p=[];
$.each(s.events,function(t,u){p.push(u.timestamp+": "+u.message)
});
$("<div></div>").append(nf.Common.formatUnorderedList(p)).appendTo(r)
}else{r.append('<div><span class="unset">None</span></div>')
}$("#node-details-dialog").modal("show")
}).fail(nf.Common.handleAjaxError)
}}}
}());