nf.CountersTable=(function(){var b={filterText:"Filter",styles:{filterList:"counters-filter-list"},urls:{counters:"../nifi-api/controller/counters"}};
var c=function(f,h){var g=function(k,i){if(f.columnId==="value"){var n=nf.Common.parseCount(k[f.columnId]);
var m=nf.Common.parseCount(i[f.columnId]);
return n-m
}else{var j=nf.Common.isDefinedAndNotNull(k[f.columnId])?k[f.columnId]:"";
var l=nf.Common.isDefinedAndNotNull(i[f.columnId])?i[f.columnId]:"";
return j===l?0:j>l?1:-1
}};
h.sort(g,f.sortAsc)
};
var e=function(){var g="";
var f=$("#counters-filter");
if(!f.hasClass(b.styles.filterList)){g=f.val()
}return g
};
var a=function(){var f=$("#counters-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(f)){var g=f.getData();
g.setFilterArgs({searchString:e(),property:$("#counters-filter-type").combo("getSelectedOption").value});
g.refresh()
}};
var d=function(g,f){if(f.searchString===""){return true
}try{var i=new RegExp(f.searchString,"i")
}catch(h){return false
}return g[f.property].search(i)>=0
};
return{init:function(){$("#counters-filter").keyup(function(){a()
}).focus(function(){if($(this).hasClass(b.styles.filterList)){$(this).removeClass(b.styles.filterList).val("")
}}).blur(function(){if($(this).val()===""){$(this).addClass(b.styles.filterList).val(b.filterText)
}}).addClass(b.styles.filterList).val(b.filterText);
$("#counters-filter-type").combo({options:[{text:"by name",value:"name"},{text:"by context",value:"context"}],select:function(k){a()
}});
$(window).resize(function(){nf.CountersTable.resetTableSize()
});
var h=[{id:"context",name:"Context",field:"context",sortable:true,resizable:true},{id:"name",name:"Name",field:"name",sortable:true,resizable:true},{id:"value",name:"Value",field:"value",sortable:true,resizable:true}];
if(nf.Common.isDFM()){var j=function(o,l,n,m,k){return'<img src="images/iconResetCounter.png" title="Reset" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.CountersTable.resetCounter(\''+o+"');\"/>"
};
h.push({id:"actions",name:"&nbsp;",sortable:false,resizable:false,formatter:j,width:100,maxWidth:100})
}var g={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:false,enableColumnReorder:false,autoEdit:false};
var i=new Slick.Data.DataView({inlineFilters:false});
i.setItems([]);
i.setFilterArgs({searchString:e(),property:$("#counters-filter-type").combo("getSelectedOption").value});
i.setFilter(d);
c({columnId:"context",sortAsc:true},i);
var f=new Slick.Grid("#counters-table",i,h,g);
f.setSelectionModel(new Slick.RowSelectionModel());
f.registerPlugin(new Slick.AutoTooltips());
f.setSortColumn("context",true);
f.onSort.subscribe(function(l,k){c({columnId:k.sortCol.field,sortAsc:k.sortAsc},i)
});
i.onRowCountChanged.subscribe(function(l,k){f.updateRowCount();
f.render();
$("#displayed-counters").text(k.current)
});
i.onRowsChanged.subscribe(function(l,k){f.invalidateRows(k.rows);
f.render()
});
$("#counters-table").data("gridInstance",f);
$("#displayed-counters").text("0")
},resetCounter:function(i){var f=$("#counters-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(f)){var h=f.getData();
var g=h.getItem(i);
$.ajax({type:"PUT",url:b.urls.counters+"/"+encodeURIComponent(g.id),dataType:"json"}).done(function(l){var j=l.counter;
var k=$("#counters-table").data("gridInstance");
var m=k.getData();
m.updateItem(j.id,j)
}).fail(nf.Common.handleAjaxError)
}},resetTableSize:function(){var f=$("#counters-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(f)){f.resizeCanvas()
}},loadCountersTable:function(){return $.ajax({type:"GET",url:b.urls.counters,dataType:"json"}).done(function(h){var f=h.counters;
if(nf.Common.isDefinedAndNotNull(f.counters)){var g=$("#counters-table").data("gridInstance");
var i=g.getData();
i.setItems(f.counters);
i.reSort();
g.invalidate();
$("#counters-last-refreshed").text(f.generated);
$("#total-counters").text(f.counters.length)
}else{$("#total-counters").text("0")
}}).fail(nf.Common.handleAjaxError)
}}
}());