$(document).ready(function(){nf.Counters.init()
});
nf.Counters=(function(){var b={urls:{banners:"../nifi-api/controller/banners",controllerAbout:"../nifi-api/controller/about",authorities:"../nifi-api/controller/authorities"}};
var c=function(){return $.Deferred(function(d){$.ajax({type:"GET",url:b.urls.authorities,dataType:"json"}).done(function(e){if(nf.Common.isDefinedAndNotNull(e.authorities)){nf.Common.setAuthorities(e.authorities);
d.resolve()
}else{d.reject()
}}).fail(function(g,e,f){nf.Common.handleAjaxError(g,e,f);
d.reject()
})
}).promise()
};
var a=function(){nf.Common.addHoverEffect("#refresh-button","button-refresh","button-refresh-hover").click(function(){nf.CountersTable.loadCountersTable()
});
return $.Deferred(function(d){if(top===window){$.ajax({type:"GET",url:b.urls.banners,dataType:"json"}).done(function(i){if(nf.Common.isDefinedAndNotNull(i.banners)){if(nf.Common.isDefinedAndNotNull(i.banners.headerText)&&i.banners.headerText!==""){var f=$("#banner-header").text(i.banners.headerText).show();
var h=function(j){var k=$("#"+j);
k.css("top",(parseInt(f.css("height"),10)+parseInt(k.css("top"),10))+"px")
};
h("counters")
}if(nf.Common.isDefinedAndNotNull(i.banners.footerText)&&i.banners.footerText!==""){var e=$("#banner-footer").text(i.banners.footerText).show();
var g=function(j){var k=$("#"+j);
k.css("bottom",parseInt(e.css("height"),10)+"px")
};
g("counters")
}}d.resolve()
}).fail(function(g,e,f){nf.Common.handleAjaxError(g,e,f);
d.reject()
})
}else{d.resolve()
}}).promise()
};
return{init:function(){c().done(function(){nf.CountersTable.init();
nf.CountersTable.loadCountersTable().done(function(){a().done(function(){nf.CountersTable.resetTableSize();
$.ajax({type:"GET",url:b.urls.controllerAbout,dataType:"json"}).done(function(e){var d=e.about;
var f=d.title+" Counters";
document.title=f;
$("#counters-header-text").text(f)
}).fail(nf.Common.handleAjaxError)
})
})
})
}}
}());