(function(b){function a(){var i=50;
var t={length:0};
var o={};
var c=null;
var m=1;
var g=null;
var j=null;
var r=new Slick.Event();
var n=new Slick.Event();
var s=function(){};
var k=function(w,v){for(var u=w;
u<=v;
u++){if(t[u]===undefined||t[u]===null){return false
}}return true
};
var q=function(){for(var u in t){delete t[u]
}t.length=0
};
var f=function(z,y){if(j){j.abort();
for(var u=j.fromPage;
u<=j.toPage;
u++){t[u*i]=undefined
}}if(z<0){z=0
}var x=Math.floor(z/i);
var v=Math.floor(y/i);
while(t[x*i]!==undefined&&x<v){x++
}while(t[v*i]!==undefined&&x<v){v--
}if(x>v||((x===v)&&t[x*i]!==undefined)){return
}var w={};
w=b.extend({count:((v-x)*i)+i,offset:x*i},w);
if(c!==null){w.sortColumn=c;
w.sortOrder=(m>0)?"asc":"desc"
}w=b.extend(w,o);
if(g!==null){clearTimeout(g)
}g=setTimeout(function(){for(var A=x;
A<=v;
A++){t[A*i]=null
}r.notify({from:z,to:y});
var B=b.ajax({type:"GET",url:"../nifi-api/controller/history",data:w,dataType:"json"}).done(function(C){var E=C.history;
var G=x*i;
var F=G+E.actions.length;
t.length=E.total;
for(var D=0;
D<E.actions.length;
D++){t[G+D]=E.actions[D];
t[G+D].index=G+D
}b("#history-last-refreshed").text(E.lastRefreshed);
b(".timezone").text(nf.Common.substringAfterLast(E.lastRefreshed," "));
if(w.sourceId||w.userName||w.startDate||w.endDate){b("#history-filter-overview").show()
}else{b("#history-filter-overview").hide()
}B=null;
n.notify({from:G,to:F})
}).fail(nf.Common.handleAjaxError);
B.fromPage=x;
B.toPage=v
},50)
};
var h=function(w,v){for(var u=w;
u<=v;
u++){delete t[u]
}f(w,v)
};
var e=function(v,u){c=v;
m=u;
q()
};
var p=function(u){o=u;
q()
};
var l=function(u){return t[u]
};
var d=function(){return t.length
};
s();
return{data:t,clear:q,isDataLoaded:k,ensureData:f,reloadData:h,setSort:e,setFilterArgs:p,getItem:l,getLength:d,onDataLoading:r,onDataLoaded:n}
}b.extend(true,window,{nf:{HistoryModel:a}})
})(jQuery);