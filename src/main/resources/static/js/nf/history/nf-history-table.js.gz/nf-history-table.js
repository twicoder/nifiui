nf.HistoryTable=(function(){var d={defaultStartTime:"00:00:00",defaultEndTime:"23:59:59",filterText:"Filter",styles:{filterList:"filter-list",hidden:"hidden"},urls:{history:"../nifi-api/controller/history"}};
var f=function(){$("#action-details-dialog").modal({headerText:"Action Details",overlayBackground:false,buttons:[{buttonText:"Ok",handler:{click:function(){$("#action-details-dialog").modal("hide")
}}}],handler:{close:function(){$("#action-details").empty()
}}})
};
var c=function(){$("#history-filter").val("");
$("#history-filter-type").combo({options:[{text:"by source id",value:"by source id"},{text:"by user",value:"by user"}]});
$("#history-filter-start-date, #history-filter-end-date").datepicker({showAnim:"",showOtherMonths:true,selectOtherMonths:true});
$("#history-filter-start-date").datepicker("setDate","-14d");
$("#history-filter-end-date").datepicker("setDate","+0d");
$("#history-filter-start-time").val(d.defaultStartTime);
$("#history-filter-end-time").val(d.defaultEndTime);
$("#history-filter-dialog").modal({headerText:"Filter History",overlayBackground:false,buttons:[{buttonText:"Filter",handler:{click:function(){$("#history-filter-dialog").modal("hide");
var h={};
var k=$("#history-filter").val();
if(k!==""){var g=$("#history-filter-type").combo("getSelectedOption").text;
if(g==="by source id"){h.sourceId=k
}else{if(g==="by user"){h.userName=k
}}}var j=$.trim($("#history-filter-start-date").val());
var i=$.trim($("#history-filter-start-time").val());
if(j!==""){if(i===""){i=d.defaultStartTime;
$("#history-filter-start-time").val(i)
}h.startDate=j+" "+i
}var m=$.trim($("#history-filter-end-date").val());
var n=$.trim($("#history-filter-end-time").val());
if(m!==""){if(n===""){n=d.defaultEndTime;
$("#history-filter-end-time").val(n)
}h.endDate=m+" "+n
}var o=$("#history-table").data("gridInstance");
var l=o.getData();
l.setFilterArgs(h);
nf.HistoryTable.loadHistoryTable()
}}},{buttonText:"Cancel",handler:{click:function(){$("#history-filter-dialog").modal("hide")
}}}]})
};
var a=function(){$("#history-purge-end-date").datepicker({showAnim:"",showOtherMonths:true,selectOtherMonths:true});
$("#history-purge-end-date").datepicker("setDate","-1m");
$("#history-purge-end-time").val(d.defaultStartTime);
$("#history-purge-dialog").modal({headerText:"Purge History",overlayBackground:false,buttons:[{buttonText:"Purge",handler:{click:function(){$("#history-purge-dialog").modal("hide");
var j=$.trim($("#history-purge-end-date").val());
var g=$.trim($("#history-purge-end-time").val());
if(j!==""){if(g===""){g=d.defaultStartTime;
$("#history-purge-end-time").val(g)
}var h=j+" "+g;
var i=$(".timezone:first").text();
nf.Dialog.showYesNoDialog({dialogContent:"Are you sure you want to delete all history before '"+nf.Common.escapeHtml(h)+" "+nf.Common.escapeHtml(i)+"'?",overlayBackground:false,yesHandler:function(){e(h)
}})
}else{nf.Dialog.showOkDialog({dialogContent:"The end date must be specified.",overlayBackground:false})
}}}},{buttonText:"Cancel",handler:{click:function(){$("#history-purge-dialog").modal("hide")
}}}]})
};
var b=function(){$(window).resize(function(){nf.HistoryTable.resetTableSize()
});
$("#clear-history-filter").click(function(){$("#history-filter-overview").hide();
var m=$("#history-table").data("gridInstance");
var l=m.getData();
l.setFilterArgs({});
nf.HistoryTable.loadHistoryTable()
});
nf.Common.addHoverEffect("#history-filter-button","button-normal","button-over").click(function(){$("#history-filter-dialog").modal("show")
});
var h=function(p,m,o,n,l){return'<img src="images/iconDetails.png" title="View Details" class="pointer" style="margin-top: 4px;" onclick="javascript:nf.HistoryTable.showActionDetails(\''+p+"');\"/>"
};
var i=[{id:"moreDetails",name:"&nbsp;",sortable:false,resizable:false,formatter:h,width:50,maxWidth:50},{id:"timestamp",name:"Date/Time",field:"timestamp",sortable:true,resizable:true},{id:"sourceName",name:"Name",field:"sourceName",sortable:true,resizable:true},{id:"sourceType",name:"Type",field:"sourceType",sortable:true,resizable:true},{id:"operation",name:"Operation",field:"operation",sortable:true,resizable:true},{id:"userName",name:"User",field:"userName",sortable:true,resizable:true}];
var g={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:false,enableColumnReorder:false,autoEdit:false};
var k=new nf.HistoryModel();
var j=new Slick.Grid("#history-table",k,i,g);
j.setSelectionModel(new Slick.RowSelectionModel());
j.registerPlugin(new Slick.AutoTooltips());
j.onSort.subscribe(function(n,m){k.setSort(m.sortCol.field,m.sortAsc?1:-1);
var l=j.getViewport();
k.ensureData(l.top,l.bottom)
});
j.setSortColumn("timestamp",false);
j.onViewportChanged.subscribe(function(n,m){var l=j.getViewport();
k.ensureData(l.top,l.bottom)
});
k.onDataLoaded.subscribe(function(n,l){for(var m=l.from;
m<=l.to;
m++){j.invalidateRow(m)
}j.updateRowCount();
j.render()
});
$("#history-table").data("gridInstance",j);
if(nf.Common.isAdmin()){$("#history-purge-button").on("click",function(){$("#history-purge-dialog").modal("show")
}).show()
}};
var e=function(g){$.ajax({type:"DELETE",url:d.urls.history+"?"+$.param({endDate:g}),dataType:"json"}).done(function(){nf.HistoryTable.loadHistoryTable()
}).fail(nf.Common.handleAjaxError)
};
return{init:function(){f();
c();
a();
b()
},resetTableSize:function(){var g=$("#history-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(g)){g.resizeCanvas()
}},loadHistoryTable:function(){var h=$("#history-table").data("gridInstance");
var g=h.getData();
g.clear();
h.onViewportChanged.notify()
},showActionDetails:function(g){var k=$("#history-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(k)){var j=k.getData();
var i=j.getItem(g);
var h=$("<div></div>").append($('<div class="action-detail"><div class="history-details-name">Id</div>'+nf.Common.escapeHtml(i.sourceId)+"</div>"));
var m=i.componentDetails;
if(nf.Common.isDefinedAndNotNull(m)){if(i.sourceType==="Processor"){h.append($('<div class="action-detail"><div class="history-details-name">Type</div>'+nf.Common.escapeHtml(m.type)+"</div>"))
}else{if(i.sourceType==="RemoteProcessGroup"){h.append($('<div class="action-detail"><div class="history-details-name">Uri</div>'+nf.Common.formatValue(m.uri)+"</div>"))
}}}var l=i.actionDetails;
if(nf.Common.isDefinedAndNotNull(l)){if(i.operation==="Configure"){h.append($('<div class="action-detail"><div class="history-details-name">Name</div>'+nf.Common.formatValue(l.name)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Value</div>'+nf.Common.formatValue(l.value)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Previous Value</div>'+nf.Common.formatValue(l.previousValue)+"</div>"))
}else{if(i.operation==="Connect"||i.operation==="Disconnect"){h.append($('<div class="action-detail"><div class="history-details-name">Source Id</div>'+nf.Common.escapeHtml(l.sourceId)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Source Name</div>'+nf.Common.formatValue(l.sourceName)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Source Type</div>'+nf.Common.escapeHtml(l.sourceType)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Relationship(s)</div>'+nf.Common.formatValue(l.relationship)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Destination Id</div>'+nf.Common.escapeHtml(l.destinationId)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Destination Name</div>'+nf.Common.formatValue(l.destinationName)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Destination Type</div>'+nf.Common.escapeHtml(l.destinationType)+"</div>"))
}else{if(i.operation==="Move"){h.append($('<div class="action-detail"><div class="history-details-name">Group</div>'+nf.Common.formatValue(l.group)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Group Id</div>'+nf.Common.escapeHtml(l.groupId)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Previous Group</div>'+nf.Common.formatValue(l.previousGroup)+"</div>")).append($('<div class="action-detail"><div class="history-details-name">Previous Group Id</div>'+nf.Common.escapeHtml(l.previousGroupId)+"</div>"))
}else{if(i.operation==="Purge"){h.append($('<div class="action-detail"><div class="history-details-name">End Date</div>'+nf.Common.escapeHtml(l.endDate)+"</div>"))
}}}}}$("#action-details").append(h);
$("#action-details-dialog").modal("show")
}}}
}());