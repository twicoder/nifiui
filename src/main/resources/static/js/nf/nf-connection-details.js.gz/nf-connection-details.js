nf.ConnectionDetails=(function(){var g=function(l,n,m){if(m.type==="PROCESSOR"){return h(l,n,m)
}else{if(m.type==="FUNNEL"){return i(l,n,m)
}else{if(m.type==="REMOTE_OUTPUT_PORT"){return d(l,n,m)
}else{return k(l,n,m)
}}}};
var h=function(l,n,m){return $.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(l)+"/processors/"+encodeURIComponent(m.id),dataType:"json"}).done(function(o){var p=o.processor;
var q=$('<div class="label"></div>').text(p.name);
var r=$("<div></div>").text(nf.Common.substringAfterLast(p.type,"."));
$("#read-only-connection-source-label").text("From processor");
$("#read-only-connection-source").append(q).append(r);
$("#read-only-connection-source-group-name").text(n)
})
};
var i=function(l,n,m){return $.Deferred(function(o){$("#read-only-connection-source-label").text("From funnel");
$("#read-only-connection-source").append("funnel");
$("#read-only-connection-source-group-name").text(n);
o.resolve()
}).promise()
};
var d=function(l,n,m){return $.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(l)+"/remote-process-groups/"+encodeURIComponent(m.groupId),data:{verbose:true},dataType:"json"}).done(function(o){var p=o.remoteProcessGroup;
$("#read-only-connection-source-label").text("From output");
$("#read-only-connection-source").text(m.name);
$("#read-only-connection-source-group-name").text(p.name)
})
};
var k=function(l,n,m){return $.Deferred(function(o){if(l===m.groupId){$("#read-only-connection-source-label").text("From input");
$("#read-only-connection-source").text(m.name);
$("#read-only-connection-source-group-name").text(n);
o.resolve()
}else{$.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(m.groupId),data:{verbose:true},dataType:"json"}).done(function(p){var q=p.processGroup;
$("#read-only-connection-source-label").text("From output");
$("#read-only-connection-source").text(m.name);
$("#read-only-connection-source-group-name").text(q.name);
o.resolve()
}).fail(function(){o.reject()
})
}}).promise()
};
var c=function(m,n,l){if(l.type==="PROCESSOR"){return a(m,n,l)
}else{if(l.type==="FUNNEL"){return j(m,n,l)
}else{if(l.type==="REMOTE_INPUT_PORT"){return f(m,n,l)
}else{return b(m,n,l)
}}}};
var a=function(m,n,l){return $.Deferred(function(o){$.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(m)+"/processors/"+encodeURIComponent(l.id),dataType:"json"}).done(function(p){var q=p.processor;
var r=$('<div class="label"></div>').text(q.name);
var s=$("<div></div>").text(nf.Common.substringAfterLast(q.type,"."));
$("#read-only-connection-target-label").text("To processor");
$("#read-only-connection-target").append(r).append(s);
$("#read-only-connection-target-group-name").text(n);
o.resolve()
}).fail(function(){o.reject()
})
}).promise()
};
var j=function(m,n,l){return $.Deferred(function(o){$("#read-only-connection-target-label").text("To funnel");
$("#read-only-connection-target").append("funnel");
$("#read-only-connection-target-group-name").text(n);
o.resolve()
}).promise()
};
var f=function(m,n,l){return $.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(m)+"/remote-process-groups/"+encodeURIComponent(l.groupId),data:{verbose:true},dataType:"json"}).done(function(o){var p=o.remoteProcessGroup;
$("#read-only-connection-target-label").text("To input");
$("#read-only-connection-target").text(l.name);
$("#read-only-connection-target-group-name").text(p.name)
})
};
var b=function(m,n,l){return $.Deferred(function(o){if(m===l.groupId){$("#read-only-connection-target-label").text("To output");
$("#read-only-connection-target").text(l.name);
$("#read-only-connection-target-group-name").text(n);
o.resolve()
}else{$.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(l.groupId),data:{verbose:true},dataType:"json"}).done(function(p){var q=p.processGroup;
$("#read-only-connection-target-label").text("To input");
$("#read-only-connection-target").text(l.name);
$("#read-only-connection-target-group-name").text(q.name);
o.resolve()
}).fail(function(){o.reject()
})
}}).promise()
};
var e=function(l){$('<div class="available-relationship-container"></div>').append($('<div class="relationship-name"></div>').text(l)).appendTo("#read-only-relationship-names")
};
return{init:function(l){l=nf.Common.isDefinedAndNotNull(l)?l:true;
$("#connection-details-tabs").tabbs({tabStyle:"tab",selectedTabStyle:"selected-tab",tabs:[{name:"Details",tabContentId:"read-only-connection-details-tab-content"},{name:"Settings",tabContentId:"read-only-connection-settings-tab-content"}]});
$("#connection-details").modal({headerText:"Connection Details",overlayBackground:l,buttons:[{buttonText:"Ok",handler:{click:function(){$("#connection-details").modal("hide")
}}}],handler:{close:function(){$("#read-only-relationship-names").empty();
nf.Common.clearField("read-only-connection-name");
nf.Common.clearField("read-only-connection-id");
$("#read-only-connection-source-label").text("");
$("#read-only-connection-source").empty();
$("#read-only-connection-source-group-name").text("");
$("#read-only-connection-target-label").text("");
$("#read-only-connection-target").empty();
$("#read-only-connection-target-group-name").text("");
$("#read-only-relationship-names").css("border-width","0").empty();
$("#read-only-flow-file-expiration").text("");
$("#read-only-back-pressure-object-threshold").text("");
$("#read-only-back-pressure-data-size-threshold").text("");
$("#read-only-prioritizers").empty()
}}});
if(l){$("#connection-details").draggable({containment:"parent",handle:".dialog-header"})
}},showDetails:function(m,o){var n=$.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(m),dataType:"json"});
var l=$.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(m)+"/connections/"+encodeURIComponent(o),dataType:"json"});
$.when(n,l).done(function(t,r){var s=t[0];
var u=r[0];
if(nf.Common.isDefinedAndNotNull(s.processGroup)&&nf.Common.isDefinedAndNotNull(u.connection)){var v=s.processGroup;
var q=u.connection;
var w=g(v.id,v.name,q.source);
var p=c(v.id,v.name,q.destination);
$.when(w,p).done(function(){var y=q.availableRelationships;
var x=q.selectedRelationships;
if(nf.Common.isDefinedAndNotNull(y)||nf.Common.isDefinedAndNotNull(x)){$.each(y,function(D,C){e(C)
});
$.each(x,function(E,C){if($.inArray(C,y)===-1){var F=e(C);
$(F).children("div.relationship-name").addClass("undefined")
}var D=$("#read-only-relationship-names").children("div");
$.each(D.children("div.relationship-name"),function(H,G){var I=$(G);
if(I.text()===C){I.css("font-weight","bold")
}})
});
$("#selected-relationship-text").show();
$("#read-only-relationship-names-container").show()
}else{$("#selected-relationship-text").hide();
$("#read-only-relationship-names-container").hide()
}nf.Common.populateField("read-only-connection-name",q.name);
nf.Common.populateField("read-only-connection-id",q.id);
nf.Common.populateField("read-only-flow-file-expiration",q.flowFileExpiration);
nf.Common.populateField("read-only-back-pressure-object-threshold",q.backPressureObjectThreshold);
nf.Common.populateField("read-only-back-pressure-data-size-threshold",q.backPressureDataSizeThreshold);
if(nf.Common.isDefinedAndNotNull(q.prioritizers)&&q.prioritizers.length>0){var B=$("<ol></ol>").css("list-style","decimal inside none");
$.each(q.prioritizers,function(C,D){B.append($("<li></li>").text(nf.Common.substringAfterLast(D,".")))
});
$("#read-only-prioritizers").append(B)
}else{var z=$('<span class="unset">No value set</span>');
$("#read-only-prioritizers").append(z)
}$("#connection-details-tabs").find("li:first").click();
$("#connection-details").modal("show");
var A=$("#read-only-relationship-names");
if(A.is(":visible")&&A.get(0).scrollHeight>A.innerHeight()){A.css("border-width","1px")
}})
}}).fail(nf.Common.handleAjaxError)
}}
}());