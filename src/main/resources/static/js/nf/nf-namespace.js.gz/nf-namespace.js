var nf;
if(!nf){nf={}
};