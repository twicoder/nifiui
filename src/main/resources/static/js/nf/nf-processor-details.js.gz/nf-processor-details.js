nf.ProcessorDetails=(function(){var a=function(s,q){e();
var l=$("#read-only-processor-properties").data("gridInstance");
var r=l.getData();
var p=r.getItem(s);
if(nf.Common.isDefinedAndNotNull(p.value)){var f=$("#processor-details").data("processorDetails");
var n=f.config.descriptors[p.property];
if(!c(n)){var i=$(l.getCellNode(s,q));
var j=i.offset();
var g=$('<div class="processor-property-detail"></div>').css({"z-index":100000,position:"absolute",background:"white",padding:"5px",overflow:"hidden",border:"3px solid #365C6A","box-shadow":"4px 4px 6px rgba(0, 0, 0, 0.9)",cursor:"move",top:j.top-5,left:j.left-5}).appendTo("body");
var m=null;
if(d(n)){var h="nfel";
var k=h+"-editor";
g.draggable({cancel:"input, textarea, pre, .button, ."+k,containment:"parent"});
m=$("<div></div>").addClass(k).appendTo(g).nfeditor({languageId:h,width:i.width(),content:p.value,minWidth:175,minHeight:100,readOnly:true,resizable:true})
}else{g.draggable({containment:"parent"});
$('<textarea hidefocus rows="5" readonly="readonly"/>').css({background:"white",width:i.width()+"px",height:"80px","border-width":"0",outline:"0","overflow-y":"auto",resize:"both","margin-bottom":"28px"}).text(p.value).appendTo(g)
}var o=$('<div class="button button-normal">Ok</div>').on("click",function(){if(m!==null){m.nfeditor("destroy")
}g.hide().remove()
});
$("<div></div>").css({position:"absolute",bottom:"0",left:"0",right:"0",padding:"0 3px 5px"}).append(o).append('<div class="clear"></div>').appendTo(g)
}}};
var e=function(){$("body").children("div.processor-property-detail").hide().remove()
};
var c=function(f){if(nf.Common.isDefinedAndNotNull(f)){return f.sensitive===true
}else{return false
}};
var d=function(f){if(nf.Common.isDefinedAndNotNull(f)){return f.supportsEl===true
}else{return false
}};
var b=function(i){var f=$('<div class="relationship-name ellipsis"></div>').text(i.name);
if(i.autoTerminate===true){f.css("font-weight","bold")
}var h=$('<div class="processor-relationship-container"></div>').append(f).appendTo("#read-only-auto-terminate-relationship-names");
if(!nf.Common.isBlank(i.description)){var g=$('<div class="relationship-description"></div>').text(i.description);
h.append(g)
}return h
};
return{init:function(k){k=nf.Common.isDefinedAndNotNull(k)?k:true;
$("#processor-details-tabs").tabbs({tabStyle:"tab",selectedTabStyle:"selected-tab",tabs:[{name:"Settings",tabContentId:"details-standard-settings-tab-content"},{name:"Scheduling",tabContentId:"details-scheduling-tab-content"},{name:"Properties",tabContentId:"details-processor-properties-tab-content"},{name:"Comments",tabContentId:"details-processor-comments-tab-content"}],select:function(){if($(this).text()==="Properties"){var m=$("#read-only-processor-properties").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(m)){m.resizeCanvas()
}}var n=$("#read-only-auto-terminate-relationship-names");
if(n.is(":visible")&&n.get(0).scrollHeight>n.innerHeight()){n.css("border-width","1px")
}}});
$("#processor-details").modal({headerText:"Processor Details",overlayBackground:k,handler:{close:function(){$("#read-only-auto-terminate-relationship-names").css("border-width","0").empty();
var m=$("#read-only-processor-properties");
nf.Common.cleanUpTooltips(m,"img.icon-info");
var n=m.data("gridInstance");
var o=n.getData();
o.setItems([]);
nf.Common.clearField("read-only-processor-id");
nf.Common.clearField("read-only-processor-type");
nf.Common.clearField("read-only-processor-name");
nf.Common.clearField("read-only-concurrently-schedulable-tasks");
nf.Common.clearField("read-only-scheduling-period");
nf.Common.clearField("read-only-penalty-duration");
nf.Common.clearField("read-only-yield-duration");
nf.Common.clearField("read-only-run-duration");
nf.Common.clearField("read-only-bulletin-level");
nf.Common.clearField("read-only-execution-status");
nf.Common.clearField("read-only-processor-comments");
$("#processor-details").removeData("processorDetails");
$("#processor-details").removeData("processorHistory");
e()
}}});
if(k){$("#processor-details").draggable({containment:"parent",handle:".dialog-header"})
}var j=function(v,u,t,q,o){var s=10;
var n=$("<div></div>");
var p=$("<span/>").addClass("table-cell").text(t).appendTo(n);
if(o.type==="required"){p.addClass("required")
}var m=$("#processor-details").data("processorDetails");
var r=m.config.descriptors[o.property];
if(nf.Common.isDefinedAndNotNull(r)){if(!nf.Common.isBlank(r.description)||!nf.Common.isBlank(r.defaultValue)||!nf.Common.isBlank(r.supportsEl)){$('<img class="icon-info" src="images/iconInfo.png" alt="Info" title="" style="float: right; margin-right: 6px; margin-top: 4px;" />').appendTo(n);
s=26
}}p.width(q.width-s).ellipsis();
return n.html()
};
var h=function(u,t,s,o,n){var r;
if(nf.Common.isDefinedAndNotNull(s)){var m=$("#processor-details").data("processorDetails");
var q=m.config.descriptors[n.property];
if(c(q)){r='<span class="table-cell sensitive">Sensitive value set</span>'
}else{if(s===""){r='<span class="table-cell blank">Empty string set</span>'
}else{r='<div class="table-cell value"><pre class="ellipsis">'+nf.Common.escapeHtml(s)+"</pre></div>"
}}}else{r='<span class="unset">No value set</span>'
}var p=$(r);
if(n.type==="required"){p.addClass("required")
}p.find(".ellipsis").width(o.width-10).ellipsis();
return $("<div/>").append(p).html()
};
var g=[{id:"property",field:"property",name:"Property",sortable:false,resizable:true,rerenderOnResize:true,formatter:j},{id:"value",field:"value",name:"Value",sortable:false,resizable:true,cssClass:"pointer",rerenderOnResize:true,formatter:h}];
var f={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:false,enableColumnReorder:false,autoEdit:false};
var i=new Slick.Data.DataView({inlineFilters:false});
i.setItems([]);
var l=new Slick.Grid("#read-only-processor-properties",i,g,f);
l.setSelectionModel(new Slick.RowSelectionModel());
l.onClick.subscribe(function(n,m){if(m.cell===1){a(m.row,m.cell);
n.stopImmediatePropagation()
}});
i.onRowCountChanged.subscribe(function(n,m){l.updateRowCount();
l.render()
});
i.onRowsChanged.subscribe(function(n,m){l.invalidateRows(m.rows);
l.render()
});
$("#read-only-processor-properties").data("gridInstance",l).on("mouseenter","div.slick-cell",function(t){var p=$(this).find("img.icon-info");
if(p.length&&!p.data("qtip")){var s=$(this).find("span.table-cell").text();
var o=$("#processor-details").data("processorDetails");
var m=o.config.descriptors[s];
var n=$("#processor-details").data("processorHistory");
var q=n.propertyHistory[s];
var r=nf.Common.formatPropertyTooltip(m,q);
if(nf.Common.isDefinedAndNotNull(r)){p.qtip($.extend({content:r},nf.Common.config.tooltipConfig))
}}})
},showDetails:function(h,i){var g=$.ajax({type:"GET",url:"../nifi-api/controller/process-groups/"+encodeURIComponent(h)+"/processors/"+encodeURIComponent(i),dataType:"json"}).done(function(m){if(nf.Common.isDefinedAndNotNull(m.processor)){var j=m.processor;
$("#processor-details").data("processorDetails",j);
nf.Common.populateField("read-only-processor-id",j.id);
nf.Common.populateField("read-only-processor-type",nf.Common.substringAfterLast(j.type,"."));
nf.Common.populateField("read-only-processor-name",j.name);
nf.Common.populateField("read-only-concurrently-schedulable-tasks",j.config.concurrentlySchedulableTaskCount);
nf.Common.populateField("read-only-scheduling-period",j.config.schedulingPeriod);
nf.Common.populateField("read-only-penalty-duration",j.config.penaltyDuration);
nf.Common.populateField("read-only-yield-duration",j.config.yieldDuration);
nf.Common.populateField("read-only-run-duration",nf.Common.formatDuration(j.config.runDurationMillis));
nf.Common.populateField("read-only-bulletin-level",j.config.bulletinLevel);
nf.Common.populateField("read-only-processor-comments",j.config.comments);
var k=true;
var l=j.config.schedulingStrategy;
if(l==="EVENT_DRIVEN"){k=false;
l="Event driven"
}else{if(l==="CRON_DRIVEN"){l="CRON driven"
}else{if(l==="TIMER_DRIVEN"){l="Timer driven"
}else{l="On primary node"
}}}nf.Common.populateField("read-only-scheduling-strategy",l);
if(k===true){$("#read-only-run-schedule").show()
}else{$("#read-only-run-schedule").hide()
}if(!nf.Common.isEmpty(j.relationships)){$.each(j.relationships,function(s,t){b(t)
})
}else{$("#read-only-auto-terminate-relationship-names").append('<div class="unset">This processor has no relationships.</div>')
}var o=$("#read-only-processor-properties").data("gridInstance");
var q=o.getData();
var p=j.config.properties;
var r=j.config.descriptors;
if(nf.Common.isDefinedAndNotNull(p)){q.beginUpdate();
var n=0;
$.each(p,function(t,v){var w=r[t];
var u="userDefined";
var s=t;
if(nf.Common.isDefinedAndNotNull(w)){if(w.required===true){u="required"
}else{if(w.dynamic===true){u="userDefined"
}else{u="optional"
}}s=w.displayName;
if(nf.Common.isNull(v)&&nf.Common.isDefinedAndNotNull(w.defaultValue)){v=w.defaultValue
}}q.addItem({id:n++,property:s,value:v,type:u})
});
q.endUpdate()
}}});
var f=$.ajax({type:"GET",url:"../nifi-api/controller/history/processors/"+encodeURIComponent(i),dataType:"json"}).done(function(j){var k=j.processorHistory;
$("#processor-details").data("processorHistory",k)
});
$.when(g,f).done(function(j){var m=j[0];
var k=m.processor;
var l=[{buttonText:"Ok",handler:{click:function(){$("#processor-details").modal("hide")
}}}];
if(nf.Common.isDefinedAndNotNull(nf.CustomProcessorUi)&&nf.Common.isDefinedAndNotNull(k.config.customUiUrl)&&k.config.customUiUrl!==""){l.push({buttonText:"Advanced",handler:{click:function(){$("#processor-details").modal("hide");
nf.CustomProcessorUi.showCustomUi(k.id,k.config.customUiUrl,false)
}}})
}$("#processor-details").modal("setButtonModel",l).modal("show");
$("#processor-details div.relationship-name").ellipsis();
var n=$("#read-only-auto-terminate-relationship-names");
if(n.is(":visible")&&n.get(0).scrollHeight>n.innerHeight()){n.css("border-width","1px")
}}).fail(function(l,j,k){if(l.status===400||l.status===404||l.status===409){nf.Dialog.showOkDialog({dialogContent:nf.Common.escapeHtml(l.responseText),overlayBackground:false})
}else{nf.Common.handleAjaxError(l,j,k)
}})
}}
}());