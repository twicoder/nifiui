$(document).ready(function(){$("#shell-dialog").modal({overlayBackground:true});
$("#shell-close-button").click(function(){$("#shell-dialog").modal("hide")
});
$("#shell-undock-button").click(function(){var a=$("#shell-iframe").attr("src");
if(!nf.Common.isBlank(a)){window.open(a);
$("#shell-dialog").modal("hide")
}});
nf.Common.addHoverEffect("#shell-undock-button","undock-normal","undock-hover");
nf.Common.addHoverEffect("#shell-close-button","close-normal","close-hover")
});
nf.Shell=(function(){return{showPage:function(a,b){if(nf.Common.isDefinedAndNotNull(nf.ContextMenu)){nf.ContextMenu.hide()
}return $.Deferred(function(c){var d=$("#shell");
if(nf.Common.isNull(b)||nf.Common.isUndefined(b)){b=true
}d.empty();
$("#shell-dialog").modal("setHandler",{close:function(){c.resolve()
}});
$("#shell-dialog").modal("show");
if(b){$("#shell-undock-button").show()
}else{$("#shell-undock-button").hide()
}var e=$("<iframe/>",{id:"shell-iframe",frameBorder:"0",src:a}).css({width:d.width(),height:d.height()}).appendTo(d);
$(window).resize(function(){e.css({width:d.width(),height:d.height()})
})
}).promise()
},showContent:function(a){if(nf.Common.isDefinedAndNotNull(nf.ContextMenu)){nf.ContextMenu.hide()
}return $.Deferred(function(b){var f=$(a);
if(f.length){var c=$("#shell");
c.empty();
var e=f.parent();
f.detach();
$("#shell-dialog").modal("setHandler",{close:function(){b.resolve();
f.hide().detach().appendTo(e)
}});
$("#shell-undock-button").hide();
var d=$("<div>").css({width:c.width(),height:c.height()}).append(f).appendTo(c);
$("#shell-dialog").modal("show");
f.show();
$(window).resize(function(){d.css({width:c.width(),height:c.height()})
})
}}).promise()
}}
}());