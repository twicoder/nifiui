nf.StatusHistory=(function(){var r={clusterInstanceId:"cluster-instance-id",clusterInstanceLabel:"Cluster",type:{processor:"Processor",inputPort:"Input Port",outputPort:"Output Port",processGroup:"Process Group",remoteProcessGroup:"Remote Process Group",connection:"Connection",funnel:"Funnel",template:"Template",label:"Label"},urls:{processGroups:"../nifi-api/controller/process-groups/",clusterProcessor:"../nifi-api/cluster/processors/",clusterProcessGroup:"../nifi-api/cluster/process-groups/",clusterRemoteProcessGroup:"../nifi-api/cluster/remote-process-groups/",clusterConnection:"../nifi-api/cluster/connections/"}};
var p={DURATION:function(s){return nf.Common.formatDuration(s)
},COUNT:function(s){if(s%1===0){return nf.Common.formatInteger(s)
}else{return nf.Common.formatFloat(s)
}},DATA_SIZE:function(s){return nf.Common.formatDataSize(s)
}};
var h=null;
var i=null;
var l=null;
var a=null;
var c=function(u,z,y,t,x){$("#status-history-last-refreshed").text(y.generated);
var s={groupId:u,id:z,type:t,clustered:true,instances:[]};
var v=null;
var w=y.clusterStatusHistory;
if(w.statusSnapshots.length>1){if(v===null){v=w.fieldDescriptors;
s.details=w.details;
s.selectedDescriptor=nf.Common.isUndefined(x)?v[0]:x
}s.instances.push({id:r.clusterInstanceId,label:r.clusterInstanceLabel,snapshots:w.statusSnapshots})
}$.each(y.nodeStatusHistory,function(C,B){var D=B.node;
var A=B.statusHistory;
if(A.statusSnapshots.length>1){if(v===null){v=A.fieldDescriptors;
s.details=A.details;
s.selectedDescriptor=nf.Common.isUndefined(x)?v[0]:x
}s.instances.push({id:D.nodeId,label:D.address+":"+D.apiPort,snapshots:A.statusSnapshots})
}});
if(s.instances.length>0){$("#status-history-dialog").data("status-history",s);
m(s,v)
}else{e()
}};
var q=function(u,x,s,t,w){if(s.statusSnapshots.length>1){$("#status-history-last-refreshed").text(s.generated);
var v=s.fieldDescriptors;
var s={groupId:u,id:x,details:s.details,type:t,clustered:false,selectedDescriptor:nf.Common.isUndefined(w)?v[0]:w,instances:[{id:"",label:"",snapshots:s.statusSnapshots}]};
$("#status-history-dialog").data("status-history",s);
m(s,v);
return
}e()
};
var e=function(){nf.Dialog.showOkDialog({dialogContent:"Insufficient history, please try again later.",overlayBackground:false})
};
var m=function(s,t){if(a===null){a={}
}$.each(s.instances,function(v,u){u.snapshots.forEach(function(y){var x=new Date();
var w=x.getTimezoneOffset()*60*1000;
y.timestamp=new Date(y.timestamp+w+h)
})
});
f(t,s.selectedDescriptor)
};
var f=function(u,t){var s=[];
$.each(u,function(v,w){s.push({text:w.label,value:w.field,description:nf.Common.escapeHtml(w.description)})
});
$("#status-history-metric-combo").combo({selectedOption:{value:t.field},options:s,select:function(w){var x=null;
$.each(u,function(y,z){if(w.value===z.field){x=z;
return false
}});
if(x!==null){if(l===null||l.field!==x.field){i=null
}l=x;
var v=$("#status-history-dialog").data("status-history");
v.selectedDescriptor=x;
$("#status-history-dialog").data("status-history",v);
g(v)
}}})
};
var g=function(V){var ab=V.selectedDescriptor;
$("#status-history-details").empty();
var v=k("Status History");
d3.map(V.details).forEach(function(x,y){d(v,x,y)
});
var z={top:15,right:10,bottom:25,left:75};
var S=d3.scale.category10();
var u=[];
$.each(V.instances,function(y,x){u.push(x.label)
});
S.domain(u);
var al=[];
$.each(V.instances,function(y,x){if(nf.Common.isUndefinedOrNull(a[x.id])){a[x.id]=true
}al.push({id:x.id,label:x.label,values:$.map(x.snapshots,function(ao){return{timestamp:ao.timestamp,value:ao.statusMetrics[ab.field]}
}),visible:a[x.id]===true})
});
var J=d3.time.format.multi([[":%S.%L",function(x){return x.getMilliseconds()
}],[":%S",function(x){return x.getSeconds()
}],["%H:%M",function(x){return x.getMinutes()
}],["%H:%M",function(x){return x.getHours()
}],["%a %d",function(x){return x.getDay()&&x.getDate()!==1
}],["%b %d",function(x){return x.getDate()!==1
}],["%B",function(x){return x.getMonth()
}],["%Y",function(){return true
}]]);
var ac=$("#status-history-dialog");
if(!ac.is(":visible")){$("#glass-pane").show();
ac.center().show()
}var I=$("#status-history-chart-container").empty();
if(I.hasClass("ui-resizable")){I.resizable("destroy")
}var s=I.width()-z.left-z.right;
var t=I.height()-z.top-z.bottom;
var Z=d3.time.scale().range([0,s]);
var N=d3.svg.axis().scale(Z).ticks(5).tickFormat(J).orient("bottom");
var Y=d3.scale.linear().range([t,0]);
var A=d3.svg.axis().scale(Y).tickFormat(p[ab.formatter]).orient("left");
var B=d3.svg.line().interpolate("monotone").x(function(x){return Z(x.timestamp)
}).y(function(x){return Y(x.value)
});
var H=d3.select("#status-history-chart-container").append("svg").attr("style","pointer-events: none;").attr("width",s+z.left+z.right).attr("height",t+z.top+z.bottom);
var C=H.append("defs").append("clipPath").attr("id","clip").append("rect").attr("width",s).attr("height",t);
var an=H.append("g").attr("transform","translate("+z.left+", "+z.top+")");
var w=d3.min(al,function(x){return d3.min(x.values,function(y){return y.timestamp
})
});
var F=d3.max(al,function(x){return d3.max(x.values,function(y){return y.timestamp
})
});
d(v,"Start",nf.Common.formatDateTime(w));
d(v,"End",nf.Common.formatDateTime(F));
Z.domain([w,F]);
Y.domain([j(al),o(al)]);
an.append("g").attr("class","x axis").attr("transform","translate(0, "+t+")").call(N);
an.append("g").attr("class","y axis").call(A).append("text").attr("transform","rotate(-90)").attr("y",6).attr("dy",".71em").attr("text-anchor","end").text(ab.label);
var W=an.selectAll(".status").data(al).enter().append("g").attr("clip-path","url(#clip)").attr("class","status");
W.append("path").attr("class",function(x){return"chart-line chart-line-"+x.id
}).attr("d",function(x){return B(x.values)
}).attr("stroke",function(x){return S(x.label)
}).classed("hidden",function(x){return x.visible===false
}).append("title").text(function(x){return x.label
});
W.each(function(x){var y=d3.select(this).append("g").attr("class",function(){return"mark-group mark-group-"+x.id
}).classed("hidden",function(ao){return ao.visible===false
});
y.selectAll("circle.mark").data(x.values).enter().append("circle").attr("style","pointer-events: all;").attr("class","mark").attr("cx",function(ao){return Z(ao.timestamp)
}).attr("cy",function(ao){return Y(ao.value)
}).attr("fill",function(){return S(x.label)
}).attr("r",1.5).append("title").text(function(ao){return x.label+" -- "+p[ab.formatter](ao.value)
})
});
var M=$("#status-history-chart-control-container").empty();
var L=M.height()-z.top-z.bottom;
var af=d3.time.scale().range([0,s]);
var E=d3.svg.axis().scale(af).ticks(5).tickFormat(J).orient("bottom");
var ai=d3.scale.linear().range([L,0]);
var ad=d3.svg.axis().scale(ai).tickValues(Y.domain()).tickFormat(p[ab.formatter]).orient("left");
var K=d3.svg.line().interpolate("monotone").x(function(x){return af(x.timestamp)
}).y(function(x){return ai(x.value)
});
var aa=d3.select("#status-history-chart-control-container").append("svg").attr("width",s+z.left+z.right).attr("height",L+z.top+z.bottom);
var Q=aa.append("g").attr("transform","translate("+z.left+", "+z.top+")");
var P=Y.domain();
P[1]*=1.04;
af.domain(Z.domain());
ai.domain(P);
Q.append("g").attr("class","x axis").attr("transform","translate(0, "+L+")").call(E);
Q.append("g").attr("class","y axis").call(ad);
var am=Q.selectAll(".status").data(al).enter().append("g").attr("class","status");
am.append("path").attr("class",function(x){return"chart-line chart-line-"+x.id
}).attr("d",function(x){return K(x.values)
}).attr("stroke",function(x){return S(x.label)
}).classed("hidden",function(x){return a[x.id]===false
}).append("title").text(function(x){return x.label
});
var ak=function(x,y){Z.domain(x);
Y.domain(y);
W.selectAll(".chart-line").attr("d",function(ao){return B(ao.values)
});
W.selectAll("circle.mark").attr("cx",function(ao){return Z(ao.timestamp)
}).attr("cy",function(ao){return Y(ao.value)
}).attr("r",function(){return ag.empty()?1.5:4
});
an.select(".x.axis").call(N);
an.select(".y.axis").call(A)
};
var D=function(){var y,x;
if(ag.empty()){var ap=$.grep(al,function(aq){return aq.visible
});
if(ap.length===0){x=ai.domain()
}else{x=[d3.min(ap,function(aq){return d3.min(aq.values,function(ar){return ar.value
})
}),d3.max(ap,function(aq){return d3.max(aq.values,function(ar){return ar.value
})
})]
}y=af.domain();
i=null
}else{var ao=ag.extent();
y=[ao[0][0],ao[1][0]];
x=[ao[0][1],ao[1][1]];
i=ao
}ak(y,x);
G()
};
var ag=d3.svg.brush().x(af).y(ai).on("brush",D);
if(nf.Common.isDefinedAndNotNull(i)){ag=ag.extent(i)
}Q.append("g").attr("class","brush").call(ag);
Q.select("rect.extent").attr("style","pointer-events: all;").on("dblclick",function(){if(!ag.empty()){var x=ag.extent();
var y=ai.domain();
ag.extent([[x[0][0],y[0]],[x[1][0],y[1]]]);
Q.select(".brush").call(ag);
D()
}});
var G=function(){var at=$.map(al,function(aC){var aA=Z.domain();
var aB=Y.domain();
var aD=$.extend({},aC);
return $.extend(aD,{values:$.grep(aC.values,function(aE){return aE.timestamp.getTime()>=aA[0].getTime()&&aE.timestamp.getTime()<=aA[1].getTime()&&aE.value>=aB[0]&&aE.value<=aB[1]
})})
});
if(V.clustered){var x=$.grep(at,function(aA){return aA.id!==r.clusterInstanceId&&aA.visible&&aA.values.length>0
});
var ar=x.length===0?"NA":p[ab.formatter](j(x));
var ap=x.length===0?"NA":p[ab.formatter](b(x));
var y=x.length===0?"NA":p[ab.formatter](o(x));
$("#node-aggregate-statistics").text(ar+" / "+y+" / "+ap);
var aw=$.grep(at,function(aA){return aA.id===r.clusterInstanceId&&aA.visible&&aA.values.length>0
});
var ay=aw.length===0?"NA":p[ab.formatter](j(aw));
var av=aw.length===0?"NA":p[ab.formatter](b(aw));
var ao=aw.length===0?"NA":p[ab.formatter](o(aw));
$("#cluster-aggregate-statistics").text(ay+" / "+ao+" / "+av)
}else{var ax=$.grep(at,function(aA){return aA.values.length>0
});
var au=ax.length===0?0:p[ab.formatter](j(ax));
var az=ax.length===0?0:p[ab.formatter](b(ax));
var aq=ax.length===0?0:p[ab.formatter](o(ax));
$("#instance-aggregate-statistics").text(au+" / "+aq+" / "+az)
}};
if(V.clustered){var X=$.grep(al,function(x){return x.id!==r.clusterInstanceId
}).sort(function(y,x){return y.label<x.label?-1:y.label>x.label?1:0
});
var aj=function(y,x){var ap=$("<div></div>").addClass("legend-label").css("color",S(x.label)).text(x.label).ellipsis();
var ao=$('<div class="nf-checkbox"></div>').on("click",function(){var aq=d3.selectAll("path.chart-line-"+x.id);
var at=d3.select("g.mark-group-"+x.id);
var ar=at.classed("hidden");
aq.classed("hidden",function(){return !ar
});
at.classed("hidden",function(){return !ar
});
x.visible=ar;
a[x.id]=x.visible;
D()
}).addClass(x.visible?"checkbox-checked":"checkbox-unchecked");
$('<div class="legend-entry"></div>').append(ao).append(ap).on("mouseenter",function(){d3.selectAll("path.chart-line-"+x.id).classed("over",true)
}).on("mouseleave",function(){d3.selectAll("path.chart-line-"+x.id).classed("over",false)
}).appendTo(y)
};
var U=$.grep(al,function(x){return x.id===r.clusterInstanceId
});
var ae=k("Cluster");
d(ae,"Min / Max / Mean","","cluster-aggregate-statistics");
aj(ae,U[0]);
if(X.length>0){var T=k("Nodes");
d(T,"Min / Max / Mean","","node-aggregate-statistics");
$.each(X,function(y,x){aj(T,x)
})
}}else{d(v,"Min / Max / Mean","","instance-aggregate-statistics")
}D();
var O,ah,R;
I.append('<div class="ui-resizable-handle ui-resizable-se"></div>').resizable({minWidth:425,minHeight:150,handles:{se:".ui-resizable-se"},start:function(ar,aq){var x=aq.helper.offset();
var ap=((ac.outerWidth()-ac.width())/2)+3;
var y=I.outerWidth()-I.width();
O=$(document).width()-x.left-ap-y;
var ao=$("#status-history-container").outerHeight(true)-$("#status-history-container").height();
ah=$(document).height()-x.top-ap-y-ao-M.outerHeight(true);
if(!ag.empty()){R=ag.extent()
}},resize:function(y,x){if(x.helper.width()>O){x.helper.width(O)
}if(x.helper.height()>ah){x.helper.height(ah)
}M.width(I.width());
n()
},stop:function(){n();
s=I.width()-z.left-z.right;
t=I.height()-z.top-z.bottom;
Z.range([0,s]);
Y.range([t,0]);
H.attr("width",s+z.left+z.right).attr("height",t+z.top+z.bottom);
C.attr("width",s).attr("height",t);
an.select(".x.axis").attr("transform","translate(0, "+t+")");
L=M.height()-z.top-z.bottom;
af.range([0,s]);
ai.range([L,0]);
aa.attr("width",s+z.left+z.right).attr("height",L+z.top+z.bottom);
am.selectAll(".chart-line").attr("d",function(x){return K(x.values)
});
Q.select(".x.axis").call(E);
Q.select(".y.axis").call(ad);
if(nf.Common.isDefinedAndNotNull(R)){ag.extent(R)
}Q.select(".brush").call(ag);
D();
R=null
}});
n()
};
var j=function(s){return d3.min(s,function(t){return d3.min(t.values,function(u){return u.value
})
})
};
var o=function(s){return d3.max(s,function(t){return d3.max(t.values,function(u){return u.value
})
})
};
var b=function(t){var u=0;
var s=d3.sum(t,function(v){u+=v.values.length;
return d3.sum(v.values,function(w){return w.value
})
});
return s/u
};
var n=function(){var s=$("#status-history-details");
var t=s.outerWidth()-s.width();
$("#status-history-details").height($("#status-history-container").height()-t)
};
var k=function(t){var s=$('<div class="status-history-detail"></div>').appendTo("#status-history-details");
$('<div class="detail-container-label"></div>').text(t).appendTo(s);
return $("<div></div>").appendTo(s)
};
var d=function(t,v,w,x){var u=$('<div class="detail-item"></div>').appendTo(t);
$('<div class="detail-item-label"></div>').text(v).appendTo(u);
var s=$('<div class="detail-item-value"></div>').text(w).appendTo(u);
if(nf.Common.isDefinedAndNotNull(x)){s.attr("id",x)
}};
return{init:function(s){h=s;
nf.Common.addHoverEffect("#status-history-refresh-button","button-refresh","button-refresh-hover").click(function(){var t=$("#status-history-dialog").data("status-history");
if(t!==null){if(t.type===r.type.processor){if(t.clustered===true){nf.StatusHistory.showClusterProcessorChart(t.groupId,t.id,t.selectedDescriptor)
}else{nf.StatusHistory.showStandaloneProcessorChart(t.groupId,t.id,t.selectedDescriptor)
}}else{if(t.type===r.type.processGroup){if(t.clustered===true){nf.StatusHistory.showClusterProcessGroupChart(t.groupId,t.id,t.selectedDescriptor)
}else{nf.StatusHistory.showStandaloneProcessGroupChart(t.groupId,t.id,t.selectedDescriptor)
}}else{if(t.type===r.type.remoteProcessGroup){if(t.clustered===true){nf.StatusHistory.showClusterRemoteProcessGroupChart(t.groupId,t.id,t.selectedDescriptor)
}else{nf.StatusHistory.showStandaloneRemoteProcessGroupChart(t.groupId,t.id,t.selectedDescriptor)
}}else{if(t.clustered===true){nf.StatusHistory.showClusterConnectionChart(t.groupId,t.id,t.selectedDescriptor)
}else{nf.StatusHistory.showStandaloneConnectionChart(t.groupId,t.id,t.selectedDescriptor)
}}}}}});
$("#status-history-dialog").draggable({cancel:"#status-history-chart-container, #status-history-chart-control-container, #status-history-details, div.detail-item-value",containment:"parent"}).on("click","#status-history-close",function(){$("#status-history-dialog").removeData("status-history").hide();
$("#glass-pane").hide();
$("#status-history-chart-container").empty();
$("#status-history-chart-control-container").empty();
$("#status-history-details").empty();
i=null;
l=null;
a=null
})
},showClusterConnectionChart:function(s,t,u){$.ajax({type:"GET",url:r.urls.clusterConnection+encodeURIComponent(t)+"/status/history",dataType:"json"}).done(function(v){c(s,t,v.clusterStatusHistory,r.type.connection,u)
}).fail(nf.Common.handleAjaxError)
},showClusterProcessorChart:function(s,u,t){$.ajax({type:"GET",url:r.urls.clusterProcessor+encodeURIComponent(u)+"/status/history",dataType:"json"}).done(function(v){c(s,u,v.clusterStatusHistory,r.type.processor,t)
}).fail(nf.Common.handleAjaxError)
},showClusterProcessGroupChart:function(t,s,u){$.ajax({type:"GET",url:r.urls.clusterProcessGroup+encodeURIComponent(s)+"/status/history",dataType:"json"}).done(function(v){c(t,s,v.clusterStatusHistory,r.type.processGroup,u)
}).fail(nf.Common.handleAjaxError)
},showClusterRemoteProcessGroupChart:function(t,s,u){$.ajax({type:"GET",url:r.urls.clusterRemoteProcessGroup+encodeURIComponent(s)+"/status/history",dataType:"json"}).done(function(v){c(t,s,v.clusterStatusHistory,r.type.remoteProcessGroup,u)
}).fail(nf.Common.handleAjaxError)
},showStandaloneConnectionChart:function(s,t,u){$.ajax({type:"GET",url:r.urls.processGroups+encodeURIComponent(s)+"/connections/"+encodeURIComponent(t)+"/status/history",dataType:"json"}).done(function(v){q(s,t,v.statusHistory,r.type.connection,u)
}).fail(nf.Common.handleAjaxError)
},showStandaloneProcessorChart:function(s,u,t){$.ajax({type:"GET",url:r.urls.processGroups+encodeURIComponent(s)+"/processors/"+encodeURIComponent(u)+"/status/history",dataType:"json"}).done(function(v){q(s,u,v.statusHistory,r.type.processor,t)
}).fail(nf.Common.handleAjaxError)
},showStandaloneProcessGroupChart:function(t,s,u){$.ajax({type:"GET",url:r.urls.processGroups+encodeURIComponent(s)+"/status/history",dataType:"json"}).done(function(v){q(t,s,v.statusHistory,r.type.processGroup,u)
}).fail(nf.Common.handleAjaxError)
},showStandaloneRemoteProcessGroupChart:function(t,s,u){$.ajax({type:"GET",url:r.urls.processGroups+encodeURIComponent(t)+"/remote-process-groups/"+encodeURIComponent(s)+"/status/history",dataType:"json"}).done(function(v){q(t,s,v.statusHistory,r.type.remoteProcessGroup,u)
}).fail(nf.Common.handleAjaxError)
}}
}());