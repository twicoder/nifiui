nf.ProvenanceLineage=(function(){var d={sliderTickCount:75,urls:{lineage:"../nifi-api/controller/provenance/lineage",events:"../nifi-api/controller/provenance/events/"}};
var f=function(){$("#lineage-percent-complete").progressbar();
$("#lineage-query-dialog").modal({headerText:"Computing FlowFile lineage...",overlayBackground:false,handler:{close:function(){$("#lineage-percent-complete").progressbar("value",0)
}}})
};
var b=function(l){var m=$("#provenance-lineage-context-menu");
$.each(l,function(n,p){if(typeof p.click==="function"){var o=$('<div class="provenance-lineage-menu-item"></div>').on("click",p.click).on("mouseenter",function(){$(this).addClass("hover")
}).on("mouseleave",function(){$(this).removeClass("hover")
}).appendTo(m);
$('<div class="provenance-lineage-menu-item-img"></div>').addClass(p["class"]).appendTo(o);
$('<div class="provenance-lineage-menu-item-text"></div>').text(p.text).appendTo(o);
$('<div class="clear"></div>').appendTo(o)
}})
};
var k=function(m,l){a(m,l).done(function(n){nf.ProvenanceTable.showEventDetails(n.provenanceEvent)
})
};
var a=function(n,m){var l;
if(nf.Common.isDefinedAndNotNull(m)){l=d.urls.events+encodeURIComponent(n)+"?"+$.param({clusterNodeId:m})
}else{l=d.urls.events+encodeURIComponent(n)
}return $.ajax({type:"GET",url:l,dataType:"json"}).fail(nf.Common.handleAjaxError)
};
var h=function(l){return $.ajax({type:"POST",url:d.urls.lineage,data:l,dataType:"json"}).fail(nf.Common.handleAjaxError)
};
var i=function(l){var m=l.uri;
if(nf.Common.isDefinedAndNotNull(l.clusterNodeId)){m+="?"+$.param({clusterNodeId:l.clusterNodeId})
}return $.ajax({type:"GET",url:m,dataType:"json"}).fail(nf.Common.handleAjaxError)
};
var e=function(l){var m=l.uri;
if(nf.Common.isDefinedAndNotNull(l.clusterNodeId)){m+="?"+$.param({clusterNodeId:l.clusterNodeId})
}return $.ajax({type:"DELETE",url:m,dataType:"json"}).fail(nf.Common.handleAjaxError)
};
var c=100;
var g=120;
var j=function(y,B,q){var p=$("#provenance-lineage");
var G=p.width();
var D=p.height();
var u;
var n;
var r;
var E=d3.map();
var z=d3.map();
var K=function(L,N,M){$.each(L,function(O,R){var Q=E.get(R);
var P=[];
$.each(Q.outgoing,function(S,T){P.push(T.target.id);
N.add(T.target.id)
});
if(nf.Common.isUndefined(M)){K(P,N)
}else{if(M>1){K(P,N,M-1)
}}})
};
var s=function(V,ad,Z,Y){var S=d3.set(V);
var ac=d3.set();
var Q=d3.set();
K(V,ac,1);
K(V,Q);
Q.forEach(function(ae){S.remove(ae)
});
var N=ac.values().sort(d3.descending);
var L=S.values();
var X=0;
$.each(L,function(ae,ag){var af=E.get(ag);
if(af.incoming.length>3){Y=g
}else{if(af.incoming.length>=2){X++
}}});
if(X>2){Y=g
}if(Z.length===1){L=L.sort(function(ai,ah){var af=E.get(ai);
var ae=E.get(ah);
if(af.outgoing.length>0&&ae.outgoing.length>0){var ag=N.indexOf(af.outgoing[0].target.id);
var aj=N.indexOf(ae.outgoing[0].target.id);
if(ag!==aj){return ag-aj
}}if(af.incoming.length>0&&ae.incoming.length>0){var ag=af.incoming[0].source.index;
var aj=ae.incoming[0].source.index;
if(ag!==aj){return ag-aj
}}if(af.type!==ae.type){return af.type>ae.type?1:-1
}if(af.eventType!==ae.eventType){return af.eventType>ae.eventType?1:-1
}return af.millis-ae.millis
})
}else{if(Z.length>1){L=L.sort(function(ai,ah){var af=E.get(ai);
var ae=E.get(ah);
if(af.incoming.length>0&&ae.incoming.length>0){var ag=af.incoming[0].source.index;
var aj=ae.incoming[0].source.index;
if(ag!==aj){return ag-aj
}}if(af.outgoing.length>0&&ae.outgoing.length>0){var ag=N.indexOf(af.outgoing[0].target.id);
var aj=N.indexOf(ae.outgoing[0].target.id);
if(ag!==aj){return ag-aj
}}if(af.type!==ae.type){return af.type>ae.type?1:-1
}if(af.eventType!==ae.eventType){return af.eventType>ae.eventType?1:-1
}return af.millis-ae.millis
})
}}var T=G/2;
if(Z.length>0){T=d3.mean(Z,function(af){var ae=E.get(af);
return ae.x
})
}var R=(L.length-1)*c;
$.each(L,function(af,ai){var ah=E.get(ai);
ah.y=Y+ad-25;
if(L.length<=Z.length){if(ah.incoming.length===1){var ag=ah.incoming[0].source;
if(ag.outgoing.length===1){ah.x=ag.x;
return
}}else{if(ah.incoming.length>1){var ae=$.grep(ah.incoming,function(aj){return(ah.y-aj.source.y)<=g
});
ah.x=d3.mean(ae,function(aj){return aj.source.x
});
return
}}}ah.x=(af*c)+T-(R/2)
});
var U=L.slice().sort(function(ah,ag){var af=E.get(ah);
var ae=E.get(ag);
return af.x-ae.x
});
for(var W=0;
W<U.length-1;
W++){var P=E.get(U[W]);
var ab=E.get(U[W+1]);
var aa=ab.x-P.x;
if(aa<c){ab.x+=(c-aa)
}}if(N.length>0){var M=g/3;
L=L.sort(function(ah,ag){var af=E.get(ah);
var ae=E.get(ag);
return af.x-ae.x
});
var O=0;
$.each(L,function(ae,ag){var af=E.get(ag);
af.index=ae;
if(af.outgoing.length>3){M=g
}else{if(af.outgoing.length>=2){O++
}}});
if(O>2){M=g
}s(N,Y+ad,L,M)
}};
var I=function(M,L){$.each(M,function(N,O){if(E.has(O.id)){return
}$.extend(O,{x:0,y:0,visible:true});
E.set(O.id,O)
});
$.each(L,function(N,O){var P={id:O.sourceId+"-"+O.targetId,source:E.get(O.sourceId),target:E.get(O.targetId),flowFileUuid:O.flowFileUuid,millis:O.millis,visible:true};
z.set(P.id,P)
});
o()
};
var o=function(){var M=d3.set(E.keys());
E.forEach(function(O,N){N.outgoing=[];
N.incoming=[];
if(nf.Common.isUndefined(u)||u>N.millis){u=N.millis;
n=N.timestamp
}if(nf.Common.isUndefined(r)||r<N.millis){r=N.millis
}});
z.forEach(function(O,N){N.source.outgoing.push(N);
N.target.incoming.push(N);
M.remove(N.target.id)
});
s(M.values(),1,[],50);
var L=(r-u)/d.sliderTickCount;
H.slider("option","min",u).slider("option","max",r).slider("option","step",L).slider("value",r);
$("#event-time").text(x(r));
t()
};
var x=function(O){var N=new Date();
var L=N.getTimezoneOffset()*60*1000;
var M=new Date(O+L+nf.ProvenanceTable.serverTimeOffset);
return nf.Common.formatDateTime(M)
};
$("#provenance-lineage-context-menu").on("click",function(){$(this).hide().empty()
});
var J=d3.behavior.zoom().scaleExtent([0.2,8]).on("zoom",function(){d3.select("g.lineage").attr("transform",function(){return"translate("+d3.event.translate+") scale("+d3.event.scale+")"
})
});
var C=d3.select("#provenance-lineage-container").append("svg:svg").attr("width",G).attr("height",D).call(J).on("dblclick.zoom",null).on("mousedown",function(L){d3.selectAll("circle.context").classed("context",false);
$("#provenance-lineage-context-menu").hide().empty()
}).on("contextmenu",function(){var M=$("#provenance-lineage-context-menu");
if(!M.is(":empty")){var L=d3.mouse(this);
M.css({left:L[0]+"px",top:L[1]+"px"}).show()
}d3.event.preventDefault()
});
C.append("rect").attr({width:"100%",height:"100%",fill:"#fff"});
C.append("defs").selectAll("marker").data(["FLOWFILE","FLOWFILE-SELECTED","EVENT","EVENT-SELECTED"]).enter().append("marker").attr({id:function(L){return L
},viewBox:"0 -3 6 6",refX:function(L){if(L.indexOf("FLOWFILE")>=0){return 16
}else{return 11
}},refY:0,markerWidth:6,markerHeight:6,orient:"auto",fill:function(L){if(L.indexOf("SELECTED")>=0){return"#FFCC00"
}else{return"#000000"
}}}).append("path").attr("d","M0,-3 L6,0 L0,3");
var p=C.append("g").attr({transform:"translate(0, 0) scale(1)","pointer-events":"all","class":"lineage"});
var F=p.selectAll("g.node");
var m=p.selectAll("path.link");
var w=r;
var l=function(P,Q){if(w>Q.value){var O=F.filter(function(R){return R.millis>Q.value&&R.millis<=w
});
var N=m.filter(function(R){return R.millis>Q.value&&R.millis<=w
});
N.transition().duration(400).style("opacity",0);
O.transition().delay(200).duration(400).style("opacity",0)
}else{var M=F.filter(function(R){return R.millis<=Q.value&&R.millis>w
});
var L=m.filter(function(R){return R.millis<=Q.value&&R.millis>w
});
M.transition().duration(400).style("opacity",1);
L.transition().delay(200).duration(400).style("opacity",1)
}$("#event-time").text(x(Q.value));
w=Q.value
};
var H=$("#provenance-lineage-slider").slider({min:u,max:r,step:(r-u)/d.sliderTickCount,value:r,change:l,slide:l});
var A=function(M){M.classed("flowfile",true);
M.append("circle").attr({r:16,fill:"#D4E0E5",stroke:"#000","stroke-width":1}).on("mousedown",function(N){$("#provenance-lineage-context-menu").hide().empty();
if(d3.event.button!==0){d3.event.stopPropagation()
}},true).on("mouseover",function(N){m.filter(function(O){return N.id===O.flowFileUuid
}).classed("selected",true).attr("marker-end",function(O){return"url(#"+O.target.type+"-SELECTED)"
})
}).on("mouseout",function(N){m.filter(function(O){return N.id===O.flowFileUuid
}).classed("selected",false).attr("marker-end",function(O){return"url(#"+O.target.type+")"
})
});
var L=M.append("g").attr({"class":"flowfile-icon",transform:function(N){return"translate(-9,-9)"
}});
L.append("path").attr({d:function(N){return"M0, 2 l8, 0 l0, 8 l8, 0 l0, 8 l-16, 0 z"
},"class":"flowfile-icon-base","stroke-width":0,fill:"#93b2b1"});
L.append("path").attr({d:function(N){return"M2, 18 a15, 15 0 0 0 13, -8 l1, 0 l0, 8 z"
},"class":"flowfile-icon-arc",stroke:"#69878a","stroke-width":0.5,fill:"#69878a"});
L.append("path").attr({d:function(N){return"M0, 2 l8, 0 l0, 8 l8, 0 l0, 8 l-16, 0 z"
},"class":"flowfile-icon-base-outline",stroke:"#4f6769","stroke-width":0.5,fill:"none"});
L.append("path").attr({d:function(N){return"M9, 1 l4, 0 l0, 4 l4, 0 l0, 4 l-8, 0 z"
},"class":"flowfile-icon-mid","stroke-width":0,fill:"#d2e0e5"});
L.append("path").attr({d:function(N){return"M15, 9 a15, 15 0 0 0 1, -4 l1, 0 l0, 4 z"
},"class":"flowfile-icon-arc",stroke:"#69878a","stroke-width":0.5,fill:"#69878a"});
L.append("path").attr({d:function(N){return"M9, 1 l4, 0 l0, 4 l4, 0 l0, 4 l-8, 0 z"
},"class":"flowfile-icon-mid-outline",stroke:"#4f6769","stroke-width":0.5,fill:"none"});
L.append("path").attr({d:function(N){return"M14, 0 l4, 0 l0, 4 l-4, 0 z"
},"class":"flowfile-icon-top",stroke:"#4f6769","stroke-width":0.5,fill:"#fff"})
};
var v=function(L){L.classed("event",true).append("circle").classed("selected",function(M){return M.id===B
}).attr({r:8,fill:"#527991",stroke:"#000","stroke-width":1,id:function(M){return"event-node-"+M.id
}}).on("contextmenu",function(Q){d3.select(this).classed("context",true);
$("#provenance-lineage-context-menu").hide().empty();
var P=[{"class":"lineage-view-event",text:"View details",click:function(){k(Q.id,q)
}}];
if(Q.eventType==="SPAWN"||Q.eventType==="CLONE"||Q.eventType==="FORK"||Q.eventType==="JOIN"||Q.eventType==="REPLAY"){var O=function(S){var V=$("#lineage-percent-complete");
var W=false;
var R=null;
var Y=null;
nf.ProvenanceTable.updateProgress(V,0);
$("#lineage-query-dialog").modal("setButtonModel",[{buttonText:"Cancel",handler:{click:function(){W=true;
if(Y!==null){clearTimeout(Y);
T()
}}}}]).modal("show");
var T=function(){if(nf.Common.isDefinedAndNotNull(R)){e(R)
}$("#lineage-query-dialog").modal("hide")
};
var U=function(Z){i(R).done(function(aa){R=aa.lineage;
X(Z)
}).fail(T)
};
var X=function(Z){if(W===true){T();
return
}if(!nf.Common.isEmpty(R.results.errors)){var ab=R.results.errors;
nf.Dialog.showOkDialog({dialogContent:nf.Common.formatUnorderedList(ab),overlayBackground:false});
T();
return
}nf.ProvenanceTable.updateProgress(V,R.percentCompleted);
if(R.finished===true){var aa=R.results;
if(aa.nodes.length>0){M(aa)
}else{nf.Dialog.showOkDialog({dialogContent:"The lineage search has completed successfully but there no results were found. The events may have aged off.",overlayBackground:false})
}T()
}else{Y=setTimeout(function(){Y=null;
var ad=Z*2;
var ac=ad>nf.ProvenanceTable.MAX_DELAY?nf.ProvenanceTable.MAX_DELAY:ad;
U(ac)
},Z*1000)
}};
h(S).done(function(Z){R=Z.lineage;
X(1)
}).fail(T)
};
var M=function(R){I(R.nodes,R.links)
};
var N=function(R){a(R,q).done(function(U){var T=U.provenanceEvent;
var W=T.flowFileUuid;
var X=d3.set(T.childUuids);
var S=function(aa,ab){if(aa){return ab.id!==R
}else{return ab.flowFileUuid!==W&&$.inArray(W,ab.parentUuids)===-1
}};
var Z=function(aa,ab){if(aa){return true
}else{return ab.flowFileUuid!==W
}};
var V=$.inArray(W,T.childUuids)>=0;
var Y=function(aa){var ab=false;
$.each(E.values(),function(ac,ad){if(aa.has(ad.flowFileUuid)&&S(V,ad)){E.remove(ad.id);
$.each(ad.outgoing,function(af,ae){if(!aa.has(ae.flowFileUuid)){aa.add(ae.flowFileUuid);
ab=true
}})
}});
$.each(z.values(),function(ac,ae){if(aa.has(ae.flowFileUuid)&&Z(V,ae)){z.remove(ae.id);
var ad=ae.target;
if(!aa.has(ad.flowFileUuid)){aa.add(ad.flowFileUuid);
ab=true
}}});
if(ab){Y(aa)
}};
Y(X);
o()
})
};
P.push({"class":"lineage-view-parents",text:"Find parents",click:function(){O({lineageRequestType:"PARENTS",eventId:Q.id,clusterNodeId:q})
}},{"class":"lineage-view-children",text:"Expand",click:function(){O({lineageRequestType:"CHILDREN",eventId:Q.id,clusterNodeId:q})
}},{"class":"lineage-collapse-children",text:"Collapse",click:function(){N(Q.id)
}})
}b(P)
});
L.append("text").attr({id:function(M){return"event-text-"+M.id
},"class":"event-type"}).classed("expand-parents",function(M){return M.eventType==="SPAWN"
}).classed("expand-children",function(M){return M.eventType==="SPAWN"
}).each(function(O){var N=d3.select(this);
if(O.eventType==="CONTENT_MODIFIED"||O.eventType==="ATTRIBUTES_MODIFIED"){var M=[];
if(O.eventType==="CONTENT_MODIFIED"){M.push("CONTENT")
}else{M.push("ATTRIBUTES")
}M.push("MODIFIED");
$.each(M,function(Q,P){N.append("tspan").attr("x","0").attr("dy","1.2em").text(function(){return P
})
});
N.attr("transform","translate(10,-14)")
}else{N.text(O.eventType).attr({x:10,y:4})
}})
};
var t=function(){F=F.data(E.values(),function(M){return M.id
});
var L=F.enter().append("g").attr("id",function(M){return"lineage-group-"+M.id
}).classed("node",true).attr("transform",function(M){if(M.incoming.length===0){return"translate("+(G/2)+",50)"
}else{return"translate("+M.incoming[0].source.x+","+M.incoming[0].source.y+")"
}}).style("opacity",0);
L.filter(function(M){return M.type==="FLOWFILE"
}).call(A);
L.filter(function(M){return M.type==="EVENT"
}).call(v);
F.transition().duration(400).attr("transform",function(M){return"translate("+M.x+", "+M.y+")"
}).style("opacity",1);
F.exit().transition().delay(200).duration(400).attr("transform",function(M){if(M.incoming.length===0){return"translate("+(G/2)+",50)"
}else{return"translate("+M.incoming[0].source.x+","+M.incoming[0].source.y+")"
}}).style("opacity",0).remove();
m=m.data(z.values(),function(M){return M.id
});
m.enter().insert("path",".node").attr({"class":"link","stroke-width":1.5,stroke:"#000",fill:"none",d:function(M){return"M"+M.source.x+","+M.source.y+"L"+M.source.x+","+M.source.y
}}).style("opacity",0);
m.attr("marker-end","").transition().delay(200).duration(400).attr({"marker-end":function(M){return"url(#"+M.target.type+")"
},d:function(M){return"M"+M.source.x+","+M.source.y+"L"+M.target.x+","+M.target.y
}}).style("opacity",1);
m.exit().attr("marker-end","").transition().duration(400).attr("d",function(M){return"M"+M.source.x+","+M.source.y+"L"+M.source.x+","+M.source.y
}).style("opacity",0).remove()
};
$("#provenance-lineage").show();
$("#provenance-event-search, #provenance-filter-controls, #oldest-event-message").hide();
I(y.nodes,y.links)
};
return{init:function(){$("#provenance-lineage-closer").on("click",function(){$("#provenance-lineage svg").remove();
$("#provenance-lineage-slider").slider("destroy");
$("#provenance-event-search, #provenance-filter-controls, #oldest-event-message").show();
$("#provenance-lineage").hide()
});
$("#provenance-lineage-downloader").on("click",function(){var o=$("#provenance-lineage-container").html();
var n=$("g.lineage")[0];
var q=n.getBBox();
var m=q.height+30;
var p=q.width+30;
var l=q.x-15;
var r=q.y-15;
o=o.replace(/height=".*?"/,'height="'+m+'"');
o=o.replace(/width=".*?"/,'width="'+p+'"');
o=o.replace(/transform=".*?"/,"");
o=o.replace(/<path([^>]*?)d="M[\s]?([^\s]+?)[\s,]([^\s]+?)[\s]?L[\s]?([^\s]+?)[\s,]([^\s]+?)[\s]?"(.*?)>/g,function(x,B,C,A,z,y,s){if(B.indexOf("link")===-1&&s.indexOf("link")===-1){return x
}var w=parseFloat(C)-l;
var v=parseFloat(A)-r;
var u=parseFloat(z)-l;
var t=parseFloat(y)-r;
return"<path"+B+'d="M'+w+","+v+"L"+u+","+t+'"'+s+">"
});
o=o.replace(/<g([^>]*?)transform="translate\([\s]?([^\s]+?)[\s,]([^\s]+?)[\s]?\)"(.*?)>/g,function(v,w,u,t,z){if(w.indexOf("node")===-1&&z.indexOf("node")===-1){return v
}var s=parseFloat(u)-l;
var A=parseFloat(t)-r;
return"<g"+w+'transform="translate('+s+","+A+')"'+z+">"
});
nf.Common.submit("POST","./convert-svg",{filename:"provenance",svg:encodeURIComponent(o)})
});
f()
},showLineage:function(n,l,p){var u=$("#lineage-percent-complete");
var q=false;
var t=null;
var o=null;
var s={lineageRequestType:"FLOWFILE",uuid:n,clusterNodeId:p};
nf.ProvenanceTable.updateProgress(u,0);
$("#lineage-query-dialog").modal("setButtonModel",[{buttonText:"Cancel",handler:{click:function(){q=true;
if(o!==null){clearTimeout(o);
m()
}}}}]).modal("show");
var m=function(){if(nf.Common.isDefinedAndNotNull(t)){e(t)
}$("#lineage-query-dialog").modal("hide")
};
var v=function(w){i(t).done(function(x){t=x.lineage;
r(w)
}).fail(m)
};
var r=function(w){if(q===true){m();
return
}if(!nf.Common.isEmpty(t.results.errors)){var x=t.results.errors;
nf.Dialog.showOkDialog({dialogContent:nf.Common.formatUnorderedList(x),overlayBackground:false});
m();
return
}nf.ProvenanceTable.updateProgress(u,t.percentCompleted);
if(t.finished===true){j(t.results,l,p);
m()
}else{o=setTimeout(function(){o=null;
var z=w*2;
var y=z>nf.ProvenanceTable.MAX_DELAY?nf.ProvenanceTable.MAX_DELAY:z;
v(y)
},w*1000)
}};
h(s).done(function(w){t=w.lineage;
r(1)
}).fail(m)
}}
}());