$(document).ready(function(){nf.Provenance.init()
});
nf.Provenance=(function(){var b={urls:{cluster:"../nifi-api/cluster",banners:"../nifi-api/controller/banners",config:"../nifi-api/controller/config",controllerAbout:"../nifi-api/controller/about",authorities:"../nifi-api/controller/authorities"}};
var d=null;
var c=function(){return $.Deferred(function(g){$.ajax({type:"HEAD",url:b.urls.cluster}).done(function(){d=true;
g.resolve()
}).fail(function(j,h,i){if(j.status===404){d=false;
g.resolve()
}else{nf.Common.handleAjaxError(j,h,i);
g.reject()
}})
}).promise()
};
var a=function(){return $.ajax({type:"GET",url:b.urls.config,dataType:"json"}).done(function(g){var h=g.config;
$("#nifi-controller-uri").text(h.uri);
if(!nf.Common.isBlank(h.contentViewerUrl)){$("#nifi-content-viewer-url").text(h.contentViewerUrl)
}}).fail(nf.Common.handleAjaxError)
};
var f=function(){return $.Deferred(function(g){$.ajax({type:"GET",url:b.urls.authorities,dataType:"json"}).done(function(h){if(nf.Common.isDefinedAndNotNull(h.authorities)){nf.Common.setAuthorities(h.authorities);
g.resolve(h)
}else{g.reject()
}}).fail(function(j,h,i){nf.Common.handleAjaxError(j,h,i);
g.reject()
})
}).promise()
};
var e=function(){nf.Common.addHoverEffect("#refresh-button","button-refresh","button-refresh-hover").click(function(){nf.ProvenanceTable.loadProvenanceTable()
});
return $.Deferred(function(g){if(top===window){$.ajax({type:"GET",url:b.urls.banners,dataType:"json"}).done(function(l){if(nf.Common.isDefinedAndNotNull(l.banners)){if(nf.Common.isDefinedAndNotNull(l.banners.headerText)&&l.banners.headerText!==""){var i=$("#banner-header").text(l.banners.headerText).show();
var k=function(m){var n=$("#"+m);
n.css("top",(parseInt(i.css("height"),10)+parseInt(n.css("top"),10))+"px")
};
k("provenance")
}if(nf.Common.isDefinedAndNotNull(l.banners.footerText)&&l.banners.footerText!==""){var h=$("#banner-footer").text(l.banners.footerText).show();
var j=function(m){var n=$("#"+m);
n.css("bottom",parseInt(h.css("height"),10)+"px")
};
j("provenance")
}}g.resolve()
}).fail(function(j,h,i){nf.Common.handleAjaxError(j,h,i);
g.reject()
})
}else{g.resolve()
}}).promise()
};
return{init:function(){$.when(a(),f(),c()).done(function(){nf.ProvenanceTable.init(d).done(function(){nf.ProvenanceTable.loadProvenanceTable();
e().done(function(){nf.ProvenanceTable.resetTableSize();
$.ajax({type:"GET",url:b.urls.controllerAbout,dataType:"json"}).done(function(h){var g=h.about;
var i=g.title+" Data Provenance";
document.title=i;
$("#provenance-header-text").text(i)
}).fail(nf.Common.handleAjaxError)
})
})
})
}}
}());