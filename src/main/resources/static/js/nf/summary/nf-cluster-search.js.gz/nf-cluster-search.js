nf.ClusterSearch=(function(){var a={search:"Search nodes",urls:{clusterSearch:"../nifi-api/cluster/search-results",status:"../nifi-api/controller/process-groups/root/status",systemDiagnostics:"../nifi-api/system-diagnostics"}};
return{init:function(){$("#view-single-node-dialog").modal({headerText:"Select node",overlayBackground:false,buttons:[{buttonText:"Ok",handler:{click:function(){var b=$("#cluster-search-field").val();
$.ajax({type:"GET",data:{q:b},dataType:"json",url:a.urls.clusterSearch}).done(function(c){var d=c.nodeResults;
if(!$.isArray(d)||d.length===0){nf.Dialog.showOkDialog({dialogContent:"No nodes match '"+nf.Common.escapeHtml(b)+"'.",overlayBackground:false})
}else{if(d.length>1){nf.Dialog.showOkDialog({dialogContent:"More than one node matches '"+nf.Common.escapeHtml(b)+"'.",overlayBackground:false})
}else{if(d.length===1){var e=d[0];
nf.SummaryTable.url="../nifi-api/cluster/nodes/"+encodeURIComponent(e.id)+"/status";
nf.SummaryTable.systemDiagnosticsUrl="../nifi-api/cluster/nodes/"+encodeURIComponent(e.id)+"/system-diagnostics";
nf.SummaryTable.loadProcessorSummaryTable();
$("#summary-header-text").text(e.address+" Summary");
$("#view-single-node-dialog").modal("hide")
}}}})
}}},{buttonText:"Cancel",handler:{click:function(){this.modal("hide")
}}}],handler:{close:function(){$("#cluster-search-field").val(a.search).addClass("search-nodes")
}}});
$.widget("nf.clusterSearchAutocomplete",$.ui.autocomplete,{_normalize:function(c){var b=[];
b.push(c);
return b
},_renderMenu:function(d,c){var e=c[0];
var b=this;
$.each(e.nodeResults,function(f,g){b._renderItemData(d,{label:g.address,value:g.address})
});
if(d.children().length===0){d.append('<li class="unset search-no-matches">No nodes matched the search terms</li>')
}},_resizeMenu:function(){var b=this.menu.element;
b.width(299)
}});
$("#cluster-search-field").clusterSearchAutocomplete({minLength:0,appendTo:"#search-cluster-results",position:{my:"left top",at:"left bottom",offset:"0 1"},source:function(c,b){$.ajax({type:"GET",data:{q:c.term},dataType:"json",url:a.urls.clusterSearch}).done(function(d){b(d)
})
}}).focus(function(){if($(this).val()===a.search){$(this).val("").removeClass("search-nodes")
}}).val(a.search).addClass("search-nodes");
$("#view-single-node-link").click(function(){$("#view-single-node-dialog").modal("show")
});
$("#view-cluster-link").click(function(){nf.SummaryTable.url=a.urls.status;
nf.SummaryTable.systemDiagnosticsUrl=a.urls.systemDiagnostics;
nf.SummaryTable.loadProcessorSummaryTable();
$("#summary-header-text").text("NiFi Summary")
});
$("#view-options-container").show()
}}
}());