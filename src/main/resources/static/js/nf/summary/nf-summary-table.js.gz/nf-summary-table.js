nf.SummaryTable=(function(){var p={filterText:"Filter",styles:{filterList:"summary-filter-list"},urls:{status:"../nifi-api/controller/process-groups/root/status",processGroups:"../nifi-api/controller/process-groups/",clusterProcessor:"../nifi-api/cluster/processors/",clusterConnection:"../nifi-api/cluster/connections/",clusterInputPort:"../nifi-api/cluster/input-ports/",clusterOutputPort:"../nifi-api/cluster/output-ports/",clusterRemoteProcessGroup:"../nifi-api/cluster/remote-process-groups/",systemDiagnostics:"../nifi-api/system-diagnostics",controllerConfig:"../nifi-api/controller/config",d3Script:"js/d3/d3.min.js",statusHistory:"js/nf/nf-status-history.js"}};
var d=function(){return $.Deferred(function(s){if(nf.Common.SUPPORTS_SVG){nf.Common.cachedScript(p.urls.d3Script).done(function(){var t=$.ajax({type:"GET",url:p.urls.controllerConfig,dataType:"json"});
$.when(t,nf.Common.cachedScript(p.urls.statusHistory)).done(function(v){var w=v[0];
var u=w.config;
nf.StatusHistory.init(u.timeOffset);
s.resolve()
}).fail(function(){s.reject()
})
}).fail(function(){s.reject()
})
}else{s.resolve()
}}).promise()
};
var r=function(t,s){if(top!==window){if(nf.Common.isDefinedAndNotNull(parent.nf)&&nf.Common.isDefinedAndNotNull(parent.nf.CanvasUtils)&&nf.Common.isDefinedAndNotNull(parent.nf.Shell)){parent.nf.CanvasUtils.showComponent(t,s);
parent.$("#shell-close-button").click()
}}};
var i=function(av){$("#summary-filter").keyup(function(){q()
}).focus(function(){if($(this).hasClass(p.styles.filterList)){$(this).removeClass(p.styles.filterList).val("")
}}).blur(function(){if($(this).val()===""){$(this).addClass(p.styles.filterList).val(p.filterText)
}}).addClass(p.styles.filterList).val(p.filterText);
$("#summary-tabs").tabbs({tabStyle:"summary-tab",selectedTabStyle:"summary-selected-tab",tabs:[{name:"Processors",tabContentId:"processor-summary-tab-content"},{name:"Input Ports",tabContentId:"input-port-summary-tab-content"},{name:"Output Ports",tabContentId:"output-port-summary-tab-content"},{name:"Remote Process Groups",tabContentId:"remote-process-group-summary-tab-content"},{name:"Connections",tabContentId:"connection-summary-tab-content"}],select:function(){var aJ=$(this).text();
if(aJ==="Processors"){var aI=$("#processor-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(aI)){aI.resizeCanvas();
$("#displayed-items").text(nf.Common.formatInteger(aI.getData().getLength()));
$("#total-items").text(nf.Common.formatInteger(aI.getData().getLength()))
}$("#summary-filter-type").combo({options:[{text:"by name",value:"name"},{text:"by type",value:"type"}],select:function(aN){q()
}})
}else{if(aJ==="Connections"){var aH=$("#connection-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(aH)){aH.resizeCanvas();
$("#displayed-items").text(nf.Common.formatInteger(aH.getData().getLength()));
$("#total-items").text(nf.Common.formatInteger(aH.getData().getLength()))
}$("#summary-filter-type").combo({options:[{text:"by source",value:"sourceName"},{text:"by name",value:"name"},{text:"by destination",value:"destinationName"}],select:function(aN){q()
}})
}else{if(aJ==="Input Ports"){var aM=$("#input-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(aM)){aM.resizeCanvas();
$("#displayed-items").text(nf.Common.formatInteger(aM.getData().getLength()));
$("#total-items").text(nf.Common.formatInteger(aM.getData().getLength()))
}$("#summary-filter-type").combo({options:[{text:"by name",value:"name"}],select:function(aN){q()
}})
}else{if(aJ==="Output Ports"){var aL=$("#output-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(aL)){aL.resizeCanvas();
$("#displayed-items").text(nf.Common.formatInteger(aL.getData().getLength()));
$("#total-items").text(nf.Common.formatInteger(aL.getData().getLength()))
}$("#summary-filter-type").combo({options:[{text:"by name",value:"name"}],select:function(aN){q()
}})
}else{var aK=$("#remote-process-group-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(aK)){aK.resizeCanvas();
$("#displayed-items").text(nf.Common.formatInteger(aK.getData().getLength()));
$("#total-items").text(nf.Common.formatInteger(aK.getData().getLength()))
}$("#summary-filter-type").combo({options:[{text:"by name",value:"name"},{text:"by uri",value:"targetUri"}],select:function(aN){q()
}})
}}}}$("#summary-filter").addClass(p.styles.filterList).val(p.filterText);
q()
}});
$(window).resize(function(){nf.SummaryTable.resetTableSize()
});
var aB=function(aM,aI,aL,aK,aH){var aJ='<img src="images/iconDetails.png" title="View Details" class="pointer" style="margin-top: 5px; float: left;" onclick="javascript:nf.SummaryTable.showProcessorDetails(\''+aM+"');\"/>";
if(!nf.Common.isEmpty(aH.bulletins)){aJ+='<img src="images/iconBulletin.png" class="has-bulletins" style="margin-top: 5px; margin-left: 5px; float: left;"/><span class="hidden row-id">'+nf.Common.escapeHtml(aH.id)+"</span>"
}return aJ
};
var V=function(aL,aI,aK,aJ,aH){return aH.read+" / "+aH.written
};
var ac=function(aL,aI,aK,aJ,aH){return nf.Common.formatInteger(aH.tasks)+" / "+aH.tasksDuration
};
var au=function(aL,aI,aK,aJ,aH){return nf.Common.formatValue(aK)
};
var F=function(aN,aI,aM,aJ,aH){var aL="";
if(nf.Common.isDefinedAndNotNull(aH.activeThreadCount)&&aH.activeThreadCount>0){aL="("+aH.activeThreadCount+")"
}var aK='<div class="'+nf.Common.escapeHtml(aM.toLowerCase())+'" style="margin-top: 3px;"></div>';
return aK+'<div class="status-text" style="margin-top: 4px;">'+nf.Common.escapeHtml(aM)+'</div><div style="float: left; margin-left: 4px;">'+nf.Common.escapeHtml(aL)+"</div>"
};
var E={id:"name",field:"name",name:"Name",sortable:true,resizable:true};
var ar={id:"runStatus",field:"runStatus",name:"Run Status",formatter:F,sortable:true};
var w={id:"input",field:"input",name:'<span class="input-title">In</span>&nbsp;/&nbsp;<span class="input-size-title">Size</span>&nbsp;<span style="font-weight: normal; overflow: hidden;">5 min</span>',toolTip:"Count / data size in the last 5 min",sortable:true,resizable:true};
var am={id:"io",field:"io",name:'<span class="read-title">Read</span>&nbsp;/&nbsp;<span class="written-title">Write</span>&nbsp;<span style="font-weight: normal; overflow: hidden;">5 min</span>',toolTip:"Data size in the last 5 min",formatter:V,sortable:true,resizable:true};
var R={id:"output",field:"output",name:'<span class="output-title">Out</span>&nbsp;/&nbsp;<span class="output-size-title">Size</span>&nbsp;<span style="font-weight: normal; overflow: hidden;">5 min</span>',toolTip:"Count / data size in the last 5 min",sortable:true,resizable:true};
var U={id:"tasks",field:"tasks",name:'<span class="tasks-title">Tasks</span>&nbsp;/&nbsp;<span class="time-title">Time</span>&nbsp;<span style="font-weight: normal; overflow: hidden;">5 min</span>',toolTip:"Count / duration in the last 5 min",formatter:ac,sortable:true,resizable:true};
var s=[{id:"moreDetails",field:"moreDetails",name:"&nbsp;",resizable:false,formatter:aB,sortable:true,width:50,maxWidth:50},E,{id:"type",field:"type",name:"Type",sortable:true,resizable:true},ar,w,am,R,U];
if(av){nf.ClusterSearch.init()
}var ad=(top!==window);
if(av||ad||nf.Common.SUPPORTS_SVG){var ap=function(aM,aI,aL,aK,aH){var aJ="";
if(ad){aJ+='<img src="images/iconGoTo.png" title="Go To" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.goToProcessor(\''+aM+"');\"/>&nbsp;"
}if(nf.Common.SUPPORTS_SVG){if(av){aJ+='<img src="images/iconChart.png" title="Show History" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterProcessorStatusHistory(\''+aM+"');\"/>&nbsp;"
}else{aJ+='<img src="images/iconChart.png" title="Show History" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showProcessorStatusHistory(\''+aM+"');\"/>&nbsp;"
}}if(av){aJ+='<img src="images/iconClusterSmall.png" title="Show Details" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterProcessorSummary(\''+aM+"');\"/>&nbsp;"
}return aJ
};
s.push({id:"action",name:"&nbsp;",formatter:ap,resizable:false,sortable:false,width:75,maxWidth:75})
}var aD={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var t=new Slick.Data.DataView({inlineFilters:false});
t.setItems([]);
t.setFilterArgs({searchString:"",property:"name"});
t.setFilter(g);
o("processor-summary-table",{columnId:"name",sortAsc:true},t);
var aw=new Slick.Grid("#processor-summary-table",t,s,aD);
aw.setSelectionModel(new Slick.RowSelectionModel());
aw.registerPlugin(new Slick.AutoTooltips());
aw.setSortColumn("name",true);
aw.onSort.subscribe(function(aI,aH){o("processor-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},t)
});
t.onRowCountChanged.subscribe(function(aI,aH){aw.updateRowCount();
aw.render();
if($("#processor-summary-table").is(":visible")){$("#displayed-items").text(nf.Common.formatInteger(aH.current))
}});
t.onRowsChanged.subscribe(function(aI,aH){aw.invalidateRows(aH.rows);
aw.render()
});
$("#processor-summary-table").data("gridInstance",aw).on("mouseenter","div.slick-cell",function(aL){var aI=$(this).find("img.has-bulletins");
if(aI.length&&!aI.data("qtip")){var aM=$(this).find("span.row-id").text();
var aH=t.getItemById(aM);
var aK=nf.Common.getFormattedBulletins(aH.bulletins);
var aJ=nf.Common.formatUnorderedList(aK);
if(nf.Common.isDefinedAndNotNull(aJ)){aI.qtip($.extend({content:aJ,position:{target:"mouse",viewport:$(window),adjust:{x:8,y:8,method:"flipinvert flipinvert"}}},nf.Common.config.tooltipConfig))
}}});
$("#cluster-processor-summary-dialog").modal({headerText:"Cluster Processor Summary",overlayBackground:false,buttons:[{buttonText:"Close",handler:{click:function(){$("#cluster-processor-id").text("");
$("#cluster-processor-name").text("");
this.modal("hide")
}}}],handler:{close:function(){$("#summary-loading-container").show()
}}});
var ao=[{id:"node",field:"node",name:"Node",sortable:true,resizable:true},ar,w,am,R,U];
var ae={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var K=new Slick.Data.DataView({inlineFilters:false});
K.setItems([]);
o("cluster-processor-summary-table",{columnId:"node",sortAsc:true},K);
var x=new Slick.Grid("#cluster-processor-summary-table",K,ao,ae);
x.setSelectionModel(new Slick.RowSelectionModel());
x.registerPlugin(new Slick.AutoTooltips());
x.setSortColumn("node",true);
x.onSort.subscribe(function(aI,aH){o("cluster-processor-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},K)
});
K.onRowCountChanged.subscribe(function(aI,aH){x.updateRowCount();
x.render()
});
K.onRowsChanged.subscribe(function(aI,aH){x.invalidateRows(aH.rows);
x.render()
});
$("#cluster-processor-summary-table").data("gridInstance",x);
var aA=function(aL,aI,aK,aJ,aH){return'<img src="images/iconDetails.png" title="View Details" class="pointer" style="margin-top: 5px;" onclick="javascript:nf.SummaryTable.showConnectionDetails(\''+aL+"');\"/>"
};
var M={id:"queued",field:"queued",name:'<span class="queued-title">Queue</span>&nbsp;/&nbsp;<span class="queued-size-title">Size</span>',sortable:true,resize:true};
var v=[{id:"moreDetails",name:"&nbsp;",sortable:false,resizable:false,formatter:aA,width:50,maxWidth:50},{id:"sourceName",field:"sourceName",name:"Source Name",sortable:true,resizable:true},{id:"name",field:"name",name:"Name",sortable:true,resizable:true,formatter:au},{id:"destinationName",field:"destinationName",name:"Destination Name",sortable:true,resizable:true},w,M,R];
if(av||ad||nf.Common.SUPPORTS_SVG){var z=function(aM,aI,aL,aK,aH){var aJ="";
if(ad){aJ+='<img src="images/iconGoTo.png" title="Go To" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.goToConnection(\''+aM+"');\"/>&nbsp;"
}if(nf.Common.SUPPORTS_SVG){if(av){aJ+='<img src="images/iconChart.png" title="Show History" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterConnectionStatusHistory(\''+aM+"');\"/>&nbsp;"
}else{aJ+='<img src="images/iconChart.png" title="Show History" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showConnectionStatusHistory(\''+aM+"');\"/>&nbsp;"
}}if(av){aJ+='<img src="images/iconClusterSmall.png" title="Show Details" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterConnectionSummary(\''+aM+"');\"/>&nbsp;"
}return aJ
};
v.push({id:"action",name:"&nbsp;",formatter:z,resizable:false,sortable:false,width:75,maxWidth:75})
}var aa={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var ab=new Slick.Data.DataView({inlineFilters:false});
ab.setItems([]);
ab.setFilterArgs({searchString:"",property:"sourceName"});
ab.setFilter(g);
o("connection-summary-table",{columnId:"sourceName",sortAsc:true},ab);
var S=new Slick.Grid("#connection-summary-table",ab,v,aa);
S.setSelectionModel(new Slick.RowSelectionModel());
S.registerPlugin(new Slick.AutoTooltips());
S.setSortColumn("sourceName",true);
S.onSort.subscribe(function(aI,aH){o("connection-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},ab)
});
ab.onRowCountChanged.subscribe(function(aI,aH){S.updateRowCount();
S.render();
if($("#connection-summary-table").is(":visible")){$("#displayed-items").text(nf.Common.formatInteger(aH.current))
}});
ab.onRowsChanged.subscribe(function(aI,aH){S.invalidateRows(aH.rows);
S.render()
});
$("#connection-summary-table").data("gridInstance",S);
$("#cluster-connection-summary-dialog").modal({headerText:"Cluster Connection Summary",overlayBackground:false,buttons:[{buttonText:"Close",handler:{click:function(){$("#cluster-connection-id").text("");
$("#cluster-connection-name").text("");
this.modal("hide")
}}}],handler:{close:function(){$("#summary-loading-container").show()
}}});
var at=[{id:"node",field:"node",name:"Node",sortable:true,resizable:true},w,M,R];
var N={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var A=new Slick.Data.DataView({inlineFilters:false});
A.setItems([]);
o("cluster-connection-summary-table",{columnId:"node",sortAsc:true},A);
var aF=new Slick.Grid("#cluster-connection-summary-table",A,at,N);
aF.setSelectionModel(new Slick.RowSelectionModel());
aF.registerPlugin(new Slick.AutoTooltips());
aF.setSortColumn("node",true);
aF.onSort.subscribe(function(aI,aH){o("cluster-connection-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},A)
});
A.onRowCountChanged.subscribe(function(aI,aH){aF.updateRowCount();
aF.render()
});
A.onRowsChanged.subscribe(function(aI,aH){aF.invalidateRows(aH.rows);
aF.render()
});
$("#cluster-connection-summary-table").data("gridInstance",aF);
var az=function(aM,aI,aL,aK,aH){var aJ="";
if(!nf.Common.isEmpty(aH.bulletins)){aJ+='<img src="images/iconBulletin.png" class="has-bulletins" style="margin-top: 5px; margin-left: 5px; float: left;"/><span class="hidden row-id">'+nf.Common.escapeHtml(aH.id)+"</span>"
}return aJ
};
var T=[{id:"moreDetails",field:"moreDetails",name:"&nbsp;",resizable:false,formatter:az,sortable:true,width:50,maxWidth:50},E,ar,R];
if(av||ad){var aj=function(aM,aI,aL,aK,aH){var aJ="";
if(ad){aJ+='<img src="images/iconGoTo.png" title="Go To" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.goToInputPort(\''+aM+"');\"/>&nbsp;"
}if(av){aJ+='<img src="images/iconClusterSmall.png" title="Show Details" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterInputPortSummary(\''+aM+"');\"/>&nbsp;"
}return aJ
};
T.push({id:"action",name:"&nbsp;",formatter:aj,resizable:false,sortable:false,width:75,maxWidth:75})
}var ag={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var W=new Slick.Data.DataView({inlineFilters:false});
W.setItems([]);
W.setFilterArgs({searchString:"",property:"name"});
W.setFilter(g);
o("input-port-summary-table",{columnId:"name",sortAsc:true},W);
var G=new Slick.Grid("#input-port-summary-table",W,T,ag);
G.setSelectionModel(new Slick.RowSelectionModel());
G.registerPlugin(new Slick.AutoTooltips());
G.setSortColumn("name",true);
G.onSort.subscribe(function(aI,aH){o("input-port-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},W)
});
W.onRowCountChanged.subscribe(function(aI,aH){G.updateRowCount();
G.render();
if($("#input-port-summary-table").is(":visible")){$("#display-items").text(nf.Common.formatInteger(aH.current))
}});
W.onRowsChanged.subscribe(function(aI,aH){G.invalidateRows(aH.rows);
G.render()
});
$("#input-port-summary-table").data("gridInstance",G).on("mouseenter","div.slick-cell",function(aM){var aJ=$(this).find("img.has-bulletins");
if(aJ.length&&!aJ.data("qtip")){var aH=$(this).find("span.row-id").text();
var aI=W.getItemById(aH);
var aL=nf.Common.getFormattedBulletins(aI.bulletins);
var aK=nf.Common.formatUnorderedList(aL);
if(nf.Common.isDefinedAndNotNull(aK)){aJ.qtip($.extend({content:aK,position:{target:"mouse",viewport:$(window),adjust:{x:8,y:8,method:"flipinvert flipinvert"}}},nf.Common.config.tooltipConfig))
}}});
$("#cluster-input-port-summary-dialog").modal({headerText:"Cluster Input Port Summary",overlayBackground:false,buttons:[{buttonText:"Close",handler:{click:function(){$("#cluster-input-port-id").text("");
$("#cluster-input-port-name").text("");
this.modal("hide")
}}}],handler:{close:function(){$("#summary-loading-container").show()
}}});
var D=[{id:"node",field:"node",name:"Node",sortable:true,resizable:true},ar,R];
var P={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var ai=new Slick.Data.DataView({inlineFilters:false});
ai.setItems([]);
o("cluster-input-port-summary-table",{columnId:"node",sortAsc:true},ai);
var Z=new Slick.Grid("#cluster-input-port-summary-table",ai,D,P);
Z.setSelectionModel(new Slick.RowSelectionModel());
Z.registerPlugin(new Slick.AutoTooltips());
Z.setSortColumn("node",true);
Z.onSort.subscribe(function(aI,aH){o("cluster-input-port-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},ai)
});
ai.onRowCountChanged.subscribe(function(aI,aH){Z.updateRowCount();
Z.render()
});
ai.onRowsChanged.subscribe(function(aI,aH){Z.invalidateRows(aH.rows);
Z.render()
});
$("#cluster-input-port-summary-table").data("gridInstance",Z);
var X=[{id:"moreDetails",field:"moreDetails",name:"&nbsp;",resizable:false,formatter:az,sortable:true,width:50,maxWidth:50},E,ar,w];
if(av||ad){var Q=function(aM,aI,aL,aK,aH){var aJ="";
if(ad){aJ+='<img src="images/iconGoTo.png" title="Go To" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.goToOutputPort(\''+aM+"');\"/>&nbsp;"
}if(av){aJ+='<img src="images/iconClusterSmall.png" title="Show Details" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterOutputPortSummary(\''+aM+"');\"/>&nbsp;"
}return aJ
};
X.push({id:"action",name:"&nbsp;",formatter:Q,resizable:false,sortable:false,width:75,maxWidth:75})
}var Y={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var L=new Slick.Data.DataView({inlineFilters:false});
L.setItems([]);
L.setFilterArgs({searchString:"",property:"name"});
L.setFilter(g);
o("output-port-summary-table",{columnId:"name",sortAsc:true},L);
var y=new Slick.Grid("#output-port-summary-table",L,X,Y);
y.setSelectionModel(new Slick.RowSelectionModel());
y.registerPlugin(new Slick.AutoTooltips());
y.setSortColumn("name",true);
y.onSort.subscribe(function(aI,aH){o("output-port-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},L)
});
L.onRowCountChanged.subscribe(function(aI,aH){y.updateRowCount();
y.render();
if($("#output-port-summary-table").is(":visible")){$("#display-items").text(nf.Common.formatInteger(aH.current))
}});
L.onRowsChanged.subscribe(function(aI,aH){y.invalidateRows(aH.rows);
y.render()
});
$("#output-port-summary-table").data("gridInstance",y).on("mouseenter","div.slick-cell",function(aM){var aJ=$(this).find("img.has-bulletins");
if(aJ.length&&!aJ.data("qtip")){var aH=$(this).find("span.row-id").text();
var aI=L.getItemById(aH);
var aL=nf.Common.getFormattedBulletins(aI.bulletins);
var aK=nf.Common.formatUnorderedList(aL);
if(nf.Common.isDefinedAndNotNull(aK)){aJ.qtip($.extend({content:aK,position:{target:"mouse",viewport:$(window),adjust:{x:8,y:8,method:"flipinvert flipinvert"}}},nf.Common.config.tooltipConfig))
}}});
$("#cluster-output-port-summary-dialog").modal({headerText:"Cluster Output Port Summary",overlayBackground:false,buttons:[{buttonText:"Close",handler:{click:function(){$("#cluster-output-port-id").text("");
$("#cluster-output-port-name").text("");
this.modal("hide")
}}}],handler:{close:function(){$("#summary-loading-container").show()
}}});
var J=[{id:"node",field:"node",name:"Node",sortable:true,resizable:true},ar,w];
var H={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var aC=new Slick.Data.DataView({inlineFilters:false});
aC.setItems([]);
o("cluster-output-port-summary-table",{columnId:"node",sortAsc:true},aC);
var ak=new Slick.Grid("#cluster-output-port-summary-table",aC,J,H);
ak.setSelectionModel(new Slick.RowSelectionModel());
ak.registerPlugin(new Slick.AutoTooltips());
ak.setSortColumn("node",true);
ak.onSort.subscribe(function(aI,aH){o("cluster-output-port-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},aC)
});
aC.onRowCountChanged.subscribe(function(aI,aH){ak.updateRowCount();
ak.render()
});
aC.onRowsChanged.subscribe(function(aI,aH){ak.invalidateRows(aH.rows);
ak.render()
});
$("#cluster-output-port-summary-table").data("gridInstance",ak);
var ah=function(aP,aN,aM,aK,aH){var aL="";
if(nf.Common.isDefinedAndNotNull(aH.activeThreadCount)&&aH.activeThreadCount>0){aL="("+aH.activeThreadCount+")"
}var aO="invalid";
var aI="Invalid";
if(nf.Common.isEmpty(aH.authorizationIssues)){if(aM==="Transmitting"){aO="transmitting";
aI=aM
}else{aO="not-transmitting";
aI="Not Transmitting"
}}var aJ='<div class="'+aO+'" style="margin-top: 3px;"></div>';
return aJ+'<div class="status-text" style="margin-top: 4px;">'+aI+'</div><div style="float: left; margin-left: 4px;">'+nf.Common.escapeHtml(aL)+"</div>"
};
var ax={id:"transmissionStatus",field:"transmissionStatus",name:"Transmitting",formatter:ah,sortable:true,resizable:true};
var aE={id:"targetUri",field:"targetUri",name:"Target URI",sortable:true,resizable:true};
var u={id:"sent",field:"sent",name:'<span class="sent-title">Sent</span>&nbsp;/&nbsp;<span class="sent-size-title">Size</span>&nbsp;<span style="font-weight: normal; overflow: hidden;">5 min</span>',toolTip:"Count / data size in the last 5 min",sortable:true,resizable:true};
var ay={id:"received",field:"received",name:'<span class="received-title">Received</span>&nbsp;/&nbsp;<span class="received-size-title">Size</span>&nbsp;<span style="font-weight: normal; overflow: hidden;">5 min</span>',toolTip:"Count / data size in the last 5 min",sortable:true,resizable:true};
var C=[{id:"moreDetails",field:"moreDetails",name:"&nbsp;",resizable:false,formatter:az,sortable:true,width:50,maxWidth:50},E,aE,ax,u,ay];
if(av||ad||nf.Common.SUPPORTS_SVG){var aG=function(aM,aI,aL,aK,aH){var aJ="";
if(ad){aJ+='<img src="images/iconGoTo.png" title="Go To" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.goToRemoteProcessGroup(\''+aM+"');\"/>&nbsp;"
}if(nf.Common.SUPPORTS_SVG){if(av){aJ+='<img src="images/iconChart.png" title="Show History" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterRemoteProcessGroupStatusHistory(\''+aM+"');\"/>&nbsp;"
}else{aJ+='<img src="images/iconChart.png" title="Show History" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showRemoteProcessGroupStatusHistory(\''+aM+"');\"/>&nbsp;"
}}if(av){aJ+='<img src="images/iconClusterSmall.png" title="Show Details" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.SummaryTable.showClusterRemoteProcessGroupSummary(\''+aM+"');\"/>&nbsp;"
}return aJ
};
C.push({id:"action",name:"&nbsp;",formatter:aG,resizable:false,sortable:false,width:75,maxWidth:75})
}var al={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false,multiSelect:false};
var O=new Slick.Data.DataView({inlineFilters:false});
O.setItems([]);
O.setFilterArgs({searchString:"",property:"name"});
O.setFilter(g);
o("remote-process-group-summary-table",{columnId:"name",sortAsc:true},O);
var B=new Slick.Grid("#remote-process-group-summary-table",O,C,al);
B.setSelectionModel(new Slick.RowSelectionModel());
B.registerPlugin(new Slick.AutoTooltips());
B.setSortColumn("name",true);
B.onSort.subscribe(function(aI,aH){o("remote-process-group-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},O)
});
O.onRowCountChanged.subscribe(function(aI,aH){B.updateRowCount();
B.render();
if($("#remote-process-group-summary-table").is(":visible")){$("#displayed-items").text(nf.Common.formatInteger(aH.current))
}});
O.onRowsChanged.subscribe(function(aI,aH){B.invalidateRows(aH.rows);
B.render()
});
$("#remote-process-group-summary-table").data("gridInstance",B).on("mouseenter","div.slick-cell",function(aM){var aJ=$(this).find("img.has-bulletins");
if(aJ.length&&!aJ.data("qtip")){var aH=$(this).find("span.row-id").text();
var aI=O.getItemById(aH);
var aL=nf.Common.getFormattedBulletins(aI.bulletins);
var aK=nf.Common.formatUnorderedList(aL);
if(nf.Common.isDefinedAndNotNull(aK)){aJ.qtip($.extend({content:aK,position:{target:"mouse",viewport:$(window),adjust:{x:8,y:8,method:"flipinvert flipinvert"}}},nf.Common.config.tooltipConfig))
}}});
$("#cluster-remote-process-group-summary-dialog").modal({headerText:"Cluster Remote Process Group Summary",overlayBackground:false,buttons:[{buttonText:"Close",handler:{click:function(){$("#cluster-remote-process-group-id").text("");
$("#cluster-remote-process-group-name").text("");
this.modal("hide")
}}}],handler:{close:function(){$("#summary-loading-container").show()
}}});
var aq=[{id:"node",field:"node",name:"Node",sortable:true,resizable:true},aE,ax,u,ay];
var I={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:false,enableColumnReorder:false,autoEdit:false};
var an=new Slick.Data.DataView({inlineFilters:false});
an.setItems([]);
o("cluster-remote-process-group-summary-table",{columnId:"node",sortAsc:true},an);
var af=new Slick.Grid("#cluster-remote-process-group-summary-table",an,aq,I);
af.setSelectionModel(new Slick.RowSelectionModel());
af.registerPlugin(new Slick.AutoTooltips());
af.setSortColumn("node",true);
af.onSort.subscribe(function(aI,aH){o("cluster-remote-process-group-summary-table",{columnId:aH.sortCol.field,sortAsc:aH.sortAsc},an)
});
an.onRowCountChanged.subscribe(function(aI,aH){af.updateRowCount();
af.render()
});
an.onRowsChanged.subscribe(function(aI,aH){af.invalidateRows(aH.rows);
af.render()
});
$("#cluster-remote-process-group-summary-table").data("gridInstance",af);
$("#system-diagnostics-link").click(function(){j().done(function(){$("#summary-loading-container").hide();
$("#system-diagnostics-dialog").modal("show")
})
});
$("#system-diagnostics-tabs").tabbs({tabStyle:"summary-tab",selectedTabStyle:"summary-selected-tab",tabs:[{name:"JVM",tabContentId:"jvm-tab-content"},{name:"System",tabContentId:"system-tab-content"}]});
$("#system-diagnostics-dialog").modal({headerText:"System Diagnostics",overlayBackground:false,buttons:[{buttonText:"Close",handler:{click:function(){this.modal("hide")
}}}],handler:{close:function(){$("#summary-loading-container").show()
}}});
nf.Common.addHoverEffect("#system-diagnostics-refresh-button","button-refresh","button-refresh-hover").click(function(){j()
});
$("#total-items").text("0")
};
var a={};
var o=function(u,s,v){if(nf.Common.isUndefined(a[u])){a[u]={}
}var t=function(Q,P){if(s.columnId==="moreDetails"){var L=0;
if(!nf.Common.isEmpty(Q.bulletins)){L=Q.bulletins.length
}var z=0;
if(!nf.Common.isEmpty(P.bulletins)){z=P.bulletins.length
}return L-z
}else{if(s.columnId==="runStatus"||s.columnId==="transmissionStatus"){var H=nf.Common.isDefinedAndNotNull(Q[s.columnId])?Q[s.columnId]:"";
var F=nf.Common.isDefinedAndNotNull(P[s.columnId])?P[s.columnId]:"";
if(H===F){return Q.activeThreadCount-P.activeThreadCount
}else{return H===F?0:H>F?1:-1
}}else{if(s.columnId==="queued"){var R=a[u].count%4;
if(R<2){$("#"+u+" span.queued-title").addClass("sorted");
var S=nf.Common.parseCount(Q.queuedCount);
var x=nf.Common.parseCount(P.queuedCount);
return S-x
}else{$("#"+u+" span.queued-size-title").addClass("sorted");
var w=nf.Common.parseSize(Q.queuedSize);
var C=nf.Common.parseSize(P.queuedSize);
return w-C
}}else{if(s.columnId==="sent"||s.columnId==="received"||s.columnId==="input"||s.columnId==="output"){var K=Q[s.columnId].split(/ \/ /);
var N=P[s.columnId].split(/ \/ /);
var R=a[u].count%4;
if(R<2){$("#"+u+" span."+s.columnId+"-title").addClass("sorted");
var B=nf.Common.parseCount(K[0]);
var D=nf.Common.parseCount(N[0]);
return B-D
}else{$("#"+u+" span."+s.columnId+"-size-title").addClass("sorted");
var G=nf.Common.parseSize(K[1]);
var A=nf.Common.parseSize(N[1]);
return G-A
}}else{if(s.columnId==="io"){var R=a[u].count%4;
if(R<2){$("#"+u+" span.read-title").addClass("sorted");
var U=nf.Common.parseSize(Q.read);
var O=nf.Common.parseSize(P.read);
return U-O
}else{$("#"+u+" span.written-title").addClass("sorted");
var E=nf.Common.parseSize(Q.written);
var T=nf.Common.parseSize(P.written);
return E-T
}}else{if(s.columnId==="tasks"){var R=a[u].count%4;
if(R<2){$("#"+u+" span.tasks-title").addClass("sorted");
var J=nf.Common.parseCount(Q.tasks);
var M=nf.Common.parseCount(P.tasks);
return J-M
}else{$("#"+u+" span.time-title").addClass("sorted");
var y=nf.Common.parseDuration(Q.tasksDuration);
var I=nf.Common.parseDuration(P.tasksDuration);
return y-I
}}else{var H=nf.Common.isDefinedAndNotNull(Q[s.columnId])?Q[s.columnId]:"";
var F=nf.Common.isDefinedAndNotNull(P[s.columnId])?P[s.columnId]:"";
return H===F?0:H>F?1:-1
}}}}}}};
$("#"+u+" span.queued-title").removeClass("sorted");
$("#"+u+" span.queued-size-title").removeClass("sorted");
$("#"+u+" span.input-title").removeClass("sorted");
$("#"+u+" span.input-size-title").removeClass("sorted");
$("#"+u+" span.output-title").removeClass("sorted");
$("#"+u+" span.output-size-title").removeClass("sorted");
$("#"+u+" span.read-title").removeClass("sorted");
$("#"+u+" span.written-title").removeClass("sorted");
$("#"+u+" span.time-title").removeClass("sorted");
$("#"+u+" span.tasks-title").removeClass("sorted");
$("#"+u+" span.sent-title").removeClass("sorted");
$("#"+u+" span.sent-size-title").removeClass("sorted");
$("#"+u+" span.received-title").removeClass("sorted");
$("#"+u+" span.received-size-title").removeClass("sorted");
if(a[u].prevColumn!==s.columnId){a[u].count=0
}else{a[u].count++
}v.sort(t,s.sortAsc);
a[u].prevColumn=s.columnId
};
var g=function(t,s){if(s.searchString===""){return true
}try{var v=new RegExp(s.searchString,"i")
}catch(u){return false
}return t[s.property].search(v)>=0
};
var j=function(){return $.ajax({type:"GET",url:nf.SummaryTable.systemDiagnosticsUrl,dataType:"json"}).done(function(v){var u=v.systemDiagnostics;
$("#max-heap").text(u.maxHeap);
$("#total-heap").text(u.totalHeap);
$("#used-heap").text(u.usedHeap);
$("#free-heap").text(u.freeHeap);
$("#utilization-heap").text(u.heapUtilization);
$("#max-non-heap").text(u.maxNonHeap);
$("#total-non-heap").text(u.totalNonHeap);
$("#used-non-heap").text(u.usedNonHeap);
$("#free-non-heap").text(u.freeNonHeap);
$("#utilization-non-heap").text(u.nonHeapUtilization);
var w=$("#garbage-collection-table tbody").empty();
$.each(u.garbageCollection,function(y,x){k(w,x)
});
$("#available-processors").text(u.availableProcessors);
$("#processor-load-average").html(nf.Common.formatValue(u.processorLoadAverage));
var t=$("#flow-file-repository-storage-usage-container").empty();
c(t,u.flowFileRepositoryStorageUsage);
var s=$("#content-repository-storage-usage-container").empty();
$.each(u.contentRepositoryStorageUsage,function(x,y){c(s,y)
});
$("#system-diagnostics-last-refreshed").text(u.statsLastRefreshed)
}).fail(nf.Common.handleAjaxError)
};
var k=function(t,s){var u=$("<tr></tr>").appendTo(t);
$("<td></td>").append($("<b></b>").text(s.name)).appendTo(u);
$("<td></td>").text(s.collectionCount+" times").appendTo(u);
$("<td></td>").text(s.collectionTime).appendTo(u)
};
var c=function(t,w){var v=parseInt(w.totalSpaceBytes,10);
var u=parseInt(w.usedSpaceBytes,10);
var y=$('<div class="storage-usage"></div>').appendTo(t);
$('<div class="storage-usage-progressbar"></div>').progressbar({max:v,value:u}).appendTo(y).children(".ui-progressbar-value").text(w.utilization);
var x=$('<span class="storage-identifier"></span>').text(w.identifier);
var s=$('<span class="storage-usage-details"></span>').text(w.usedSpace+" of "+w.totalSpace);
$('<div class="storage-usage-header"></div>').append(x).append(s).append('<div class="clear"></div>').appendTo(y)
};
var n=function(){var t="";
var s=$("#summary-filter");
if(!s.hasClass(p.styles.filterList)){t=s.val()
}return t
};
var m=function(x,w,v,u,t,s){$.each(s.processorStatus,function(y,z){x.push(z)
});
$.each(s.connectionStatus,function(y,z){w.push(z)
});
$.each(s.inputPortStatus,function(z,y){v.push(y)
});
$.each(s.outputPortStatus,function(z,y){u.push(y)
});
$.each(s.remoteProcessGroupStatus,function(y,z){t.push(z)
});
$.each(s.processGroupStatus,function(z,y){m(x,w,v,u,t,y)
})
};
var q=function(){var s;
if($("#processor-summary-table").is(":visible")){s=$("#processor-summary-table").data("gridInstance")
}else{s=$("#connection-summary-table").data("gridInstance")
}if(nf.Common.isDefinedAndNotNull(s)){var t=s.getData();
t.setFilterArgs({searchString:n(),property:$("#summary-filter-type").combo("getSelectedOption").value});
t.refresh()
}};
var h=function(s){$.ajax({type:"GET",url:p.urls.clusterProcessor+encodeURIComponent(s)+"/status",data:{verbose:true},dataType:"json"}).done(function(t){if(nf.Common.isDefinedAndNotNull(t.clusterProcessorStatus)){var w=t.clusterProcessorStatus;
var v=$("#cluster-processor-summary-table").data("gridInstance");
var x=v.getData();
var u=[];
$.each(w.nodeProcessorStatus,function(y,z){u.push({id:z.node.nodeId,node:z.node.address+":"+z.node.apiPort,runStatus:z.processorStatus.runStatus,activeThreadCount:z.processorStatus.activeThreadCount,input:z.processorStatus.input,read:z.processorStatus.read,written:z.processorStatus.written,output:z.processorStatus.output,tasks:z.processorStatus.tasks,tasksDuration:z.processorStatus.tasksDuration})
});
x.setItems(u);
x.reSort();
v.invalidate();
$("#cluster-processor-name").text(w.processorName).ellipsis();
$("#cluster-processor-id").text(w.processorId);
$("#cluster-processor-summary-last-refreshed").text(w.statsLastRefreshed)
}}).fail(nf.Common.handleAjaxError)
};
var b=function(s){$.ajax({type:"GET",url:p.urls.clusterConnection+encodeURIComponent(s)+"/status",data:{verbose:true},dataType:"json"}).done(function(u){if(nf.Common.isDefinedAndNotNull(u.clusterConnectionStatus)){var t=u.clusterConnectionStatus;
var w=$("#cluster-connection-summary-table").data("gridInstance");
var x=w.getData();
var v=[];
$.each(t.nodeConnectionStatus,function(y,z){v.push({id:z.node.nodeId,node:z.node.address+":"+z.node.apiPort,input:z.connectionStatus.input,queued:z.connectionStatus.queued,queuedCount:z.connectionStatus.queuedCount,queuedSize:z.connectionStatus.queuedSize,output:z.connectionStatus.output})
});
x.setItems(v);
x.reSort();
w.invalidate();
$("#cluster-connection-name").text(t.connectionName).ellipsis();
$("#cluster-connection-id").text(t.connectionId);
$("#cluster-connection-summary-last-refreshed").text(t.statsLastRefreshed)
}}).fail(nf.Common.handleAjaxError)
};
var l=function(s){$.ajax({type:"GET",url:p.urls.clusterInputPort+encodeURIComponent(s)+"/status",data:{verbose:true},dataType:"json"}).done(function(u){if(nf.Common.isDefinedAndNotNull(u.clusterPortStatus)){var x=u.clusterPortStatus;
var t=$("#cluster-input-port-summary-table").data("gridInstance");
var v=t.getData();
var w=[];
$.each(x.nodePortStatus,function(z,y){w.push({id:y.node.nodeId,node:y.node.address+":"+y.node.apiPort,runStatus:y.portStatus.runStatus,activeThreadCount:y.portStatus.activeThreadCount,output:y.portStatus.output})
});
v.setItems(w);
v.reSort();
t.invalidate();
$("#cluster-input-port-name").text(x.portName).ellipsis();
$("#cluster-input-port-id").text(x.portId);
$("#cluster-input-port-summary-last-refreshed").text(x.statsLastRefreshed)
}}).fail(nf.Common.handleAjaxError)
};
var f=function(s){$.ajax({type:"GET",url:p.urls.clusterOutputPort+encodeURIComponent(s)+"/status",data:{verbose:true},dataType:"json"}).done(function(u){if(nf.Common.isDefinedAndNotNull(u.clusterPortStatus)){var t=u.clusterPortStatus;
var v=$("#cluster-output-port-summary-table").data("gridInstance");
var x=v.getData();
var w=[];
$.each(t.nodePortStatus,function(y,z){w.push({id:z.node.nodeId,node:z.node.address+":"+z.node.apiPort,runStatus:z.portStatus.runStatus,activeThreadCount:z.portStatus.activeThreadCount,input:z.portStatus.input})
});
x.setItems(w);
x.reSort();
v.invalidate();
$("#cluster-output-port-name").text(t.portName).ellipsis();
$("#cluster-output-port-id").text(t.portId);
$("#cluster-output-port-summary-last-refreshed").text(t.statsLastRefreshed)
}}).fail(nf.Common.handleAjaxError)
};
var e=function(s){$.ajax({type:"GET",url:p.urls.clusterRemoteProcessGroup+encodeURIComponent(s)+"/status",data:{verbose:true},dataType:"json"}).done(function(u){if(nf.Common.isDefinedAndNotNull(u.clusterRemoteProcessGroupStatus)){var x=u.clusterRemoteProcessGroupStatus;
var v=$("#cluster-remote-process-group-summary-table").data("gridInstance");
var w=v.getData();
var t=[];
$.each(x.nodeRemoteProcessGroupStatus,function(y,z){t.push({id:z.node.nodeId,node:z.node.address+":"+z.node.apiPort,targetUri:z.remoteProcessGroupStatus.targetUri,transmissionStatus:z.remoteProcessGroupStatus.transmissionStatus,sent:z.remoteProcessGroupStatus.sent,received:z.remoteProcessGroupStatus.received,activeThreadCount:z.remoteProcessGroupStatus.activeThreadCount,authorizationIssues:z.remoteProcessGroupStatus.authorizationIssues})
});
w.setItems(t);
w.reSort();
v.invalidate();
$("#cluster-remote-process-group-name").text(x.remoteProcessGroupName).ellipsis();
$("#cluster-remote-process-group-id").text(x.remoteProcessGroupId);
$("#cluster-remote-process-group-summary-last-refreshed").text(x.statsLastRefreshed)
}}).fail(nf.Common.handleAjaxError)
};
return{systemDiagnosticsUrl:null,url:null,init:function(s){nf.SummaryTable.url=p.urls.status;
nf.SummaryTable.systemDiagnosticsUrl=p.urls.systemDiagnostics;
return $.Deferred(function(t){d().done(function(){nf.ProcessorDetails.init(false);
nf.ConnectionDetails.init(false);
i(s);
t.resolve()
}).fail(function(){t.reject()
})
}).promise()
},resetTableSize:function(){var t=$("#processor-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(t)){t.resizeCanvas()
}var s=$("#connection-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){s.resizeCanvas()
}var w=$("#input-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){w.resizeCanvas()
}var v=$("#output-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){v.resizeCanvas()
}var u=$("#remote-process-group-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){u.resizeCanvas()
}},loadProcessorSummaryTable:function(){return $.ajax({type:"GET",url:nf.SummaryTable.url,data:{recursive:true},dataType:"json"}).done(function(s){var C=s.processGroupStatus;
if(nf.Common.isDefinedAndNotNull(C)){var y=$("#processor-summary-table");
nf.Common.cleanUpTooltips(y,"img.has-bulletins");
var x=y.data("gridInstance");
var w=x.getData();
var u=$("#connection-summary-table").data("gridInstance");
var t=u.getData();
var K=$("#input-port-summary-table");
nf.Common.cleanUpTooltips(K,"img.has-bulletins");
var I=K.data("gridInstance");
var H=I.getData();
var L=$("#output-port-summary-table");
nf.Common.cleanUpTooltips(L,"img.has-bulletins");
var A=L.data("gridInstance");
var z=A.getData();
var B=$("#remote-process-group-summary-table");
nf.Common.cleanUpTooltips(B,"img.has-bulletins");
var F=B.data("gridInstance");
var E=F.getData();
var J=[];
var G=[];
var D=[];
var M=[];
var v=[];
m(J,G,D,M,v,C);
w.setItems(J);
w.reSort();
x.invalidate();
t.setItems(G);
t.reSort();
u.invalidate();
H.setItems(D);
H.reSort();
I.invalidate();
z.setItems(M);
z.reSort();
A.invalidate();
E.setItems(v);
E.reSort();
F.invalidate();
$("#summary-last-refreshed").text(C.statsLastRefreshed);
if($("#processor-summary-table").is(":visible")){$("#total-items").text(nf.Common.formatInteger(J.length))
}else{if($("#connection-summary-table").is(":visible")){$("#total-items").text(nf.Common.formatInteger(G.length))
}else{if($("#input-port-summary-table").is(":visible")){$("#total-items").text(nf.Common.formatInteger(D.length))
}else{if($("#output-port-summary-table").is(":visible")){$("#total-items").text(nf.Common.formatInteger(M.length))
}else{$("#total-items").text(nf.Common.formatInteger(v.length))
}}}}}else{$("#total-items").text("0")
}}).fail(nf.Common.handleAjaxError)
},showProcessorDetails:function(v){var s=$("#processor-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.ProcessorDetails.showDetails(t.groupId,t.id)
}},goToProcessor:function(v){var s=$("#processor-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
r(t.groupId,t.id)
}},showClusterProcessorStatusHistory:function(v){var s=$("#processor-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.StatusHistory.showClusterProcessorChart(t.groupId,t.id)
}},showProcessorStatusHistory:function(v){var s=$("#processor-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.StatusHistory.showStandaloneProcessorChart(t.groupId,t.id)
}},showClusterProcessorSummary:function(v){var s=$("#processor-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
h(t.id);
$("#summary-loading-container").hide();
$("#cluster-processor-summary-dialog").modal("show")
}},showConnectionDetails:function(v){var s=$("#connection-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.ConnectionDetails.showDetails(t.groupId,t.id)
}},goToConnection:function(v){var s=$("#connection-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
r(t.groupId,t.id)
}},showClusterConnectionStatusHistory:function(v){var s=$("#connection-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.StatusHistory.showClusterConnectionChart(t.groupId,t.id)
}},showConnectionStatusHistory:function(v){var s=$("#connection-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.StatusHistory.showStandaloneConnectionChart(t.groupId,t.id)
}},showClusterConnectionSummary:function(v){var s=$("#connection-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
b(t.id);
$("#summary-loading-container").hide();
$("#cluster-connection-summary-dialog").modal("show")
}},goToInputPort:function(v){var s=$("#input-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
r(t.groupId,t.id)
}},showClusterInputPortSummary:function(v){var s=$("#input-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
l(t.id);
$("#summary-loading-container").hide();
$("#cluster-input-port-summary-dialog").modal("show")
}},goToOutputPort:function(v){var s=$("#output-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
r(t.groupId,t.id)
}},showClusterOutputPortSummary:function(v){var s=$("#output-port-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
f(t.id);
$("#summary-loading-container").hide();
$("#cluster-output-port-summary-dialog").modal("show")
}},goToRemoteProcessGroup:function(v){var s=$("#remote-process-group-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
r(t.groupId,t.id)
}},showClusterRemoteProcessGroupStatusHistory:function(v){var s=$("#remote-process-group-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.StatusHistory.showClusterRemoteProcessGroupChart(t.groupId,t.id)
}},showRemoteProcessGroupStatusHistory:function(v){var s=$("#remote-process-group-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
nf.StatusHistory.showStandaloneRemoteProcessGroupChart(t.groupId,t.id)
}},showClusterRemoteProcessGroupSummary:function(v){var s=$("#remote-process-group-summary-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(s)){var u=s.getData();
var t=u.getItem(v);
e(t.id);
$("#summary-loading-container").hide();
$("#cluster-remote-process-group-summary-dialog").modal("show")
}}}
}());