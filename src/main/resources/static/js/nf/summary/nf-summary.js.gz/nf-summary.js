$(document).ready(function(){nf.Summary.init()
});
nf.Summary=(function(){var a={urls:{banners:"../nifi-api/controller/banners",controllerAbout:"../nifi-api/controller/about",cluster:"../nifi-api/cluster"}};
var c=function(){return $.Deferred(function(d){$.ajax({type:"HEAD",url:a.urls.cluster}).done(function(){nf.SummaryTable.init(true).done(function(){d.resolve()
}).fail(function(){d.reject()
})
}).fail(function(g,e,f){if(g.status===404){nf.SummaryTable.init(false).done(function(){d.resolve()
}).fail(function(){d.reject()
})
}else{nf.Common.handleAjaxError(g,e,f);
d.reject()
}})
}).promise()
};
var b=function(){nf.Common.addHoverEffect("#refresh-button","button-refresh","button-refresh-hover").click(function(){nf.SummaryTable.loadProcessorSummaryTable()
});
nf.Common.addHoverEffect("#cluster-processor-refresh-button","button-refresh","button-refresh-hover").click(function(){nf.SummaryTable.loadClusterProcessorSummary($("#cluster-processor-id").text())
});
nf.Common.addHoverEffect("#cluster-connection-refresh-button","button-refresh","button-refresh-hover").click(function(){nf.SummaryTable.loadClusterConnectionSummary($("#cluster-connection-id").text())
});
return $.Deferred(function(d){if(top===window){$.ajax({type:"GET",url:a.urls.banners,dataType:"json"}).done(function(i){if(nf.Common.isDefinedAndNotNull(i.banners)){if(nf.Common.isDefinedAndNotNull(i.banners.headerText)&&i.banners.headerText!==""){var f=$("#banner-header").text(i.banners.headerText).show();
var h=function(j){var k=$("#"+j);
k.css("top",(parseInt(f.css("height"),10)+parseInt(k.css("top"),10))+"px")
};
h("summary")
}if(nf.Common.isDefinedAndNotNull(i.banners.footerText)&&i.banners.footerText!==""){var e=$("#banner-footer").text(i.banners.footerText).show();
var g=function(j){var k=$("#"+j);
k.css("bottom",parseInt(e.css("height"),10)+"px")
};
g("summary")
}}d.resolve()
}).fail(function(g,e,f){nf.Common.handleAjaxError(g,e,f);
d.reject()
})
}else{d.resolve()
}}).promise()
};
return{init:function(){c().done(function(){nf.SummaryTable.loadProcessorSummaryTable().done(function(){b().done(function(){nf.SummaryTable.resetTableSize();
$.ajax({type:"GET",url:a.urls.controllerAbout,dataType:"json"}).done(function(f){var e=f.about;
var g=e.title+" Summary";
document.title=g;
$("#status-header-text").text(g)
}).fail(nf.Common.handleAjaxError);
var d=function(){$("body").css({height:$(window).height()+"px",width:$(window).width()+"px"})
};
$(window).resize(d);
d()
})
})
})
}}
}());