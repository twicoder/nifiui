nf.TemplatesTable=(function(){var b={filterText:"Filter",styles:{filterList:"templates-filter-list"},urls:{templates:"../nifi-api/controller/templates"}};
var d=function(g,i){var h=function(l,j){if(g.columnId==="timestamp"){var o=nf.Common.parseDateTime(l[g.columnId]);
var n=nf.Common.parseDateTime(j[g.columnId]);
return o.getTime()-n.getTime()
}else{var k=nf.Common.isDefinedAndNotNull(l[g.columnId])?l[g.columnId]:"";
var m=nf.Common.isDefinedAndNotNull(j[g.columnId])?j[g.columnId]:"";
return k===m?0:k>m?1:-1
}};
i.sort(h,g.sortAsc)
};
var c=function(g){$.ajax({type:"DELETE",url:b.urls.templates+"/"+encodeURIComponent(g),dataType:"json"}).done(function(){var h=$("#templates-table").data("gridInstance");
var i=h.getData();
i.deleteItem(g)
}).fail(nf.Common.handleAjaxError)
};
var f=function(){var h="";
var g=$("#templates-filter");
if(!g.hasClass(b.styles.filterList)){h=g.val()
}return h
};
var a=function(){var g=$("#templates-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(g)){var h=g.getData();
h.setFilterArgs({searchString:f(),property:$("#templates-filter-type").combo("getSelectedOption").value});
h.refresh()
}};
var e=function(h,g){if(g.searchString===""){return true
}try{var j=new RegExp(g.searchString,"i")
}catch(i){return false
}return h[g.property].search(j)>=0
};
return{init:function(){$("#templates-filter").keyup(function(){a()
}).focus(function(){if($(this).hasClass(b.styles.filterList)){$(this).removeClass(b.styles.filterList).val("")
}}).blur(function(){if($(this).val()===""){$(this).addClass(b.styles.filterList).val(b.filterText)
}}).addClass(b.styles.filterList).val(b.filterText);
$("#templates-filter-type").combo({options:[{text:"by name",value:"name"},{text:"by description",value:"description"}],select:function(m){a()
}});
$(window).resize(function(){nf.TemplatesTable.resetTableSize()
});
if(nf.Common.isDFM()){$("#upload-template-container").show()
}var g=function(q,n,p,o,m){return nf.Common.formatValue(p)
};
var k=function(r,n,q,p,m){var o='<img src="images/iconExport.png" title="Download" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.TemplatesTable.exportTemplate(\''+r+"');\"/>";
if(nf.Common.isDFM()){o+='&nbsp;<img src="images/iconDelete.png" title="Remove Template" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.TemplatesTable.promptToDeleteTemplate(\''+r+"');\"/>"
}return o
};
var j=[{id:"timestamp",name:"Date/Time",field:"timestamp",sortable:true,resizable:false,formatter:g,width:225,maxWidth:225},{id:"name",name:"Name",field:"name",sortable:true,resizable:true},{id:"description",name:"Description",field:"description",sortable:true,resizable:true,formatter:g},{id:"actions",name:"&nbsp;",sortable:false,resizable:false,formatter:k,width:100,maxWidth:100}];
var h={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:false,enableColumnReorder:false,autoEdit:false};
var l=new Slick.Data.DataView({inlineFilters:false});
l.setItems([]);
l.setFilterArgs({searchString:f(),property:$("#templates-filter-type").combo("getSelectedOption").value});
l.setFilter(e);
d({columnId:"timestamp",sortAsc:true},l);
var i=new Slick.Grid("#templates-table",l,j,h);
i.setSelectionModel(new Slick.RowSelectionModel());
i.registerPlugin(new Slick.AutoTooltips());
i.setSortColumn("timestamp",true);
i.onSort.subscribe(function(n,m){d({columnId:m.sortCol.field,sortAsc:m.sortAsc},l)
});
l.onRowCountChanged.subscribe(function(n,m){i.updateRowCount();
i.render();
$("#displayed-templates").text(m.current)
});
l.onRowsChanged.subscribe(function(n,m){i.invalidateRows(m.rows);
i.render()
});
$("#templates-table").data("gridInstance",i);
$("#displayed-templates").text("0")
},resetTableSize:function(){var g=$("#templates-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(g)){g.resizeCanvas()
}},exportTemplate:function(j){var g=$("#templates-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(g)){var i=g.getData();
var h=i.getItem(j);
window.open(b.urls.templates+"/"+encodeURIComponent(h.id))
}},promptToDeleteTemplate:function(j){var g=$("#templates-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(g)){var i=g.getData();
var h=i.getItem(j);
nf.Dialog.showYesNoDialog({dialogContent:"Delete template '"+nf.Common.escapeHtml(h.name)+"'?",overlayBackground:false,yesHandler:function(){c(h.id)
}})
}},loadTemplatesTable:function(){return $.ajax({type:"GET",url:b.urls.templates,data:{verbose:false},dataType:"json"}).done(function(g){if(nf.Common.isDefinedAndNotNull(g.templates)){var h=$("#templates-table").data("gridInstance");
var i=h.getData();
i.setItems(g.templates);
i.reSort();
h.invalidate();
$("#templates-last-refreshed").text(g.generated);
$("#total-templates").text(g.templates.length)
}else{$("#total-templates").text("0")
}}).fail(nf.Common.handleAjaxError)
}}
}());