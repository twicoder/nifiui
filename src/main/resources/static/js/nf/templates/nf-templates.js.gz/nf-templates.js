$(document).ready(function(){nf.Templates.init()
});
nf.Templates=(function(){var a={urls:{banners:"../nifi-api/controller/banners",controllerAbout:"../nifi-api/controller/about",authorities:"../nifi-api/controller/authorities"}};
var c=function(){return $.Deferred(function(d){$.ajax({type:"GET",url:a.urls.authorities,dataType:"json"}).done(function(e){if(nf.Common.isDefinedAndNotNull(e.authorities)){nf.Common.setAuthorities(e.authorities);
d.resolve()
}else{d.reject()
}}).fail(function(g,e,f){nf.Common.handleAjaxError(g,e,f);
d.reject()
})
}).promise()
};
var b=function(){var e="Select template to import";
nf.Common.addHoverEffect("#refresh-button","button-refresh","button-refresh-hover").click(function(){nf.TemplatesTable.loadTemplatesTable()
});
$("#upload-template-status").text(e);
nf.Common.addHoverEffect("#select-template-button","button-normal","button-over");
$("#template-file-field").on("change",function(h){var g=$(this).val();
if(!nf.Common.isBlank(g)){g=g.replace(/^.*[\\\/]/,"")
}$("#selected-template-name").text(g);
$("#select-template-container").hide();
$("#submit-template-container").show()
});
var f=function(g){$("#upload-template-status").removeClass("import-status").addClass("import-status-error").text(g);
$("#cancel-upload-template-button").click()
};
var d=$("#template-upload-form").ajaxForm({dataType:"xml",success:function(h,k,l,j){if(h.documentElement.tagName==="templateEntity"){$("#upload-template-status").removeClass("import-status-error").addClass("import-status").text(e);
$("#cancel-upload-template-button").click();
nf.TemplatesTable.loadTemplatesTable()
}else{var g="Unable to import template. Please check the log for errors.";
if(h.documentElement.tagName==="errorResponse"){var i=h.documentElement.getAttribute("statusText");
if(!nf.Common.isBlank(i)){g=i
}}f(g)
}},error:function(i,h,g){f(g)
}});
nf.Common.addHoverEffect("#upload-template-button","button-normal","button-over").click(function(){d.submit()
});
nf.Common.addHoverEffect("#cancel-upload-template-button","button-normal","button-over").click(function(){$("#selected-template-name").text("");
d.resetForm();
$("#select-template-container").show();
$("#submit-template-container").hide()
});
return $.Deferred(function(g){if(top===window){$.ajax({type:"GET",url:a.urls.banners,dataType:"json"}).done(function(l){if(nf.Common.isDefinedAndNotNull(l.banners)){if(nf.Common.isDefinedAndNotNull(l.banners.headerText)&&l.banners.headerText!==""){var i=$("#banner-header").text(l.banners.headerText).show();
var k=function(m){var n=$("#"+m);
n.css("top",(parseInt(i.css("height"),10)+parseInt(n.css("top"),10))+"px")
};
k("templates")
}if(nf.Common.isDefinedAndNotNull(l.banners.footerText)&&l.banners.footerText!==""){var h=$("#banner-footer").text(l.banners.footerText).show();
var j=function(m){var n=$("#"+m);
n.css("bottom",parseInt(h.css("height"),10)+"px")
};
j("templates")
}}g.resolve()
}).fail(function(j,h,i){nf.Common.handleAjaxError(j,h,i);
g.reject()
})
}else{g.resolve()
}}).promise()
};
return{init:function(){c().done(function(){nf.TemplatesTable.init();
nf.TemplatesTable.loadTemplatesTable().done(function(){b().done(function(){nf.TemplatesTable.resetTableSize();
$.ajax({type:"GET",url:a.urls.controllerAbout,dataType:"json"}).done(function(e){var d=e.about;
var f=d.title+" Templates";
document.title=f;
$("#templates-header-text").text(f)
}).fail(nf.Common.handleAjaxError)
})
})
})
}}
}());