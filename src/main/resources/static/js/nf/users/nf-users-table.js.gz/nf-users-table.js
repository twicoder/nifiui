nf.UsersTable=(function(){var c={filterText:"Filter",styles:{filterList:"users-filter-list"},urls:{users:"../nifi-api/controller/users",userGroups:"../nifi-api/controller/user-groups"}};
var i=function(){$("#user-details-dialog").modal({headerText:"User Details",overlayBackground:false,buttons:[{buttonText:"Ok",handler:{click:function(){$("#user-details-dialog").modal("hide")
}}}],handler:{close:function(){$("#user-name-details-dialog").text("");
$("#user-dn-details-dialog").text("");
$("#user-created-details-dialog").text("");
$("#user-verified-details-dialog").text("");
$("#user-justification-details-dialog").text("")
}}})
};
var l=function(){$("#user-roles-dialog").modal({headerText:"User Roles",overlayBackground:false,buttons:[{buttonText:"Apply",handler:{click:function(){var p=$("#user-id-roles-dialog").val();
var q=[];
var s=function(t){return $("#"+t).hasClass("checkbox-checked")
};
if(s("role-admin-checkbox")){q.push("ROLE_ADMIN")
}if(s("role-dfm-checkbox")){q.push("ROLE_DFM")
}if(s("role-provenance-checkbox")){q.push("ROLE_PROVENANCE")
}if(s("role-monitor-checkbox")){q.push("ROLE_MONITOR")
}if(s("role-nifi-checkbox")){q.push("ROLE_NIFI")
}if(s("role-proxy-checkbox")){q.push("ROLE_PROXY")
}var r={};
r.id=p;
r.authorities=q;
r.status="ACTIVE";
var o={};
o.user=r;
$.ajax({type:"PUT",url:c.urls.users+"/"+encodeURIComponent(p),data:JSON.stringify(o),contentType:"application/json",dataType:"json"}).done(function(u){if(nf.Common.isDefinedAndNotNull(u.user)){var t=u.user;
var v=$("#users-table").data("gridInstance");
var w=v.getData();
w.updateItem(t.id,t)
}}).fail(nf.Common.handleAjaxError);
$("#user-roles-dialog").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#user-roles-dialog").modal("hide")
}}}],handler:{close:function(){$("div.role-checkbox").removeClass("checkbox-checked").addClass("checkbox-unchecked");
$("#user-id-roles-dialog").val("")
}}})
};
var m=function(){$("#group-roles-dialog").modal({headerText:"Group Roles",overlayBackground:false,buttons:[{buttonText:"Apply",handler:{click:function(){var q=$("#group-name-roles-dialog").text();
var r=[];
var s=function(t){return $("#"+t).hasClass("checkbox-checked")
};
if(s("group-role-admin-checkbox")){r.push("ROLE_ADMIN")
}if(s("group-role-dfm-checkbox")){r.push("ROLE_DFM")
}if(s("group-role-provenance-checkbox")){r.push("ROLE_PROVENANCE")
}if(s("group-role-monitor-checkbox")){r.push("ROLE_MONITOR")
}if(s("group-role-nifi-checkbox")){r.push("ROLE_NIFI")
}if(s("group-role-proxy-checkbox")){r.push("ROLE_PROXY")
}var p={};
p.group=q;
p.authorities=r;
p.status="ACTIVE";
var o={};
o.userGroup=p;
$.ajax({type:"PUT",url:c.urls.userGroups+"/"+encodeURIComponent(q),data:JSON.stringify(o),contentType:"application/json",dataType:"json"}).done(function(){nf.UsersTable.loadUsersTable()
}).fail(nf.Common.handleAjaxError);
$("#group-roles-dialog").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#group-roles-dialog").modal("hide")
}}}],handler:{close:function(){$("div.role-checkbox").removeClass("checkbox-checked").addClass("checkbox-unchecked");
$("#group-name-roles-dialog").text("")
}}})
};
var b=function(){$("#user-delete-dialog").modal({headerText:"Delete User",overlayBackground:false,buttons:[{buttonText:"Delete",handler:{click:function(){var o=$("#user-id-delete-dialog").val();
$.ajax({type:"DELETE",url:c.urls.users+"/"+encodeURIComponent(o),dataType:"json"}).done(function(){nf.UsersTable.loadUsersTable()
}).fail(nf.Common.handleAjaxError);
$("#user-delete-dialog").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#user-delete-dialog").modal("hide")
}}}],handler:{close:function(){$("#user-id-delete-dialog").val("");
$("#user-name-delete-dialog").text("")
}}})
};
var h=function(){$("#user-revoke-dialog").modal({headerText:"Revoke Access",overlayBackground:false,buttons:[{buttonText:"Revoke",handler:{click:function(){var o=$("#user-id-revoke-dialog").val();
$.ajax({type:"PUT",url:c.urls.users+"/"+encodeURIComponent(o),data:{status:"DISABLED"},dataType:"json"}).done(function(q){if(nf.Common.isDefinedAndNotNull(q.user)){var p=q.user;
var r=$("#users-table").data("gridInstance");
var s=r.getData();
s.updateItem(p.id,p)
}}).fail(nf.Common.handleAjaxError);
$("#user-revoke-dialog").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#user-revoke-dialog").modal("hide")
}}}],handler:{close:function(){$("#user-id-revoke-dialog").val("");
$("#user-name-revoke-dialog").text("")
}}})
};
var n=function(){$("#group-revoke-dialog").modal({headerText:"Revoke Access",overlayBackground:false,buttons:[{buttonText:"Revoke",handler:{click:function(){var o=$("#group-name-revoke-dialog").text();
$.ajax({type:"PUT",url:c.urls.userGroups+"/"+encodeURIComponent(o),data:{status:"DISABLED"},dataType:"json"}).done(function(){nf.UsersTable.loadUsersTable()
}).fail(nf.Common.handleAjaxError);
$("#group-revoke-dialog").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#group-revoke-dialog").modal("hide")
}}}],handler:{close:function(){$("#group-name-revoke-dialog").text("")
}}})
};
var k=function(){$("#user-group-dialog").modal({headerText:"Set Users Group",overlayBackground:false,buttons:[{buttonText:"Group",handler:{click:function(){var q=$.trim($("#group-name").val());
if(q===""){nf.Dialog.showOkDialog({headerText:"Group Users",dialogContent:"Group name cannot be blank.",overlayBackground:false})
}else{var r=$("#group-name").data("selected-user-ids");
var p={};
p.userIds=r;
p.group=q;
var o={};
o.userGroup=p;
$.ajax({type:"PUT",url:c.urls.userGroups+"/"+encodeURIComponent(q),data:JSON.stringify(o),contentType:"application/json",dataType:"json"}).done(function(){nf.UsersTable.loadUsersTable()
}).fail(nf.Common.handleAjaxError)
}$("#user-group-dialog").modal("hide")
}}},{buttonText:"Cancel",handler:{click:function(){$("#user-group-dialog").modal("hide")
}}}],handler:{close:function(){$("#group-name").removeData("selected-user-ids");
$("#group-name").val("");
$("div.group-role-checkbox").removeClass("checkbox-checked").addClass("checkbox-unchecked")
}}})
};
var d=function(){$("#users-filter").keyup(function(){g()
}).focus(function(){if($(this).hasClass(c.styles.filterList)){$(this).removeClass(c.styles.filterList).val("")
}}).blur(function(){if($(this).val()===""){$(this).addClass(c.styles.filterList).val(c.filterText)
}}).addClass(c.styles.filterList).val(c.filterText);
$("#users-filter-type").combo({options:[{text:"by user",value:"userName"},{text:"by group",value:"userGroup"},{text:"by role",value:"authorities"}],select:function(x){g()
}});
nf.Common.addHoverEffect("#group-button","button-normal","button-over").click(function(){e()
});
$(window).resize(function(){nf.UsersTable.resetTableSize()
});
var w=function(B,y,A,z,x){return'<img src="images/iconDetails.png" title="View Details" class="pointer" style="margin-top: 4px;" onclick="javascript:nf.UsersTable.showUserDetails(\''+B+"');\"/>"
};
var v=function(B,y,A,z,x){return nf.Common.formatValue(A)
};
var p=function(C,y,B,z,x){var A=$("#group-collaspe-checkbox").hasClass("checkbox-checked");
var D=function(){var E=[];
$.each(B,function(G,H){var F=H;
if(H==="ROLE_ADMIN"){F="Administrator"
}else{if(H==="ROLE_DFM"){F="Data Flow Manager"
}else{if(H==="ROLE_PROVENANCE"){F="Provenance"
}else{if(H==="ROLE_MONITOR"){F="Read Only"
}else{if(H==="ROLE_NIFI"){F="NiFi"
}else{if(H==="ROLE_PROXY"){F="Proxy"
}}}}}}E.push(F)
});
return E.join(", ")
};
if(A&&nf.Common.isDefinedAndNotNull(x.userGroup)){if(x.status==="PENDING"){return'<span style="color: #0081D7; font-weight: bold;">Authorization Pending</span>'
}else{if(x.status==="DISABLED"){return'<span style="color: red; font-weight: bold;">Access Revoked</span>'
}else{if(nf.Common.isDefinedAndNotNull(B)){if(!nf.Common.isEmpty(B)){return D()
}else{return'<span class="unset">No roles set</span>'
}}else{return'<span class="unset">Multiple users with different roles</span>'
}}}}else{if(x.status==="PENDING"){return'<span style="color: #0081D7; font-weight: bold;">Authorization Pending</span>'
}else{if(x.status==="DISABLED"){return'<span style="color: red; font-weight: bold;">Access Revoked</span>'
}else{if(!nf.Common.isEmpty(B)){return D()
}else{return'<span class="unset">No roles set</span>'
}}}}};
var o=function(C,y,B,z,x){var A=$("#group-collaspe-checkbox").hasClass("checkbox-checked");
if(nf.Common.isDefinedAndNotNull(B)){return B
}else{if(A&&nf.Common.isDefinedAndNotNull(x.userGroup)){return'<span class="unset">Multiple users with different status</span>'
}else{return'<span class="unset">No status set</span>'
}}};
var t=function(D,y,B,z,x){var A=$("#group-collaspe-checkbox").hasClass("checkbox-checked");
if(nf.Common.isDefinedAndNotNull(x.userGroup)&&A){var C='<img src="images/iconEdit.png" title="Edit Access" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.UsersTable.updateGroupAccess(\''+D+'\');"/>&nbsp;<img src="images/iconRevoke.png" title="Revoke Access" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.UsersTable.revokeGroupAccess(\''+D+'\');"/>&nbsp;&nbsp;<img src="images/ungroup.png" title="Ungroup" class="pointer" onclick="javascript:nf.UsersTable.ungroup(\''+D+"');\"/>"
}else{var C='<img src="images/iconEdit.png" title="Edit Access" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.UsersTable.updateUserAccess(\''+D+"');\"/>";
if(x.status==="ACTIVE"){C+='&nbsp;<img src="images/iconRevoke.png" title="Revoke Access" class="pointer" onclick="javascript:nf.UsersTable.revokeUserAccess(\''+D+"');\"/>";
if(nf.Common.isDefinedAndNotNull(x.userGroup)){C+='&nbsp;&nbsp;<img src="images/ungroup.png" title="Ungroup" class="pointer" style="margin-top: 2px;" onclick="javascript:nf.UsersTable.ungroupUser(\''+D+"');\"/>"
}}else{C+='&nbsp;<img src="images/iconDelete.png" title="Delete Account" class="pointer" onclick="javascript:nf.UsersTable.deleteUserAccount(\''+D+"');\"/>"
}}return C
};
var u=[{id:"moreDetails",name:"&nbsp;",sortable:false,resizable:false,formatter:w,width:50,maxWidth:50},{id:"userName",name:"User",field:"userName",sortable:true,resizable:true},{id:"userGroup",name:"Group",field:"userGroup",sortable:true,resizable:true,formatter:v},{id:"authorities",name:"Roles",field:"authorities",sortable:true,resizable:true,formatter:p},{id:"lastAccessed",name:"Last Accessed",field:"lastAccessed",sortable:true,resizable:true,formatter:v},{id:"status",name:"Status",field:"status",sortable:true,resizable:false,formatter:o},{id:"actions",name:"&nbsp;",sortable:false,resizable:false,formatter:t,width:100,maxWidth:100}];
var r={forceFitColumns:true,enableTextSelectionOnCells:true,enableCellNavigation:true,enableColumnReorder:false,autoEdit:false};
var s=new Slick.Data.DataView({inlineFilters:false});
s.setItems([]);
s.setFilterArgs({searchString:j(),property:$("#users-filter-type").combo("getSelectedOption").value});
s.setFilter(a);
f({columnId:"userName",sortAsc:true},s);
var q=new Slick.Grid("#users-table",s,u,r);
q.setSelectionModel(new Slick.RowSelectionModel());
q.registerPlugin(new Slick.AutoTooltips());
q.setSortColumn("userName",true);
q.onSort.subscribe(function(y,x){f({columnId:x.sortCol.field,sortAsc:x.sortAsc},s)
});
s.onRowCountChanged.subscribe(function(y,x){q.updateRowCount();
q.render();
$("#displayed-users").text(x.current)
});
s.onRowsChanged.subscribe(function(y,x){q.invalidateRows(x.rows);
q.render()
});
$("#users-table").data("gridInstance",q);
$("#displayed-users").text("0")
};
var f=function(o,q){var p=function(t,r){if(o.columnId==="lastAccessed"){var w=nf.Common.parseDateTime(t[o.columnId]);
var v=nf.Common.parseDateTime(r[o.columnId]);
return w.getTime()-v.getTime()
}else{var s=nf.Common.isDefinedAndNotNull(t[o.columnId])?t[o.columnId]:"";
var u=nf.Common.isDefinedAndNotNull(r[o.columnId])?r[o.columnId]:"";
return s===u?0:s>u?1:-1
}};
q.sort(p,o.sortAsc)
};
var e=function(){var p=$("#users-table").data("gridInstance");
var o=p.getSelectedRows();
if($.isArray(o)&&o.length>0){var r=p.getData();
var s=[];
$.each(o,function(v,u){var t=r.getItem(u);
s=s.concat(t.id.split(","))
});
var q=$("#group-name");
q.data("selected-user-ids",s);
$("#user-group-dialog").modal("show");
q.focus()
}else{nf.Dialog.showOkDialog({headerText:"Group Users",dialogContent:"Select one or more users to group.",overlayBackground:false})
}};
var j=function(){var p="";
var o=$("#users-filter");
if(!o.hasClass(c.styles.filterList)){p=o.val()
}return p
};
var g=function(){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){var p=o.getData();
p.setFilterArgs({searchString:j(),property:$("#users-filter-type").combo("getSelectedOption").value});
p.refresh()
}};
var a=function(v,u){if(u.searchString===""){return true
}try{var o=new RegExp(u.searchString,"i")
}catch(t){return false
}if(u.property==="authorities"){var s=v[u.property];
var w=false;
for(var r=0;
r<s.length;
r++){var q=s[r];
var p=q;
if(q==="ROLE_ADMIN"){p="Administrator"
}else{if(q==="ROLE_DFM"){p="Data Flow Manager"
}else{if(q==="ROLE_PROVENANCE"){p="Provenance"
}else{if(q==="ROLE_MONITOR"){p="Read Only"
}else{if(q==="ROLE_NIFI"){p="NiFi"
}else{if(q==="ROLE_PROXY"){p="Proxy"
}}}}}}if(p.search(o)>=0){w=true;
break
}}return w
}else{return v[u.property].search(o)>=0
}};
return{init:function(){i();
l();
m();
h();
b();
k();
n();
d()
},revokeUserAccess:function(r){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){var q=o.getData();
var p=q.getItem(r);
$("#user-id-revoke-dialog").val(p.id);
$("#user-name-revoke-dialog").text(p.userName);
$("#user-revoke-dialog").modal("show")
}},deleteUserAccount:function(r){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){var q=o.getData();
var p=q.getItem(r);
$("#user-id-delete-dialog").val(p.id);
$("#user-name-delete-dialog").text(p.userName);
$("#user-delete-dialog").modal("show")
}},revokeGroupAccess:function(r){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){var q=o.getData();
var p=q.getItem(r);
$("#group-name-revoke-dialog").text(p.userGroup);
$("#group-revoke-dialog").modal("show")
}},updateUserAccess:function(s){var p=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(p)){var r=p.getData();
var q=r.getItem(s);
$("#user-id-roles-dialog").val(q.id);
$("#user-name-roles-dialog").attr("title",q.dn).text(q.userName);
$("#user-justification-roles-dialog").html(nf.Common.formatValue(q.justification));
var o=function(t){$("#"+t).removeClass("checkbox-unchecked").addClass("checkbox-checked")
};
$.each(q.authorities,function(t,u){if(u==="ROLE_ADMIN"){o("role-admin-checkbox")
}else{if(u==="ROLE_DFM"){o("role-dfm-checkbox")
}else{if(u==="ROLE_PROVENANCE"){o("role-provenance-checkbox")
}else{if(u==="ROLE_MONITOR"){o("role-monitor-checkbox")
}else{if(u==="ROLE_NIFI"){o("role-nifi-checkbox")
}else{if(u==="ROLE_PROXY"){o("role-proxy-checkbox")
}}}}}}});
$("#user-roles-dialog").modal("show")
}},updateGroupAccess:function(r){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){var q=o.getData();
var p=q.getItem(r);
$("#group-name-roles-dialog").text(p.userGroup);
$("#group-roles-dialog").modal("show")
}},ungroupUser:function(r){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){var q=o.getData();
var p=q.getItem(r);
nf.Dialog.showYesNoDialog({dialogContent:"Remove user '"+nf.Common.escapeHtml(p.userName)+"' from group '"+nf.Common.escapeHtml(p.userGroup)+"'?",overlayBackground:false,yesHandler:function(){$.ajax({type:"DELETE",url:c.urls.userGroups+"/"+encodeURIComponent(p.userGroup)+"/users/"+encodeURIComponent(p.id),dataType:"json"}).done(function(s){nf.UsersTable.loadUsersTable()
}).fail(nf.Common.handleAjaxError)
}})
}},ungroup:function(r){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){var q=o.getData();
var p=q.getItem(r);
nf.Dialog.showYesNoDialog({dialogContent:"Remove all users from group '"+nf.Common.escapeHtml(p.userGroup)+"'?",overlayBackground:false,yesHandler:function(){$.ajax({type:"DELETE",url:c.urls.userGroups+"/"+encodeURIComponent(p.userGroup),dataType:"json"}).done(function(s){nf.UsersTable.loadUsersTable()
}).fail(nf.Common.handleAjaxError)
}})
}},resetTableSize:function(){var o=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(o)){o.resizeCanvas()
}},loadUsersTable:function(){return $.ajax({type:"GET",url:c.urls.users,data:{grouped:$("#group-collaspe-checkbox").hasClass("checkbox-checked")},dataType:"json"}).done(function(o){if(nf.Common.isDefinedAndNotNull(o.users)){var p=$("#users-table").data("gridInstance");
var q=p.getData();
q.setItems(o.users);
q.reSort();
p.invalidate();
p.getSelectionModel().setSelectedRows([]);
$("#users-last-refreshed").text(o.generated);
$("#total-users").text(o.users.length)
}else{$("#total-users").text("0")
}}).fail(nf.Common.handleAjaxError)
},showUserDetails:function(s){var q=$("#users-table").data("gridInstance");
if(nf.Common.isDefinedAndNotNull(q)){var r=q.getData();
var o=r.getItem(s);
var p=$("#group-collaspe-checkbox").hasClass("checkbox-checked");
$("#user-name-details-dialog").text(o.userName);
$("#user-dn-details-dialog").text(o.dn);
if(nf.Common.isDefinedAndNotNull(o.creation)){$("#user-created-details-dialog").text(o.creation)
}else{if(p&&nf.Common.isDefinedAndNotNull(o.userGroup)){$("#user-created-details-dialog").html('<span class="unset">Multiple users with different creation timestamps.</span>')
}else{$("#user-created-details-dialog").html('<span class="unset">No creation timestamp set</span>')
}}if(nf.Common.isDefinedAndNotNull(o.lastVerified)){$("#user-verified-details-dialog").text(o.lastVerified)
}else{if(p&&nf.Common.isDefinedAndNotNull(o.userGroup)){$("#user-verified-details-dialog").html('<span class="unset">Multiple users with different last verified timestamps.</span>')
}else{$("#user-verified-details-dialog").html('<span class="unset">No last verified timestamp set.</span>')
}}if(nf.Common.isDefinedAndNotNull(o.justification)){$("#user-justification-details-dialog").text(o.justification)
}else{if(p&&nf.Common.isDefinedAndNotNull(o.userGroup)){$("#user-justification-details-dialog").html('<span class="unset">Multiple users with different justifications.</span>')
}else{$("#user-justification-details-dialog").html('<span class="unset">No justification set.</span>')
}}$("#user-details-dialog").modal("show")
}}}
}());